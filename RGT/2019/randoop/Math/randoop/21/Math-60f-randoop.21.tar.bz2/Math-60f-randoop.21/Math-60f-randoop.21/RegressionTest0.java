import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.017453292519943295d), (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextUniform((double) '#', 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (10): lower bound (35) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextBeta((double) (-1), (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.768");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.718281828459045d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08474286656927434d + "'", double2 == 0.08474286656927434d);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        try {
//            double double7 = randomDataImpl1.nextUniform((double) 10L, 1.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (1): lower bound (10) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.021395526666037d + "'", double4 == 10.021395526666037d);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution1 = null;
        try {
            int int2 = randomDataImpl0.nextInversionDeviate(integerDistribution1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0.0f, (double) 1.0f, (double) (short) 100, 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6098494453571889d + "'", double1 == 0.6098494453571889d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (0): permutation size (1) exceeds permuation domain (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        try {
            double double5 = randomDataImpl1.nextF((double) 1.0f, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.apache.commons.math.util.FastMath.max(100L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl1.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0E-9d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextLong((long) '4', 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (10): lower bound (52) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        try {
//            long long10 = randomDataImpl1.nextLong((long) 100, (long) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.11833920548759d + "'", double4 == 10.11833920548759d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.61127530121384d + "'", double7 == 0.61127530121384d);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6100272411255648d, (double) (short) -1, (double) 10L, (int) (short) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.6483608274590866d, 0.6100272411255648d, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.6649055706799991d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.6649055706799991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.930874936879059d + "'", double1 == 0.930874936879059d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double10 = randomDataImpl1.nextGaussian((double) ' ', 2.302585092994046d);
//        try {
//            long long13 = randomDataImpl1.nextLong((long) ' ', (long) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (32): lower bound (32) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.061253252369815d + "'", double4 == 10.061253252369815d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6147681636142146d + "'", double7 == 0.6147681636142146d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 30.078027582050115d + "'", double10 == 30.078027582050115d);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 56L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8258623655447783d + "'", double1 == 3.8258623655447783d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6133776958784604d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5756327086974166d + "'", double1 == 0.5756327086974166d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1712659507785417d + "'", double1 == 1.1712659507785417d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 56L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.018017530612444158d + "'", double1 == 0.018017530612444158d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) ' ');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(9.927711597057533d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.829280371880436E-4d + "'", double2 == 5.829280371880436E-4d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 7L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 7L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.579251212010101d + "'", double1 == 6.579251212010101d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        try {
//            int int6 = randomDataImpl0.nextZipf((int) (short) 0, (double) 10.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.7621553244661734d + "'", double3 == 2.7621553244661734d);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.max(10.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4342998565809584d + "'", double1 == 0.4342998565809584d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(13.019699760953051d, 1.6649055706799991d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.495785744349465E-8d + "'", double2 == 2.495785744349465E-8d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 44L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.0d + "'", double1 == 44.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5456928232039928d + "'", double1 == 0.5456928232039928d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        try {
//            int int6 = randomDataImpl0.nextZipf((int) (byte) -1, 0.6133776958784604d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9035334332626216d + "'", double3 == 0.9035334332626216d);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 56L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7481880270062005d + "'", double1 == 1.7481880270062005d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double10 = randomDataImpl1.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl1.reSeedSecure((long) 1);
//        try {
//            double double15 = randomDataImpl1.nextCauchy(0.6483608274590866d, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.957230473512693d + "'", double4 == 9.957230473512693d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6076781198040921d + "'", double7 == 0.6076781198040921d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.20565240930579d + "'", double10 == 32.20565240930579d);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double7 = randomDataImpl1.nextT(Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument -1 p = 0.041");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.961456020602748d + "'", double4 == 9.961456020602748d);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        try {
//            int int8 = randomDataImpl0.nextPascal((int) (byte) 0, (double) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.String str19 = outOfRangeException3.toString();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 0 out of [-1, 2.718] range" + "'", str19.equals("org.apache.commons.math.exception.OutOfRangeException: 0 out of [-1, 2.718] range"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.6098494453571889d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5403322559833335d + "'", double1 == 3.5403322559833335d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        normalDistributionImpl3.reseedRandomGenerator((long) '#');
        try {
            double double8 = normalDistributionImpl3.cumulativeProbability((double) '#', 2.302585092994046d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.39618046876130475d + "'", double0 == 0.39618046876130475d);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double double7 = normalDistributionImpl3.cumulativeProbability((double) (short) 100, (double) 100L);
        double double9 = normalDistributionImpl3.density((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.6898464671044491E-4d + "'", double9 == 1.6898464671044491E-4d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10.0f, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = org.apache.commons.math.util.FastMath.abs(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.829280371880436E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0842021724855044E-19d + "'", double1 == 1.0842021724855044E-19d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(9.927711597057533d, (double) (byte) -1, (double) '#', 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) -1, (double) '4');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.expm1(9.927711597057533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20489.396604684087d + "'", double1 == 20489.396604684087d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        double double8 = randomDataImpl0.nextGaussian(100.0d, (double) '#');
//        try {
//            double double10 = randomDataImpl0.nextExponential((-4.9E-324d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0 is smaller than, or equal to, the minimum (0): mean (-0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 61L + "'", long2 == 61L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 175.9962982574348d + "'", double8 == 175.9962982574348d);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.7615941559557649d, number1, (java.lang.Number) 10.172028608154612d);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl1.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.077090442629046d + "'", double4 == 10.077090442629046d);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.6180815137742874d, 33.55452857985193d, 8.520185096803155d, (int) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999999999999996d + "'", double4 == 0.9999999999999996d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.acos(6.579251212010101d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson((double) '4');
        randomDataImpl0.reSeed((long) (-1));
        double double7 = randomDataImpl0.nextCauchy(0.018017530612444158d, (double) 56L);
        try {
            double double9 = randomDataImpl0.nextChiSquare((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.5 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 55L + "'", long2 == 55L);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.68420393244495d) + "'", double7 == (-49.68420393244495d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        try {
            double[] doubleArray5 = normalDistributionImpl3.sample((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.018017530612444158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01801558118013052d + "'", double1 == 0.01801558118013052d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10.124725369816879d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12476.200989019924d + "'", double1 == 12476.200989019924d);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        randomDataImpl0.reSeed((long) (-1));
//        double double7 = randomDataImpl0.nextCauchy(0.018017530612444158d, (double) 56L);
//        try {
//            double double9 = randomDataImpl0.nextChiSquare((-1.0769824743038552d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.538 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.68420393244495d) + "'", double7 == (-49.68420393244495d));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 100);
        try {
            double double8 = normalDistributionImpl3.cumulativeProbability((double) (short) 1, 0.4342998565809584d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        long long1 = org.apache.commons.math.util.FastMath.round(88.53074452756374d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 89L + "'", long1 == 89L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.6649055706799991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2903121989193154d + "'", double1 == 1.2903121989193154d);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double8 = randomDataImpl1.nextBeta(2.302585092994046d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.449");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.99932549013614d + "'", double4 == 9.99932549013614d);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        long long12 = randomDataImpl1.nextPoisson(10.124725369816879d);
//        try {
//            int int15 = randomDataImpl1.nextPascal(5, (-4.9E-324d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.998716748465572d + "'", double4 == 9.998716748465572d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6108010107838411d + "'", double7 == 0.6108010107838411d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 15L + "'", long12 == 15L);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.2903121989193154d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        try {
//            double double8 = randomDataImpl0.nextBeta((double) 'a', 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.751");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.atan(9.927711597057533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4704067880903589d + "'", double1 == 1.4704067880903589d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.cos(6.579251212010101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9564916978322142d + "'", double1 == 0.9564916978322142d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) Double.POSITIVE_INFINITY, false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable19, objArray23);
        java.lang.Number number26 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) -1 + "'", number26.equals((byte) -1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.040187691180085916d + "'", double1 == 0.040187691180085916d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 100, 1.1712659507785417d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 220.05533476569371d + "'", double2 == 220.05533476569371d);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        long long12 = randomDataImpl1.nextPoisson(10.124725369816879d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl1.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.066031162221785d + "'", double4 == 10.066031162221785d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6144751546609573d + "'", double7 == 0.6144751546609573d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8L + "'", long12 == 8L);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable21, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "", objArray25);
        int int29 = maxIterationsExceededException28.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.acos((-49.68420393244495d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException10, localizable17, objArray24);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable17, objArray29);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable17, objArray32);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0L, (java.lang.Number) 0.3796077390275217d, false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray29);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        try {
//            int[] intArray5 = randomDataImpl0.nextPermutation(5, 6);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6 is larger than the maximum (5): permutation size (6) exceeds permuation domain (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49L + "'", long2 == 49L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(5, "org.apache.commons.math.MaxIterationsExceededException: ", objArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(9.237835778729162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.117017115913347d + "'", double1 == 11.117017115913347d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.special.Erf.erf(9.976078852368191d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 44L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.477207657226922d + "'", double1 == 4.477207657226922d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6100272411255648d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 8.520185096803155d, (java.lang.Number) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        java.lang.String str2 = convergenceException0.toString();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.ConvergenceException: convergence failed" + "'", str2.equals("org.apache.commons.math.ConvergenceException: convergence failed"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
        double double4 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9999999999999996d, 14.043231579372502d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.043231579372502d + "'", double2 == 14.043231579372502d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 100);
        double[] doubleArray7 = normalDistributionImpl3.sample((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNull(localizable47);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.cumulativeProbability((double) 50L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 0, (double) ' ', 2.302585092994046d);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-16.211269295877596d) + "'", double4 == (-16.211269295877596d));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray4);
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        long long7 = randomDataImpl0.nextPoisson(1.1712659507785417d);
//        try {
//            long long10 = randomDataImpl0.nextLong((long) 1, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        long long7 = randomDataImpl0.nextPoisson(1.1712659507785417d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56L + "'", long2 == 56L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = maxIterationsExceededException25.getSpecificPattern();
        java.lang.String str27 = maxIterationsExceededException25.getPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9564916978322142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray6);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable9, objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((-1), "org.apache.commons.math.ConvergenceException: convergence failed", objArray10);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long3 = randomDataImpl1.nextPoisson((double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = maxIterationsExceededException25.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = maxIterationsExceededException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 0.08474286656927434d, (java.lang.Number) 0.603632357402044d, true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertNotNull(localizable27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.floor(10.129293685722505d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator(89L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.482146690578855d + "'", double4 == 12.482146690578855d);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.248291097914389d, 4.9E-324d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.930874936879059d, Double.POSITIVE_INFINITY, 0.6483608274590866d);
        double double5 = normalDistributionImpl3.cumulativeProbability(88.53074452756374d);
        double double7 = normalDistributionImpl3.cumulativeProbability(3.8258623655447783d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, (float) 44L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 58L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11918013544881928d + "'", double1 == 0.11918013544881928d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(220.05533476569371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 965.118899979778d + "'", double1 == 965.118899979778d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(12476.200989019924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12476.200989019926d + "'", double1 == 12476.200989019926d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5456928232039928d, 644.1650679589596d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5456928232039929d + "'", double2 == 0.5456928232039929d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.577215664901533d + "'", double1 == 0.577215664901533d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 89L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.499809670330265d + "'", double1 == 4.499809670330265d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.199329338564076E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.494941051394773d) + "'", double1 == (-6.494941051394773d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.asin(9.74008235741185d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextCauchy((double) 10, (double) 5);
//        try {
//            long long9 = randomDataImpl0.nextLong((long) 2, (long) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2 is larger than, or equal to, the maximum (-1): lower bound (2) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8500855918006631d + "'", double3 == 0.8500855918006631d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.346271808237857d + "'", double6 == 3.346271808237857d);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.rint(12476.200989019924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12476.0d + "'", double1 == 12476.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.248797278892095d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2487972788920954d + "'", double1 == 2.2487972788920954d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 9.927711597057533d, (java.lang.Number) 28.158022179325044d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 9.927711597057533d, (java.lang.Number) 28.158022179325044d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 28.158022179325044d + "'", number4.equals(28.158022179325044d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeed(44L);
        randomDataImpl1.reSeed();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36221568869946325d + "'", double1 == 0.36221568869946325d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.7481880270062005d, 9.927711597057533d, 10.129293685722505d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 9.928 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6133776958784604d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8496550830689211d + "'", double1 == 0.8496550830689211d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double10 = randomDataImpl1.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl1.reSeedSecure((long) 1);
//        double double15 = randomDataImpl1.nextBeta(1.6898464671044491E-4d, (double) ' ');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.911171240117117d + "'", double4 == 9.911171240117117d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6145031101040538d + "'", double7 == 0.6145031101040538d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.575119789088564d + "'", double10 == 31.575119789088564d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-49.68420393244495d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8633047912461438d + "'", double1 == 1.8633047912461438d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.9564916978322142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2960659048305147d + "'", double1 == 0.2960659048305147d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        long long12 = randomDataImpl1.nextPoisson(10.124725369816879d);
//        try {
//            int int15 = randomDataImpl1.nextInt((int) (short) 100, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.908738322977216d + "'", double4 == 9.908738322977216d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6060945444187359d + "'", double7 == 0.6060945444187359d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 13L + "'", long12 == 13L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(13.019699760953051d, 2.0734385601034926E-6d, 0.0d, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 51L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.046745412134694E21d + "'", double1 == 7.046745412134694E21d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.6052975674015244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6501396430459592d + "'", double1 == 0.6501396430459592d);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure(100L);
//        try {
//            double double10 = randomDataImpl1.nextUniform(10.083282313848116d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10.083 is larger than, or equal to, the maximum (0): lower bound (10.083) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.916665072535547d + "'", double4 == 9.916665072535547d);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695754d + "'", double1 == 359.1342053695754d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 56L, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 56.0f + "'", float2 == 56.0f);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int[] intArray5 = randomDataImpl0.nextPermutation(1, (int) (short) 1);
//        try {
//            int int9 = randomDataImpl0.nextHypergeometric(5, 100, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (5): number of successes (100) must be less than or equal to population size (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 40L + "'", long2 == 40L);
//        org.junit.Assert.assertNotNull(intArray5);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 0 out of [-1, 2.718] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 0 out of [-1, 2.718] range"));
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        java.lang.String str12 = randomDataImpl1.nextHexString(10);
//        try {
//            randomDataImpl1.setSecureAlgorithm("34d799312e", "02bfa1a17b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 02bfa1a17b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.875851547448683d + "'", double4 == 9.875851547448683d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6042255945947864d + "'", double7 == 0.6042255945947864d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "797cb615cf" + "'", str12.equals("797cb615cf"));
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 88.53074452756374d, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.36221568869946325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.686013773954787d + "'", double1 == 8.686013773954787d);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double10 = randomDataImpl1.nextGaussian((double) ' ', 2.302585092994046d);
//        double double13 = randomDataImpl1.nextCauchy((double) (byte) 0, (double) 100L);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.881768129399141d + "'", double4 == 9.881768129399141d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6058711767099236d + "'", double7 == 0.6058711767099236d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.62956029765782d + "'", double10 == 32.62956029765782d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-177.37149935915423d) + "'", double13 == (-177.37149935915423d));
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        double double13 = randomDataImpl1.nextCauchy((double) 51L, 0.39618046876130475d);
//        randomDataImpl1.reSeedSecure((long) 1);
//        try {
//            int int18 = randomDataImpl1.nextZipf((int) (byte) 0, (double) 51L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.881017066657535d + "'", double4 == 9.881017066657535d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6098602166216202d + "'", double7 == 0.6098602166216202d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 51.10811568047205d + "'", double13 == 51.10811568047205d);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.log(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.124725369816879d, 0.39618046876130475d, 10.077274257623571d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeed(44L);
        try {
            int int7 = randomDataImpl1.nextInt(100, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        double double13 = randomDataImpl1.nextCauchy((double) 51L, 0.39618046876130475d);
//        randomDataImpl1.reSeedSecure((long) 1);
//        try {
//            java.lang.String str17 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.842541365299121d + "'", double4 == 9.842541365299121d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.593329675841113d + "'", double7 == 0.593329675841113d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 48.78824654318339d + "'", double13 == 48.78824654318339d);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.log10(10.008984731160238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0003900267283883d + "'", double1 == 1.0003900267283883d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-177.37149935915423d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.523017628717626d + "'", double1 == 6.523017628717626d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 89L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 89.0f + "'", float1 == 89.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.603632357402044d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5396292281164147d + "'", double1 == 0.5396292281164147d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 105L, (float) 50L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 50.0f + "'", float2 == 50.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.acos(8.686013773954787d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.asin(31.575119789088564d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6077970268926886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5754992848055241d + "'", double1 == 0.5754992848055241d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 50L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 50.0f + "'", float1 == 50.0f);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            java.lang.String str7 = randomDataImpl0.nextSecureHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.3174606603118364d) + "'", double5 == (-1.3174606603118364d));
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        try {
//            int int13 = randomDataImpl1.nextZipf((int) (short) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.92783199290945d + "'", double4 == 9.92783199290945d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.599381252641119d + "'", double7 == 0.599381252641119d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0003900267283883d, 10.08757245750952d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0003900267283885d + "'", double2 == 1.0003900267283885d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 50.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.0d + "'", double1 == 50.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(9.923402117160139d, 0.4551698081411386d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999114874d + "'", double2 == 0.9999999999114874d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 9.927711597057533d);
        java.lang.Class<?> wildcardClass2 = notStrictlyPositiveException1.getClass();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.6649055706799991d, number4, (java.lang.Number) 9.925100554614186d);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) outOfRangeException6);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.6110999849438242d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1926052396732023d + "'", double1 == 1.1926052396732023d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable19, objArray23);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException25, "hi!", objArray27);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure(50L);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '#');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.85885477206232d + "'", double4 == 9.85885477206232d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9d14d5de30aff8768f38ad5cbafc0d7093d" + "'", str8.equals("9d14d5de30aff8768f38ad5cbafc0d7093d"));
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.124725369816879d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.764876066248559d) + "'", double1 == (-0.764876066248559d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("hi!", objArray62);
        java.lang.Object[] objArray65 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException51, localizable58, objArray65);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable58, objArray70);
        org.apache.commons.math.exception.util.Localizable localizable73 = maxIterationsExceededException72.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = maxIterationsExceededException72.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("hi!", objArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable74, objArray78);
        org.apache.commons.math.exception.util.Localizable localizable82 = outOfRangeException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNull(localizable73);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNull(localizable82);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int[] intArray5 = randomDataImpl0.nextPermutation(1, (int) (short) 1);
//        try {
//            double double7 = randomDataImpl0.nextChiSquare(4.9E-324d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 55L + "'", long2 == 55L);
//        org.junit.Assert.assertNotNull(intArray5);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 103L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.687548147653598d + "'", double1 == 4.687548147653598d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(16.399971027615795d, 50.0d, 7.046745412134694E21d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0213144232784423E-8d + "'", double4 == 1.0213144232784423E-8d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable19, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException25.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertNull(localizable27);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 'a', 103L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 0, (double) ' ', 2.302585092994046d);
        double[] doubleArray5 = normalDistributionImpl3.sample((int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        normalDistributionImpl4.reseedRandomGenerator(56L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.1403243952591335d) + "'", double5 == (-1.1403243952591335d));
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        java.lang.String str12 = randomDataImpl1.nextHexString(10);
//        double double15 = randomDataImpl1.nextCauchy((double) 15L, 0.6100272411255648d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.944681656281887d + "'", double4 == 9.944681656281887d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6161181258700371d + "'", double7 == 0.6161181258700371d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "daa1b51c7c" + "'", str12.equals("daa1b51c7c"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 14.778425287217077d + "'", double15 == 14.778425287217077d);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(9.946054089648355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1057658239391731d + "'", double1 == 0.1057658239391731d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double2 = org.apache.commons.math.util.FastMath.atan2(10.008984731160238d, 1.0E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963266949865d + "'", double2 == 1.5707963266949865d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6180815137742874d, (double) 44L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
        double[] doubleArray5 = normalDistributionImpl3.sample(10);
        normalDistributionImpl3.reseedRandomGenerator(100L);
        double double10 = normalDistributionImpl3.cumulativeProbability(0.6145031101040538d, 12.482146690578855d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0414241752022797d + "'", double10 == 0.0414241752022797d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.special.Erf.erf(0.01801558118013052d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020326207430467664d + "'", double1 == 0.020326207430467664d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Object[] objArray6 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.017453292519943295d) + "'", number4.equals((-0.017453292519943295d)));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.2903121989193154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong(2L, (long) '#');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl1.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24L + "'", long5 == 24L);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 6, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 88.53074452756374d, (java.lang.Number) 0.6140020868095057d, false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable12, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable34 = mathException33.getGeneralPattern();
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable34, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, localizable50, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray51);
        java.lang.Object[] objArray54 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException40, localizable47, objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException40, localizable56, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable34, objArray60);
        java.lang.Throwable throwable64 = null;
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl69 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
        double[] doubleArray71 = normalDistributionImpl69.sample(10);
        java.lang.Object[] objArray73 = new java.lang.Object[] { normalDistributionImpl69, 10.0d };
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(throwable64, "hi!", objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException(5, localizable34, objArray73);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) 0.48418580385580895d, (java.lang.Number) 0.3796077390275217d, false);
        java.lang.Number number80 = numberIsTooSmallException79.getMin();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 0.3796077390275217d + "'", number80.equals(0.3796077390275217d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.5403322559833335d, (double) (-1.0f), 16.399971027615795d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double2 = org.apache.commons.math.util.FastMath.pow(7525.963076084939d, 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.462207705525083E20d + "'", double2 == 3.462207705525083E20d);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double7 = randomDataImpl1.nextT(0.6483608274590866d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("02bfa1a17b", "org.apache.commons.math.ConvergenceException: convergence failed");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.ConvergenceException: convergence failed");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.933184465562162d + "'", double4 == 9.933184465562162d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2158615120475954d + "'", double7 == 0.2158615120475954d);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.1102230246251565E-16d, (java.lang.Number) 1.5707963266949865d, true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.log10(12476.200989019924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.096082362535825d + "'", double1 == 4.096082362535825d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.764876066248559d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure();
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 10);
//        try {
//            long long10 = randomDataImpl0.nextPoisson((double) (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 17L + "'", long8 == 17L);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getSpecificPattern();
        java.lang.String str20 = mathException18.toString();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str20.equals("org.apache.commons.math.MathException: hi!"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3796077390275217d, 6.579251212010101d, 3.588815668294669d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 6.579 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.298342365610589d, 1.0d, 0.5772156649015329d);
        double double5 = normalDistributionImpl3.density((double) 0);
        normalDistributionImpl3.reseedRandomGenerator((long) (-1));
        java.lang.Class<?> wildcardClass8 = normalDistributionImpl3.getClass();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.199329338564076E-7d + "'", double5 == 3.199329338564076E-7d);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(14.043231579372502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24510062868009358d + "'", double1 == 0.24510062868009358d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 44L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.6552250398037804d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6552250398037804d + "'", double1 == 2.6552250398037804d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.log(12.632069669034312d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5362387922195055d + "'", double1 == 2.5362387922195055d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(31.575119789088564d, 0.6501396430459592d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.57511978908856d + "'", double2 == 31.57511978908856d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        randomDataImpl0.reSeed((long) (-1));
//        double double7 = randomDataImpl0.nextCauchy(0.018017530612444158d, (double) 56L);
//        double double10 = randomDataImpl0.nextUniform(0.0d, 1.6898464671044491E-4d);
//        try {
//            long long13 = randomDataImpl0.nextSecureLong((long) (short) 10, (long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (10): lower bound (10) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 54L + "'", long2 == 54L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.68420393244495d) + "'", double7 == (-49.68420393244495d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0734385601034926E-6d + "'", double10 == 2.0734385601034926E-6d);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.776867205101192d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36739793265954146d + "'", double1 == 0.36739793265954146d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 12L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.6092808745597276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1914250602725112d + "'", double1 == 1.1914250602725112d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9564916978322142d, 0.4798845265851441d, 10.092048604380373d, 6);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3121187688654299d + "'", double4 == 0.3121187688654299d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5723649429247d + "'", double1 == 0.5723649429247d);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        randomDataImpl0.reSeed((long) (-1));
//        double double7 = randomDataImpl0.nextCauchy(0.018017530612444158d, (double) 56L);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution8 = null;
//        try {
//            double double9 = randomDataImpl0.nextInversionDeviate(continuousDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57L + "'", long2 == 57L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.68420393244495d) + "'", double7 == (-49.68420393244495d));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int[] intArray5 = randomDataImpl0.nextPermutation(1, (int) (short) 1);
//        double double8 = randomDataImpl0.nextGamma(4.9E-324d, 31.372074264726397d);
//        double double11 = randomDataImpl0.nextBeta(33.85096138642799d, 1.3383347192042695E42d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.9E-324d + "'", double8 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.7218476541247782E-9d + "'", double11 == 1.7218476541247782E-9d);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double double7 = normalDistributionImpl3.cumulativeProbability((double) (short) 100, (double) 100L);
        double double9 = normalDistributionImpl3.cumulativeProbability((double) (-1L));
        double double11 = normalDistributionImpl3.density(0.5845934792093626d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.5975272230471802E-5d + "'", double9 == 2.5975272230471802E-5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.6425119241206285E-4d + "'", double11 == 3.6425119241206285E-4d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.495785744349465E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963018370392d + "'", double1 == 1.5707963018370392d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 89.0f, 0.4798845265851441d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.298342365610589d, 1.0d, 0.5772156649015329d);
        double double5 = normalDistributionImpl3.density((double) 0);
        normalDistributionImpl3.reseedRandomGenerator((long) (-1));
        double double8 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.199329338564076E-7d + "'", double5 == 3.199329338564076E-7d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.829280371880436E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0174013551119309E-5d + "'", double1 == 1.0174013551119309E-5d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double2 = org.apache.commons.math.util.FastMath.min(31.72451022810671d, 0.5723649429247d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5723649429247d + "'", double2 == 0.5723649429247d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.6898464671044491E-4d, 0.7499091666989383d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.cosh(12476.200989019924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0E-9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 11.117017115913347d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.6552250398037804d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure(50L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "org.apache.commons.math.MathException: hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MathException: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.98289857793814d + "'", double4 == 9.98289857793814d);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Object[] objArray8 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray8);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) maxIterationsExceededException9);
        java.lang.String str11 = maxIterationsExceededException9.toString();
        int int12 = maxIterationsExceededException9.getMaxIterations();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str11.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(52.02805828290602d, 100.0d, 10.008984731160238d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 100 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable4, objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("org.apache.commons.math.ConvergenceException: convergence failed", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double2 = org.apache.commons.math.util.FastMath.min(32.37155335122092d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.4551698081411386d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47256291379017856d + "'", double1 == 0.47256291379017856d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.1403243952591335d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.930874936879059d, Double.POSITIVE_INFINITY, 0.6483608274590866d);
        double double4 = normalDistributionImpl3.sample();
        double double5 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.930874936879059d + "'", double5 == 0.930874936879059d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.930874936879059d + "'", double7 == 0.930874936879059d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5754992848055241d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8389206693850744d + "'", double1 == 0.8389206693850744d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9999999999999996d, (double) (byte) -1, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.019691932154573932d) + "'", double1 == (-0.019691932154573932d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.signum(9.978593096205453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure();
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 63L + "'", long2 == 63L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4L + "'", long8 == 4L);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        try {
//            double double10 = randomDataImpl1.nextBeta(0.0d, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.217");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.053233722809205d + "'", double4 == 10.053233722809205d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6041709737920793d + "'", double7 == 0.6041709737920793d);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.2487972788920954d, 2.718281828459045d, 0.4551698081411386d, 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.4174421516698077d + "'", double4 == 0.4174421516698077d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable7, objArray8);
        java.lang.Class<?> wildcardClass10 = localizable7.getClass();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) Double.NaN);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.477207657226922d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.52510276275757d + "'", double1 == 256.52510276275757d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.985439830035573d + "'", double1 == 7.985439830035573d);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        double double5 = randomDataImpl0.nextBeta(9.925100554614186d, 0.5754992848055241d);
//        double double8 = randomDataImpl0.nextGamma(0.6133776958784604d, 0.5930509904947074d);
//        try {
//            double double11 = randomDataImpl0.nextBeta(9.906571838448365d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.129");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57L + "'", long2 == 57L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7181802301506865d + "'", double5 == 0.7181802301506865d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.42074757387825606d + "'", double8 == 0.42074757387825606d);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number23, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException26.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(localizable28);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0414241752022797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextSecureInt((int) (short) -1, 4);
//        double double6 = randomDataImpl0.nextGamma(12476.0d, 0.603632357402044d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7580.067649283424d + "'", double6 == 7580.067649283424d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1752706800276cbc328ddfee44516e379e200192e0738a551a944982ae400ee1485943d5c9f3ec582f3dd17612bb7378d" + "'", str8.equals("1752706800276cbc328ddfee44516e379e200192e0738a551a944982ae400ee1485943d5c9f3ec582f3dd17612bb7378d"));
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException6, localizable13, objArray20);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable13, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray25);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure(100L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl1.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.038265408223875d + "'", double4 == 10.038265408223875d);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 31.57511978908856d, (java.lang.Number) 0.6058711767099236d, true);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int[] intArray5 = randomDataImpl0.nextPermutation(1, (int) (short) 1);
//        double double7 = randomDataImpl0.nextT(644.1650679589596d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49L + "'", long2 == 49L);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3310021571640793d + "'", double7 == 1.3310021571640793d);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.018017530612444158d, (java.lang.Number) 9.944681656281887d, number2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.expm1(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl1.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.043977987320943d + "'", double4 == 10.043977987320943d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5966109892523642d + "'", double7 == 0.5966109892523642d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure(50L);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl1.getClass();
//        double double10 = randomDataImpl1.nextUniform(0.0d, (double) 100L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.046097276497898d + "'", double4 == 10.046097276497898d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5.72514908951427d + "'", double10 == 5.72514908951427d);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable12, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable34 = mathException33.getGeneralPattern();
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable34, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, localizable50, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray51);
        java.lang.Object[] objArray54 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException40, localizable47, objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException40, localizable56, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable34, objArray60);
        java.lang.Throwable throwable64 = null;
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl69 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
        double[] doubleArray71 = normalDistributionImpl69.sample(10);
        java.lang.Object[] objArray73 = new java.lang.Object[] { normalDistributionImpl69, 10.0d };
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(throwable64, "hi!", objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException(5, localizable34, objArray73);
        int int76 = maxIterationsExceededException75.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 5 + "'", int76 == 5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6133776958784604d, 4.9E-324d);
        double double4 = normalDistributionImpl2.cumulativeProbability(0.6077970268926886d);
        double double7 = normalDistributionImpl2.cumulativeProbability((-6.494941051394773d), 0.2960659048305147d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        try {
            double double4 = randomDataImpl1.nextChiSquare(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double2 = org.apache.commons.math.util.FastMath.max(31.575119789088564d, 3.462207705525083E20d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.462207705525083E20d + "'", double2 == 3.462207705525083E20d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(44.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02298749353692483d + "'", double1 == 0.02298749353692483d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0);
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 63L);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) 10);
//        int int10 = randomDataImpl0.nextBinomial(34, 0.0d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 55L + "'", long2 == 55L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17b5039fcc" + "'", str7.equals("17b5039fcc"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable12, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray44);
        java.lang.Object[] objArray47 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, localizable40, objArray47);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable40, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable27, objArray52);
        java.lang.Throwable[] throwableArray57 = mathIllegalArgumentException56.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("1752706800276cbc328ddfee44516e379e200192e0738a551a944982ae400ee1485943d5c9f3ec582f3dd17612bb7378d", (java.lang.Object[]) throwableArray57);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray57);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int2 = org.apache.commons.math.util.FastMath.min(100, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int1 = org.apache.commons.math.util.FastMath.abs(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 55L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException10, localizable17, objArray24);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable17, objArray29);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable17, objArray32);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable47, objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray48);
        java.lang.Object[] objArray51 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException37, localizable44, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray51);
        java.lang.Throwable[] throwableArray54 = mathIllegalArgumentException53.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.7218476541247782E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7218476541247782E-9d + "'", double1 == 1.7218476541247782E-9d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 403.4287934927351d + "'", double1 == 403.4287934927351d);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution3 = null;
//        try {
//            int int4 = randomDataImpl0.nextInversionDeviate(integerDistribution3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 39L + "'", long2 == 39L);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 100, (java.lang.Number) 3.462207705525083E20d, false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException6, localizable13, objArray20);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable13, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException34, localizable41, objArray48);
        java.lang.Object[] objArray53 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable41, objArray53);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable28, objArray53);
        java.lang.Throwable[] throwableArray58 = mathIllegalArgumentException57.getSuppressed();
        java.lang.Object[] objArray59 = mathIllegalArgumentException57.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(0, "daa1b51c7c", objArray59);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray59);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7467135528742547E19d + "'", double1 == 1.7467135528742547E19d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.220446049250313E-16d, 4.9E-324d, 1.2903121989193154d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999999999998391d + "'", double4 == 0.9999999999998391d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.978593096205453d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double8 = normalDistributionImpl4.cumulativeProbability(4.096082362535825d, 9.978593096205453d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.7266275237111985d) + "'", double5 == (-0.7266275237111985d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.1936431338076545E-8d + "'", double8 == 2.1936431338076545E-8d);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(220.05533476569371d, 0.24510062868009358d, (-0.017453292519943295d), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (100) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.017453292519943295d), 2.5975272230471802E-5d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number23, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getSpecificPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) 9.906571838448365d, (java.lang.Number) 4.096082362535825d, (java.lang.Number) 12L);
        java.lang.Number number32 = outOfRangeException31.getArgument();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 9.906571838448365d + "'", number32.equals(9.906571838448365d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 13.019699760953051d, (java.lang.Number) 56L, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        outOfRangeException4.addSuppressed((java.lang.Throwable) mathException11);
        java.lang.Object[] objArray13 = outOfRangeException4.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.5456928232039928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.48754707723034807d + "'", double1 == 0.48754707723034807d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        double double5 = randomDataImpl0.nextBeta(9.925100554614186d, 0.5754992848055241d);
//        double double8 = randomDataImpl0.nextGamma(0.6133776958784604d, 0.5930509904947074d);
//        long long11 = randomDataImpl0.nextSecureLong(0L, 105L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 55L + "'", long2 == 55L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9631544744718238d + "'", double5 == 0.9631544744718238d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.06946735015924059d + "'", double8 == 0.06946735015924059d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 22L + "'", long11 == 22L);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = outOfRangeException22.getSpecificPattern();
        java.lang.Object[] objArray25 = outOfRangeException22.getArguments();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(objArray25);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray11);
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable14, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        java.lang.Object[] objArray20 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
//        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException6, localizable14, objArray20);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        java.lang.Object[] objArray32 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable31, objArray32);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("hi!", objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable35 = mathException34.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        java.lang.Object[] objArray39 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray39);
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray39);
//        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException28, localizable35, objArray42);
//        java.lang.Number number45 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) 1.0E-9d, number45, (java.lang.Number) 10.124725369816879d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator48 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl49 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator48);
//        double double52 = randomDataImpl49.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double55 = randomDataImpl49.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double58 = randomDataImpl49.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl49.reSeedSecure((long) 1);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { randomDataImpl49, ' ' };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable35, objArray62);
//        java.lang.Class<?> wildcardClass64 = convergenceException63.getClass();
//        java.lang.Object[] objArray65 = convergenceException63.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, "02bfa1a17b", objArray65);
//        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: ", objArray65);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "ab285dc08b", objArray65);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(localizable14);
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertNotNull(objArray20);
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(localizable35);
//        org.junit.Assert.assertNotNull(objArray39);
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 9.877041709444338d + "'", double52 == 9.877041709444338d);
//        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.6104267705666283d + "'", double55 == 0.6104267705666283d);
//        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 32.22885768115818d + "'", double58 == 32.22885768115818d);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(objArray65);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        long long12 = randomDataImpl1.nextPoisson(10.124725369816879d);
//        int int15 = randomDataImpl1.nextBinomial((int) (short) 1, 0.7499091666989383d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.851577238769147d + "'", double4 == 9.851577238769147d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6035540814839848d + "'", double7 == 0.6035540814839848d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 11L + "'", long12 == 11L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.asinh(403.4287934927351d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.693148716609494d + "'", double1 == 6.693148716609494d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 5, 2.302585092994046d, 10.0d);
        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 10);
        double double7 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 0, (double) 33L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.019691932154573932d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.6649055706799991d, number1, (java.lang.Number) 9.925100554614186d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.0d, (java.lang.Number) 0.5845934792093626d, false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson((double) '4');
        randomDataImpl0.reSeed((long) (-1));
        double double7 = randomDataImpl0.nextCauchy(0.018017530612444158d, (double) 56L);
        try {
            long long10 = randomDataImpl0.nextLong((long) 35, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (-1): lower bound (35) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56L + "'", long2 == 56L);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.68420393244495d) + "'", double7 == (-49.68420393244495d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(88.53074452756374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.409077772426144d + "'", double1 == 9.409077772426144d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.5063656411097588d), 10.129293685722505d, 3.5403322559833335d, 3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray43);
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException32, localizable39, objArray46);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable39, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable26, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable60, objArray61);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("hi!", objArray61);
        org.apache.commons.math.exception.util.Localizable localizable64 = mathException63.getGeneralPattern();
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable64, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException55, "9d14d5de30aff8768f38ad5cbafc0d7093d", objArray65);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(objArray65);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        double double5 = randomDataImpl0.nextF(1.0842021724855044E-19d, 0.8389206693850744d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66L + "'", long2 == 66L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.8937085940556833E-9d + "'", double5 == 1.8937085940556833E-9d);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        long long7 = randomDataImpl0.nextPoisson(1.1712659507785417d);
//        double double9 = randomDataImpl0.nextT(16.399971027615795d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 61L + "'", long2 == 61L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.4681356083918512d) + "'", double9 == (-0.4681356083918512d));
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.7315770488412858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22372269968613967d + "'", double1 == 0.22372269968613967d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable7, objArray8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.930874936879059d, (java.lang.Number) 0.01801558118013052d, true);
        boolean boolean14 = numberIsTooLargeException13.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException13);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray14 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray26 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray26);
//        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        java.lang.Object[] objArray33 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray33);
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException22, localizable29, objArray36);
//        java.lang.Number number39 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 1.0E-9d, number39, (java.lang.Number) 10.124725369816879d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator42 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator42);
//        double double46 = randomDataImpl43.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double49 = randomDataImpl43.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double52 = randomDataImpl43.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl43.reSeedSecure((long) 1);
//        java.lang.Object[] objArray56 = new java.lang.Object[] { randomDataImpl43, ' ' };
//        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable29, objArray56);
//        java.lang.Object[] objArray58 = null;
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable29, objArray58);
//        java.lang.String str60 = convergenceException59.getPattern();
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException59);
//        java.lang.String str62 = convergenceException59.toString();
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(localizable29);
//        org.junit.Assert.assertNotNull(objArray33);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 9.758076254158418d + "'", double46 == 9.758076254158418d);
//        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.6054303628686525d + "'", double49 == 0.6054303628686525d);
//        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 31.8147365078235d + "'", double52 == 31.8147365078235d);
//        org.junit.Assert.assertNotNull(objArray56);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.ConvergenceException: hi!" + "'", str62.equals("org.apache.commons.math.ConvergenceException: hi!"));
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        try {
//            int int8 = randomDataImpl0.nextZipf(1, (-0.4681356083918512d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.468 is smaller than, or equal to, the minimum (0): exponent (-0.468)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.32043371719516767d) + "'", double3 == (-0.32043371719516767d));
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.764876066248559d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.764876066248559d) + "'", double2 == (-0.764876066248559d));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Object[] objArray9 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
//        java.lang.Object[] objArray13 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable12, objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        java.lang.Object[] objArray18 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray18);
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray18);
//        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable12, objArray18);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray30);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        java.lang.Object[] objArray37 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray37);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray37);
//        java.lang.Object[] objArray40 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26, localizable33, objArray40);
//        java.lang.Number number43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 1.0E-9d, number43, (java.lang.Number) 10.124725369816879d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator46 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator46);
//        double double50 = randomDataImpl47.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double53 = randomDataImpl47.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double56 = randomDataImpl47.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl47.reSeedSecure((long) 1);
//        java.lang.Object[] objArray60 = new java.lang.Object[] { randomDataImpl47, ' ' };
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable33, objArray60);
//        java.lang.Class<?> wildcardClass62 = convergenceException61.getClass();
//        java.lang.Object[] objArray63 = convergenceException61.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, "02bfa1a17b", objArray63);
//        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: ", objArray63);
//        org.apache.commons.math.exception.util.Localizable localizable66 = mathException65.getGeneralPattern();
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(localizable12);
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(objArray18);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable33);
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 9.933794012324014d + "'", double50 == 9.933794012324014d);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.6097259066515753d + "'", double53 == 0.6097259066515753d);
//        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 28.693750789170082d + "'", double56 == 28.693750789170082d);
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(objArray63);
//        org.junit.Assert.assertNotNull(localizable66);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray20);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number27 = numberIsTooSmallException26.getMin();
        java.lang.Number number28 = numberIsTooSmallException26.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray44);
        java.lang.Object[] objArray47 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, localizable40, objArray47);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable40, objArray52);
        java.lang.Object[] objArray55 = null;
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException26, localizable40, objArray55);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("hi!", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable67 = mathException66.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, localizable70, objArray71);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("hi!", objArray71);
        java.lang.Object[] objArray74 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException60, localizable67, objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.ConvergenceException: convergence failed", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable11, objArray74);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException("daa1b51c7c", objArray74);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) 0 + "'", number27.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 0 + "'", number28.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math.special.Erf.erf(49.98984243963481d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        try {
//            int int11 = randomDataImpl1.nextSecureInt((int) 'a', (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (1): lower bound (97) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.885585964167415d + "'", double4 == 9.885585964167415d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 606.7904427741977d + "'", double8 == 606.7904427741977d);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(33.85096138642799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.029981897410206196d + "'", double1 == 0.029981897410206196d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-6.494941051394773d), 28.693750789170082d, 10.669031621848436d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.72514908951427d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4302997780530635d + "'", double1 == 2.4302997780530635d);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        java.lang.String str12 = randomDataImpl1.nextHexString(10);
//        double double15 = randomDataImpl1.nextGamma(0.7615941559557649d, 0.8496550830689211d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.891165073496994d + "'", double4 == 9.891165073496994d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6004871325643916d + "'", double7 == 0.6004871325643916d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "da5edee0a4" + "'", str12.equals("da5edee0a4"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.1554843637161998d + "'", double15 == 1.1554843637161998d);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable3, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure();
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 10);
//        try {
//            long long11 = randomDataImpl0.nextSecureLong(97L, 51L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (51): lower bound (97) must be strictly less than upper bound (51)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 64L + "'", long2 == 64L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 49L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5503909961083586d + "'", double1 == 1.5503909961083586d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        double double5 = randomDataImpl0.nextBeta(9.925100554614186d, 0.5754992848055241d);
//        try {
//            int[] intArray8 = randomDataImpl0.nextPermutation((int) (byte) -1, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than the maximum (-1): permutation size (0) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44L + "'", long2 == 44L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7764190003163725d + "'", double5 == 0.7764190003163725d);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5723649429247d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8406224230002417d + "'", double1 == 0.8406224230002417d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
        double[] doubleArray5 = normalDistributionImpl3.sample(10);
        normalDistributionImpl3.reseedRandomGenerator(100L);
        double double8 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.930874936879059d + "'", double8 == 0.930874936879059d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.6898464671044491E-4d, (double) 103L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6898464671044494E-4d + "'", double2 == 1.6898464671044494E-4d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(359.1342053695754d, (double) (short) 100, 0.6060928282773596d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.409077772426144d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.log(33.85096138642799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.521967400326553d + "'", double1 == 3.521967400326553d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 89.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.181751987126265d + "'", double1 == 5.181751987126265d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.log10(32.49723192432058d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5118463698653086d + "'", double1 == 1.5118463698653086d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 8.520185096803155d, true);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.462207705525083E20d, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number23, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getSpecificPattern();
        java.lang.Number number28 = numberIsTooSmallException26.getMin();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 2.718281828459045d + "'", number28.equals(2.718281828459045d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.6145031101040538d, (java.lang.Number) 2.5362387922195055d, false);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure();
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, (double) 10);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.930874936879059d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-17.095892353902908d) + "'", double12 == (-17.095892353902908d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5370829735576599d + "'", double14 == 0.5370829735576599d);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) 10);
//        randomDataImpl0.reSeed();
//        try {
//            double double11 = randomDataImpl0.nextGamma(0.0d, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "63d9491be3" + "'", str7.equals("63d9491be3"));
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        try {
//            int int7 = randomDataImpl1.nextInt((int) (byte) 0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.880148824946305d + "'", double4 == 9.880148824946305d);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) 63L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 63.0f + "'", float2 == 63.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.6881171418161356E43d, (-0.4458178502007277d), (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.446 is smaller than, or equal to, the minimum (0): standard deviation (-0.446)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("hi!", objArray62);
        java.lang.Object[] objArray65 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException51, localizable58, objArray65);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable58, objArray70);
        org.apache.commons.math.exception.util.Localizable localizable73 = maxIterationsExceededException72.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = maxIterationsExceededException72.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("hi!", objArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable74, objArray78);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException83 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable74, (java.lang.Number) 0.22372269968613967d);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNull(localizable73);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray78);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 9.906571838448365d, (java.lang.Number) (short) 100, (java.lang.Number) 1L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable12, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray44);
        java.lang.Object[] objArray47 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, localizable40, objArray47);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable40, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable27, objArray52);
        java.lang.Throwable[] throwableArray57 = mathIllegalArgumentException56.getSuppressed();
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("02bfa1a17b", (java.lang.Object[]) throwableArray57);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray57);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        java.lang.String str12 = randomDataImpl1.nextHexString(10);
//        double double15 = randomDataImpl1.nextGamma((double) (byte) 1, (double) 7L);
//        randomDataImpl1.reSeedSecure((long) (short) 1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.944987789934327d + "'", double4 == 9.944987789934327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6163824199058279d + "'", double7 == 0.6163824199058279d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10247a8637" + "'", str12.equals("10247a8637"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 5.750511280592366d + "'", double15 == 5.750511280592366d);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 10, (float) 89L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6161181258700371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5484194618947535d + "'", double1 == 0.5484194618947535d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable2, objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException8);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.0769824743038552d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(9.885967993100097d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.54574211517152d + "'", double1 == 12.54574211517152d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 9.927711597057533d, (java.lang.Number) 28.158022179325044d, false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString(4);
//        try {
//            long long13 = randomDataImpl1.nextLong(56L, 43L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 56 is larger than, or equal to, the maximum (43): lower bound (56) must be strictly less than upper bound (43)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.948809723881313d + "'", double4 == 9.948809723881313d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 500.2300375169105d + "'", double8 == 500.2300375169105d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ea00" + "'", str10.equals("ea00"));
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        double double13 = randomDataImpl1.nextCauchy((double) 51L, 0.39618046876130475d);
//        try {
//            int int16 = randomDataImpl1.nextInt((int) 'a', (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (-1): lower bound (97) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.949188722208282d + "'", double4 == 9.949188722208282d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6134573528007483d + "'", double7 == 0.6134573528007483d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 50.45992787492957d + "'", double13 == 50.45992787492957d);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        long long7 = randomDataImpl0.nextPoisson(1.1712659507785417d);
//        long long9 = randomDataImpl0.nextPoisson((double) 100.0f);
//        double double12 = randomDataImpl0.nextWeibull(12.482146690578855d, 12476.200989019926d);
//        double double15 = randomDataImpl0.nextBeta(14.043231579372502d, 190.43173506866498d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 37L + "'", long2 == 37L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 94L + "'", long9 == 94L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11185.253091863251d + "'", double12 == 11185.253091863251d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.07417234797031484d + "'", double15 == 0.07417234797031484d);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.8389206693850744d, (java.lang.Number) 9.993527645635158d, (java.lang.Number) 35L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 62L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.8203465956817455d + "'", double1 == 4.8203465956817455d);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        int int9 = randomDataImpl0.nextHypergeometric((int) (short) 100, 0, (int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.1369174896167626d) + "'", double5 == (-1.1369174896167626d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 88.53074452756374d, false);
        java.lang.Throwable[] throwableArray51 = numberIsTooSmallException50.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable23, (java.lang.Object[]) throwableArray51);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray51);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(31.72451022810671d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5536971570630794d + "'", double1 == 0.5536971570630794d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.log1p(9.640346975596497d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3646530938701806d + "'", double1 == 2.3646530938701806d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.849036009050675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.983088083708414d + "'", double1 == 2.983088083708414d);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextGaussian((double) 10.0f, (double) 89.0f);
//        double double9 = randomDataImpl0.nextCauchy(0.5d, 0.8389206693850744d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5344323418835167d + "'", double3 == 0.5344323418835167d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-82.40467672356628d) + "'", double6 == (-82.40467672356628d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.6317992286964826d + "'", double9 == 1.6317992286964826d);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextSecureInt((int) (short) -1, 4);
//        double double6 = randomDataImpl0.nextGamma(12476.0d, 0.603632357402044d);
//        try {
//            int int9 = randomDataImpl0.nextPascal((int) (short) 0, 9.927954684514956d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 9.928 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7505.387401933913d + "'", double6 == 7505.387401933913d);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 63L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 63.0d + "'", double2 == 63.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-82.40467672356628d), (java.lang.Number) 0.24510062868009358d, false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 54L);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 54L + "'", number2.equals(54L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Class<?> wildcardClass23 = outOfRangeException22.getClass();
        java.lang.Number number24 = outOfRangeException22.getLo();
        org.apache.commons.math.exception.util.Localizable localizable25 = outOfRangeException22.getSpecificPattern();
        java.lang.Object[] objArray30 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException22, "ea273927af", objArray30);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray30);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextF((double) 46L, 1.7481880270062005d);
//        double double10 = randomDataImpl1.nextGaussian(0.0d, 9.874613050434176d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.965310062286884d + "'", double4 == 9.965310062286884d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.6935133704001326d + "'", double7 == 1.6935133704001326d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-5.128235259690005d) + "'", double10 == (-5.128235259690005d));
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(0.6054303628686525d, (double) 45L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2615734117460071d + "'", double3 == 0.2615734117460071d);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-82.12860851402517d), (double) 56L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.16239025956232522d), 0.0d, 9.776867205101192d, 6);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.6035540814839848d, 9.94503952345092d, 0.0d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 9.945 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1712659507785417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020442447257587395d + "'", double1 == 0.020442447257587395d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.018017530612444158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3082.0193027110404d + "'", double1 == 3082.0193027110404d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) (short) 100, (java.lang.Number) 100.0f, true);
        boolean boolean51 = numberIsTooLargeException50.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        double double8 = randomDataImpl0.nextGaussian(100.0d, (double) '#');
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 1, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66L + "'", long2 == 66L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 142.572218304062d + "'", double8 == 142.572218304062d);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9631544744718238d, 9.758076254158418d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.758076254158418d + "'", double2 == 9.758076254158418d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.891165073496994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.145022269157564d + "'", double1 == 3.145022269157564d);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int[] intArray5 = randomDataImpl0.nextPermutation(1, (int) (short) 1);
//        double double8 = randomDataImpl0.nextGamma(4.9E-324d, 31.372074264726397d);
//        long long11 = randomDataImpl0.nextSecureLong(12L, (long) '#');
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.602415391186038E-9d + "'", double8 == 1.602415391186038E-9d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 14L + "'", long11 == 14L);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5930509904947074d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        randomDataImpl0.reSeed((long) (-1));
//        try {
//            double double7 = randomDataImpl0.nextGamma((-0.019691932154573932d), 0.9792875859931631d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.02 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59L + "'", long2 == 59L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.4681356083918512d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.sin(28.158022179325044d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11604962820744152d + "'", double1 == 0.11604962820744152d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.015952019922548d);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) 'a', 0.040187691180085916d);
//        randomDataImpl0.reSeedSecure(0L);
//        int int8 = randomDataImpl0.nextPascal((int) (byte) 1, 0.0d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 44 + "'", int3 == 44);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextCauchy((double) 10, (double) 5);
//        double double8 = randomDataImpl0.nextT(10.172028608154612d);
//        double double11 = randomDataImpl0.nextGaussian(33.55452857985193d, (double) 56L);
//        java.lang.String str13 = randomDataImpl0.nextHexString((int) '4');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.911968023251907d + "'", double3 == 0.911968023251907d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.7151961518855838d) + "'", double6 == (-0.7151961518855838d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0337069475028133d) + "'", double8 == (-1.0337069475028133d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-45.01843692196189d) + "'", double11 == (-45.01843692196189d));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "68a9dae8282db87ca06c3a0b90371ce4c5b87c042514c464fe91" + "'", str13.equals("68a9dae8282db87ca06c3a0b90371ce4c5b87c042514c464fe91"));
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = outOfRangeException22.getSpecificPattern();
        java.lang.Number number25 = outOfRangeException22.getHi();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 10.124725369816879d + "'", number25.equals(10.124725369816879d));
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        double double13 = randomDataImpl1.nextCauchy((double) 51L, 0.39618046876130475d);
//        randomDataImpl1.reSeed(0L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "org.apache.commons.math.exception.OutOfRangeException: 0 out of [-1, 2.718] range");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.OutOfRangeException: 0 out of [-1, 2.718] range");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.960979823626193d + "'", double4 == 9.960979823626193d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5857295812080957d + "'", double7 == 0.5857295812080957d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 50.658559904178d + "'", double13 == 50.658559904178d);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 5, 2.302585092994046d, 10.0d);
        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 10);
        double double7 = normalDistributionImpl3.density(31.57511978908856d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0591701319444926E-30d + "'", double7 == 2.0591701319444926E-30d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 13.019699760953051d, (java.lang.Number) 56L, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        outOfRangeException4.addSuppressed((java.lang.Throwable) mathException11);
        java.lang.Number number13 = outOfRangeException4.getLo();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 56L + "'", number13.equals(56L));
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong(2L, (long) '#');
//        double double7 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double10 = randomDataImpl1.nextGamma(0.6052533530593858d, 2.220446049250313E-16d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4L + "'", long5 == 4L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.44965604763510864d + "'", double7 == 0.44965604763510864d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.6828269538405507E-9d + "'", double10 == 1.6828269538405507E-9d);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) (short) 100, (java.lang.Number) 100.0f, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 0.6133776958784604d);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) (short) 100, (java.lang.Number) 100.0f, true);
        java.lang.Object[] objArray51 = numberIsTooLargeException50.getArguments();
        java.lang.Number number52 = numberIsTooLargeException50.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 100.0f + "'", number52.equals(100.0f));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Class<?> wildcardClass23 = outOfRangeException22.getClass();
        java.lang.Number number24 = outOfRangeException22.getLo();
        java.lang.Number number25 = outOfRangeException22.getArgument();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0E-9d + "'", number25.equals(1.0E-9d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 35, 32.49723192432058d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.99999999999999d + "'", double2 == 34.99999999999999d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7580.067649283424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.atanh(32.62956029765782d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number23, (java.lang.Number) 2.718281828459045d, true);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, number27, (java.lang.Number) 0.5d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException34, localizable41, objArray48);
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) 1.0E-9d, number51, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, number54, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooSmallException57.getSpecificPattern();
        java.lang.Number number60 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable58, (java.lang.Number) 9.946054089648355d, number60, false);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable58, objArray65);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        long long2 = org.apache.commons.math.util.FastMath.max(14L, 7L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        long long7 = randomDataImpl0.nextPoisson(1.1712659507785417d);
//        long long9 = randomDataImpl0.nextPoisson((double) 100.0f);
//        double double12 = randomDataImpl0.nextWeibull(12.482146690578855d, 12476.200989019926d);
//        try {
//            double double14 = randomDataImpl0.nextExponential((-0.764876066248559d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.765 is smaller than, or equal to, the minimum (0): mean (-0.765)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 89L + "'", long9 == 89L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10026.844046910663d + "'", double12 == 10026.844046910663d);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) convergenceException5);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException10, localizable17, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getSpecificPattern();
        convergenceException5.addSuppressed((java.lang.Throwable) mathException25);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNull(localizable26);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable23, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException15, localizable23, objArray29);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable11, objArray29);
        java.lang.Number number35 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 11.117017115913347d, number35, number36);
        java.lang.Number number38 = outOfRangeException37.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNull(number38);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.017453292519943295d) + "'", number4.equals((-0.017453292519943295d)));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getSpecificPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 12L, (java.lang.Number) 2.495785744349465E-8d, false);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 97L, number29, true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable23);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1.0f), (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.09966865249116202d) + "'", double2 == (-0.09966865249116202d));
    }
}

