import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (-28629141L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28629141L) + "'", long2 == (-28629141L));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1113831611), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1113831611) + "'", int2 == (-1113831611));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-118608245L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1860824499999999E8d) + "'", double1 == (-1.1860824499999999E8d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(77413197264L, (long) (-1546572378));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.1415926221935986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05483113501364058d + "'", double1 == 0.05483113501364058d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1011892322, (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1088898461023600640L + "'", long2 == 1088898461023600640L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 2704);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2704L + "'", long2 == 2704L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-118608220), 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5707962918655727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796291865573d + "'", double1 == 1.570796291865573d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611504d + "'", double1 == 81.55795945611504d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1000L, 0.029985180230424707d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570766341614675d + "'", double2 == 1.570766341614675d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.1909687824208959d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4931702671644849d) + "'", double1 == (-1.4931702671644849d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0950671531879624E27d, (java.lang.Number) (-320L), 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7890481L, (java.lang.Number) 3.1415926221935986d, 0, orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 28661240, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2309908846280704E17d + "'", double2 == 1.2309908846280704E17d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.029985180230424707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3106720772016449d + "'", double1 == 0.3106720772016449d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        java.lang.Number number14 = nonMonotonousSequenceException5.getArgument();
        java.lang.Class<?> wildcardClass15 = number14.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 10L + "'", number14.equals(10L));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.4762920118769467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.550007213731497d + "'", double1 == 10.550007213731497d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 'a', (long) 108640);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10538080L + "'", long2 == 10538080L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double1 = org.apache.commons.math.util.FastMath.tan(3200.0000000000005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.3771464214718416d) + "'", double1 == (-3.3771464214718416d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (-118608186));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-89), 2.7255121382673138d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.18608245E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(6062501530L, (long) 1674494048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5075811363987946720L + "'", long2 == 5075811363987946720L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, 1095479168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1095479168 + "'", int2 == 1095479168);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 916132832L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.644483341943246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7306786685136297d + "'", double1 == 1.7306786685136297d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.18608224E8f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08105829906083993d + "'", double1 == 0.08105829906083993d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 1, 990L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 991L + "'", long2 == 991L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) -1, 3200);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.398046511104E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 99L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray11 = new int[] { (byte) -1 };
        int[] intArray18 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray18);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) '#', (-4.9E-324d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection10, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection25, false);
        java.lang.Throwable[] throwableArray28 = nonMonotonousSequenceException27.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection38, false);
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.Number number42 = nonMonotonousSequenceException40.getArgument();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.String str44 = nonMonotonousSequenceException40.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.Number number46 = nonMonotonousSequenceException40.getArgument();
        java.lang.Number number47 = nonMonotonousSequenceException40.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0f + "'", number42.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.0f + "'", number46.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (-1.18608224E8f) + "'", number47.equals((-1.18608224E8f)));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(5.733486234193786E104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5558.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.713573381989622d + "'", double1 == 17.713573381989622d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-8.86120699709114E10d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', 65);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6305 + "'", int2 == 6305);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 70, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 69.99999999999999d + "'", double2 == 69.99999999999999d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1113831611));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(320.0d, (double) 65);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-28629151L), (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1002020285L) + "'", long2 == (-1002020285L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 100, (long) 1490045466);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1490045366L) + "'", long2 == (-1490045366L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.041914822473389d, 8.178185013543274E-7d, 2704);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2862915100L, (double) 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8629151E9d + "'", double2 == 2.8629151E9d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.FastMath.rint(22.716225035560587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.0d + "'", double1 == 23.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1002020285L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.2676506002282294E30d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 0, 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 28661240);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-118608186), (long) (-36));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-36L) + "'", long2 == (-36L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-2.8629152E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.8629151999999996E7d) + "'", double1 == (-2.8629151999999996E7d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.2236022912706814d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3994113737640705d + "'", double1 == 2.3994113737640705d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 26316305322681560L, 9.889030319346946E42d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 118608255L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 118608256 + "'", int1 == 118608256);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.35635482752298947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9371747034179245d + "'", double1 == 0.9371747034179245d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double1 = org.apache.commons.math.util.FastMath.log(0.5101770449416689d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6729974665608759d) + "'", double1 == (-0.6729974665608759d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.7061806015116946d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1074790400), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-17.80422716567731d), (double) 1095479168);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0954791650153134E9d + "'", double2 == 1.0954791650153134E9d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-3395662222958640L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1608653586));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.373491181781864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31999.000000000007d + "'", double1 == 31999.000000000007d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1608652696L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.608652697E9d) + "'", double1 == (-1.608652697E9d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int int1 = org.apache.commons.math.util.MathUtils.hash(7.676039227458498E10d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-530363769) + "'", int1 == (-530363769));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 100.0f, 98.45029678472541d, (-3.123701912297712d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1030825348, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1030825251L + "'", long2 == 1030825251L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-99L), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-99.0f) + "'", float2 == (-99.0f));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-50.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.6840314986403864d) + "'", double1 == (-3.6840314986403864d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        long long2 = org.apache.commons.math.util.FastMath.min((-4441386545051598748L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4441386545051598748L) + "'", long2 == (-4441386545051598748L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.889030319346946E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0393599117879015d + "'", double1 == 1.0393599117879015d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9371747034179245d, 0.49870655758087346d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9681590896047046d + "'", double2 == 0.9681590896047046d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 118608220L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 118608224 + "'", int1 == 118608224);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 10538080L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 1011892322);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1186082200, (-118608245L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(118608255);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 605958124, 6305);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean21 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number22 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection32, true);
        java.lang.String str35 = nonMonotonousSequenceException34.toString();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        boolean boolean37 = nonMonotonousSequenceException28.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Throwable[] throwableArray45 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(orderDirection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.18608224E8f) + "'", number22.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str35.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1434050571));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(4, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.2124676738864985E28d, 147457.44418529558d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 1.7182818284590453d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-106));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(28629141, (-1434050571));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1405421430) + "'", int2 == (-1405421430));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (-887503592L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 887503592L + "'", long2 == 887503592L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-118608186), (int) (byte) -1, 1674494048);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-28135805470149888L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.8135805470149888E16d) + "'", double1 == (-2.8135805470149888E16d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.610473652295695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.610473652295695d + "'", double1 == 3.610473652295695d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.FastMath.sin(18334.649444186347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3095481786866593d + "'", double1 == 0.3095481786866593d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(28629151, 28629240);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 1076101122);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.4929377100149654d, (double) (-28135805470149888L), Double.NaN);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.812644285236262E-103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1030825251L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(32000, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8414709848078944d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray15.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-36L), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-887503592L), (-35.99999999999999d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double[] doubleArray4 = new double[] { 6.338253001141147E30d, 30.0f, (-1190133760), 7.456808469171364d };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = null;
        try {
            double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1546572378) + "'", int5 == (-1546572378));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1546572378) + "'", int6 == (-1546572378));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1405421430));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double1 = org.apache.commons.math.util.MathUtils.sign(34.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5643018306624046d, 1.1947055233182955d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5643018306624044d + "'", double2 == 1.5643018306624044d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.String str17 = nonMonotonousSequenceException13.toString();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException13.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(10.550007213731497d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.2309908846280704E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2L, (double) (-1608653686), 0.7551949618496253d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1434050571L, (float) 34L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double2 = org.apache.commons.math.util.FastMath.max(2.9554156163191374E213d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9554156163191374E213d + "'", double2 == 2.9554156163191374E213d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7061806015116946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7840892038537085d + "'", double1 == 0.7840892038537085d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1095479168);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray15.getClass();
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 28629151 + "'", int17 == 28629151);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 28629151 + "'", int18 == 28629151);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.4991311460098435d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5451748644507478d) + "'", double1 == (-0.5451748644507478d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1073741824));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double1 = org.apache.commons.math.util.FastMath.asin(17.713573381989622d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-28629141L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray31.getClass();
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        int[] intArray41 = new int[] { 98, ' ', (short) 1, (-1546572378), (-1608653686), 118608255 };
        int[] intArray48 = new int[] { (short) 100, (-118608221), (byte) 0, 0, 1, (short) 1 };
        int[] intArray50 = new int[] { (byte) -1 };
        int[] intArray57 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray57);
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray48);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray41);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 118608220 + "'", int59 == 118608220);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.237808892798469E9d + "'", double60 == 2.237808892798469E9d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.23466351519089E9d + "'", double61 == 2.23466351519089E9d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1353352832366127d + "'", double1 == 0.1353352832366127d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 416 + "'", int2 == 416);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(32, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.1415926221935986d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, 1186082200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean22 = nonMonotonousSequenceException18.getStrict();
        java.lang.Number number23 = nonMonotonousSequenceException18.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0f + "'", number19.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.18608224E8f) + "'", number20.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0f + "'", number23.equals(0.0f));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double[] doubleArray2 = new double[] { 0.9999092042625951d, 1.1860822427888854E8d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1860822427888854E8d + "'", double3 == 1.1860822427888854E8d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1860822427888854E8d + "'", double4 == 1.1860822427888854E8d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.3721648899999958E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15401.833949241227d + "'", double1 == 15401.833949241227d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-530363769), 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-530363774) + "'", int2 == (-530363774));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number17 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0f + "'", number17.equals(100.0f));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2597559464087268d) + "'", double1 == (-0.2597559464087268d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2704);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1030825348L, 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35048061832L + "'", long2 == 35048061832L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray61);
        double[] doubleArray71 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray77 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        double[] doubleArray85 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray91 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, (double) 0.0f);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray94);
        int int98 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 28629151 + "'", int95 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 28629151 + "'", int98 == 28629151);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-32), (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray29);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray29.getClass();
        double[] doubleArray43 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray49 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 0.0f);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 0.0f);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray66);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.3440585709080678E43d + "'", double33 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 28629151 + "'", int53 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.3440585709080678E43d + "'", double70 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-8.86120699709114E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.077097623251163E12d) + "'", double1 == (-5.077097623251163E12d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 1.4901161193847655E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4901161193847655E-8d + "'", double2 == 1.4901161193847655E-8d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.8414709848078944d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 28629141, 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.843160129832652d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8431601298326523d + "'", double1 == 2.8431601298326523d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.6403346226671169E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.812644285236262E-103d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray31.getClass();
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        int[] intArray36 = new int[] { (byte) -1 };
        int[] intArray43 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        int[] intArray46 = new int[] { (byte) -1 };
        int[] intArray53 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray43);
        int[] intArray57 = null;
        try {
            int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 98, (-10L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.16132832E8d, (java.lang.Number) 20.818341138543172d, 1072693248);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.6328096796422548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2069954852796814d + "'", double1 == 1.2069954852796814d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.49004544E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.12207245308306d + "'", double1 == 21.12207245308306d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(32, 118608256);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 3200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1000L, (long) (-530363769));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.tan(52.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792571d) + "'", double1 == (-6.053272382792571d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double1 = org.apache.commons.math.util.FastMath.log(0.7061806015116946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3478842646959184d) + "'", double1 == (-0.3478842646959184d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1608653686) + "'", int16 == (-1608653686));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 6305);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5752220392306202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1700525517702927d + "'", double1 == 1.1700525517702927d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-320L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-320.0d) + "'", double1 == (-320.0d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 77413197264L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5558.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.31614079895527d + "'", double1 == 9.31614079895527d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.2833782334517141d, 5.7233120074752435d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28337823345171415d + "'", double2 == 0.28337823345171415d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 0.7496154300672659d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 642915097, 1674494048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 600653219388620033L + "'", long2 == 600653219388620033L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.7233120074752435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6267730472324786d) + "'", double1 == (-0.6267730472324786d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.8664221567260895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double1 = org.apache.commons.math.util.FastMath.ulp(18.591336386802322d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection17, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', (-2088681202));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9341334322691035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.966505784912384d + "'", double1 == 0.966505784912384d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(98.99999999999999d, 118608220);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.676409074575426E106d + "'", double2 == 5.676409074575426E106d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 2862915100L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 98);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.975087461085999d, 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.1415926535897927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.66553889764798E-16d) + "'", double1 == (-5.66553889764798E-16d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int[] intArray6 = new int[] { 98, ' ', (short) 1, (-1546572378), (-1608653686), 118608255 };
        int[] intArray13 = new int[] { (short) 100, (-118608221), (byte) 0, 0, 1, (short) 1 };
        int[] intArray15 = new int[] { (byte) -1 };
        int[] intArray22 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray22);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray27 = new int[] { (byte) -1 };
        int[] intArray34 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray34);
        int[] intArray37 = new int[] { (byte) -1 };
        int[] intArray44 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray44);
        java.lang.Class<?> wildcardClass46 = intArray37.getClass();
        int[] intArray48 = new int[] { (byte) -1 };
        int[] intArray55 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray55);
        java.lang.Class<?> wildcardClass57 = intArray55.getClass();
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray55);
        int[] intArray60 = new int[] { (byte) -1 };
        int[] intArray67 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray67);
        java.lang.Class<?> wildcardClass69 = intArray60.getClass();
        int[] intArray71 = new int[] { (byte) -1 };
        int[] intArray78 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray78);
        java.lang.Class<?> wildcardClass80 = intArray78.getClass();
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray78);
        int[] intArray83 = new int[] { (byte) -1 };
        int[] intArray90 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray83, intArray90);
        java.lang.Class<?> wildcardClass92 = intArray90.getClass();
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray78, intArray90);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray78);
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray55);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray34);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 118608220 + "'", int24 == 118608220);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.237808892798469E9d + "'", double25 == 2.237808892798469E9d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + (-1021132647) + "'", int96 == (-1021132647));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(104152956928L, (-1608652696L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.3564024076814046E-4d, (-0.9666819391258082d), (double) (-36L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(7890481L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1095479166, 0.5752220392306202d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.02656803100692317d) + "'", double2 == (-0.02656803100692317d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1113831611), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 2.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.4273625532358719E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray29);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray29.getClass();
        double[] doubleArray43 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray49 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 0.0f);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 0.0f);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray66);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.3440585709080678E43d + "'", double33 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 28629151 + "'", int53 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.3440585709080678E43d + "'", double70 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-89), 416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-37024) + "'", int2 == (-37024));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7496154300672659d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.94980040073845d + "'", double1 == 42.94980040073845d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0d, (java.lang.Number) Double.NaN, 98);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 605958124);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(4.0d, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557651d + "'", double1 == 0.7615941559557651d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-32));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.log((-2.6992780116498314E7d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-3395662222958640L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1546572378), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        long long2 = org.apache.commons.math.util.MathUtils.pow(118608255L, 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6265192108622114049L + "'", long2 == 6265192108622114049L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1546572378L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1546572416) + "'", int1 == (-1546572416));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (-32));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1674494048, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.674494048E9d + "'", double2 == 1.674494048E9d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1546572416));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2016339740L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.01633974E9d + "'", double1 == 2.01633974E9d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1073741824));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6173264150460421d + "'", double1 == 0.6173264150460421d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.0033036728937607058d), (-0.9251475365964139d), 0.029989675383798743d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double[] doubleArray2 = new double[] { 0.9999092042625951d, 1.1860822427888854E8d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray10 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray16 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray16);
        double[] doubleArray24 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray30 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray33);
        double[] doubleArray42 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray48 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray56 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray62 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray33);
        double[] doubleArray76 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray82 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) 0.0f);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        int int88 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1860822427888854E8d + "'", double3 == 1.1860822427888854E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 28629151 + "'", int34 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 28629151 + "'", int66 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.1860822427888854E8d + "'", double69 == 1.1860822427888854E8d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 28629151 + "'", int86 == 28629151);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 28629151 + "'", int87 == 28629151);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 28629151 + "'", int88 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 28629175L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8629175E7d + "'", double1 == 2.8629175E7d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1212500306 + "'", int17 == 1212500306);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException11.toString();
        java.lang.Throwable throwable14 = null;
        try {
            nonMonotonousSequenceException11.addSuppressed(throwable14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 605958124);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1434050571), (-1002020285L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1436947761857832735L + "'", long2 == 1436947761857832735L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(5.930411213944417E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-28629141L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 70, (double) 28661240, 0.35635482752298947d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-89), 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-89.0f) + "'", float2 == (-89.0f));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.1415926535897927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.03799291018846901d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03799291018846901d + "'", double2 == 0.03799291018846901d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-106), (float) 1030825251L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-106.0f) + "'", float2 == (-106.0f));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 416);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7436205014573454d + "'", double1 == 3.7436205014573454d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double[] doubleArray4 = new double[] { 6.338253001141147E30d, 30.0f, (-1190133760), 7.456808469171364d };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) 30.0f, (-1190133760), orderDirection10, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection10, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (6,338,253,001,141,147,000,000,000,000,000 > 30)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1546572378) + "'", int5 == (-1546572378));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1546572378) + "'", int6 == (-1546572378));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double2 = org.apache.commons.math.util.FastMath.pow(21.12207245308306d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.1909687824208959d), (double) 118608220);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1909687824208959d) + "'", double2 == (-1.1909687824208959d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 3920342001959040L, 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.27851308876856207d + "'", double2 == 0.27851308876856207d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int2 = org.apache.commons.math.util.FastMath.min(32, (-53));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-53) + "'", int2 == (-53));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1490045366L), 0.5403023058681398d, 5.7233120074752435d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1186082200, 3200, 98);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1095479168L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int2 = org.apache.commons.math.util.FastMath.max((-32), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray23);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 0.0f);
        java.lang.Class<?> wildcardClass48 = doubleArray47.getClass();
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.3440585709080678E43d + "'", double31 == 1.3440585709080678E43d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 28629151 + "'", int49 == 28629151);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4593566380802732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025470578295336027d + "'", double1 == 0.025470578295336027d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean17 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection28, true);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException24.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean37 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.18608224E8f) + "'", number18.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 28629141L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double2 = org.apache.commons.math.util.FastMath.pow(14.703675447601967d, (double) 26316305322681560L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.7278759594743862d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4557519189487724d + "'", double2 == 3.4557519189487724d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 26316305322681560L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-36), (long) 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.20237568556709695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20375993084799743d + "'", double1 == 0.20375993084799743d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-10L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1073741824L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1073741824) + "'", int1 == (-1073741824));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.0789326212358863d, (double) 3200, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        long long2 = org.apache.commons.math.util.FastMath.min((-18L), (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-18L) + "'", long2 == (-18L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray29);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray29.getClass();
        double[] doubleArray43 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray49 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray55 = new double[] { 6.338253001141147E30d, 30.0f, (-1190133760), 7.456808469171364d };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray55);
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.3440585709080678E43d + "'", double33 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1546572378) + "'", int56 == (-1546572378));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray31.getClass();
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        int[] intArray36 = new int[] { (byte) -1 };
        int[] intArray43 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray43);
        int[] intArray47 = new int[] { (byte) -1 };
        int[] intArray54 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray54);
        java.lang.Class<?> wildcardClass56 = intArray47.getClass();
        int[] intArray58 = new int[] { (byte) -1 };
        int[] intArray65 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray65);
        java.lang.Class<?> wildcardClass67 = intArray65.getClass();
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray65);
        try {
            int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9996159447946292d + "'", double1 == 0.9996159447946292d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double1 = org.apache.commons.math.util.FastMath.ceil(7.9042495952004295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5101770449416689d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41222689225952863d + "'", double1 == 0.41222689225952863d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1030825251L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-10L), (long) (-530363774));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5303637740L + "'", long2 == 5303637740L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        long long1 = org.apache.commons.math.util.FastMath.round(1.7278759594743862d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.03799291018846901d, number1, (-36), orderDirection6, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection15, false);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException17.getSuppressed();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection23, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException25.getDirection();
        boolean boolean27 = nonMonotonousSequenceException25.getStrict();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        boolean boolean29 = nonMonotonousSequenceException17.getStrict();
        java.lang.Number number30 = nonMonotonousSequenceException17.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection34, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection40, true);
        java.lang.String str43 = nonMonotonousSequenceException42.toString();
        nonMonotonousSequenceException36.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException42);
        boolean boolean45 = nonMonotonousSequenceException36.getStrict();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        int int48 = nonMonotonousSequenceException17.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(orderDirection26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1.18608224E8f) + "'", number30.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        int int2 = org.apache.commons.math.util.FastMath.max(642915097, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 642915097 + "'", int2 == 642915097);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(990L, (-3395662222958640L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 37352284452545040L + "'", long2 == 37352284452545040L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.3964729204944982d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-888610971) + "'", int1 == (-888610971));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.2736239505345667d), (double) (-118608245L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.27362395053456673d) + "'", double2 == (-0.27362395053456673d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 118608224);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (byte) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 118608224);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (byte) 0);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger29);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 118608224);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger29);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.99563519459755d, 3.990828984128352E20d, 70);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-530363769));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1490045466), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double double2 = org.apache.commons.math.util.FastMath.min(534.4916555247646d, (double) 320);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 320.0d + "'", double2 == 320.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (-0.5752220392306202d));
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.5752220392306202d + "'", double59 == 0.5752220392306202d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1937657580 + "'", int60 == 1937657580);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray31.getClass();
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        int[] intArray36 = new int[] { (byte) -1 };
        int[] intArray43 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        int[] intArray46 = new int[] { (byte) -1 };
        int[] intArray53 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray43);
        int[] intArray60 = new int[] { 98, (-2), (short) 100 };
        try {
            double double61 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean21 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number22 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection32, true);
        java.lang.String str35 = nonMonotonousSequenceException34.toString();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        boolean boolean37 = nonMonotonousSequenceException28.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Class<?> wildcardClass45 = nonMonotonousSequenceException43.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(orderDirection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.18608224E8f) + "'", number22.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str35.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 10, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double double1 = org.apache.commons.math.util.MathUtils.sign(70.55187593126503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-89), 35048061832L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5501233616894985665L + "'", long2 == 5501233616894985665L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1436947761857832735L, (int) (byte) 100, 1078591488);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-530363769), 1.18608255E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray21 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray27 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) 0.0f);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray30);
        try {
            double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 28629151 + "'", int31 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 5075811363987946720L, 28629141, 6305);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.Number number0 = null;
        double[] doubleArray9 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray15 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        java.lang.Class<?> wildcardClass19 = doubleArray15.getClass();
        double[] doubleArray26 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray32 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 0.0f);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray43 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray49 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 0.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray49);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection61, false);
        java.lang.Throwable[] throwableArray64 = nonMonotonousSequenceException63.getSuppressed();
        boolean boolean65 = nonMonotonousSequenceException63.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection69, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = nonMonotonousSequenceException71.getDirection();
        boolean boolean73 = nonMonotonousSequenceException71.getStrict();
        nonMonotonousSequenceException63.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException71);
        java.lang.String str75 = nonMonotonousSequenceException63.toString();
        boolean boolean76 = nonMonotonousSequenceException63.getStrict();
        java.lang.Number number77 = nonMonotonousSequenceException63.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException63.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException80 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-887503592L), 1629445216, orderDirection78, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection78, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException84 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.9E-324d, 4, orderDirection78, false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 28629151 + "'", int36 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.3440585709080678E43d + "'", double53 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(orderDirection72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str75.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + (-1.18608224E8f) + "'", number77.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1752011936438018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 6305);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 79.40403012442127d + "'", double1 == 79.40403012442127d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.03799291018846901d, (double) 605958124);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.269890390720962E-11d + "'", double2 == 6.269890390720962E-11d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray61);
        double[] doubleArray71 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray77 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        double[] doubleArray85 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray91 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, (double) 0.0f);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray94);
        java.lang.Class<?> wildcardClass98 = doubleArray94.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 28629151 + "'", int95 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertNotNull(wildcardClass98);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.2069954852796814d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9345511282111346d + "'", double1 == 0.9345511282111346d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-530363769));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9858540032854514d) + "'", double1 == (-0.9858540032854514d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray18 = new double[] { 6.338253001141147E30d, 30.0f, (-1190133760), 7.456808469171364d };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray18);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1546572378) + "'", int19 == (-1546572378));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.3440585709080678E43d + "'", double21 == 1.3440585709080678E43d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 1436947761857832735L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796325865616d + "'", double1 == 1.570796325865616d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1113831611), 108640);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 227705867358520961L + "'", long2 == 227705867358520961L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection6, false);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        boolean boolean10 = nonMonotonousSequenceException8.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection14, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        boolean boolean18 = nonMonotonousSequenceException16.getStrict();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.String str20 = nonMonotonousSequenceException8.toString();
        boolean boolean21 = nonMonotonousSequenceException8.getStrict();
        java.lang.Number number22 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-887503592L), 1629445216, orderDirection23, false);
        int int26 = nonMonotonousSequenceException25.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(orderDirection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.18608224E8f) + "'", number22.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1629445216 + "'", int26 == 1629445216);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-118608220));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.4330001021490115d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8891251057861819d + "'", double1 == 0.8891251057861819d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6265192108622114049L, (java.lang.Number) 18.59133638445098d, 100);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(18936.712965226587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.65435629815825d + "'", double1 == 26.65435629815825d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 30.0f, (-1190133760), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 30.0f + "'", number6.equals(30.0f));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { (byte) -1 };
        int[] intArray9 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray9);
        java.lang.Class<?> wildcardClass11 = intArray2.getClass();
        int[] intArray13 = new int[] { (byte) -1 };
        int[] intArray20 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray20);
        java.lang.Class<?> wildcardClass22 = intArray20.getClass();
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray20);
        int[] intArray25 = new int[] { (byte) -1 };
        int[] intArray32 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray32);
        java.lang.Class<?> wildcardClass34 = intArray32.getClass();
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray32);
        int[] intArray37 = new int[] { (byte) -1 };
        int[] intArray44 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray44);
        int[] intArray47 = new int[] { (byte) -1 };
        int[] intArray54 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray54);
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999092042625951d, (java.lang.Number) 3.141592653589793d, 32, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22.716225035560587d, (java.lang.Number) 6.338253001141147E30d, 28629240, orderDirection9, true);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException15.getSuppressed();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        boolean boolean19 = nonMonotonousSequenceException15.getStrict();
        java.lang.Number number20 = nonMonotonousSequenceException15.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 22.716225035560587d + "'", number16.equals(22.716225035560587d));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 6.338253001141147E30d + "'", number20.equals(6.338253001141147E30d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-37024), (-1002020285L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 37098799031840L + "'", long2 == 37098799031840L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1405421430), (-2.8135805470149888E16d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        try {
            double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, Double.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        boolean boolean16 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        int int18 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray69);
        double[] doubleArray77 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray83 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) 0.0f);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        try {
            double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray86);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 8.21110255092798d + "'", double70 == 8.21110255092798d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 28629151 + "'", int87 == 28629151);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-37024));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double1 = org.apache.commons.math.util.FastMath.atan(20.646240241504042d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.522399180142575d + "'", double1 == 1.522399180142575d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1405421430), (-1073741824));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int int2 = org.apache.commons.math.util.FastMath.min(100, (-1073741824));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        int int1 = org.apache.commons.math.util.FastMath.abs((-118608186));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 118608186 + "'", int1 == 118608186);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 887503627L, (-32));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2016339740L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6173264150460421d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.549263781399762d + "'", double1 == 0.549263781399762d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-237216448));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.37216448E8d + "'", double1 == 2.37216448E8d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(10, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1076101110) + "'", int2 == (-1076101110));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1120, (long) (-1490045466));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.237808892798469E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.2219102317922d + "'", double1 == 22.2219102317922d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999092042625951d, (java.lang.Number) 3.141592653589793d, 32, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22.716225035560587d, (java.lang.Number) 6.338253001141147E30d, 28629240, orderDirection9, true);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException15.getSuppressed();
        int int18 = nonMonotonousSequenceException15.getIndex();
        java.lang.String str19 = nonMonotonousSequenceException15.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 22.716225035560587d + "'", number16.equals(22.716225035560587d));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 28629240 + "'", int18 == 28629240);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 28,629,239 and 28,629,240 are not strictly decreasing (6,338,253,001,141,147,000,000,000,000,000 <= 22.716)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 28,629,239 and 28,629,240 are not strictly decreasing (6,338,253,001,141,147,000,000,000,000,000 <= 22.716)"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.abs(857.9508725162755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 857.9508725162755d + "'", double1 == 857.9508725162755d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 11013.423843485813d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1076101122);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.48975745438405d + "'", double1 == 21.48975745438405d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray39 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray45 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 0.0f);
        java.lang.Class<?> wildcardClass49 = doubleArray45.getClass();
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray45);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (-0.5752220392306202d));
        double[] doubleArray65 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray71 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 0.0f);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray82 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray88 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray82);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray82);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray82);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray82);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 28629151 + "'", int75 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.3440585709080678E43d + "'", double90 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1011892322 + "'", int91 == 1011892322);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1011892322 + "'", int92 == 1011892322);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.3440585709080678E43d + "'", double93 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.2309908846280704E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(32000, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7953289489023998E20d + "'", double2 == 2.7953289489023998E20d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 2862915100L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1095479168);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1490045466);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.122072470532192d + "'", double1 == 21.122072470532192d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double2 = org.apache.commons.math.util.FastMath.min(0.2833782334517141d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 320, 227705867358520961L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 227705867358521281L + "'", long2 == 227705867358521281L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.FastMath.log(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4337808304830271d + "'", double1 == 0.4337808304830271d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.floor(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1113831611));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.718863221535756d + "'", double1 == 4.718863221535756d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.6267730472324786d), (java.lang.Number) 18.591336386802325d, (int) (short) -1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 18.591336386802325d + "'", number4.equals(18.591336386802325d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1.18608224E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.3012988146633884d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(101.5309649148734d, (double) 3L, (-3.258483699200228E-175d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2676506002282294E30d, 2.1780986680938473E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        long long2 = org.apache.commons.math.util.MathUtils.pow(100L, 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(28629151L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28629151L + "'", long2 == 28629151L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, (-1074790400));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 10, 28629240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 286292400 + "'", int2 == 286292400);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.990828984128352E20d, 1.1860822427888852E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.990828984128351E20d + "'", double2 == 3.990828984128351E20d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5557.690612768985d + "'", double1 == 5557.690612768985d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 28629141);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8629141E7d + "'", double1 == 2.8629141E7d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double1 = org.apache.commons.math.util.FastMath.log(2.7255121382673138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0026563511051316d + "'", double1 == 1.0026563511051316d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-3.6840314986403864d), 3964.7115544948506d, (double) (-99L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10L + "'", number16.equals(10L));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 70);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2577193354595834E30d + "'", double1 == 1.2577193354595834E30d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.61512051684126d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 4, (double) 32L, (-0.4722694785373302d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3L, 37352284452545040L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 37352284452545040L + "'", long2 == 37352284452545040L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection25, false);
        java.lang.Throwable[] throwableArray28 = nonMonotonousSequenceException27.getSuppressed();
        boolean boolean29 = nonMonotonousSequenceException27.getStrict();
        java.lang.Throwable[] throwableArray30 = nonMonotonousSequenceException27.getSuppressed();
        java.lang.Number number31 = nonMonotonousSequenceException27.getArgument();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0f + "'", number19.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.18608224E8f) + "'", number20.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.0f + "'", number31.equals(0.0f));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 990L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double1 = org.apache.commons.math.util.FastMath.log(5.7233120074752435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7445476601088654d + "'", double1 == 1.7445476601088654d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        java.lang.Number number14 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 10L + "'", number14.equals(10L));
        org.junit.Assert.assertNull(orderDirection15);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1030825348L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(3920342001959040L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3920342001959040L + "'", long2 == 3920342001959040L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int int2 = org.apache.commons.math.util.FastMath.min((-1021132647), 416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1021132647) + "'", int2 == (-1021132647));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int int1 = org.apache.commons.math.util.MathUtils.hash(16.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076887552 + "'", int1 == 1076887552);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException5.getArgument();
        boolean boolean16 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(9L, 593040780L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-593040771L) + "'", long2 == (-593040771L));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray21 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray27 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) 0.0f);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 28629151 + "'", int31 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = org.apache.commons.math.util.FastMath.min(605958124, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.223626578289051E21d, 0.45261282001081243d, 32000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        long long2 = org.apache.commons.math.util.FastMath.max(600653219388620033L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 600653219388620033L + "'", long2 == 600653219388620033L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (-3395662222958640L), 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.37216448E8d, (-36));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.398046511102E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.112181583517476d + "'", double1 == 29.112181583517476d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707650767949068d + "'", double1 == 1.5707650767949068d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-106), 593040780L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-593040886L) + "'", long2 == (-593040886L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 7890481L, (-2));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7890500.0f + "'", float2 == 7890500.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        double[] doubleArray9 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray15 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        java.lang.Class<?> wildcardClass19 = doubleArray15.getClass();
        double[] doubleArray26 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray32 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 0.0f);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray43 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray49 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 0.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray49);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection61, false);
        java.lang.Throwable[] throwableArray64 = nonMonotonousSequenceException63.getSuppressed();
        boolean boolean65 = nonMonotonousSequenceException63.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection69, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = nonMonotonousSequenceException71.getDirection();
        boolean boolean73 = nonMonotonousSequenceException71.getStrict();
        nonMonotonousSequenceException63.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException71);
        java.lang.String str75 = nonMonotonousSequenceException63.toString();
        boolean boolean76 = nonMonotonousSequenceException63.getStrict();
        java.lang.Number number77 = nonMonotonousSequenceException63.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException63.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException80 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-887503592L), 1629445216, orderDirection78, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection78, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException84 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) 35048061832L, (int) (short) 10, orderDirection78, false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 28629151 + "'", int36 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.3440585709080678E43d + "'", double53 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(orderDirection72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str75.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + (-1.18608224E8f) + "'", number77.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 35048061832L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5048061832E10d + "'", double1 == 3.5048061832E10d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-887503556L), 2848847076375955649L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-2088681202), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2088681202L + "'", long2 == 2088681202L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1434050571), (-89));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5707962918655727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.810477212938632d + "'", double1 == 4.810477212938632d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 7890481L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '4', 1.1947055233182955d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 112.23250921451573d + "'", double2 == 112.23250921451573d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (short) -1);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray23);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        java.lang.Class<?> wildcardClass50 = doubleArray46.getClass();
        double[] doubleArray57 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray63 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 0.0f);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray74 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray80 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray80);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 0.0f);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray80);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray66);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 7.211102550927978d);
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, (double) (-1.19013376E9f));
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 28629151 + "'", int67 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.3440585709080678E43d + "'", double84 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 7.211102550927978d + "'", double88 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.3440585709080678E43d + "'", double91 == 1.3440585709080678E43d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1608653686), 0.8708497436336323d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8708497436336323d + "'", double2 == 0.8708497436336323d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        long long1 = org.apache.commons.math.util.FastMath.abs(1088898461023600640L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1088898461023600640L + "'", long1 == 1088898461023600640L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.8414709848078944d, (-0.9033391107665127d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.037035976334486E90d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-89), 1.5705423613240965d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-89.0f), 1529.6660781016924d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-88.99999999999999d) + "'", double2 == (-88.99999999999999d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 320);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-3.3771464214718416d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-14.62646701451244d) + "'", double1 == (-14.62646701451244d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-106), (float) 2848847076375955649L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.848847E18f + "'", float2 == 2.848847E18f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-530363774), (java.lang.Number) 7.676039227458498E10d, 1095479166);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.9251475365964139d), 2070104.0287429588d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray61);
        double[] doubleArray71 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray77 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        double[] doubleArray85 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray91 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, (double) 0.0f);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray94);
        try {
            double[] doubleArray99 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray94, (-0.02656803100692317d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 28629151 + "'", int95 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double[] doubleArray70 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray76 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray76);
        double[] doubleArray84 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray90 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray84, doubleArray90);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray90, (double) 0.0f);
        int int94 = org.apache.commons.math.util.MathUtils.hash(doubleArray93);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray93);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray93);
        double[] doubleArray97 = new double[] {};
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray93, doubleArray97);
        try {
            double double99 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 28629151 + "'", int94 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double double1 = org.apache.commons.math.util.FastMath.signum(70.55187593126503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        java.lang.Class<?> wildcardClass30 = doubleArray26.getClass();
        double[] doubleArray37 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray43 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 0.0f);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray54 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray60 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 0.0f);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray60);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray46);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 28629151 + "'", int47 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.3440585709080678E43d + "'", double64 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 118608224);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (byte) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 118608224);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger33);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger33);
        try {
            java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (-28629151L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1076101122);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 52L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 70);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (int) (byte) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger37);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 118608224);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (int) (byte) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger48);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 118608224);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger48);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger48);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger53);
        java.math.BigInteger bigInteger55 = null;
        try {
            java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0099454586078447d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7657394585211276d + "'", double1 == 0.7657394585211276d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (-1021132647));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int int2 = org.apache.commons.math.util.FastMath.max(100, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120 + "'", int2 == 1120);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.4900220109246905d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.47226947853733026d) + "'", double1 == (-0.47226947853733026d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.6173264150460421d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1821461900 + "'", int1 == 1821461900);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(70, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 6062501530L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1095479166, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-593040771L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.93040771E8d) + "'", double1 == (-5.93040771E8d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 0.0f);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray24 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray30 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray30);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray35);
        java.lang.Class<?> wildcardClass37 = doubleArray30.getClass();
        double[] doubleArray44 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray50 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray50);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray61 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray67 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 0.0f);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray67);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray67);
        try {
            double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 28629151 + "'", int17 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.3440585709080678E43d + "'", double34 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 28629151 + "'", int54 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.3440585709080678E43d + "'", double71 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 10L, (double) 65);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.2309908846280704E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.508547968359661E8d + "'", double1 == 3.508547968359661E8d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.49870655758087346d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5196372217252947d + "'", double1 == 0.5196372217252947d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 118608220);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4901161193847656E-8d + "'", double1 == 1.4901161193847656E-8d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1095479166, 1095479168L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.211102550927978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 677.1927304722554d + "'", double1 == 677.1927304722554d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (-0.5752220392306202d));
        double[] doubleArray65 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray71 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        java.lang.Class<?> wildcardClass73 = doubleArray71.getClass();
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray71);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1937657580 + "'", int75 == 1937657580);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1937657580 + "'", int76 == 1937657580);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-37024), 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2591680) + "'", int2 == (-2591680));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 118608224);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (byte) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 118608224);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger33);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger33);
        try {
            java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (-1546572346));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int int1 = org.apache.commons.math.util.MathUtils.sign(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 320, 118608220);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1490045466), 108640);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1546572378));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int int2 = org.apache.commons.math.util.FastMath.min(3200, 28629141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        java.lang.Class<?> wildcardClass54 = doubleArray53.getClass();
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1434050571) + "'", int55 == (-1434050571));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.508547968359661E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.6222301107636228E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.62223011E8d + "'", double1 == 1.62223011E8d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.522399180142575d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-2.37216448E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707962918655727d, 3200.0000000000005d, 1120);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(118608255L, 3920342001959040L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3920341883350785L) + "'", long2 == (-3920341883350785L));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(3.610473652295695d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.672711654883891d) + "'", double2 == (-2.672711654883891d));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7657394585211276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6444451887786965d + "'", double1 == 0.6444451887786965d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 5303637740L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.39165878810078d + "'", double1 == 22.39165878810078d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3087524420351149d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7015529286232827d + "'", double1 == 3.7015529286232827d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-1546572416));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        int int2 = org.apache.commons.math.util.FastMath.max(1030825348, 1212500306);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1212500306 + "'", int2 == 1212500306);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int[] intArray6 = new int[] { 98, ' ', (short) 1, (-1546572378), (-1608653686), 118608255 };
        int[] intArray13 = new int[] { (short) 100, (-118608221), (byte) 0, 0, 1, (short) 1 };
        int[] intArray15 = new int[] { (byte) -1 };
        int[] intArray22 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray22);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray27 = new int[] { (byte) -1 };
        int[] intArray34 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray34);
        int[] intArray37 = new int[] { (byte) -1 };
        int[] intArray44 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray44);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 118608220 + "'", int24 == 118608220);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.237808892798469E9d + "'", double25 == 2.237808892798469E9d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1608653685 + "'", int47 == 1608653685);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 118608256);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1186082200, (-1546572346));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1608653586), (long) (-36));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-36L) + "'", long2 == (-36L));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 6305, 5200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1105L + "'", long2 == 1105L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.4577586472211064E169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1212500306, 1095479168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117021138 + "'", int2 == 117021138);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.03799291018846901d, number1, (-36), orderDirection6, false);
        int int11 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-36) + "'", int11 == (-36));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 34.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9173087126372744E14d + "'", double1 == 2.9173087126372744E14d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean16 = nonMonotonousSequenceException13.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0f + "'", number14.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.990828984128351E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.990828984128352E20d + "'", double1 == 3.990828984128352E20d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) '#', 1.7254630513334037d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.004721557599192018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1546572378), 1076101122);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 887503627L, 3.141592622193598d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5647375583648682d + "'", double2 == 1.5647375583648682d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 5L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.0f + "'", float1 == 5.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1490045466, (long) (-1608653586));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-118608120L) + "'", long2 == (-118608120L));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-14.62646701451244d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1996753450) + "'", int1 == (-1996753450));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(28629151, (-118608186));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.176833405218859d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.475409572023599d + "'", double1 == 1.475409572023599d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 416, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-53.0f), (-0.47226947853733026d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.73451754256331d) + "'", double2 == (-2.73451754256331d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1120, (-0.4991311460098435d), 18.59133665424674d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-3395662222958640L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray61);
        double[] doubleArray65 = new double[] {};
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection71, false);
        java.lang.Throwable[] throwableArray74 = nonMonotonousSequenceException73.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException80 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection78, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection84, false);
        nonMonotonousSequenceException80.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException86);
        java.lang.Number number88 = nonMonotonousSequenceException86.getArgument();
        nonMonotonousSequenceException73.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException86);
        boolean boolean90 = nonMonotonousSequenceException73.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = nonMonotonousSequenceException73.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection91, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray74);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number88 + "' != '" + 0.0f + "'", number88.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + orderDirection91 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection91.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-1190133760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean17 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection28, true);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException24.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Number number35 = nonMonotonousSequenceException24.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.18608224E8f) + "'", number18.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 100.0f + "'", number35.equals(100.0f));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(320);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 34L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double1 = org.apache.commons.math.util.FastMath.signum(7.456808469171364d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-3395662222958640L), 3200L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 118608224);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }
}

