import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.223626578289051E21d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9554156163191374E213d + "'", double2 == 2.9554156163191374E213d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 118608255);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.sin(101.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078944d + "'", double1 == 0.8414709848078944d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1073741824));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1073741824) + "'", int1 == (-1073741824));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.log(1.1860822427888852E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.591336386802322d + "'", double1 == 18.591336386802322d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        java.lang.String str15 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0f + "'", number13.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 28629151L, 22.716225035560587d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4577586472211064E169d + "'", double2 == 2.4577586472211064E169d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.9604644775390625E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1113831611), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray21 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray27 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) 0.0f);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray30);
        double[] doubleArray39 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray45 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double[] doubleArray53 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray59 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 0.0f);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray62);
        double[] doubleArray66 = new double[] {};
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray66);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray66);
        double[] doubleArray76 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray82 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) 0.0f);
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray85);
        try {
            double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (-0.4991311460098435d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 28629151 + "'", int31 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 28629151 + "'", int63 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0437346740099507d + "'", double1 == 1.0437346740099507d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1608653686));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.2676506002282294E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-118608221), (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1011892322);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 990L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99563519459755d + "'", double1 == 2.99563519459755d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        long long1 = org.apache.commons.math.util.FastMath.abs(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.9541180407703d + "'", double1 == 349.9541180407703d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 118608255L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 491.3281405524724d + "'", double1 == 491.3281405524724d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-887503592L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1212500306, 98);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.96046465517475E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.960464655174742E-8d + "'", double1 == 5.960464655174742E-8d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 916132832L, (-1073741824));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.16132832E8d + "'", double2 == 9.16132832E8d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.math.util.MathUtils.log(10.0d, (double) (-34L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-32), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32) + "'", int2 == (-32));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 118608255L, 52, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.223626578289051E21d, 305.9164444997882d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9033391107665127d) + "'", double1 == (-0.9033391107665127d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 1030825348);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        float float2 = org.apache.commons.math.util.FastMath.max(1.07610112E9f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1608653686), 990L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1608652696L) + "'", long2 == (-1608652696L));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int2 = org.apache.commons.math.util.FastMath.min(118608220, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 35, (-887503592L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 887503627L + "'", long2 == 887503627L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 887503627L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3628800.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1095479168 + "'", int1 == 1095479168);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1076101120, (-1546572378));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        java.lang.Class<?> wildcardClass54 = doubleArray53.getClass();
        double[] doubleArray55 = null;
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 34L, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 320, (float) 1120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1120.0f + "'", float2 == 1120.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 28661240);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10L, 990L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-2), 0.0d, 0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-2.8629152E7f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-887503592L), (long) (-36));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-887503556L) + "'", long2 == (-887503556L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(62.95376037989951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-887503556L), (long) (-53));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1030825348, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1030825348L + "'", long2 == 1030825348L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(18.59133665424674d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(2016339740L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8342233605065102d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(118608156L, (long) (-237216448));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28135805470149888L) + "'", long2 == (-28135805470149888L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double2 = org.apache.commons.math.util.MathUtils.log((-4.9E-324d), 0.01923076923076924d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(34, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.5625799401208676d, 0.2833782334517141d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.8708497436336323d, 0.9795918367346939d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 30.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1113831611));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.11383155E9f + "'", float1 == 1.11383155E9f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(18.591336386802322d, (double) 1.18608218E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.591336386802325d + "'", double2 == 18.591336386802325d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1186082200, (-1546572378));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-53), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-17.80422716567731d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.029989675383798743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.029985180230424707d + "'", double1 == 0.029985180230424707d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int int1 = org.apache.commons.math.util.FastMath.abs(118608255);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 118608255 + "'", int1 == 118608255);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        int int22 = nonMonotonousSequenceException11.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0f + "'", number19.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.18608224E8f) + "'", number20.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 97 + "'", int22 == 97);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.exp(9.848857801796106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18936.712965226587d + "'", double1 == 18936.712965226587d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.2609727597150384d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.123701912297712d) + "'", double1 == (-3.123701912297712d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray61);
        double[] doubleArray65 = new double[] {};
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        try {
            double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.9033391107665127d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9666819391258082d) + "'", double1 == (-0.9666819391258082d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.tan(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2736239505345667d) + "'", double1 == (-0.2736239505345667d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.18608224E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.acos(153.97436846011828d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1608653686));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.cosh(18.591336386802322d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.930411213944417E7d + "'", double1 == 5.930411213944417E7d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.237808892798469E9d, (double) (-10L), 32000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray31.getClass();
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        int[] intArray36 = new int[] { (byte) -1 };
        int[] intArray43 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        int[] intArray46 = new int[] { (byte) -1 };
        int[] intArray53 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray43);
        int[] intArray57 = null;
        try {
            int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) ' ', (-2), 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438018d + "'", double1 == 1.1752011936438018d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 28629141);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.42242003352433E-103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.42242003352433E-103d + "'", double1 == 1.42242003352433E-103d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.abs(320.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 320.0d + "'", double1 == 320.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 0.0f);
        java.lang.Class<?> wildcardClass17 = doubleArray13.getClass();
        double[] doubleArray24 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray30 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray47 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 0.0f);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray47);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray33);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 7.211102550927978d);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (-1.19013376E9f));
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 28629151 + "'", int34 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.3440585709080678E43d + "'", double51 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 7.211102550927978d + "'", double55 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1), 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-118608221), (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (-0.5752220392306202d));
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double1 = org.apache.commons.math.util.FastMath.abs(534.4916555247646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 534.4916555247646d + "'", double1 == 534.4916555247646d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1073741824L), (long) 28629151);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-30740316814311424L) + "'", long2 == (-30740316814311424L));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0d, (java.lang.Number) Double.NaN, 98);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        boolean boolean13 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7233154714075614d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7496154300672659d + "'", double1 == 0.7496154300672659d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 35, 8.21110255092798d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { (byte) -1 };
        int[] intArray9 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray9);
        java.lang.Class<?> wildcardClass11 = intArray2.getClass();
        int[] intArray13 = new int[] { (byte) -1 };
        int[] intArray20 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray20);
        java.lang.Class<?> wildcardClass22 = intArray20.getClass();
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray20);
        int[] intArray25 = new int[] { (byte) -1 };
        int[] intArray32 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray32);
        java.lang.Class<?> wildcardClass34 = intArray32.getClass();
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray32);
        int[] intArray37 = new int[] { (byte) -1 };
        int[] intArray44 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray44);
        try {
            int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1490045466));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2704 + "'", int2 == 2704);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-0.8853134509493964d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(28629175L, (-237216448));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.4991311460098435d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5201157597405306d) + "'", double1 == (-0.5201157597405306d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000036d + "'", double1 == 1.0000000000000036d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.18608245E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.18608245E8d + "'", double1 == 1.18608245E8d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-887503592L), (long) (-2088681202));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.0033036728937607058d), (-307.6526555685888d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-2088681202), 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1030825348L, 2.2856585006921635d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.990828984128352E20d + "'", double2 == 3.990828984128352E20d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-1190133760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1190133760) + "'", int2 == (-1190133760));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.9E-324d) + "'", double1 == (-4.9E-324d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.384185791015625E-7d, 1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.029613460430559936d) + "'", double2 == (-0.029613460430559936d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.830951894845301d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9999092042625951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999546011007675d + "'", double1 == 0.9999546011007675d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.20237568556709695d, (java.lang.Number) 0L, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.20237568556709695d + "'", number4.equals(0.20237568556709695d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.725290298461914E-9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.99563519459755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2104868485710067d) + "'", double1 == (-2.2104868485710067d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(28629151, 28629240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-89) + "'", int2 == (-89));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 99, (long) 28629240);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28629141L) + "'", long2 == (-28629141L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 26316305322681560L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6222301107636228E8d + "'", double1 == 1.6222301107636228E8d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray24.getClass();
        int[] intArray35 = new int[] { (byte) -1 };
        int[] intArray42 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray42);
        java.lang.Class<?> wildcardClass44 = intArray42.getClass();
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray42);
        int[] intArray47 = new int[] { (byte) -1 };
        int[] intArray54 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray54);
        java.lang.Class<?> wildcardClass56 = intArray54.getClass();
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray54);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray42);
        int[] intArray61 = new int[] { (byte) 1, (-1546572378) };
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.0d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4593566380802732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2677879318469856d + "'", double1 == 2.2677879318469856d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.02720913096084206d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1629445216 + "'", int1 == 1629445216);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.01923076923076924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3564024076814046E-4d + "'", double1 == 3.3564024076814046E-4d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 10, (float) 1030825348);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.03082534E9f + "'", float2 == 1.03082534E9f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 'a', (long) (-1073741824));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104152956928L + "'", long2 == 104152956928L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.8148436360867664d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5625799401208676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5124501842629651d + "'", double1 == 0.5124501842629651d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.456808469171364d, 0.20237568556709695d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5436632683584697d + "'", double2 == 1.5436632683584697d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 32L, (double) 118608156L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.447693680631751d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 857.9508725162755d + "'", double1 == 857.9508725162755d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4210854715202004E-14d, 2.6171775302701263d, 5.234185770515822E-4d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int1 = org.apache.commons.math.util.FastMath.abs(1030825348);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1030825348 + "'", int1 == 1030825348);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int int2 = org.apache.commons.math.util.FastMath.max((-89), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2), 1095479168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1095479166 + "'", int2 == 1095479166);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.atan(153.97436846011828d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5643018306624046d + "'", double1 == 1.5643018306624046d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.176833405218859d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.442925725710415d) + "'", double1 == (-1.442925725710415d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 320);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(34, (long) (-89));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591488 + "'", int1 == 1078591488);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1113831611));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.11383155E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1490045466));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1076101120, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101122 + "'", int2 == 1076101122);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.2677879318469856d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-89), (-1608653686));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.812644285236262E-103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.812644285236262E-103d + "'", double1 == 2.812644285236262E-103d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.exp(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-118608220), 118608255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 118608224);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6328096796422548d + "'", double1 == 0.6328096796422548d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-2088681202));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(100L, (-4441386545051598848L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4441386545051598748L) + "'", long2 == (-4441386545051598748L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 28629151L, 349.9541180407703d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3411662132536345d + "'", double2 == 0.3411662132536345d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        boolean boolean13 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(28629151, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 104152956928L, (float) 1629445216);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.62944525E9f + "'", float2 == 1.62944525E9f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection10, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number22 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException18.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.0f + "'", number22.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.18608224E8f) + "'", number23.equals((-1.18608224E8f)));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.expm1(52.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716604E22d + "'", double1 == 3.831008000716604E22d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0950671531879624E27d, (java.lang.Number) (-320L), 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (-320 >= 1,095,067,153,187,962,400,000,000,000)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (-320 >= 1,095,067,153,187,962,400,000,000,000)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (-320 >= 1,095,067,153,187,962,400,000,000,000)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (-320 >= 1,095,067,153,187,962,400,000,000,000)"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean21 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number22 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection32, true);
        java.lang.String str35 = nonMonotonousSequenceException34.toString();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        boolean boolean37 = nonMonotonousSequenceException28.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number45 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(orderDirection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.18608224E8f) + "'", number22.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str35.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 1.18608224E8d + "'", number45.equals(1.18608224E8d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 2848847076375955649L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35635482752298947d + "'", double1 == 0.35635482752298947d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double2 = org.apache.commons.math.util.FastMath.min(1.7998921637913432d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1608653686), 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.4901161193847656E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4901161193847655E-8d + "'", double1 == 1.4901161193847655E-8d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-118608245L), 306.0d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        long long1 = org.apache.commons.math.util.FastMath.abs(118608255L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 118608255L + "'", long1 == 118608255L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-4441386545051598848L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1546572378));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 990L, (java.lang.Number) 98, (-1434050571));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-36));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-36L) + "'", long1 == (-36L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1947055233182955d + "'", double1 == 1.1947055233182955d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.908990346477531E-105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.908990346477532E-105d + "'", double1 == 4.908990346477532E-105d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07610112E9d + "'", double1 == 1.07610112E9d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double2 = org.apache.commons.math.util.FastMath.max(2.1504937134529085E44d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1504937134529085E44d + "'", double2 == 2.1504937134529085E44d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2704, (long) 28629141);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 77413197264L + "'", long2 == 77413197264L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger9 = null;
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.7182818284590455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.45029678472541d + "'", double1 == 98.45029678472541d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.908990346477531E-105d, 55.850536063818545d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.908990346477532E-105d + "'", double2 == 4.908990346477532E-105d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.154434690031884d, 2704);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.44184823419093E197d) + "'", double2 == (-6.44184823419093E197d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int2 = org.apache.commons.math.util.FastMath.min(1011892322, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-118608186), (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 77413197264L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5707963267948966d, 1.5707962918655727d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1546572378), 5L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1674494048 + "'", int2 == 1674494048);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1, (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.0d), (int) (short) 0, 320);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1546572378), (-28629151L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(77413197264L, (-237216448));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-53L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.644483341943246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6684472092677387d + "'", double1 == 1.6684472092677387d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double2 = org.apache.commons.math.util.FastMath.min(19.2844837420644d, (double) (-118608245L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.18608245E8d) + "'", double2 == (-1.18608245E8d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.017453292519943295d, (int) (short) -1, (-1190133760));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.5403023058681399d, (-0.7741134543031625d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection20, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean31 = nonMonotonousSequenceException22.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(orderDirection33);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.029989675383798743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.029989675383798743d + "'", double1 == 0.029989675383798743d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 28629141, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28629141L + "'", long2 == 28629141L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-237216448));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1074790400), 118608224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        int int1 = org.apache.commons.math.util.MathUtils.hash(6.165605250530094E10d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 605958124 + "'", int1 == 605958124);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(11013.232874703393d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1909687824208959d) + "'", double2 == (-1.1909687824208959d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.6222301107636228E8d, 70);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6222301107636228E8d + "'", double2 == 1.6222301107636228E8d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1546572378L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.86120699709114E10d) + "'", double1 == (-8.86120699709114E10d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1095479168, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 636.3698433827307d + "'", double2 == 636.3698433827307d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double2 = org.apache.commons.math.util.FastMath.max(11013.423843485813d, 3628800.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3628800.0d + "'", double2 == 3628800.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, (long) 28629240);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-320L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.408020843150437E11d + "'", double1 == 6.408020843150437E11d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.expm1(19.2844837420644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3721648899999958E8d + "'", double1 == 2.3721648899999958E8d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-118608245L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.3440585709080678E43d, 4.3980465111023286E12d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-36));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 36.0f + "'", float1 == 36.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.1138316131195753E9d), (-0.4991311460098435d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1434050571), (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1434050571L + "'", long2 == 1434050571L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-36), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-6.44184823419093E197d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1076101122);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(28629141, 32000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3964.7115544948506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 69.19727051779773d + "'", double1 == 69.19727051779773d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 28629141L, (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.812644285236262E-103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.asin(11013.423843485813d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-53L), (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7890481L + "'", long2 == 7890481L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) ' ', (-1490045466));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9033391107665127d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.427362553235872E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) ' ', 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120 + "'", int2 == 1120);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 118608224);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2070104.0287429588d + "'", double1 == 2070104.0287429588d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1095479166);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999092042625951d, (java.lang.Number) 3.141592653589793d, 32, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22.716225035560587d, (java.lang.Number) 6.338253001141147E30d, 28629240, orderDirection12, true);
        java.lang.Class<?> wildcardClass19 = orderDirection12.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1.4330001021490115d, (int) (short) 0, orderDirection12, true);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 0, (long) 1095479168);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1095479168L + "'", long2 == 1095479168L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, (-1190133760));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1095479168);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 32L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.03799291018846901d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-32));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-118608186), (-36));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.7278759594743862d, (-2088681202), 1076101120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-307.6526555685888d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1095479168, (long) 28629240);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3920342001959040L + "'", long2 == 3920342001959040L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.log((-35.99999999999999d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.0d, (double) 1212500306);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 7890481L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection10, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection25, false);
        java.lang.Throwable[] throwableArray28 = nonMonotonousSequenceException27.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection38, false);
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.Number number42 = nonMonotonousSequenceException40.getArgument();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.String str44 = nonMonotonousSequenceException40.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.Number number46 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0f + "'", number42.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.0f + "'", number46.equals(0.0f));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 3920342001959040L, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.92034200195904E15d + "'", double2 == 3.92034200195904E15d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1546572378L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9341334322691035d + "'", double1 == 0.9341334322691035d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1.03082534E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7991296265803173E7d + "'", double1 == 1.7991296265803173E7d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 605958124);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.log10(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.041914822473389d + "'", double1 == 4.041914822473389d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 1.7182818284590453d);
        double[] doubleArray65 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray71 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 0.0f);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray74);
        java.lang.Number number77 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number77, (java.lang.Number) 30.0f, (-1190133760), orderDirection80, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection80, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (0 > -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 7.211102550927978d + "'", double76 == 7.211102550927978d);
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 3200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3200.0000000000005d + "'", double1 == 3200.0000000000005d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.029989675383798743d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray12.getClass();
        int[] intArray23 = new int[] { (byte) -1 };
        int[] intArray30 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray30);
        java.lang.Class<?> wildcardClass32 = intArray30.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray30);
        int[] intArray35 = new int[] { (byte) -1 };
        int[] intArray42 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray42);
        java.lang.Class<?> wildcardClass44 = intArray35.getClass();
        int[] intArray46 = new int[] { (byte) -1 };
        int[] intArray53 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray53);
        java.lang.Class<?> wildcardClass55 = intArray53.getClass();
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray53);
        int[] intArray58 = new int[] { (byte) -1 };
        int[] intArray65 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray65);
        java.lang.Class<?> wildcardClass67 = intArray65.getClass();
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray53);
        int[] intArray71 = new int[] { (byte) -1 };
        int[] intArray78 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray78);
        java.lang.Class<?> wildcardClass80 = intArray71.getClass();
        int[] intArray82 = new int[] { (byte) -1 };
        int[] intArray89 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray89);
        java.lang.Class<?> wildcardClass91 = intArray89.getClass();
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray89);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray89);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray53);
        int[] intArray95 = null;
        try {
            int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 100L, 98, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 9.1613286E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.831008000716604E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.583313058969097d + "'", double1 == 22.583313058969097d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.8708497436336323d, 1076101120, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(17.1699391311404d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.431462000000001E7d + "'", double1 == 1.431462000000001E7d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 887503627L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 960.9999805093762d + "'", double1 == 960.9999805093762d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        java.lang.Class<?> wildcardClass18 = doubleArray12.getClass();
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (-1546572378));
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= -1,546,572,378)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double2 = org.apache.commons.math.util.FastMath.max(11013.232920103324d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232920103324d + "'", double2 == 11013.232920103324d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double2 = org.apache.commons.math.util.FastMath.pow((-17.80422716567731d), 2.2250738585072014E-308d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(118608220);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0864771021954992E9d + "'", double1 == 2.0864771021954992E9d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 118608156L, 99);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(18334.649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18334.649444186347d + "'", double1 == 18334.649444186347d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(70, (-53));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int2 = org.apache.commons.math.util.FastMath.min(99, 3200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray69);
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 8.21110255092798d + "'", double70 == 8.21110255092798d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1434050571) + "'", int71 == (-1434050571));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray29);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        java.lang.Class<?> wildcardClass50 = doubleArray46.getClass();
        double[] doubleArray57 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray63 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 0.0f);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray74 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray80 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray80);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 0.0f);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray80);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray66);
        java.lang.Class<?> wildcardClass86 = doubleArray46.getClass();
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.3440585709080678E43d + "'", double33 == 1.3440585709080678E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 28629151 + "'", int67 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.3440585709080678E43d + "'", double84 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.3440585709080678E43d + "'", double87 == 1.3440585709080678E43d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-8.86120699709114E10d), 1186082200);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.258483699200228E-175d) + "'", double2 == (-3.258483699200228E-175d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { (byte) -1 };
        int[] intArray9 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray9);
        java.lang.Class<?> wildcardClass11 = intArray2.getClass();
        int[] intArray13 = new int[] { (byte) -1 };
        int[] intArray20 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray20);
        java.lang.Class<?> wildcardClass22 = intArray20.getClass();
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray20);
        int[] intArray25 = new int[] { (byte) -1 };
        int[] intArray32 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray32);
        java.lang.Class<?> wildcardClass34 = intArray25.getClass();
        int[] intArray36 = new int[] { (byte) -1 };
        int[] intArray43 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        java.lang.Class<?> wildcardClass45 = intArray43.getClass();
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray43);
        int[] intArray48 = new int[] { (byte) -1 };
        int[] intArray55 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray55);
        java.lang.Class<?> wildcardClass57 = intArray55.getClass();
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray55);
        int[] intArray60 = new int[] { (byte) -1 };
        int[] intArray67 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray55);
        try {
            int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1076101122);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 52L);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 26316305322681560L, 0.20237568556709695d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20237568556709695d + "'", double2 == 0.20237568556709695d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((-28135805470149888L), (long) 1674494048);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 70, (double) (-53));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.218853212725411d + "'", double2 == 2.218853212725411d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2016339740L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49870655758087346d + "'", double1 == 0.49870655758087346d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double2 = org.apache.commons.math.util.FastMath.min(18.591336386802325d, 1.5705423613240965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5705423613240965d + "'", double2 == 1.5705423613240965d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) (-1.0d), 28629151);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable throwable7 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800507E-15d + "'", double1 == 3.552713678800507E-15d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.8629152E7d), (java.lang.Number) 6.691673596021348E41d, (-2088681202));
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1490045466), 2.6171775302701263d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.490045466E9d) + "'", double2 == (-1.490045466E9d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1072693248, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0726932479999999E9d + "'", double2 == 1.0726932479999999E9d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5606956602095747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621329194890567d + "'", double1 == 3.7621329194890567d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int2 = org.apache.commons.math.util.FastMath.max((-1190133760), 1076101122);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101122 + "'", int2 == 1076101122);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-118608220));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.9666819391258082d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(320, 28629240);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.908990346477531E-105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.029985180230424707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02998068709802318d + "'", double1 == 0.02998068709802318d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 5, 118608156L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 593040780L + "'", long2 == 593040780L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double2 = org.apache.commons.math.util.FastMath.max(1354.3847226018647d, 2.2124676738864985E28d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2124676738864985E28d + "'", double2 == 2.2124676738864985E28d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1095479168);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1608653686), (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 2);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.acos(3200.0000000000005d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1546572378), (-1490045466));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1212500306, (-34L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-2088681202));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-118608221));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-118608224) + "'", int1 == (-118608224));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.FastMath.atanh(11013.423843485813d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.log10(70.55187593126503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8485085658687572d + "'", double1 == 1.8485085658687572d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 118608224);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) (byte) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 118608224);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger19);
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(5L, (long) 1212500306);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6062501530L + "'", long2 == 6062501530L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1), 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-53L) + "'", long2 == (-53L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray11 = new int[] { (byte) -1 };
        int[] intArray18 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray18);
        java.lang.Class<?> wildcardClass20 = intArray11.getClass();
        int[] intArray22 = new int[] { (byte) -1 };
        int[] intArray29 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray29);
        java.lang.Class<?> wildcardClass31 = intArray29.getClass();
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray29);
        int[] intArray34 = new int[] { (byte) -1 };
        int[] intArray41 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray41);
        java.lang.Class<?> wildcardClass43 = intArray41.getClass();
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray41);
        int[] intArray46 = new int[] { (byte) -1 };
        int[] intArray53 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray53);
        int[] intArray56 = new int[] { (byte) -1 };
        int[] intArray63 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray63);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray63);
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray63);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 0.0f);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray24 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray30 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray30);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 28629151 + "'", int17 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.3440585709080678E43d + "'", double34 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray21 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray27 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) 0.0f);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray30);
        double[] doubleArray39 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray45 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double[] doubleArray53 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray59 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 0.0f);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray62);
        double[] doubleArray66 = new double[] {};
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray66);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray66);
        double[] doubleArray76 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray82 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) 0.0f);
        java.lang.Class<?> wildcardClass86 = doubleArray85.getClass();
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray85);
        java.lang.Class<?> wildcardClass89 = doubleArray66.getClass();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 28629151 + "'", int31 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 28629151 + "'", int63 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 28629151 + "'", int87 == 28629151);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass89);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.exp(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319346946E42d + "'", double1 == 9.889030319346946E42d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 118608255, (-53));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(593040780L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.FastMath.asinh(18334.649444186347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.509695142138224d + "'", double1 == 10.509695142138224d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.388939977821737d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        long long1 = org.apache.commons.math.util.FastMath.round(0.1961677171948711d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.3980465111023286E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.398046511102E12d + "'", double1 == 4.398046511102E12d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        long long1 = org.apache.commons.math.util.FastMath.round((-18.064852370988632d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-18L) + "'", long1 == (-18L));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int int2 = org.apache.commons.math.util.MathUtils.pow(32, 28629240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 1.4593566380802732d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2236022912706814d, 2.2873554892516914d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2L, 17.1699391311404d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 147457.44418529558d + "'", double2 == 147457.44418529558d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 0, 28661240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1608653686), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1608653586) + "'", int2 == (-1608653586));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int1 = org.apache.commons.math.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray29);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray29.getClass();
        double[] doubleArray43 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray49 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 0.0f);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 0.0f);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException77 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection75, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection75, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (-1 <= 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.3440585709080678E43d + "'", double33 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 28629151 + "'", int53 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.3440585709080678E43d + "'", double70 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1011892322, (long) 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 887503627L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5625799401208675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7551949618496253d + "'", double1 == 0.7551949618496253d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-89));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5101770449416689d + "'", double1 == 0.5101770449416689d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 0, (-32));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1434050571));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(320);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1529.6660781016924d + "'", double1 == 1529.6660781016924d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int2 = org.apache.commons.math.util.FastMath.max(1076101120, (-1546572346));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101120 + "'", int2 == 1076101120);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.asin(7.447693680631751d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-53L), 20.646240241504042d, 5.930412799999998E7d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7867071229411882d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7061806015116946d + "'", double1 == 0.7061806015116946d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1113831611), 52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.373491181781864d + "'", double1 == 10.373491181781864d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 118608156L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.990828984128352E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-2088681202));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.08868122E9f + "'", float1 == 2.08868122E9f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, (-53));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-106) + "'", int2 == (-106));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 118608224);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (byte) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 118608224);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger18);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) (byte) 0);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger30);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 118608224);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0L);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (int) (byte) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger41);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 118608224);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger41);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger41);
        try {
            java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (-1608653586));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03490658503988659d + "'", double1 == 0.03490658503988659d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-32));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1546572346));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-2088681202));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) '#', (long) 28661240);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200628680L + "'", long2 == 200628680L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1.19013376E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5597083663815732d + "'", double1 == 0.5597083663815732d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int2 = org.apache.commons.math.util.FastMath.max((-53), (-1608653586));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-53) + "'", int2 == (-53));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-106), (-106), 1629445216);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray31.getClass();
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        int[] intArray36 = new int[] { (byte) -1 };
        int[] intArray43 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray43);
        int[] intArray47 = new int[] { (byte) -1 };
        int[] intArray54 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray54);
        java.lang.Class<?> wildcardClass56 = intArray47.getClass();
        int[] intArray58 = new int[] { (byte) -1 };
        int[] intArray65 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray65);
        java.lang.Class<?> wildcardClass67 = intArray65.getClass();
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray65);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int1 = org.apache.commons.math.util.MathUtils.sign(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int2 = org.apache.commons.math.util.FastMath.min(1095479166, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-4441386545051598848L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.4413865450515988E18d + "'", double1 == 4.4413865450515988E18d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.0864771021954992E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double1 = org.apache.commons.math.util.FastMath.tanh(17.1699391311404d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999976d + "'", double1 == 0.9999999999999976d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-50.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1068957696) + "'", int1 == (-1068957696));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-237216448), (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 30.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double double1 = org.apache.commons.math.util.FastMath.log1p(18.59133665424674d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.975087461085999d + "'", double1 == 2.975087461085999d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.338253001141147E30d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-887503592L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        float float2 = org.apache.commons.math.util.MathUtils.round(30.0f, 1095479166);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        long long2 = org.apache.commons.math.util.MathUtils.pow(990L, (long) 1186082200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1113831611), (long) 98);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 642915097 + "'", int2 == 642915097);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray24.getClass();
        int[] intArray35 = new int[] { (byte) -1 };
        int[] intArray42 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray42);
        java.lang.Class<?> wildcardClass44 = intArray42.getClass();
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray42);
        int[] intArray47 = new int[] { (byte) -1 };
        int[] intArray54 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray54);
        int[] intArray57 = new int[] { (byte) -1 };
        int[] intArray64 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray64);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray64);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, 1030825348);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1095479168);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1095479168 + "'", int1 == 1095479168);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1113831611), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4645918875615231d + "'", double1 == 1.4645918875615231d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 34, (long) (-1546572378));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1546572378L) + "'", long2 == (-1546572378L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.00000000000001d, (java.lang.Number) 28629240, 52, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.03082534E9f, (java.lang.Number) 97L, 0, orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.930411213944417E7d, 0.9998150944560208d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.9304112139444165E7d + "'", double2 == 5.9304112139444165E7d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.9999546011007675d, 118608220);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.733486234193786E104d + "'", double2 == 5.733486234193786E104d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.FastMath.tan(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.5045996724326973d) + "'", double1 == (-2.5045996724326973d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1073741824), (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.037035976334486E90d + "'", double2 == 2.037035976334486E90d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(100, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1120.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.714231344147495d + "'", double1 == 7.714231344147495d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double1 = org.apache.commons.math.util.FastMath.atan(320.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5676713369673632d + "'", double1 == 1.5676713369673632d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double2 = org.apache.commons.math.util.FastMath.atan2(69.19727051779773d, 19.2844837420644d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2990041880233025d + "'", double2 == 1.2990041880233025d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108640 + "'", int2 == 108640);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999092042625951d, (java.lang.Number) 3.141592653589793d, 32, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22.716225035560587d, (java.lang.Number) 6.338253001141147E30d, 28629240, orderDirection9, true);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.String str17 = nonMonotonousSequenceException15.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 22.716225035560587d + "'", number16.equals(22.716225035560587d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 28,629,239 and 28,629,240 are not strictly decreasing (6,338,253,001,141,147,000,000,000,000,000 <= 22.716)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 28,629,239 and 28,629,240 are not strictly decreasing (6,338,253,001,141,147,000,000,000,000,000 <= 22.716)"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(3200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22631.853901740316d + "'", double1 == 22631.853901740316d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 28629151, (long) (-237216448));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double2 = org.apache.commons.math.util.FastMath.max(2.6881171418161356E43d, 0.9999546011007675d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (byte) 0);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 1.5430806348152437d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.00000000000001d, (java.lang.Number) 28629240, 52, orderDirection22, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection22, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) (-237216448));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.37216448E8f) + "'", float2 == (-2.37216448E8f));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean21 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number22 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection32, true);
        java.lang.String str35 = nonMonotonousSequenceException34.toString();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        boolean boolean37 = nonMonotonousSequenceException28.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(orderDirection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.18608224E8f) + "'", number22.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str35.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.7278759594743862d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7255121382673138d + "'", double1 == 2.7255121382673138d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 642915097);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.433780830483027d) + "'", double1 == (-1.433780830483027d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.141592653589793d, 5.9604644775390625E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926535897927d + "'", double2 == 3.1415926535897927d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-320L), (double) 1011892322, 4.398046511104E12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998151400298467d + "'", double1 == 0.9998151400298467d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.01923076923076924d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.7657394585211276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0099454586078447d + "'", double1 == 1.0099454586078447d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0437346740099507d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1074790400), 2.1780986680938473E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747903999999998E9d) + "'", double2 == (-1.0747903999999998E9d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 10, (long) (-1434050571));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1434050581L + "'", long2 == 1434050581L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1073741824), 3920342001959040L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 990L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-118608186), (long) 28629240);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3395662222958640L) + "'", long2 == (-3395662222958640L));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9999092042625951d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(Float.POSITIVE_INFINITY, 0, (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.3012989023072943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3619730303123128d + "'", double1 == 0.3619730303123128d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 98, 887503627L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.302585092994046d, 0.5101770449416689d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3527517838398029d + "'", double2 == 1.3527517838398029d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double1 = org.apache.commons.math.util.FastMath.cos((-18.064852370988632d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.70759777601678d + "'", double1 == 0.70759777601678d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 108640);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 108640 + "'", int1 == 108640);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, number1, 32000);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0L, (-36));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1490045466));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.49004544E9f + "'", float1 == 1.49004544E9f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 5, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.03799291018846901d, number1, (-36), orderDirection6, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.03799291018846901d + "'", number11.equals(0.03799291018846901d));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.714231344147495d, (double) 5L, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1860822427888852E8d, 1.1860822427888852E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1860822427888852E8d + "'", double2 == 1.1860822427888852E8d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9999999999999998d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999998d + "'", double1 == 0.9999999999999998d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(97, (-32));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 916132832L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1, 118608255, orderDirection25, true);
        boolean boolean28 = nonMonotonousSequenceException27.getStrict();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0f + "'", number19.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.18608224E8f) + "'", number20.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1490045466));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1490045466 + "'", int1 == 1490045466);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1030825348L, (long) (-2));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 97L, 1.344058570908068E43d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }
}

