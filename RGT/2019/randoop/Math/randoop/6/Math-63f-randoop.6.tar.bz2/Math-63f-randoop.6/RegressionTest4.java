import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.8556343548213666d, (double) 28629141, 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 118608224, 3200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double double1 = org.apache.commons.math.util.FastMath.cosh(18936.712965226587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-530363774), 1030825348);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) '4', 10.373491181781864d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3738909928169887d + "'", double2 == 1.3738909928169887d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.5201157597405306d), 1.42242003352433E-103d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5101770449416689d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.6729974665608759d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6233326730343048d) + "'", double1 == (-0.6233326730343048d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 1.5430806348152437d);
        double[] doubleArray25 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray31 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 0.0f);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray48 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 0.0f);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray48);
        double[] doubleArray53 = null;
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray53);
        java.lang.Class<?> wildcardClass55 = doubleArray48.getClass();
        double[] doubleArray62 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray68 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 0.0f);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray79 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray85 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) 0.0f);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray71, doubleArray85);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray85);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 28629151 + "'", int35 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.3440585709080678E43d + "'", double52 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 28629151 + "'", int72 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.3440585709080678E43d + "'", double89 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1212500306 + "'", int91 == 1212500306);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(5L, (long) (-1608653686));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(97.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-53L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        double double1 = org.apache.commons.math.util.FastMath.cosh(17.713573381989622d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4653420251638222E7d + "'", double1 == 2.4653420251638222E7d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.19616771719487114d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 725096562 + "'", int1 == 725096562);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 118608220);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        double double1 = org.apache.commons.math.util.FastMath.log(17.713573381989622d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8743312034341497d + "'", double1 == 2.8743312034341497d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(10.550007213731497d, (double) 990L, (double) 416);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(22.2219102317922d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8114290604649264d + "'", double1 == 2.8114290604649264d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray15.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray37 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray43 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 0.0f);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray56 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray62 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        java.lang.Class<?> wildcardClass66 = doubleArray62.getClass();
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray62);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 28629151 + "'", int47 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1546572416));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-53L), 118608255L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 118608202L + "'", long2 == 118608202L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        double double1 = org.apache.commons.math.util.FastMath.tanh(636.3698433827307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 1078591488);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (byte) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1076101122);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 52L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 70);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (byte) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 1076101122);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 52L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 70);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (int) (byte) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger48);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 118608224);
        java.math.BigInteger bigInteger52 = null;
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, 0L);
        java.math.BigInteger bigInteger55 = null;
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 0L);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, (int) (byte) 0);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, bigInteger59);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, 118608224);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger59);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger59);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger64);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger66);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.7073724617761614d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6090265281802509d) + "'", double1 == (-0.6090265281802509d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27941549819892586d) + "'", double1 == (-0.27941549819892586d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3258176636680326d + "'", double1 == 1.3258176636680326d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        double double2 = org.apache.commons.math.util.MathUtils.round(5.96046465517475E-8d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.725290298461914E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.725290305400808E-9d + "'", double1 == 3.725290305400808E-9d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1021132647), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1021132647) + "'", int2 == (-1021132647));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double1 = org.apache.commons.math.util.FastMath.rint(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 30.0f, (-1190133760), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        boolean boolean13 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection17, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection27, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection33, false);
        nonMonotonousSequenceException29.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Number number37 = nonMonotonousSequenceException35.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        int int39 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.0f + "'", number37.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1190133760) + "'", int39 == (-1190133760));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.49870655758087346d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47829003537107234d + "'", double1 == 0.47829003537107234d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 320, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 118608256, (long) 118608220);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 1030825348);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 118608224);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (byte) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 118608224);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger33);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger33);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 98);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 10);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 0L);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 0L);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, (int) (byte) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger50);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 1076101122);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2704, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2704L + "'", long2 == 2704L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1120, 1490045466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1608653586), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1608653586L) + "'", long2 == (-1608653586L));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 30.0f, (-1190133760), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        boolean boolean13 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection17, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(857.9508725162755d, (double) (-1546572378L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7496154300672659d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01308325737842709d + "'", double1 == 0.01308325737842709d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 147.4131591025766d + "'", double1 == 147.4131591025766d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double double2 = org.apache.commons.math.util.FastMath.max(1.4711276743037347d, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1.49004544E9f, (-2.8629152E7d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.8629152E7d) + "'", double2 == (-2.8629152E7d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 97, (-10L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970L + "'", long2 == 970L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 286292400, (-887503592L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 286292400L + "'", long2 == 286292400L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray61 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray67 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 0.0f);
        java.lang.Class<?> wildcardClass71 = doubleArray70.getClass();
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 28629151 + "'", int72 == 28629151);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 7.211102550927978d + "'", double74 == 7.211102550927978d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        double double2 = org.apache.commons.math.util.FastMath.min(2.9554156163191374E213d, 1.4273625532358719E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4273625532358719E-8d + "'", double2 == 1.4273625532358719E-8d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1546572416), 1608653685);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.45261282001081243d, number1, 118608255);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 118,608,254 and 118,608,255 are not strictly increasing (null >= 0.453)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 118,608,254 and 118,608,255 are not strictly increasing (null >= 0.453)"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-4441386545051598748L), (-118608120L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        int int2 = org.apache.commons.math.util.FastMath.min((-1608653586), (-1113831611));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1608653586) + "'", int2 == (-1608653586));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 99);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 99L + "'", long1 == 99L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-530363769), (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1113831611));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.113831611E9d) + "'", double1 == (-1.113831611E9d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1674494048);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.674494048E9d + "'", double1 == 1.674494048E9d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray72 = null;
        try {
            double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 8.21110255092798d + "'", double70 == 8.21110255092798d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 7.211102550927978d + "'", double71 == 7.211102550927978d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1608653586));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1608653586) + "'", int2 == (-1608653586));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(30.0f, (int) (short) 0, (-1068957696));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1490045466), (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(18334.649444186347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 5, 887503627L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4437518135L + "'", long2 == 4437518135L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5604874136486533d + "'", double1 == 1.5604874136486533d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.9996159447946292d, 11013.232874703392d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-30740316814311424L), (-2088681202), 108640);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.862924E7d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-10L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5663706143591725d + "'", double2 == 2.5663706143591725d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int[] intArray0 = null;
        int[] intArray7 = new int[] { (short) 100, (-118608221), (byte) 0, 0, 1, (short) 1 };
        int[] intArray9 = new int[] { (byte) -1 };
        int[] intArray16 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray16);
        try {
            int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 118608220 + "'", int18 == 118608220);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1120.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1120.0000000000002d + "'", double1 == 1120.0000000000002d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1, (long) (-1996753450));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 65);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4700382576631723d) + "'", double1 == (-1.4700382576631723d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 18334.649444186343d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1074790400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.344058570908068E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1996753450), 2704);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1095479168, 2, 28629151);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.03799291018846901d, number1, (-36), orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -37 and -36 are not decreasing (null < 0.038)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -37 and -36 are not decreasing (null < 0.038)"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1021132647), (-118608221));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.7657394585211276d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 916184295 + "'", int1 == 916184295);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10538080L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10538080L + "'", long2 == 10538080L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 118608220L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.591336350726507d + "'", double1 == 18.591336350726507d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.18608218E9f, 153.97436846011828d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.24106466411465108d + "'", double2 == 0.24106466411465108d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray61);
        double[] doubleArray71 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray77 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        double[] doubleArray85 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray91 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, (double) 0.0f);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray94);
        double double98 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 28629151 + "'", int95 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double2 = org.apache.commons.math.util.FastMath.min(1.62223011E8d, (double) 3L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        double[] doubleArray2 = new double[] { 0.9999092042625951d, 1.1860822427888854E8d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray10 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray16 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray16);
        double[] doubleArray24 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray30 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray33);
        double[] doubleArray42 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray48 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray56 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray62 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray33);
        double[] doubleArray76 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray82 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) 0.0f);
        java.lang.Class<?> wildcardClass86 = doubleArray85.getClass();
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1860822427888854E8d + "'", double3 == 1.1860822427888854E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 28629151 + "'", int34 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 28629151 + "'", int66 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.1860822427888854E8d + "'", double69 == 1.1860822427888854E8d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 28629151 + "'", int87 == 28629151);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(11013.232920103324d, (-2.37216442E8d), (double) 1078591488);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.2677879318469856d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.880776975400334d + "'", double1 == 4.880776975400334d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 28629141, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28629141L + "'", long2 == 28629141L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1000L, 1.99563519459755d, 0.7551949618496253d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 1.5430806348152437d);
        double[] doubleArray25 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray31 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 0.0f);
        java.lang.Class<?> wildcardClass35 = doubleArray31.getClass();
        double[] doubleArray42 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray48 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 0.0f);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray59 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray65 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray65);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) 0.0f);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray65);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray51);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 7.211102550927978d);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (-1.19013376E9f));
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (-0.5752220392306202d));
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray77);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 28629151 + "'", int52 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.3440585709080678E43d + "'", double69 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 7.211102550927978d + "'", double73 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.5752220392306202d + "'", double78 == 0.5752220392306202d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 668252872 + "'", int80 == 668252872);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1011892322, (-320L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1011892002L + "'", long2 == 1011892002L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-3395662222958640L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 28629240);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.862924E7f + "'", float1 == 2.862924E7f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1436947761857832735L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        float float2 = org.apache.commons.math.util.MathUtils.round((-2.8629152E7f), (-118608221));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1190133760), 286292400L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 286292400L + "'", long2 == 286292400L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.899494936611665d + "'", double1 == 9.899494936611665d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.5201157597405306d), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2600578798702653d) + "'", double2 == (-0.2600578798702653d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.1780986680938473E13d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1142577858) + "'", int1 == (-1142577858));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        long long1 = org.apache.commons.math.util.FastMath.abs(796283574570L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 796283574570L + "'", long1 == 796283574570L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean22 = nonMonotonousSequenceException18.getStrict();
        boolean boolean23 = nonMonotonousSequenceException18.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0f + "'", number19.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.18608224E8f) + "'", number20.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-118608224), (-118608186));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.570766341614675d, (java.lang.Number) (-1.1752011936438014d), 97);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.1752011936438014d) + "'", number4.equals((-1.1752011936438014d)));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-2088681202));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2088681202L + "'", long1 == 2088681202L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1212500306, 1076101122);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 136399184 + "'", int2 == 136399184);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        long long2 = org.apache.commons.math.util.FastMath.max(887503592L, 2016339740L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2016339740L + "'", long2 == 2016339740L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-89), 1.99563519459755d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-89.0d) + "'", double2 == (-89.0d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-4441386545051598748L), (float) (-3395662222958640L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.44138651E18f) + "'", float2 == (-4.44138651E18f));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.7741134543031625d), (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7741134543031625d) + "'", double2 == (-0.7741134543031625d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(725096562);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        float float2 = org.apache.commons.math.util.FastMath.max(2.848847E18f, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(970L, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.848857801796106d, (java.lang.Number) (-1113831611), (-118608221), orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 9.848857801796106d + "'", number6.equals(9.848857801796106d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1073741824));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 970L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-118608221));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1937657580);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        double double1 = org.apache.commons.math.util.FastMath.tan(8.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.799711455220379d) + "'", double1 == (-6.799711455220379d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.908990346477532E-105d, 4.908990346477531E-105d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.908990346477531E-105d + "'", double2 == 4.908990346477531E-105d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        double double1 = org.apache.commons.math.util.FastMath.asin((-5.077097623251163E12d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(22631.853901740316d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 395.00036641569375d + "'", double1 == 395.00036641569375d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        boolean boolean16 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException23.getDirection();
        boolean boolean25 = nonMonotonousSequenceException23.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection29, false);
        java.lang.Number number32 = nonMonotonousSequenceException31.getArgument();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        java.lang.Class<?> wildcardClass34 = nonMonotonousSequenceException31.getClass();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(orderDirection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0f + "'", number32.equals(0.0f));
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) '#', 1.5705423613240965d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1212500306, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-118608224));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1076887552);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(960.9999805093762d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(3.948148009134034E13d, (-1068957696), (-1068957696));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.433780830483027d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.252715437981207d) + "'", double1 == (-7.252715437981207d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.6293307767469674E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.953093063104237d + "'", double1 == 19.953093063104237d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double1 = org.apache.commons.math.util.FastMath.log(6.338253001141147E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 70.92415596842864d + "'", double1 == 70.92415596842864d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1608653685, (int) (short) 100, 416);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 320, 99L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1436947761857832735L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.96046465517475E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4150946867841273E-6d + "'", double1 == 3.4150946867841273E-6d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (-0.5752220392306202d));
        double[] doubleArray65 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray71 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.3440585709080678E43d + "'", double73 == 1.3440585709080678E43d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(416, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 316 + "'", int2 == 316);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-6.053272382792571d), 108640);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.795896480869979E29d) + "'", double2 == (-4.795896480869979E29d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1074790400));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.6881171418161356E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 28629151, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.6291760449174614E37d + "'", double2 == 3.6291760449174614E37d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 0, 1212500306);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1212500306) + "'", int2 == (-1212500306));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1212500306);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.212500306E9d + "'", double1 == 1.212500306E9d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 0, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-97L) + "'", long2 == (-97L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-118608186));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-118608224), (long) (-888610971));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1937657580, 1.4645918875615231d, 0.3106720772016449d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(6062501530L, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 54562513770L + "'", long2 == 54562513770L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-118608186), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-118608186L) + "'", long2 == (-118608186L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1212500306, 2147483647);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0f + "'", number9.equals(100.0f));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1608653586L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-4.795896480869979E29d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-3920341883350785L), (int) (byte) 0, (-237216448));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.710422666954443d + "'", double1 == 1.710422666954443d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1088898461023600640L, (double) 227705867358520961L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1095479168L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        int int2 = org.apache.commons.math.util.FastMath.min((-1074790400), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.830951894845301d, (-0.6498388983827946d), 18.59133665424674d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.47226947853733026d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.18608245E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1002020285L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 525196494 + "'", int1 == 525196494);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1120.0000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        double double2 = org.apache.commons.math.util.MathUtils.log(22.2219102317922d, (double) 118608186);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.9951189781306695d + "'", double2 == 5.9951189781306695d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1937657580);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1190133760));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.19013376E9d) + "'", double1 == (-1.19013376E9d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.398046511102E12d, (-1.18608245E8d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.3980465111019995E12d + "'", double2 == 4.3980465111019995E12d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.113831611E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.113831611E9d) + "'", double1 == (-1.113831611E9d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        double[] doubleArray51 = null;
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray51);
        java.lang.Class<?> wildcardClass53 = doubleArray46.getClass();
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 0.0f);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double[] doubleArray77 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray83 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) 0.0f);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray83);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray83);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 28629151 + "'", int70 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.3440585709080678E43d + "'", double87 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1072693248, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3218079744L + "'", long2 == 3218079744L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        double double1 = org.apache.commons.math.util.FastMath.tan(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5101770449416689d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4902958736967448d + "'", double1 == 0.4902958736967448d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int int2 = org.apache.commons.math.util.FastMath.max((-53), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1490045466), (-1021132647));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1546572416));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 525196494);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number23 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0f + "'", number19.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.18608224E8f) + "'", number20.equals((-1.18608224E8f)));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.18608224E8f) + "'", number23.equals((-1.18608224E8f)));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-118608186), 117021138);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1.18608224E8f), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        double double1 = org.apache.commons.math.util.FastMath.signum(18.59133638445098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 118608224);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (byte) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 118608224);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger33);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger33);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 98);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (int) (short) 10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.6267730472324786d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 30.0f, (-1190133760), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0f + "'", number9.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1095479166);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.0747903999999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 26316305322681560L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017437248368829285d + "'", double1 == 0.017437248368829285d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.3964729204944982d, 5.830951894845302d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1546572346));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1546572346 + "'", int2 == 1546572346);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray44 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray61);
        double[] doubleArray71 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray77 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        double[] doubleArray85 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray91 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, (double) 0.0f);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray94);
        int int98 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        int int99 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 28629151 + "'", int30 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 28629151 + "'", int62 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 28629151 + "'", int95 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 28629151 + "'", int98 == 28629151);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 28629151 + "'", int99 == 28629151);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(725096562, (-2591680));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 727688242 + "'", int2 == 727688242);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(991L, (long) (-1546572416));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546573407L + "'", long2 == 1546573407L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(28629240, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5196372217252947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6814175572809504d + "'", double1 == 0.6814175572809504d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(642915097, 1120);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        float float2 = org.apache.commons.math.util.MathUtils.round(1.03082534E9f, 2147483647);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(136399184, 668252872);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 804652056 + "'", int2 == 804652056);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.1780986680938473E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.712058534562416d + "'", double1 == 30.712058534562416d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(36.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray23);
        java.lang.Class<?> wildcardClass32 = doubleArray23.getClass();
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray34 = null;
        try {
            double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.3440585709080678E43d + "'", double31 == 1.3440585709080678E43d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1011892322 + "'", int33 == 1011892322);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.7255121382673138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        long long1 = org.apache.commons.math.util.FastMath.abs(35048061832L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35048061832L + "'", long1 == 35048061832L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1608653685);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 108640, (-118608221));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.473735823738583E-101d + "'", double2 == 9.473735823738583E-101d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 97, (double) (-1608653586L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.608653586E9d) + "'", double2 == (-1.608653586E9d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999092042625951d, (java.lang.Number) 3.141592653589793d, 32, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963267948963d, (java.lang.Number) 10, 1095479168, orderDirection9, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection19, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection25, true);
        java.lang.String str28 = nonMonotonousSequenceException27.toString();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.String str30 = nonMonotonousSequenceException21.toString();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str28.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8148436360867664d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(104152956928L, (long) 118608255);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.5201157597405306d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4796104083775564d) + "'", double1 == (-0.4796104083775564d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 32000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1120.0000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1121.0d + "'", double1 == 1121.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.447693680631751d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.705528514488884d + "'", double1 == 2.705528514488884d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0d, (java.lang.Number) Double.NaN, 98);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        boolean boolean13 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number14 = nonMonotonousSequenceException5.getArgument();
        int int15 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0f + "'", number14.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) (-1.0d), 28629151);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28629151 + "'", int7 == 28629151);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.8629152E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6403295806385198E9d + "'", double1 == 1.6403295806385198E9d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        int int1 = org.apache.commons.math.util.FastMath.abs(1608653685);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1608653685 + "'", int1 == 1608653685);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray15.getClass();
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        java.lang.Class<?> wildcardClass18 = doubleArray15.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 28629151 + "'", int17 == 28629151);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1212500306), 725096562);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 118608186);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(727688242, (-1190133760));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-8.86120699709114E10d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException18.getSuppressed();
        boolean boolean20 = nonMonotonousSequenceException18.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection24, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException26.getDirection();
        boolean boolean28 = nonMonotonousSequenceException26.getStrict();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        java.lang.String str30 = nonMonotonousSequenceException18.toString();
        boolean boolean31 = nonMonotonousSequenceException18.getStrict();
        java.lang.Number number32 = nonMonotonousSequenceException18.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException18.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-887503592L), 1629445216, orderDirection33, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.18608224E8f) + "'", number7.equals((-1.18608224E8f)));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0f + "'", number9.equals(0.0f));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(orderDirection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-1.18608224E8f) + "'", number32.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1490045366L), 3920342001959040L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 916184295, (long) (-1608653586));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-30740316814311424L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        int int2 = org.apache.commons.math.util.FastMath.min(28629141, (-1405421430));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1405421430) + "'", int2 == (-1405421430));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.570766341614675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35048061832L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.5048063E10f + "'", float1 == 3.5048063E10f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1120, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120 + "'", int2 == 1120);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray11 = new int[] { (byte) -1 };
        int[] intArray18 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray18);
        java.lang.Class<?> wildcardClass20 = intArray11.getClass();
        int[] intArray22 = new int[] { (byte) -1 };
        int[] intArray29 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray29);
        java.lang.Class<?> wildcardClass31 = intArray29.getClass();
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray29);
        int[] intArray34 = new int[] { (byte) -1 };
        int[] intArray41 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray41);
        java.lang.Class<?> wildcardClass43 = intArray34.getClass();
        int[] intArray45 = new int[] { (byte) -1 };
        int[] intArray52 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray52);
        java.lang.Class<?> wildcardClass54 = intArray52.getClass();
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray52);
        int[] intArray57 = new int[] { (byte) -1 };
        int[] intArray64 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray64);
        java.lang.Class<?> wildcardClass66 = intArray64.getClass();
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray52);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray29);
        int[] intArray70 = null;
        try {
            int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection10, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection16, false);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number22 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.18608224E8f) + "'", number22.equals((-1.18608224E8f)));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 4437518135L, 28629151);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray11 = new int[] { (byte) -1 };
        int[] intArray18 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray18);
        java.lang.Class<?> wildcardClass20 = intArray11.getClass();
        int[] intArray22 = new int[] { (byte) -1 };
        int[] intArray29 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray29);
        java.lang.Class<?> wildcardClass31 = intArray29.getClass();
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray29);
        int[] intArray34 = new int[] { (byte) -1 };
        int[] intArray41 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray41);
        java.lang.Class<?> wildcardClass43 = intArray34.getClass();
        int[] intArray45 = new int[] { (byte) -1 };
        int[] intArray52 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray52);
        java.lang.Class<?> wildcardClass54 = intArray52.getClass();
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray52);
        int[] intArray57 = new int[] { (byte) -1 };
        int[] intArray64 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray64);
        java.lang.Class<?> wildcardClass66 = intArray64.getClass();
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray52);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray52);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3527517838398029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.063291409135596d + "'", double1 == 2.063291409135596d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 70, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 2088681202L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.990828984128351E20d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.990828984128351E20d + "'", double2 == 3.990828984128351E20d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1011892322);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1011892352 + "'", int1 == 1011892352);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.18608255E8d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1860825499999999E8d + "'", double2 == 1.1860825499999999E8d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.101103026882598d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1.18608218E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.186082176E9d + "'", double1 == 1.186082176E9d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 7890481L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9418924385953806d + "'", double1 == 0.9418924385953806d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 28629240);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28629240L + "'", long2 == 28629240L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, 10538080L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10538080L + "'", long2 == 10538080L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1011892002L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.4991311460098435d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5201157597405306d) + "'", double1 == (-0.5201157597405306d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11013.423843485813d, 0.5625799401208676d, 2704);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1076101120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-887503592L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.297070307189543d) + "'", double1 == (-21.297070307189543d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0950671531879624E27d, (java.lang.Number) (-320L), 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException10.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNull(orderDirection14);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-887503556L), (float) 2704L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2704.0f + "'", float2 == 2704.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.8853134509493964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(20.818341138543172d, 98);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.597595660007573E30d + "'", double2 == 6.597595660007573E30d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1529.6660781016924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-320L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-118608186), 1821461900);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.03799291018846901d, number1, (-36), orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        double[] doubleArray2 = new double[] { 0.9999092042625951d, 1.1860822427888854E8d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray10 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray16 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray16);
        double[] doubleArray24 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray30 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray33);
        double[] doubleArray42 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray48 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray56 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray62 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray33);
        double[] doubleArray76 = new double[] { (-1.1752011936438014d), 18.591336350726507d, 1.4330001021490115d, (-1074790400), (-0.8148436360867664d), (-6.799711455220379d) };
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1860822427888854E8d + "'", double3 == 1.1860822427888854E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 28629151 + "'", int34 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 28629151 + "'", int66 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.1860822427888854E8d + "'", double69 == 1.1860822427888854E8d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.1860820568755218E8d + "'", double77 == 1.1860820568755218E8d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 5200L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 2704L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6127388384658345d) + "'", double1 == (-0.6127388384658345d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        int int2 = org.apache.commons.math.util.FastMath.min((-1212500306), 28629141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1212500306) + "'", int2 == (-1212500306));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3920342001959040L, 4437518135L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.6403346226671169E9d, (java.lang.Number) 0.27851308876856207d, (-2088681202));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (-1142577858));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.5663706143591725d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 147.04220486917677d + "'", double1 == 147.04220486917677d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 2704.0f, (double) 117021138);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.350888285597864d + "'", double2 == 2.350888285597864d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1186082200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1186082176 + "'", int1 == 1186082176);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3218079744L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray18 = new double[] { 6.338253001141147E30d, 30.0f, (-1190133760), 7.456808469171364d };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray18);
        double[] doubleArray27 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray33 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        double[] doubleArray41 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray47 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 0.0f);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray50);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 0.0f);
        java.lang.Class<?> wildcardClass70 = doubleArray66.getClass();
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray66);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1546572378) + "'", int19 == (-1546572378));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 28629151 + "'", int51 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1212500306 + "'", int72 == 1212500306);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean17 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection28, true);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException24.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        int int35 = nonMonotonousSequenceException24.getIndex();
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException24.getSuppressed();
        boolean boolean37 = nonMonotonousSequenceException24.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.18608224E8f) + "'", number18.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1434050571));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1434050571 + "'", int1 == 1434050571);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.6403295806385198E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        int int1 = org.apache.commons.math.util.MathUtils.sign(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.7741134543031625d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        double[] doubleArray22 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray28 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0.0f);
        java.lang.Class<?> wildcardClass32 = doubleArray28.getClass();
        double[] doubleArray39 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray45 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 0.0f);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray56 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray62 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray62);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray48);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 7.211102550927978d);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (-1.19013376E9f));
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 1.7182818284590453d);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 28629151 + "'", int49 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.3440585709080678E43d + "'", double66 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 7.211102550927978d + "'", double70 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(6.408020843150437E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1076101122);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 52L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 70);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (int) (byte) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger37);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 118608224);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (int) (byte) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger48);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 118608224);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger48);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger48);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger53);
        try {
            java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (-2088681202));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.1947055233182955d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1546572346, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546572346L + "'", long2 == 1546572346L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1186082176);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2069954852796814d, (java.lang.Number) 1.2676506002282294E30d, (int) '#');
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.9951189781306695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9452126169979063d + "'", double1 == 1.9452126169979063d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(5075811363987946720L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5075811363987946755L + "'", long2 == 5075811363987946755L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 7890481L, (-89.0d), 5.9604644775390625E-8d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-3920341883350785L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.59810244061049d) + "'", double1 == (-36.59810244061049d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        double double1 = org.apache.commons.math.util.FastMath.exp(6.408020843150437E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        int int1 = org.apache.commons.math.util.FastMath.abs(3200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3200 + "'", int1 == 3200);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.960464655174742E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 0.4929377100149654d, (int) '4', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 286292400, (-1996753450), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1608653586));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1608653586 + "'", int1 == 1608653586);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1937657580, (-37024));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(23.0d, 1.710422666954443d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.150444078461241d + "'", double2 == 4.150444078461241d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.3106720772016449d, 1095479168);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.12983179271898E-40d + "'", double2 == 9.12983179271898E-40d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 636.3698433827307d, (-1.4700382576631723d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.725290298461915E-9d, (-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.6729974665608759d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.592372668186967d) + "'", double1 == (-0.592372668186967d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.930412799999998E7d, (java.lang.Number) 1186082200, 1095479166);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.830951894845302d, 6.103515625E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.830951894845301d + "'", double2 == 5.830951894845301d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.141592540914193d, 0.5625799401208675d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1076101122);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1212500306 + "'", int54 == 1212500306);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(316, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1212500306 + "'", int15 == 1212500306);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        double[] doubleArray1 = new double[] { 0.45261282001081243d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray9 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray15 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray32);
        double[] doubleArray41 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray47 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 0.0f);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray58 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray64 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray64);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 0.0f);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray64);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray50);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 28629151 + "'", int51 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.3440585709080678E43d + "'", double68 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.45261282001081243d + "'", double70 == 0.45261282001081243d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.6293307767469674E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1434050571);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.434050571E9d + "'", double1 == 1.434050571E9d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(10.0f, (int) '#', (-1608653586));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-888610971));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray13 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 0.0f);
        double[] doubleArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray13.getClass();
        double[] doubleArray26 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray32 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 0.0f);
        java.lang.Class<?> wildcardClass36 = doubleArray32.getClass();
        double[] doubleArray43 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray49 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 0.0f);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray60 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray66 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 0.0f);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray52);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 7.211102550927978d);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (-1.19013376E9f));
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (-0.5752220392306202d));
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray73);
        try {
            double double81 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 28629151 + "'", int53 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.3440585709080678E43d + "'", double70 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 7.211102550927978d + "'", double74 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1434050571) + "'", int79 == (-1434050571));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.3440585709080678E43d + "'", double80 == 1.3440585709080678E43d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        double double1 = org.apache.commons.math.util.FastMath.acosh(18.59133638445098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6151187804331646d + "'", double1 == 3.6151187804331646d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.4700382576631723d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 227705867358520961L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 2, 1546572346);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray15.getClass();
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 28629151 + "'", int17 == 28629151);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 28629151 + "'", int19 == 28629151);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        java.lang.Class<?> wildcardClass52 = doubleArray12.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-34L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-1073741824));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1434050571L, (long) (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-118608186L), (-1.442925725710415d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        int[] intArray1 = new int[] { 1490045466 };
        int[] intArray3 = new int[] { (byte) -1 };
        int[] intArray10 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray10);
        java.lang.Class<?> wildcardClass12 = intArray10.getClass();
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1490045467 + "'", int13 == 1490045467);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-6.44184823419093E197d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.6909071608294225E199d) + "'", double1 == (-3.6909071608294225E199d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(118608255);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1546572378L), (-50.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-50.0f) + "'", float2 == (-50.0f));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(416, 118608256);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int int2 = org.apache.commons.math.util.FastMath.max(2, 1095479168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1095479168 + "'", int2 == 1095479168);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.508547968359661E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18731.11840857257d + "'", double1 == 18731.11840857257d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        double double1 = org.apache.commons.math.util.FastMath.atan((-3.3771464214718416d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2829140079988552d) + "'", double1 == (-1.2829140079988552d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean21 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number22 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection32, true);
        java.lang.String str35 = nonMonotonousSequenceException34.toString();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        boolean boolean37 = nonMonotonousSequenceException28.getStrict();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.18608224E8d, (java.lang.Number) 1.18608245E8d, 2);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        boolean boolean45 = nonMonotonousSequenceException43.getStrict();
        int int46 = nonMonotonousSequenceException43.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(orderDirection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.18608224E8f) + "'", number22.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str35.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4645918875615231d, (java.lang.Number) (-1.18608224E8f), 32);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', 1608653685);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(525196494, (-2088681202));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1563484708) + "'", int2 == (-1563484708));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        double double2 = org.apache.commons.math.util.MathUtils.log(101.5309649148734d, 98.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9945363664354249d + "'", double2 == 0.9945363664354249d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999092042625951d, (java.lang.Number) 3.141592653589793d, 32, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22.716225035560587d, (java.lang.Number) 6.338253001141147E30d, 28629240, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 0.08105829906083993d, (-89), orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.063291409135596d, (java.lang.Number) 0.41222689225952863d, 1120, orderDirection15, true);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 28629151L, 98.99999999999999d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-28629151L), (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(70, (long) (-1190133760));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07610112E9d + "'", double1 == 1.07610112E9d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.02720913096084206d), 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03d) + "'", double2 == (-0.03d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        double double2 = org.apache.commons.math.util.FastMath.max(4.4413865450515988E18d, 8.178185013543274E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.4413865450515988E18d + "'", double2 == 4.4413865450515988E18d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, (float) 118608156L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1860816E8f + "'", float2 == 1.1860816E8f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1030825348L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-32), 1937657580);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-2.8629152E7f), (double) 7890481L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(97, (-1068957696));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.269890390720962E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(725096562, 1608653586);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5557.690612768986d, 0.9998151400298467d, 1.186082176E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1629445216);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1021132647), 117021138);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1076101122);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 52L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 70);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 118608224);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (byte) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 118608224);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger33);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger33);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 98);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 10);
        try {
            java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (-1073741824));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { (byte) -1 };
        int[] intArray9 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray9);
        java.lang.Class<?> wildcardClass11 = intArray2.getClass();
        int[] intArray13 = new int[] { (byte) -1 };
        int[] intArray20 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray20);
        java.lang.Class<?> wildcardClass22 = intArray20.getClass();
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray20);
        int[] intArray25 = new int[] { (byte) -1 };
        int[] intArray32 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray32);
        java.lang.Class<?> wildcardClass34 = intArray25.getClass();
        int[] intArray36 = new int[] { (byte) -1 };
        int[] intArray43 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        java.lang.Class<?> wildcardClass45 = intArray43.getClass();
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray43);
        int[] intArray48 = new int[] { (byte) -1 };
        int[] intArray55 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray55);
        java.lang.Class<?> wildcardClass57 = intArray55.getClass();
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray55);
        int[] intArray60 = new int[] { (byte) -1 };
        int[] intArray67 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray55);
        try {
            int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.608653586E9d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1212500306));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1212500306 + "'", int2 == 1212500306);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.2856585006921635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9795231645879577d + "'", double1 == 0.9795231645879577d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 227705867358520961L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.20237568556709695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.8708497436336323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1072693248, 100, (-1021132647));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(118608255L, (long) 316);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 118607939L + "'", long2 == 118607939L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 991L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 991.0d + "'", double1 == 991.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(18.59133638445098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.591336384450983d + "'", double1 == 18.591336384450983d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-36));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 36L + "'", long1 == 36L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2704L, (-1608652696L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1608655400L + "'", long2 == 1608655400L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int int1 = org.apache.commons.math.util.MathUtils.sign(727688242);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        int[] intArray1 = new int[] { (byte) -1 };
        int[] intArray8 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        int[] intArray12 = new int[] { (byte) -1 };
        int[] intArray19 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        java.lang.Class<?> wildcardClass21 = intArray19.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) -1 };
        int[] intArray31 = new int[] { (short) -1, (-1), (short) 100, 100, (short) -1, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        java.lang.Class<?> wildcardClass33 = intArray24.getClass();
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray24);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int int2 = org.apache.commons.math.util.FastMath.min(1434050571, 1608653586);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1434050571 + "'", int2 == 1434050571);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(118608256, (-1608653586));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-28629141L), 525196494, 1076887552);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-89));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5752220392306202d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5191840406914351d) + "'", double1 == (-0.5191840406914351d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 54562513770L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3792.8423381926395d + "'", double1 == 3792.8423381926395d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.8708497436336323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        int int2 = org.apache.commons.math.util.FastMath.min(1674494048, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 30.0f, (-1190133760), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        boolean boolean13 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection17, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection27, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection33, false);
        nonMonotonousSequenceException29.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Number number37 = nonMonotonousSequenceException35.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Throwable[] throwableArray39 = nonMonotonousSequenceException35.getSuppressed();
        java.lang.String str40 = nonMonotonousSequenceException35.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.0f + "'", number37.equals(0.0f));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)" + "'", str40.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (-118,608,224 < 0)"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(118608255L, (long) (-1212500306));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-143812545481626030L) + "'", long2 == (-143812545481626030L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-71535587) + "'", int1 == (-71535587));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.String str17 = nonMonotonousSequenceException13.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1, 118608255, orderDirection21, true);
        boolean boolean24 = nonMonotonousSequenceException23.getStrict();
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException23.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection29, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection35, true);
        java.lang.String str38 = nonMonotonousSequenceException37.toString();
        nonMonotonousSequenceException31.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException37);
        boolean boolean40 = nonMonotonousSequenceException31.getStrict();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        java.lang.Throwable[] throwableArray43 = nonMonotonousSequenceException23.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str38.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.6313083693369503E35d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.176833405218859d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-505192252) + "'", int1 == (-505192252));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection20, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean31 = nonMonotonousSequenceException22.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Class<?> wildcardClass33 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number35 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, number35, (-1074790400), orderDirection37, true);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 9.1613286E8f, 0.4929377100149654d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03427910964770211d) + "'", double2 == (-0.03427910964770211d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1105L, (float) 6265192108622114049L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.2651921E18f + "'", float2 == 6.2651921E18f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.8114290604649264d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-888610971));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-53L), (long) 6305);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7106259489313277515L + "'", long2 == 7106259489313277515L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.288241522117258d + "'", double1 == 5.288241522117258d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, 286292400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        double double1 = org.apache.commons.math.util.FastMath.sin(22.583313058969097d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5581582759082884d) + "'", double1 == (-0.5581582759082884d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (-1546572346));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1190133760));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray23);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray41 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray47 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 0.0f);
        double[] doubleArray51 = null;
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray51);
        java.lang.Class<?> wildcardClass53 = doubleArray47.getClass();
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray54);
        double[] doubleArray62 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray68 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 0.0f);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray71);
        try {
            double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray71);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28629151 + "'", int16 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.3440585709080678E43d + "'", double31 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1011892322 + "'", int32 == 1011892322);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1011892322 + "'", int33 == 1011892322);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.3440585709080678E43d + "'", double34 == 1.3440585709080678E43d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 28629151 + "'", int72 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 6305, (float) 28629240L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6305.0f + "'", float2 == 6305.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        long long2 = org.apache.commons.math.util.MathUtils.pow(600653219388620033L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8204047388822071551L) + "'", long2 == (-8204047388822071551L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.9251475365964139d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        int int2 = org.apache.commons.math.util.FastMath.max((-32), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        long long1 = org.apache.commons.math.util.FastMath.abs((-3920341883350785L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3920341883350785L + "'", long1 == 3920341883350785L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1432389362) + "'", int1 == (-1432389362));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1546572346, (-118608220));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) 118607939L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.6498388983827946d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6498388983827946d + "'", double1 == 0.6498388983827946d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-28629151L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 99L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.608652697E9d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 664270981 + "'", int1 == 664270981);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 3920342001959040L, 1629445216);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.1860822427888854E8d, 20.646240241504042d, 4.644483341943245d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.6291760449174614E37d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-37024), 118608186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-118645210) + "'", int2 == (-118645210));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray34 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray40 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 0.0f);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray43);
        double[] doubleArray52 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray58 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray66 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray72 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) 0.0f);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray75);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 28629151 + "'", int44 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 28629151 + "'", int76 == 28629151);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(17.713573381989622d, (-1.608652697E9d), 1.62223011E8d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(727688242, 416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 727688658 + "'", int2 == 727688658);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1490045466, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1432389362), (double) (-53L), (double) (-3395662222958640L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1546572346));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1674494048, 227705867358521281L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 227705867358521281L + "'", long2 == 227705867358521281L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1546572378));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection20, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection26, true);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean31 = nonMonotonousSequenceException22.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number33 = nonMonotonousSequenceException5.getArgument();
        boolean boolean34 = nonMonotonousSequenceException5.getStrict();
        boolean boolean35 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection39, false);
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 10L + "'", number33.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0f + "'", number42.equals(0.0f));
        org.junit.Assert.assertNull(orderDirection44);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1546572378), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.546572378E9d) + "'", double2 == (-1.546572378E9d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1434050571), (-1190133760));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        double double2 = org.apache.commons.math.util.FastMath.atan2(14.703675447601967d, 0.6444451887786965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5269955088869989d + "'", double2 == 1.5269955088869989d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        double double2 = org.apache.commons.math.util.FastMath.max(0.966505784912384d, (double) (-3395662222958640L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.966505784912384d + "'", double2 == 0.966505784912384d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        int int1 = org.apache.commons.math.util.FastMath.round((-50.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-50) + "'", int1 == (-50));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 10538080L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10538080L + "'", long2 == 10538080L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.966505784912384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.014795542206552909d) + "'", double1 == (-0.014795542206552909d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.6403295806385198E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35920557229660605d + "'", double1 == 0.35920557229660605d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-1.18608224E8f), (int) 'a', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean17 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection28, true);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException24.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.18608224E8f) + "'", number18.equals((-1.18608224E8f)));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-118608224));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.8853134509493964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0871676747897452d + "'", double1 == 1.0871676747897452d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 3200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.071218539969863d + "'", double1 == 8.071218539969863d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray20 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray26 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 0.0f);
        java.lang.Class<?> wildcardClass30 = doubleArray26.getClass();
        double[] doubleArray37 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray43 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 0.0f);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray54 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray60 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 0.0f);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray60);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray46);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 7.211102550927978d);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (-1.19013376E9f));
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 28629151 + "'", int47 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.3440585709080678E43d + "'", double64 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 7.211102550927978d + "'", double68 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.19013376E9d + "'", double71 == 1.19013376E9d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        long long2 = org.apache.commons.math.util.FastMath.max((-97L), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-118608220), 1546572346);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        float float2 = org.apache.commons.math.util.MathUtils.round((-2.37216448E8f), 118608186);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.6444451887786965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2149417855546318d + "'", double1 == 1.2149417855546318d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.143525342095829d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5508071232888865d) + "'", double1 == (-1.5508071232888865d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) 100.0f, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (100 <= 10)"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.029985180230424707d, (double) (-237216448));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 35, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray12 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 0.0f);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double[] doubleArray23 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray29 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray46 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray32);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.211102550927978d);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.19013376E9f));
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (-0.5752220392306202d));
        double[] doubleArray65 = new double[] { (byte) 1, (-1.0d), ' ', (short) 10, 1.3440585709080678E43d, 1L };
        double[] doubleArray71 = new double[] { (short) 100, (byte) -1, 1.3440585709080678E43d, (-0.5440211108893698d), '4' };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        java.lang.Class<?> wildcardClass73 = doubleArray71.getClass();
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray71);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= -0.575)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 28629151 + "'", int33 == 28629151);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.3440585709080678E43d + "'", double50 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 7.211102550927978d + "'", double54 == 7.211102550927978d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1212500306), (-118608220));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 118608224);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) (byte) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 118608224);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger19);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (int) (byte) 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger31);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 118608224);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (int) (byte) 0);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger42);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 118608224);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, bigInteger42);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger42);
        java.lang.Class<?> wildcardClass48 = bigInteger47.getClass();
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger52 = null;
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, 0L);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (int) (byte) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 118608224);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, 0L);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (int) (byte) 0);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger67);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, 118608224);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, bigInteger67);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger59);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35, (java.lang.Number) bigInteger47, (-1432389362));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
    }
}

