import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2, (int) (short) 1, 100, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.String[] strArray3 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: ", "hi!", "org.apache.commons.math.MaxEvaluationsExceededException: hi!" };
        java.lang.String[] strArray7 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: ", "hi!", "org.apache.commons.math.MaxEvaluationsExceededException: hi!" };
        java.lang.String[][] strArray8 = new java.lang.String[][] { strArray3, strArray7 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable9, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException14 = new org.apache.commons.math.linear.InvalidMatrixException(localizable7, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, doubleArray5, localizable6, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException(localizable2, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException17 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray12);
        int int18 = maxEvaluationsExceededException17.getMaxEvaluations();
        java.lang.String str19 = maxEvaluationsExceededException17.getPattern();
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) maxEvaluationsExceededException17);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(illegalArgumentException20);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException2 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable5, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException2, "org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException21 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: hi!", (java.lang.Object[]) doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        double double7 = blockRealMatrix2.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.Class<?> wildcardClass1 = array2DRowRealMatrix0.getClass();
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, (java.lang.Object[]) doubleArray10);
        java.lang.Object[] objArray13 = invalidMatrixException12.getArguments();
        java.lang.NullPointerException nullPointerException14 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray13);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable18, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException23 = new org.apache.commons.math.linear.InvalidMatrixException(localizable16, (java.lang.Object[]) doubleArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", 52, doubleArray21 };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException(localizable2, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable34, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable32, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException29, doubleArray30, localizable31, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.exception.Localizable localizable43 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable48 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable50, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException55 = new org.apache.commons.math.linear.InvalidMatrixException(localizable48, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException45, doubleArray46, localizable47, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.optimization.OptimizationException optimizationException57 = new org.apache.commons.math.optimization.OptimizationException(localizable43, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException40, (double) 1, "", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException26, "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray53);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray53, 0, 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalStateException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(nullPointerException14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double3 = levenbergMarquardtOptimizer2.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker5 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer4.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer2.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction9 = null;
        double[] doubleArray16 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix17 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray16);
        double[] doubleArray18 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray18);
        double[] doubleArray20 = vectorialPointValuePair19.getValue();
        double[] doubleArray21 = vectorialPointValuePair19.getPointRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = array2DRowRealMatrix22.preMultiply(doubleArray23);
        double[] doubleArray31 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix32 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix35 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray31);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = levenbergMarquardtOptimizer0.optimize(differentiableMultivariateVectorialFunction9, doubleArray21, doubleArray23, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: dimensions mismatch 6 != 0");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(bigMatrix17);
        org.junit.Assert.assertNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(bigMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double[] doubleArray6 = array2DRowRealMatrix2.getColumn(0);
        int int7 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix11.scalarMultiply((double) 0L);
        int int14 = blockRealMatrix11.getColumnDimension();
        try {
            array2DRowRealMatrix2.setRowMatrix(100, (org.apache.commons.math.linear.RealMatrix) blockRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 1);
        int int4 = levenbergMarquardtOptimizer0.getIterations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer5.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker6);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker6);
        int int9 = levenbergMarquardtOptimizer0.getMaxIterations();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.Class<?> wildcardClass1 = array2DRowRealMatrix0.getClass();
        double[][] doubleArray2 = array2DRowRealMatrix0.getDataRef();
        array2DRowRealMatrix0.luDecompose();
        double[][] doubleArray4 = array2DRowRealMatrix0.getData();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix2.transpose();
        double[] doubleArray55 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix56 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray55);
        org.apache.commons.math.linear.RealMatrix realMatrix57 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(doubleArray55);
        org.apache.commons.math.linear.RealVector realVector59 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray55);
        try {
            blockRealMatrix2.setColumnVector((int) '#', realVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(bigMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable9, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException14 = new org.apache.commons.math.linear.InvalidMatrixException(localizable7, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, doubleArray5, localizable6, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException(localizable2, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException17 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray12);
        java.lang.Object[] objArray18 = maxEvaluationsExceededException17.getArguments();
        java.lang.RuntimeException runtimeException19 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) maxEvaluationsExceededException17);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(runtimeException19);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl10 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix8, (double) (byte) -1);
        double double11 = lUDecompositionImpl10.getDeterminant();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver12 = lUDecompositionImpl10.getSolver();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(decompositionSolver12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = array2DRowRealMatrix0.preMultiply(doubleArray1);
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = blockRealMatrix15.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = invalidMatrixException43.getArguments();
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray44);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", 52, doubleArray52 };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, 1.0d, "", objArray55);
        boolean boolean58 = blockRealMatrix15.equals((java.lang.Object) 1.0d);
        double double59 = blockRealMatrix15.getNorm();
        double[][] doubleArray60 = blockRealMatrix15.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        double double62 = blockRealMatrix15.getFrobeniusNorm();
        java.io.ObjectInputStream objectInputStream64 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) blockRealMatrix15, "", objectInputStream64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        double[][] doubleArray47 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix2.scalarAdd((double) (short) 10);
        blockRealMatrix2.multiplyEntry((int) '#', (int) (short) -1, (double) (-1.0f));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix2.scalarAdd(0.0d);
        try {
            blockRealMatrix2.setEntry((int) (byte) -1, (-1), (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, -1) in a 52x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable11, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException16 = new org.apache.commons.math.linear.InvalidMatrixException(localizable9, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException6, doubleArray7, localizable8, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException(localizable4, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable3, (java.lang.Object[]) doubleArray14);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray14);
        java.io.ObjectInputStream objectInputStream22 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) doubleArray14, "", objectInputStream22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        levenbergMarquardtOptimizer0.setMaxEvaluations(0);
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double3 = levenbergMarquardtOptimizer2.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker5 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer4.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer2.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        int int9 = levenbergMarquardtOptimizer0.getIterations();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double[] doubleArray6 = array2DRowRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor7, 1, (int) '#', (int) '4', 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        int int15 = blockRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix12.getSubMatrix((int) ' ', (int) '#', 0, 0);
        try {
            org.apache.commons.math.linear.RealVector realVector22 = blockRealMatrix20.getRowVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = blockRealMatrix15.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = invalidMatrixException43.getArguments();
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray44);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", 52, doubleArray52 };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, 1.0d, "", objArray55);
        boolean boolean58 = blockRealMatrix15.equals((java.lang.Object) 1.0d);
        double double59 = blockRealMatrix15.getNorm();
        double[][] doubleArray60 = blockRealMatrix15.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        try {
            double double64 = blockRealMatrix61.getEntry(2147483647, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (2,147,483,647, 32) in a 52x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setMaxIterations(52);
        levenbergMarquardtOptimizer0.setMaxEvaluations(100);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 100.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) 0L);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix13.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = invalidMatrixException41.getArguments();
        java.lang.NullPointerException nullPointerException43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray42);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable47, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException52 = new org.apache.commons.math.linear.InvalidMatrixException(localizable45, (java.lang.Object[]) doubleArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] { "hi!", 52, doubleArray50 };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, 1.0d, "", objArray53);
        boolean boolean56 = blockRealMatrix13.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.RealVector realVector58 = blockRealMatrix13.getRowVector(0);
        org.apache.commons.math.linear.RealVector realVector59 = blockRealMatrix8.operate(realVector58);
        blockRealMatrix2.setColumnVector((int) (byte) 0, realVector59);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix63 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix63.getRowVector(0);
        boolean boolean66 = blockRealMatrix63.isSquare();
        boolean boolean67 = blockRealMatrix2.equals((java.lang.Object) boolean66);
        try {
            boolean boolean68 = blockRealMatrix2.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 52x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(nullPointerException43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) ' ');
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable9, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException14 = new org.apache.commons.math.linear.InvalidMatrixException(localizable7, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, doubleArray5, localizable6, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable22, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException27 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, (java.lang.Object[]) doubleArray25);
        java.lang.Object[] objArray28 = invalidMatrixException27.getArguments();
        java.lang.NullPointerException nullPointerException29 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray28);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable33 = null;
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable33, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException38 = new org.apache.commons.math.linear.InvalidMatrixException(localizable31, (java.lang.Object[]) doubleArray36);
        java.lang.Object[] objArray39 = new java.lang.Object[] { "hi!", 52, doubleArray36 };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, 1.0d, "", objArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable48 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray51 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable52 = null;
        org.apache.commons.math.exception.Localizable localizable53 = null;
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable55, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException60 = new org.apache.commons.math.linear.InvalidMatrixException(localizable53, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException50, doubleArray51, localizable52, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.optimization.OptimizationException optimizationException62 = new org.apache.commons.math.optimization.OptimizationException(localizable48, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException46, localizable47, (java.lang.Object[]) doubleArray58);
        java.lang.IllegalArgumentException illegalArgumentException64 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, (-1.0d), "hi!", (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException1, "org.apache.commons.math.MaxEvaluationsExceededException: ", (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(nullPointerException29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(illegalArgumentException64);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException2, "", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = invalidMatrixException2.getLocalizablePattern();
        java.lang.Object[] objArray14 = null;
        java.io.EOFException eOFException15 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable13, objArray14);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException17 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable24 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable27, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException32 = new org.apache.commons.math.linear.InvalidMatrixException(localizable25, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException22, doubleArray23, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable20, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException17, "org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray30);
        java.lang.ArithmeticException arithmeticException36 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable13, (java.lang.Object[]) doubleArray30);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray38);
        org.apache.commons.math.exception.Localizable localizable41 = null;
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable43, (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException48 = new org.apache.commons.math.linear.InvalidMatrixException(localizable41, (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException39, "", (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.exception.Localizable localizable50 = invalidMatrixException39.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable52 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable56 = null;
        org.apache.commons.math.exception.Localizable localizable57 = null;
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable59, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException64 = new org.apache.commons.math.linear.InvalidMatrixException(localizable57, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException54, doubleArray55, localizable56, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable52, (java.lang.Object[]) doubleArray62);
        java.io.EOFException eOFException67 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable50, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.exception.Localizable localizable72 = null;
        org.apache.commons.math.exception.Localizable localizable74 = null;
        double[][] doubleArray77 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable74, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException79 = new org.apache.commons.math.linear.InvalidMatrixException(localizable72, (java.lang.Object[]) doubleArray77);
        java.lang.Object[] objArray80 = invalidMatrixException79.getArguments();
        java.text.ParseException parseException81 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray80);
        org.apache.commons.math.optimization.OptimizationException optimizationException83 = new org.apache.commons.math.optimization.OptimizationException(localizable50, objArray80);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException84 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable13, objArray80);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(eOFException15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(arithmeticException36);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(eOFException67);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(parseException81);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException84);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", objArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix8.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.multiply(realMatrix11);
        blockRealMatrix2.multiplyEntry((int) ' ', (-1), (double) (-1.0f));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector22 = blockRealMatrix20.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = blockRealMatrix20.transpose();
        org.apache.commons.math.linear.RealVector realVector25 = blockRealMatrix20.getRowVector((int) (byte) 10);
        try {
            blockRealMatrix2.setRowVector((int) 'a', realVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double[] doubleArray6 = array2DRowRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        int int10 = array2DRowRealMatrix9.getColumnDimension();
        double[][] doubleArray11 = array2DRowRealMatrix9.getData();
        double[][] doubleArray12 = array2DRowRealMatrix9.getDataRef();
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable11, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException16 = new org.apache.commons.math.linear.InvalidMatrixException(localizable9, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException6, doubleArray7, localizable8, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException(localizable4, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable3, (java.lang.Object[]) doubleArray14);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) illegalArgumentException20, 52.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException19 = new org.apache.commons.math.optimization.OptimizationException(localizable5, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, localizable4, (java.lang.Object[]) doubleArray15);
        java.lang.IllegalArgumentException illegalArgumentException21 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(illegalArgumentException21);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl10 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix8, (double) (byte) -1);
        double double11 = lUDecompositionImpl10.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix12 = lUDecompositionImpl10.getU();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver13 = lUDecompositionImpl10.getSolver();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(decompositionSolver13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) 0L);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix13.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = invalidMatrixException41.getArguments();
        java.lang.NullPointerException nullPointerException43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray42);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable47, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException52 = new org.apache.commons.math.linear.InvalidMatrixException(localizable45, (java.lang.Object[]) doubleArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] { "hi!", 52, doubleArray50 };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, 1.0d, "", objArray53);
        boolean boolean56 = blockRealMatrix13.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.RealVector realVector58 = blockRealMatrix13.getRowVector(0);
        org.apache.commons.math.linear.RealVector realVector59 = blockRealMatrix8.operate(realVector58);
        blockRealMatrix2.setColumnVector((int) (byte) 0, realVector59);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix63 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix63.getRowVector(0);
        boolean boolean66 = blockRealMatrix63.isSquare();
        boolean boolean67 = blockRealMatrix2.equals((java.lang.Object) boolean66);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix69 = blockRealMatrix2.getColumnMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(nullPointerException43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double3 = levenbergMarquardtOptimizer2.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker5 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer4.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer2.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker9 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vectorialConvergenceChecker9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double3 = levenbergMarquardtOptimizer2.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker5 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer4.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer2.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 1L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix2.scalarAdd((double) 0.0f);
        try {
            double[] doubleArray49 = blockRealMatrix2.getColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        double double7 = blockRealMatrix2.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException1, doubleArray2, localizable3, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable19, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException24 = new org.apache.commons.math.linear.InvalidMatrixException(localizable17, (java.lang.Object[]) doubleArray22);
        java.lang.Object[] objArray25 = invalidMatrixException24.getArguments();
        java.lang.NullPointerException nullPointerException26 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray25);
        org.apache.commons.math.exception.Localizable localizable28 = null;
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable30, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException35 = new org.apache.commons.math.linear.InvalidMatrixException(localizable28, (java.lang.Object[]) doubleArray33);
        java.lang.Object[] objArray36 = new java.lang.Object[] { "hi!", 52, doubleArray33 };
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException1, 1.0d, "", objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException38);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(nullPointerException26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix(100);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 1);
        int int4 = levenbergMarquardtOptimizer0.getIterations();
        try {
            double[] doubleArray5 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            double double14 = array2DRowRealMatrix11.getEntry((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (52, 0) in a 6x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix12.transpose();
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl16 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 52x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        double[][] doubleArray4 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5, 10, 0, 0, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable5, (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException10 = new org.apache.commons.math.linear.InvalidMatrixException(localizable3, (java.lang.Object[]) doubleArray8);
        java.lang.Object[] objArray11 = invalidMatrixException10.getArguments();
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 10, "hi!", objArray11);
        int int14 = maxEvaluationsExceededException13.getMaxEvaluations();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray7);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray14 = new double[] { 'a', (short) 100 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray14, true);
        double[] doubleArray17 = vectorialPointValuePair16.getValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException6 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        java.text.ParseException parseException7 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', "hi!", objArray4);
        java.lang.Throwable[] throwableArray8 = parseException7.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable14 = null;
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable17, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException(localizable15, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException12, doubleArray13, localizable14, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.exception.Localizable localizable26 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable30 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable33 = null;
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable33, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException38 = new org.apache.commons.math.linear.InvalidMatrixException(localizable31, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException28, doubleArray29, localizable30, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException(localizable26, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException23, (double) 1, "", (java.lang.Object[]) doubleArray36);
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        java.lang.Object[] objArray48 = new java.lang.Object[] { (short) 0, doubleArray47 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException41, (double) (byte) -1, "hi!", objArray48);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) parseException7, (double) (short) 100, localizable10, objArray48);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException6);
        org.junit.Assert.assertNotNull(parseException7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        double[][] doubleArray4 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor5, 0, 2147483647, 52, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable8, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException13 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException3, doubleArray4, localizable5, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable24, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException29 = new org.apache.commons.math.linear.InvalidMatrixException(localizable22, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException19, doubleArray20, localizable21, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.optimization.OptimizationException optimizationException31 = new org.apache.commons.math.optimization.OptimizationException(localizable17, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException14, (double) 1, "", (java.lang.Object[]) doubleArray27);
        java.lang.String str33 = functionEvaluationException32.getPattern();
        java.lang.Object[] objArray34 = functionEvaluationException32.getArguments();
        java.lang.ArithmeticException arithmeticException35 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray34);
        java.util.NoSuchElementException noSuchElementException36 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MaxEvaluationsExceededException: hi!", objArray34);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(arithmeticException35);
        org.junit.Assert.assertNotNull(noSuchElementException36);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(0);
        double[][] doubleArray11 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix14.scalarMultiply((double) (byte) 0);
        double double17 = blockRealMatrix14.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix2.subtract(blockRealMatrix14);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix14.createMatrix(1, (int) 'a');
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor23 = null;
        try {
            double double28 = blockRealMatrix14.walkInOptimizedOrder(realMatrixPreservingVisitor23, (int) '#', (int) (byte) 10, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: initial row 35 after final row 10");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable9, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException14 = new org.apache.commons.math.linear.InvalidMatrixException(localizable7, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, doubleArray5, localizable6, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException(localizable2, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException17 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray12);
        java.lang.Object[] objArray18 = maxEvaluationsExceededException17.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException17, (double) 52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException17, (double) ' ');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray4);
        double[] doubleArray12 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix13 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray12);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl16 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix14, (double) (byte) -1);
        int[] intArray17 = lUDecompositionImpl16.getPivot();
        double[] doubleArray24 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix25 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray24);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl28 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix26, (double) (byte) -1);
        int[] intArray29 = lUDecompositionImpl28.getPivot();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix30 = blockRealMatrix5.getSubMatrix(intArray17, intArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(bigMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(bigMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        double[][] doubleArray47 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47, true);
        double[][] doubleArray52 = array2DRowRealMatrix51.getDataRef();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable14, (java.lang.Object[]) doubleArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 'a', '#', 10.0f, localizable5, localizable14, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException(localizable1, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", objArray20);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setMaxIterations(52);
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(Double.NaN);
        int int7 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        boolean boolean6 = array2DRowRealMatrix2.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException2, "", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = invalidMatrixException2.getLocalizablePattern();
        java.lang.Object[] objArray14 = null;
        java.io.EOFException eOFException15 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable13, objArray14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double19 = array2DRowRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        double double21 = array2DRowRealMatrix18.getFrobeniusNorm();
        double[][] doubleArray22 = array2DRowRealMatrix18.getData();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException23 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable13, (java.lang.Object[]) doubleArray22);
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.linear.RealMatrix realMatrix25 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(eOFException15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.scalarAdd((double) '#');
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.createMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix13.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = invalidMatrixException41.getArguments();
        java.lang.NullPointerException nullPointerException43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray42);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable47, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException52 = new org.apache.commons.math.linear.InvalidMatrixException(localizable45, (java.lang.Object[]) doubleArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] { "hi!", 52, doubleArray50 };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, 1.0d, "", objArray53);
        boolean boolean56 = blockRealMatrix13.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.RealVector realVector58 = blockRealMatrix13.getRowVector(0);
        try {
            array2DRowRealMatrix2.setColumnVector((int) 'a', realVector58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(nullPointerException43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realVector58);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        double[][] doubleArray47 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix2.scalarAdd((double) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix54 = blockRealMatrix52.scalarMultiply((double) (byte) 0);
        blockRealMatrix52.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = blockRealMatrix52.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix49.add(blockRealMatrix52);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix62 = blockRealMatrix49.getColumnMatrix(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 2,147,483,647 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray2);
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException3, "", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable24, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException29 = new org.apache.commons.math.linear.InvalidMatrixException(localizable22, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException19, doubleArray20, localizable21, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.optimization.OptimizationException optimizationException31 = new org.apache.commons.math.optimization.OptimizationException(localizable17, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException32 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, "", (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException34 = new org.apache.commons.math.linear.MatrixIndexException("BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", (java.lang.Object[]) doubleArray27);
        java.lang.Class<?> wildcardClass35 = matrixIndexException34.getClass();
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.Class<?> wildcardClass1 = array2DRowRealMatrix0.getClass();
        double[][] doubleArray2 = array2DRowRealMatrix0.getDataRef();
        array2DRowRealMatrix0.luDecompose();
        java.lang.String str4 = array2DRowRealMatrix0.toString();
        int int5 = array2DRowRealMatrix0.getColumnDimension();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{}" + "'", str4.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray3);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable8, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException13 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException4, "", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.exception.Localizable localizable15 = invalidMatrixException4.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable41, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException46 = new org.apache.commons.math.linear.InvalidMatrixException(localizable39, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException36, doubleArray37, localizable38, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.optimization.OptimizationException optimizationException48 = new org.apache.commons.math.optimization.OptimizationException(localizable34, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException31, (double) 1, "", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException50 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", (java.lang.Object[]) doubleArray44);
        java.io.EOFException eOFException51 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray44);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException52 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable15, (java.lang.Object[]) doubleArray44);
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable15, objArray53);
        org.apache.commons.math.exception.Localizable localizable55 = null;
        org.apache.commons.math.exception.Localizable localizable57 = null;
        org.apache.commons.math.exception.Localizable localizable61 = null;
        org.apache.commons.math.exception.Localizable localizable63 = null;
        double[][] doubleArray66 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable63, (java.lang.Object[]) doubleArray66);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException68 = new org.apache.commons.math.linear.InvalidMatrixException(localizable61, (java.lang.Object[]) doubleArray66);
        org.apache.commons.math.exception.Localizable localizable70 = null;
        double[][] doubleArray73 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable70, (java.lang.Object[]) doubleArray73);
        java.lang.Object[] objArray76 = new java.lang.Object[] { 'a', '#', 10.0f, localizable61, localizable70, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException77 = new org.apache.commons.math.linear.MatrixIndexException(localizable57, objArray76);
        double[] doubleArray81 = new double[] { 100L, 52, '#' };
        org.apache.commons.math.exception.Localizable localizable82 = null;
        double[][] doubleArray85 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException77, doubleArray81, localizable82, (java.lang.Object[]) doubleArray85);
        java.io.EOFException eOFException87 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray85);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(localizable55, (java.lang.Object[]) doubleArray85);
        java.text.ParseException parseException89 = org.apache.commons.math.MathRuntimeException.createParseException(0, localizable15, (java.lang.Object[]) doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(eOFException51);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException52);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(eOFException87);
        org.junit.Assert.assertNotNull(parseException89);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable4, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException(localizable2, (java.lang.Object[]) doubleArray7);
        java.lang.Object[] objArray10 = invalidMatrixException9.getArguments();
        java.text.ParseException parseException11 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable19, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException24 = new org.apache.commons.math.linear.InvalidMatrixException(localizable17, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException14, doubleArray15, localizable16, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.exception.Localizable localizable28 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable33 = null;
        org.apache.commons.math.exception.Localizable localizable35 = null;
        double[][] doubleArray38 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable35, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException40 = new org.apache.commons.math.linear.InvalidMatrixException(localizable33, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException30, doubleArray31, localizable32, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException(localizable28, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, (double) 1, "", (java.lang.Object[]) doubleArray38);
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) 0, doubleArray49 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException43, (double) (byte) -1, "hi!", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException11, "org.apache.commons.math.MathRuntimeException: maximal number of evaluations (0) exceeded", objArray50);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(parseException11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        double[][] doubleArray47 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47, true);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix52 = array2DRowRealMatrix49.createMatrix(0, 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        levenbergMarquardtOptimizer0.setMaxEvaluations(0);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) (short) 0);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0.0f);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable8, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException13 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException3, doubleArray4, localizable5, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 1, "", (java.lang.Object[]) doubleArray11);
        java.lang.String str16 = functionEvaluationException15.getPattern();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String[] strArray5 = new java.lang.String[] { "org.apache.commons.math.MaxEvaluationsExceededException: hi!", "", "org.apache.commons.math.MaxEvaluationsExceededException: hi!", "org.apache.commons.math.MathException: ", "BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable4, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException(localizable2, (java.lang.Object[]) doubleArray7);
        java.lang.Object[] objArray10 = invalidMatrixException9.getArguments();
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException12 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", objArray10);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector50 = blockRealMatrix48.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = blockRealMatrix48.transpose();
        int int52 = blockRealMatrix48.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix2.add(blockRealMatrix48);
        int int54 = blockRealMatrix48.getColumnDimension();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 52 + "'", int52 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable10, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException15 = new org.apache.commons.math.linear.InvalidMatrixException(localizable8, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException5, doubleArray6, localizable7, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        java.lang.Object[] objArray29 = invalidMatrixException28.getArguments();
        java.lang.NullPointerException nullPointerException30 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray29);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable34, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable32, (java.lang.Object[]) doubleArray37);
        java.lang.Object[] objArray40 = new java.lang.Object[] { "hi!", 52, doubleArray37 };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException5, 1.0d, "", objArray40);
        org.apache.commons.math.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException2, localizable3, objArray40);
        java.lang.IllegalArgumentException illegalArgumentException44 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray40);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(nullPointerException30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(illegalArgumentException44);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 1);
        int int4 = levenbergMarquardtOptimizer0.getMaxIterations();
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        double double6 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector50 = blockRealMatrix48.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = blockRealMatrix48.transpose();
        int int52 = blockRealMatrix48.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix2.add(blockRealMatrix48);
        java.lang.Class<?> wildcardClass54 = blockRealMatrix2.getClass();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 52 + "'", int52 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(wildcardClass54);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxIterations();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1000 + "'", int1 == 1000);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = blockRealMatrix15.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = invalidMatrixException43.getArguments();
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray44);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", 52, doubleArray52 };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, 1.0d, "", objArray55);
        boolean boolean58 = blockRealMatrix15.equals((java.lang.Object) 1.0d);
        double double59 = blockRealMatrix15.getNorm();
        double[][] doubleArray60 = blockRealMatrix15.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        double[] doubleArray68 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix69 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray68);
        double[] doubleArray70 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair71 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray68, doubleArray70);
        double[] doubleArray72 = vectorialPointValuePair71.getValue();
        double[] doubleArray73 = vectorialPointValuePair71.getPointRef();
        double[] doubleArray74 = vectorialPointValuePair71.getPoint();
        try {
            double[] doubleArray75 = blockRealMatrix61.solve(doubleArray74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 52x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(bigMatrix69);
        org.junit.Assert.assertNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double[] doubleArray3 = new double[] { (short) 0, 1L, 100.0f };
        double[] doubleArray10 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray10);
        double[] doubleArray12 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray12);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray3, doubleArray12);
        double[] doubleArray15 = vectorialPointValuePair14.getPointRef();
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(bigMatrix11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray2);
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException3, "", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.exception.Localizable localizable14 = invalidMatrixException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable16, (java.lang.Object[]) doubleArray26);
        java.io.EOFException eOFException31 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable14, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = invalidMatrixException43.getArguments();
        java.text.ParseException parseException45 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray44);
        org.apache.commons.math.optimization.OptimizationException optimizationException47 = new org.apache.commons.math.optimization.OptimizationException(localizable14, objArray44);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException48 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("org.apache.commons.math.MathException: ", objArray44);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(eOFException31);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(parseException45);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException48);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix2.scalarAdd((double) 0.0f);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix2.getColumnMatrix((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException2, "", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = invalidMatrixException2.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable39, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException44 = new org.apache.commons.math.linear.InvalidMatrixException(localizable37, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException34, doubleArray35, localizable36, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.optimization.OptimizationException optimizationException46 = new org.apache.commons.math.optimization.OptimizationException(localizable32, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException29, (double) 1, "", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException48 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", (java.lang.Object[]) doubleArray42);
        java.io.EOFException eOFException49 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray42);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException50 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable13, (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException55 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: ", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException56 = new org.apache.commons.math.linear.MatrixIndexException(localizable13, objArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable60 = null;
        org.apache.commons.math.exception.Localizable localizable61 = null;
        org.apache.commons.math.exception.Localizable localizable63 = null;
        double[][] doubleArray66 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable63, (java.lang.Object[]) doubleArray66);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException68 = new org.apache.commons.math.linear.InvalidMatrixException(localizable61, (java.lang.Object[]) doubleArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException58, doubleArray59, localizable60, (java.lang.Object[]) doubleArray66);
        org.apache.commons.math.exception.Localizable localizable72 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray75 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable76 = null;
        org.apache.commons.math.exception.Localizable localizable77 = null;
        org.apache.commons.math.exception.Localizable localizable79 = null;
        double[][] doubleArray82 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable79, (java.lang.Object[]) doubleArray82);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException84 = new org.apache.commons.math.linear.InvalidMatrixException(localizable77, (java.lang.Object[]) doubleArray82);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException85 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException74, doubleArray75, localizable76, (java.lang.Object[]) doubleArray82);
        org.apache.commons.math.optimization.OptimizationException optimizationException86 = new org.apache.commons.math.optimization.OptimizationException(localizable72, (java.lang.Object[]) doubleArray82);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException69, (double) 1, "", (java.lang.Object[]) doubleArray82);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException88 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable13, (java.lang.Object[]) doubleArray82);
        double[][] doubleArray91 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 10, (int) (byte) 10);
        java.lang.NullPointerException nullPointerException92 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable13, (java.lang.Object[]) doubleArray91);
        double[][] doubleArray93 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(eOFException49);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException88);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(nullPointerException92);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxIterations();
        levenbergMarquardtOptimizer0.setMaxEvaluations(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1000 + "'", int1 == 1000);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) (byte) 0);
        double double5 = blockRealMatrix2.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector11 = blockRealMatrix9.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = blockRealMatrix9.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable19, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException24 = new org.apache.commons.math.linear.InvalidMatrixException(localizable17, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException14, doubleArray15, localizable16, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.exception.Localizable localizable30 = null;
        org.apache.commons.math.exception.Localizable localizable32 = null;
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable32, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException37 = new org.apache.commons.math.linear.InvalidMatrixException(localizable30, (java.lang.Object[]) doubleArray35);
        java.lang.Object[] objArray38 = invalidMatrixException37.getArguments();
        java.lang.NullPointerException nullPointerException39 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray38);
        org.apache.commons.math.exception.Localizable localizable41 = null;
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable43, (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException48 = new org.apache.commons.math.linear.InvalidMatrixException(localizable41, (java.lang.Object[]) doubleArray46);
        java.lang.Object[] objArray49 = new java.lang.Object[] { "hi!", 52, doubleArray46 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException14, 1.0d, "", objArray49);
        boolean boolean52 = blockRealMatrix9.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.RealVector realVector54 = blockRealMatrix9.getRowVector(0);
        blockRealMatrix2.setRowVector((int) ' ', realVector54);
        blockRealMatrix2.setEntry(0, 36, (double) (short) 1);
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, 36);
        double double62 = blockRealMatrix2.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(nullPointerException39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException1, doubleArray2, localizable3, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable19 = null;
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable22, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException27 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException17, doubleArray18, localizable19, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.optimization.OptimizationException optimizationException29 = new org.apache.commons.math.optimization.OptimizationException(localizable15, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, (double) 1, "", (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException30, (double) (-1L), localizable32, objArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException30);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.Class<?> wildcardClass1 = array2DRowRealMatrix0.getClass();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix4.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = blockRealMatrix4.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable14, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException19 = new org.apache.commons.math.linear.InvalidMatrixException(localizable12, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException9, doubleArray10, localizable11, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable27, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException32 = new org.apache.commons.math.linear.InvalidMatrixException(localizable25, (java.lang.Object[]) doubleArray30);
        java.lang.Object[] objArray33 = invalidMatrixException32.getArguments();
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray33);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = new java.lang.Object[] { "hi!", 52, doubleArray41 };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException9, 1.0d, "", objArray44);
        boolean boolean47 = blockRealMatrix4.equals((java.lang.Object) 1.0d);
        double double48 = blockRealMatrix4.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix4.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix49.transpose();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix0.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(nullPointerException34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException2, "", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = invalidMatrixException2.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable19 = null;
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable22, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException27 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException17, doubleArray18, localizable19, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable15, (java.lang.Object[]) doubleArray25);
        java.io.EOFException eOFException30 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable13, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable37, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException(localizable35, (java.lang.Object[]) doubleArray40);
        java.lang.Object[] objArray43 = invalidMatrixException42.getArguments();
        java.text.ParseException parseException44 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray43);
        org.apache.commons.math.optimization.OptimizationException optimizationException46 = new org.apache.commons.math.optimization.OptimizationException(localizable13, objArray43);
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray52 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable53 = null;
        org.apache.commons.math.exception.Localizable localizable54 = null;
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable56, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException61 = new org.apache.commons.math.linear.InvalidMatrixException(localizable54, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException51, doubleArray52, localizable53, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException63 = new org.apache.commons.math.optimization.OptimizationException(localizable49, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray59);
        java.lang.Object[] objArray65 = maxEvaluationsExceededException64.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.Localizable localizable70 = null;
        org.apache.commons.math.exception.Localizable localizable71 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray74 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable75 = null;
        org.apache.commons.math.exception.Localizable localizable76 = null;
        org.apache.commons.math.exception.Localizable localizable78 = null;
        double[][] doubleArray81 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable78, (java.lang.Object[]) doubleArray81);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException83 = new org.apache.commons.math.linear.InvalidMatrixException(localizable76, (java.lang.Object[]) doubleArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException73, doubleArray74, localizable75, (java.lang.Object[]) doubleArray81);
        org.apache.commons.math.optimization.OptimizationException optimizationException85 = new org.apache.commons.math.optimization.OptimizationException(localizable71, (java.lang.Object[]) doubleArray81);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException69, localizable70, (java.lang.Object[]) doubleArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException64, (double) 1L, "org.apache.commons.math.MaxEvaluationsExceededException: ", (java.lang.Object[]) doubleArray81);
        java.lang.IllegalStateException illegalStateException88 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable13, (java.lang.Object[]) doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(eOFException30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(parseException44);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(illegalStateException88);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        double[] doubleArray14 = blockRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        java.io.ObjectInputStream objectInputStream6 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) 0, "BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", objectInputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix8.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.multiply(realMatrix11);
        java.io.ObjectOutputStream objectOutputStream13 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) blockRealMatrix2, objectOutputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = blockRealMatrix15.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = invalidMatrixException43.getArguments();
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray44);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", 52, doubleArray52 };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, 1.0d, "", objArray55);
        boolean boolean58 = blockRealMatrix15.equals((java.lang.Object) 1.0d);
        double double59 = blockRealMatrix15.getNorm();
        double[][] doubleArray60 = blockRealMatrix15.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        try {
            double double64 = blockRealMatrix15.getEntry((int) (byte) 1, 1000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (1, 1,000) in a 52x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        double[][] doubleArray47 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double52 = array2DRowRealMatrix51.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix55 = array2DRowRealMatrix51.createMatrix((int) (byte) 100, 10);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix51.createMatrix((int) (short) 1, (int) (short) 10);
        try {
            blockRealMatrix2.setColumnMatrix((-1), (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector19 = blockRealMatrix17.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = blockRealMatrix17.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable24 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable27, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException32 = new org.apache.commons.math.linear.InvalidMatrixException(localizable25, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException22, doubleArray23, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable40, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException45 = new org.apache.commons.math.linear.InvalidMatrixException(localizable38, (java.lang.Object[]) doubleArray43);
        java.lang.Object[] objArray46 = invalidMatrixException45.getArguments();
        java.lang.NullPointerException nullPointerException47 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray46);
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.exception.Localizable localizable51 = null;
        double[][] doubleArray54 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable51, (java.lang.Object[]) doubleArray54);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException56 = new org.apache.commons.math.linear.InvalidMatrixException(localizable49, (java.lang.Object[]) doubleArray54);
        java.lang.Object[] objArray57 = new java.lang.Object[] { "hi!", 52, doubleArray54 };
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException22, 1.0d, "", objArray57);
        boolean boolean60 = blockRealMatrix17.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector66 = blockRealMatrix64.getRowVector(0);
        blockRealMatrix17.setRowVector((int) (byte) 0, realVector66);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix14.add(blockRealMatrix17);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor69 = null;
        try {
            double double74 = blockRealMatrix68.walkInColumnOrder(realMatrixPreservingVisitor69, (int) ' ', (int) (short) 10, (int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: initial row 32 after final row 10");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(nullPointerException47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException("", objArray1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        double[][] doubleArray47 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (int) (short) 10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor50 = null;
        try {
            double double51 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = blockRealMatrix2.scalarAdd(1.0d);
        blockRealMatrix2.multiplyEntry((int) '#', (int) (short) 10, Double.NaN);
        int int11 = blockRealMatrix2.getRowDimension();
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector16 = blockRealMatrix14.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = blockRealMatrix14.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable24, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException29 = new org.apache.commons.math.linear.InvalidMatrixException(localizable22, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException19, doubleArray20, localizable21, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable37, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException(localizable35, (java.lang.Object[]) doubleArray40);
        java.lang.Object[] objArray43 = invalidMatrixException42.getArguments();
        java.lang.NullPointerException nullPointerException44 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray43);
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable48, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException53 = new org.apache.commons.math.linear.InvalidMatrixException(localizable46, (java.lang.Object[]) doubleArray51);
        java.lang.Object[] objArray54 = new java.lang.Object[] { "hi!", 52, doubleArray51 };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException19, 1.0d, "", objArray54);
        boolean boolean57 = blockRealMatrix14.equals((java.lang.Object) 1.0d);
        double double58 = blockRealMatrix14.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix14.transpose();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix11, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix59);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(nullPointerException44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix2.transpose();
        double double48 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector50 = null;
        try {
            blockRealMatrix2.setColumnVector((int) '#', realVector50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker3 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer2.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker3);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker3);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) (byte) 0);
        int int8 = levenbergMarquardtOptimizer0.getMaxIterations();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1000 + "'", int8 == 1000);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray7);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray12 = vectorialPointValuePair11.getPoint();
        double[] doubleArray13 = vectorialPointValuePair11.getValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        org.apache.commons.math.linear.RealVector realVector16 = blockRealMatrix12.getRowVector((int) '#');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix12.transpose();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException7 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray6);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable11, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException16 = new org.apache.commons.math.linear.InvalidMatrixException(localizable9, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException7, "", (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable4, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException19 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.MathException: ", (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((double) 10.0f, "hi!", (java.lang.Object[]) doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = blockRealMatrix3.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable13, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException18 = new org.apache.commons.math.linear.InvalidMatrixException(localizable11, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException8, doubleArray9, localizable10, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        org.apache.commons.math.exception.Localizable localizable26 = null;
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable26, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException31 = new org.apache.commons.math.linear.InvalidMatrixException(localizable24, (java.lang.Object[]) doubleArray29);
        java.lang.Object[] objArray32 = invalidMatrixException31.getArguments();
        java.lang.NullPointerException nullPointerException33 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray32);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable37, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException(localizable35, (java.lang.Object[]) doubleArray40);
        java.lang.Object[] objArray43 = new java.lang.Object[] { "hi!", 52, doubleArray40 };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException8, 1.0d, "", objArray43);
        boolean boolean46 = blockRealMatrix3.equals((java.lang.Object) 1.0d);
        double double47 = blockRealMatrix3.getNorm();
        int int48 = blockRealMatrix3.getColumnDimension();
        double[][] doubleArray49 = blockRealMatrix3.getData();
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException50 = new org.apache.commons.math.linear.InvalidMatrixException("BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", (java.lang.Object[]) doubleArray49);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(nullPointerException33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Object[] objArray2 = null;
        java.text.ParseException parseException3 = org.apache.commons.math.MathRuntimeException.createParseException((int) '#', "", objArray2);
        org.junit.Assert.assertNotNull(parseException3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        java.lang.Object[] objArray3 = mathException2.getArguments();
        java.lang.IllegalArgumentException illegalArgumentException4 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) mathException2);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(illegalArgumentException4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable9, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException14 = new org.apache.commons.math.linear.InvalidMatrixException(localizable7, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, doubleArray5, localizable6, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable2, (java.lang.Object[]) doubleArray12);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.exception.Localizable localizable18 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable24, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException29 = new org.apache.commons.math.linear.InvalidMatrixException(localizable22, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable31, (java.lang.Object[]) doubleArray34);
        java.lang.Object[] objArray37 = new java.lang.Object[] { 'a', '#', 10.0f, localizable22, localizable31, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException38 = new org.apache.commons.math.linear.MatrixIndexException(localizable18, objArray37);
        double[] doubleArray42 = new double[] { 100L, 52, '#' };
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException38, doubleArray42, localizable43, (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.exception.Localizable localizable48 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray52 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable53 = null;
        org.apache.commons.math.exception.Localizable localizable54 = null;
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable56, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException61 = new org.apache.commons.math.linear.InvalidMatrixException(localizable54, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException51, doubleArray52, localizable53, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException63 = new org.apache.commons.math.optimization.OptimizationException(localizable49, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException17, doubleArray42, localizable48, (java.lang.Object[]) doubleArray59);
        double[] doubleArray65 = functionEvaluationException64.getArgument();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        int int2 = maxEvaluationsExceededException1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.scalarAdd((double) '#');
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.createMatrix((int) '#', (int) '4');
        int int10 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector16 = blockRealMatrix14.getRowVector(0);
        double[][] doubleArray17 = blockRealMatrix14.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = blockRealMatrix20.scalarMultiply((double) (byte) 0);
        double double23 = blockRealMatrix20.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix14.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix24.scalarAdd((double) 0);
        org.apache.commons.math.linear.RealVector realVector28 = blockRealMatrix24.getRowVector((int) '#');
        try {
            array2DRowRealMatrix2.setColumnVector(1000, realVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 1,000 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        double[] doubleArray13 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13);
        org.apache.commons.math.linear.BigMatrix bigMatrix17 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray13);
        org.apache.commons.math.linear.BigMatrix bigMatrix18 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray13);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray13, false);
        org.apache.commons.math.linear.BigMatrix bigMatrix21 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(bigMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(bigMatrix17);
        org.junit.Assert.assertNotNull(bigMatrix18);
        org.junit.Assert.assertNotNull(bigMatrix21);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray3);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable8, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException13 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException4, "", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.exception.Localizable localizable15 = invalidMatrixException4.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable41, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException46 = new org.apache.commons.math.linear.InvalidMatrixException(localizable39, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException36, doubleArray37, localizable38, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.optimization.OptimizationException optimizationException48 = new org.apache.commons.math.optimization.OptimizationException(localizable34, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException31, (double) 1, "", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException50 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", (java.lang.Object[]) doubleArray44);
        java.io.EOFException eOFException51 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray44);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException52 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable15, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.exception.Localizable localizable54 = null;
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException57 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray56);
        org.apache.commons.math.exception.Localizable localizable59 = null;
        org.apache.commons.math.exception.Localizable localizable61 = null;
        double[][] doubleArray64 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable61, (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException66 = new org.apache.commons.math.linear.InvalidMatrixException(localizable59, (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException57, "", (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable54, (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.exception.Localizable localizable69 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("", objArray72);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException74 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException68, localizable69, objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable15, objArray72);
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 10, (int) (byte) 10);
        java.lang.IllegalArgumentException illegalArgumentException80 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable15, (java.lang.Object[]) doubleArray79);
        java.lang.Object[] objArray84 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException85 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray84);
        org.apache.commons.math.exception.Localizable localizable87 = null;
        org.apache.commons.math.exception.Localizable localizable89 = null;
        double[][] doubleArray92 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException93 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable89, (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException94 = new org.apache.commons.math.linear.InvalidMatrixException(localizable87, (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException85, "", (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException97 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 10, localizable15, (java.lang.Object[]) doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(eOFException51);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException52);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(illegalArgumentException80);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) ' ', 1000);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix(10, (int) ' ');
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException2, "", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = invalidMatrixException2.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable39, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException44 = new org.apache.commons.math.linear.InvalidMatrixException(localizable37, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException34, doubleArray35, localizable36, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.optimization.OptimizationException optimizationException46 = new org.apache.commons.math.optimization.OptimizationException(localizable32, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException29, (double) 1, "", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException48 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", (java.lang.Object[]) doubleArray42);
        java.io.EOFException eOFException49 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray42);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException50 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable13, (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException55 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: ", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException56 = new org.apache.commons.math.linear.MatrixIndexException(localizable13, objArray53);
        org.apache.commons.math.exception.Localizable localizable59 = null;
        org.apache.commons.math.exception.Localizable localizable63 = null;
        org.apache.commons.math.exception.Localizable localizable65 = null;
        double[][] doubleArray68 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable65, (java.lang.Object[]) doubleArray68);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException70 = new org.apache.commons.math.linear.InvalidMatrixException(localizable63, (java.lang.Object[]) doubleArray68);
        org.apache.commons.math.exception.Localizable localizable72 = null;
        double[][] doubleArray75 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable72, (java.lang.Object[]) doubleArray75);
        java.lang.Object[] objArray78 = new java.lang.Object[] { 'a', '#', 10.0f, localizable63, localizable72, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException79 = new org.apache.commons.math.linear.MatrixIndexException(localizable59, objArray78);
        java.lang.IllegalStateException illegalStateException80 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray78);
        org.apache.commons.math.optimization.OptimizationException optimizationException81 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray78);
        java.io.EOFException eOFException82 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable13, objArray78);
        java.lang.Object[] objArray83 = null;
        java.lang.IllegalStateException illegalStateException84 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable13, objArray83);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(eOFException49);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(illegalStateException80);
        org.junit.Assert.assertNotNull(eOFException82);
        org.junit.Assert.assertNotNull(illegalStateException84);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray4);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.getColumnMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector7 = blockRealMatrix5.getRowVector(0);
        double[][] doubleArray8 = blockRealMatrix5.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix11.scalarMultiply((double) (byte) 0);
        double double14 = blockRealMatrix11.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix11);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector20 = blockRealMatrix18.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = blockRealMatrix18.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.exception.Localizable localizable26 = null;
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable28, (java.lang.Object[]) doubleArray31);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException33 = new org.apache.commons.math.linear.InvalidMatrixException(localizable26, (java.lang.Object[]) doubleArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException23, doubleArray24, localizable25, (java.lang.Object[]) doubleArray31);
        org.apache.commons.math.exception.Localizable localizable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable41, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException46 = new org.apache.commons.math.linear.InvalidMatrixException(localizable39, (java.lang.Object[]) doubleArray44);
        java.lang.Object[] objArray47 = invalidMatrixException46.getArguments();
        java.lang.NullPointerException nullPointerException48 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray47);
        org.apache.commons.math.exception.Localizable localizable50 = null;
        org.apache.commons.math.exception.Localizable localizable52 = null;
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable52, (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException57 = new org.apache.commons.math.linear.InvalidMatrixException(localizable50, (java.lang.Object[]) doubleArray55);
        java.lang.Object[] objArray58 = new java.lang.Object[] { "hi!", 52, doubleArray55 };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("", objArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException23, 1.0d, "", objArray58);
        boolean boolean61 = blockRealMatrix18.equals((java.lang.Object) 1.0d);
        double double62 = blockRealMatrix18.getNorm();
        double[][] doubleArray63 = blockRealMatrix18.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix18);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix65 = array2DRowRealMatrix0.solve((org.apache.commons.math.linear.RealMatrix) blockRealMatrix64);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(nullPointerException48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) (byte) 0);
        blockRealMatrix2.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        double[] doubleArray10 = blockRealMatrix2.getRow(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix14.scalarMultiply((double) (byte) 0);
        blockRealMatrix14.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix14.getColumnMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = blockRealMatrix14.scalarMultiply(10.0d);
        try {
            blockRealMatrix2.setColumnMatrix(2147483647, (org.apache.commons.math.linear.RealMatrix) blockRealMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 2,147,483,647 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix8.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable18, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException23 = new org.apache.commons.math.linear.InvalidMatrixException(localizable16, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException13, doubleArray14, localizable15, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable31, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException36 = new org.apache.commons.math.linear.InvalidMatrixException(localizable29, (java.lang.Object[]) doubleArray34);
        java.lang.Object[] objArray37 = invalidMatrixException36.getArguments();
        java.lang.NullPointerException nullPointerException38 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray37);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.exception.Localizable localizable42 = null;
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable42, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException47 = new org.apache.commons.math.linear.InvalidMatrixException(localizable40, (java.lang.Object[]) doubleArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!", 52, doubleArray45 };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException13, 1.0d, "", objArray48);
        boolean boolean51 = blockRealMatrix8.equals((java.lang.Object) 1.0d);
        double double52 = blockRealMatrix8.getNorm();
        blockRealMatrix8.addToEntry(0, 36, (double) 36);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(nullPointerException38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix12.transpose();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double21 = blockRealMatrix15.walkInColumnOrder(realMatrixPreservingVisitor16, 36, (int) (byte) 100, 100, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException2, "", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = invalidMatrixException2.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable39, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException44 = new org.apache.commons.math.linear.InvalidMatrixException(localizable37, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException34, doubleArray35, localizable36, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.optimization.OptimizationException optimizationException46 = new org.apache.commons.math.optimization.OptimizationException(localizable32, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException29, (double) 1, "", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException48 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", (java.lang.Object[]) doubleArray42);
        java.io.EOFException eOFException49 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray42);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException50 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable13, (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException55 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: ", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException56 = new org.apache.commons.math.linear.MatrixIndexException(localizable13, objArray53);
        org.apache.commons.math.exception.Localizable localizable59 = null;
        org.apache.commons.math.exception.Localizable localizable61 = null;
        double[][] doubleArray64 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable61, (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException66 = new org.apache.commons.math.linear.InvalidMatrixException(localizable59, (java.lang.Object[]) doubleArray64);
        java.lang.Object[] objArray67 = invalidMatrixException66.getArguments();
        java.text.ParseException parseException68 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray67);
        java.lang.IllegalStateException illegalStateException69 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable13, objArray67);
        java.lang.Object[] objArray71 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException72 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray71);
        org.apache.commons.math.exception.Localizable localizable74 = null;
        org.apache.commons.math.exception.Localizable localizable76 = null;
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable76, (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException81 = new org.apache.commons.math.linear.InvalidMatrixException(localizable74, (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException72, "", (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.exception.Localizable localizable83 = invalidMatrixException72.getLocalizablePattern();
        java.lang.Object[] objArray84 = null;
        java.io.EOFException eOFException85 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable83, objArray84);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix88 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double89 = array2DRowRealMatrix88.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix90 = array2DRowRealMatrix88.copy();
        double double91 = array2DRowRealMatrix88.getFrobeniusNorm();
        double[][] doubleArray92 = array2DRowRealMatrix88.getData();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException93 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable83, (java.lang.Object[]) doubleArray92);
        double[][] doubleArray94 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray92);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException95 = new org.apache.commons.math.linear.InvalidMatrixException(localizable13, (java.lang.Object[]) doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(eOFException49);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(parseException68);
        org.junit.Assert.assertNotNull(illegalStateException69);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(localizable83);
        org.junit.Assert.assertNotNull(eOFException85);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException93);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable13, (java.lang.Object[]) doubleArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 'a', '#', 10.0f, localizable4, localizable13, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, objArray19);
        double[] doubleArray24 = new double[] { 100L, 52, '#' };
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException20, doubleArray24, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.BigMatrix bigMatrix30 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        array2DRowRealMatrix32.addToEntry(0, 0, (double) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector41 = blockRealMatrix39.getRowVector(0);
        double[][] doubleArray42 = blockRealMatrix39.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix47 = blockRealMatrix45.scalarMultiply((double) (byte) 0);
        double double48 = blockRealMatrix45.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix39.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix45);
        double[] doubleArray51 = blockRealMatrix39.getColumn(0);
        org.apache.commons.math.linear.RealVector realVector53 = blockRealMatrix39.getRowVector((int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector54 = array2DRowRealMatrix32.operate(realVector53);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(bigMatrix30);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector54);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setMaxIterations(52);
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(Double.NaN);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker7 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.junit.Assert.assertNull(vectorialConvergenceChecker7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable9, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException14 = new org.apache.commons.math.linear.InvalidMatrixException(localizable7, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, doubleArray5, localizable6, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable2, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.exception.Localizable localizable18 = invalidMatrixException17.getLocalizablePattern();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(localizable18);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) 0L);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix13.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable23, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException28 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, doubleArray19, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = invalidMatrixException41.getArguments();
        java.lang.NullPointerException nullPointerException43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray42);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable47, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException52 = new org.apache.commons.math.linear.InvalidMatrixException(localizable45, (java.lang.Object[]) doubleArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] { "hi!", 52, doubleArray50 };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException18, 1.0d, "", objArray53);
        boolean boolean56 = blockRealMatrix13.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.RealVector realVector58 = blockRealMatrix13.getRowVector(0);
        org.apache.commons.math.linear.RealVector realVector59 = blockRealMatrix8.operate(realVector58);
        blockRealMatrix2.setColumnVector((int) (byte) 0, realVector59);
        java.io.ObjectOutputStream objectOutputStream61 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector59, objectOutputStream61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(nullPointerException43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix4.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = blockRealMatrix4.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable14, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException19 = new org.apache.commons.math.linear.InvalidMatrixException(localizable12, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException9, doubleArray10, localizable11, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable27, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException32 = new org.apache.commons.math.linear.InvalidMatrixException(localizable25, (java.lang.Object[]) doubleArray30);
        java.lang.Object[] objArray33 = invalidMatrixException32.getArguments();
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray33);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = new java.lang.Object[] { "hi!", 52, doubleArray41 };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException9, 1.0d, "", objArray44);
        boolean boolean47 = blockRealMatrix4.equals((java.lang.Object) 1.0d);
        double double48 = blockRealMatrix4.getNorm();
        double[][] doubleArray49 = blockRealMatrix4.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49, true);
        java.util.NoSuchElementException noSuchElementException52 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathException: ", (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.optimization.OptimizationException optimizationException53 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) doubleArray49);
        java.lang.Throwable throwable54 = null;
        try {
            optimizationException53.addSuppressed(throwable54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(nullPointerException34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(noSuchElementException52);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl10 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix8, (double) (byte) -1);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = lUDecompositionImpl10.getL();
        double double12 = lUDecompositionImpl10.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix13 = lUDecompositionImpl10.getP();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = lUDecompositionImpl10.getL();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl15 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix14);
        int[] intArray16 = lUDecompositionImpl15.getPivot();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable13, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException18 = new org.apache.commons.math.linear.InvalidMatrixException(localizable11, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException8, doubleArray9, localizable10, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException(localizable6, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray16);
        java.lang.Object[] objArray22 = maxEvaluationsExceededException21.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable3, objArray22);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException24 = new org.apache.commons.math.linear.InvalidMatrixException("", objArray22);
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", objArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException25, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        org.apache.commons.math.linear.RealVector realVector16 = blockRealMatrix12.getRowVector((int) '#');
        boolean boolean17 = blockRealMatrix12.isSquare();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, (java.lang.Object[]) doubleArray10);
        java.lang.Object[] objArray13 = invalidMatrixException12.getArguments();
        java.lang.NullPointerException nullPointerException14 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray13);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable18, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException23 = new org.apache.commons.math.linear.InvalidMatrixException(localizable16, (java.lang.Object[]) doubleArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", 52, doubleArray21 };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException(localizable2, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable34, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable32, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException29, doubleArray30, localizable31, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.exception.Localizable localizable43 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable48 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable50, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException55 = new org.apache.commons.math.linear.InvalidMatrixException(localizable48, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException45, doubleArray46, localizable47, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.optimization.OptimizationException optimizationException57 = new org.apache.commons.math.optimization.OptimizationException(localizable43, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException40, (double) 1, "", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException26, "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.optimization.OptimizationException optimizationException60 = new org.apache.commons.math.optimization.OptimizationException(localizable1, (java.lang.Object[]) doubleArray53);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException61 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("org.apache.commons.math.MathRuntimeException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(nullPointerException14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException61);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        double[][] doubleArray4 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor5, 100, (int) (byte) 1, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String[] strArray5 = new java.lang.String[] { "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", "org.apache.commons.math.FunctionEvaluationException: ", "org.apache.commons.math.MathException: ", "org.apache.commons.math.MathRuntimeException: maximal number of evaluations (0) exceeded", "org.apache.commons.math.MathException: " };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getTrace();
        try {
            org.apache.commons.math.linear.RealVector realVector4 = array2DRowRealMatrix0.getColumnVector(1000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 1,000 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setMaxIterations(52);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10.0f);
        int int7 = levenbergMarquardtOptimizer0.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double[] doubleArray6 = array2DRowRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean8 = array2DRowRealMatrix7.isSingular();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = blockRealMatrix2.scalarMultiply(100.0d);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double10 = array2DRowRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.copy();
        double[] doubleArray13 = array2DRowRealMatrix9.getColumn(0);
        try {
            double[] doubleArray14 = blockRealMatrix2.operate(doubleArray13);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double5 = array2DRowRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = array2DRowRealMatrix4.getData();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix(52, (int) ' ', doubleArray6, true);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException4 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray2);
        java.lang.RuntimeException runtimeException5 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) arrayIndexOutOfBoundsException4);
        double[] doubleArray12 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix13 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) arrayIndexOutOfBoundsException4, doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException18 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray17);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable22, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException27 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException18, "", (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.exception.Localizable localizable29 = invalidMatrixException18.getLocalizablePattern();
        java.lang.Object[] objArray30 = null;
        java.io.EOFException eOFException31 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable29, objArray30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double35 = array2DRowRealMatrix34.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        double double37 = array2DRowRealMatrix34.getFrobeniusNorm();
        double[][] doubleArray38 = array2DRowRealMatrix34.getData();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException39 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable29, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.exception.Localizable localizable42 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray45 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException44, doubleArray45, localizable46, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.optimization.OptimizationException optimizationException56 = new org.apache.commons.math.optimization.OptimizationException(localizable42, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException57 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray52);
        java.lang.IllegalArgumentException illegalArgumentException58 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable29, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.exception.Localizable localizable61 = null;
        org.apache.commons.math.exception.Localizable localizable65 = null;
        org.apache.commons.math.exception.Localizable localizable67 = null;
        double[][] doubleArray70 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable67, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException72 = new org.apache.commons.math.linear.InvalidMatrixException(localizable65, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.exception.Localizable localizable74 = null;
        double[][] doubleArray77 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable74, (java.lang.Object[]) doubleArray77);
        java.lang.Object[] objArray80 = new java.lang.Object[] { 'a', '#', 10.0f, localizable65, localizable74, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException81 = new org.apache.commons.math.linear.MatrixIndexException(localizable61, objArray80);
        java.lang.IllegalStateException illegalStateException82 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray80);
        org.apache.commons.math.optimization.OptimizationException optimizationException83 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray80);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable29, objArray80);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException4);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(bigMatrix13);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(eOFException31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(illegalArgumentException58);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(illegalStateException82);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setMaxIterations(52);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor(0.0d);
        int int7 = levenbergMarquardtOptimizer0.getMaxIterations();
        levenbergMarquardtOptimizer0.setMaxIterations(1000);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        double[] doubleArray8 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray8);
        double[] doubleArray10 = vectorialPointValuePair9.getPointRef();
        double[] doubleArray11 = vectorialPointValuePair9.getValue();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNull(doubleArray11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl10 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix8, (double) (byte) -1);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = lUDecompositionImpl10.getL();
        double double12 = lUDecompositionImpl10.getDeterminant();
        double double13 = lUDecompositionImpl10.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl10 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix8, (double) (byte) -1);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = lUDecompositionImpl10.getL();
        double double12 = lUDecompositionImpl10.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix13 = lUDecompositionImpl10.getP();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = lUDecompositionImpl10.getL();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) realMatrix14, 0, (int) (short) -1, 52, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 5]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray7);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray14 = new double[] { 'a', (short) 100 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray14, true);
        org.apache.commons.math.linear.BigMatrix bigMatrix17 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray14);
        double[] doubleArray18 = null;
        double[] doubleArray25 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix26 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray25, false);
        double[] doubleArray32 = new double[] { 'a', (short) 100 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray25, doubleArray32, true);
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: ", objArray37);
        org.apache.commons.math.exception.Localizable localizable40 = invalidMatrixException39.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray45 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException44, doubleArray45, localizable46, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 1, "", (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(doubleArray32, localizable40, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair59 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray32, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(bigMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(bigMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray3);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable8, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException13 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException4, "", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.exception.Localizable localizable15 = invalidMatrixException4.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable41, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException46 = new org.apache.commons.math.linear.InvalidMatrixException(localizable39, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException36, doubleArray37, localizable38, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.optimization.OptimizationException optimizationException48 = new org.apache.commons.math.optimization.OptimizationException(localizable34, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException31, (double) 1, "", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException50 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", (java.lang.Object[]) doubleArray44);
        java.io.EOFException eOFException51 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray44);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException52 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable15, (java.lang.Object[]) doubleArray44);
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException57 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: ", objArray55);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException58 = new org.apache.commons.math.linear.MatrixIndexException(localizable15, objArray55);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException63 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray62);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        org.apache.commons.math.exception.Localizable localizable67 = null;
        double[][] doubleArray70 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable67, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException72 = new org.apache.commons.math.linear.InvalidMatrixException(localizable65, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException63, "", (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.exception.Localizable localizable75 = null;
        org.apache.commons.math.exception.Localizable localizable78 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray81 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable82 = null;
        org.apache.commons.math.exception.Localizable localizable83 = null;
        org.apache.commons.math.exception.Localizable localizable85 = null;
        double[][] doubleArray88 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException89 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable85, (java.lang.Object[]) doubleArray88);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException90 = new org.apache.commons.math.linear.InvalidMatrixException(localizable83, (java.lang.Object[]) doubleArray88);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException91 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException80, doubleArray81, localizable82, (java.lang.Object[]) doubleArray88);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100, localizable78, (java.lang.Object[]) doubleArray88);
        java.util.NoSuchElementException noSuchElementException93 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", (java.lang.Object[]) doubleArray88);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException74, localizable75, (java.lang.Object[]) doubleArray88);
        java.text.ParseException parseException95 = org.apache.commons.math.MathRuntimeException.createParseException(36, localizable15, (java.lang.Object[]) doubleArray88);
        double[][] doubleArray98 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, 100);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException99 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) -1, localizable15, (java.lang.Object[]) doubleArray98);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(eOFException51);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(noSuchElementException93);
        org.junit.Assert.assertNotNull(parseException95);
        org.junit.Assert.assertNotNull(doubleArray98);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix47.transpose();
        int int49 = blockRealMatrix48.getColumnDimension();
        try {
            blockRealMatrix48.addToEntry((int) '#', (int) (short) 100, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (35, 100) in a 52x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor7, 100, 0, (int) (short) 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        blockRealMatrix8.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        double[] doubleArray16 = blockRealMatrix8.getRow(0);
        double double17 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.subtract(blockRealMatrix8);
        double double19 = blockRealMatrix18.getNorm();
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 52.0d + "'", double17 == 52.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 52.0d + "'", double19 == 52.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        levenbergMarquardtOptimizer0.setMaxEvaluations(0);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) (short) 0);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0.0f);
        java.lang.Class<?> wildcardClass9 = levenbergMarquardtOptimizer0.getClass();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker2);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double[] doubleArray6 = array2DRowRealMatrix2.getColumn(0);
        try {
            array2DRowRealMatrix2.addToEntry(100, (-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, -1) in a 10x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix2.scalarAdd((double) 0.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix52 = blockRealMatrix50.scalarMultiply((double) (byte) 0);
        double double53 = blockRealMatrix50.getNorm();
        blockRealMatrix50.addToEntry((int) (short) 1, 0, 0.0d);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix47.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        double double3 = levenbergMarquardtOptimizer0.getRMS();
        int int4 = levenbergMarquardtOptimizer0.getEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        int int15 = blockRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix12.getSubMatrix((int) ' ', (int) '#', 0, 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double22 = blockRealMatrix20.walkInColumnOrder(realMatrixChangingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix12.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarMultiply((double) 52);
        try {
            double double18 = blockRealMatrix15.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 1x52 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix(52);
        org.junit.Assert.assertNotNull(bigMatrix1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        blockRealMatrix8.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        double[] doubleArray16 = blockRealMatrix8.getRow(0);
        double double17 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.subtract(blockRealMatrix8);
        try {
            org.apache.commons.math.linear.RealVector realVector20 = blockRealMatrix18.getColumnVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 52.0d + "'", double17 == 52.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector8 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = array2DRowRealMatrix9.preMultiply(doubleArray10);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray10, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 0);
        double double17 = blockRealMatrix14.getEntry(1, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix14.scalarAdd((double) (-1));
        double double20 = blockRealMatrix14.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray4);
        blockRealMatrix5.multiplyEntry((int) (byte) 0, (int) (short) 0, (double) (byte) 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix5.getColumnMatrix((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double[] doubleArray6 = array2DRowRealMatrix2.getColumn(0);
        int int7 = array2DRowRealMatrix2.getColumnDimension();
        double[] doubleArray14 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray14);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14);
        org.apache.commons.math.linear.RealVector realVector18 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        try {
            double[] doubleArray19 = array2DRowRealMatrix2.operate(doubleArray14);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(bigMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        java.lang.Object[] objArray12 = invalidMatrixException11.getArguments();
        java.lang.NullPointerException nullPointerException13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray12);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable17, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException(localizable15, (java.lang.Object[]) doubleArray20);
        java.lang.Object[] objArray23 = new java.lang.Object[] { "hi!", 52, doubleArray20 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException(localizable1, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable30 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable33 = null;
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable33, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException38 = new org.apache.commons.math.linear.InvalidMatrixException(localizable31, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException28, doubleArray29, localizable30, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.exception.Localizable localizable42 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray45 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException44, doubleArray45, localizable46, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.optimization.OptimizationException optimizationException56 = new org.apache.commons.math.optimization.OptimizationException(localizable42, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException39, (double) 1, "", (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException25, "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray52);
        java.lang.Object[] objArray59 = matrixIndexException25.getArguments();
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException("hi!", objArray59);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(nullPointerException13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray59);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        boolean boolean6 = array2DRowRealMatrix2.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix9.scalarMultiply((double) (byte) 0);
        blockRealMatrix9.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        double[] doubleArray17 = blockRealMatrix9.getRow(0);
        try {
            double[] doubleArray18 = array2DRowRealMatrix2.solve(doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 10x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        double double46 = blockRealMatrix2.getNorm();
        double[][] doubleArray47 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix2.scalarAdd((double) (short) 10);
        blockRealMatrix2.multiplyEntry((int) '#', (int) (short) -1, (double) (-1.0f));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix2.copy();
        blockRealMatrix56.addToEntry((int) (byte) -1, 36, (double) 100.0f);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable14, (java.lang.Object[]) doubleArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 'a', '#', 10.0f, localizable5, localizable14, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException(localizable1, objArray20);
        double[] doubleArray25 = new double[] { 100L, 52, '#' };
        org.apache.commons.math.exception.Localizable localizable26 = null;
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException21, doubleArray25, localizable26, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.linear.BigMatrix bigMatrix31 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable40, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException45 = new org.apache.commons.math.linear.InvalidMatrixException(localizable38, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException35, doubleArray36, localizable37, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray52 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable53 = null;
        org.apache.commons.math.exception.Localizable localizable54 = null;
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable56, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException61 = new org.apache.commons.math.linear.InvalidMatrixException(localizable54, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException51, doubleArray52, localizable53, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException63 = new org.apache.commons.math.optimization.OptimizationException(localizable49, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException46, (double) 1, "", (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException32, "hi!", (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxEvaluationsExceededException: ", (java.lang.Object[]) doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(bigMatrix31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        double[][] doubleArray4 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.transpose();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor6, (int) (byte) 10, (int) ' ', (int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable13, (java.lang.Object[]) doubleArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 'a', '#', 10.0f, localizable4, localizable13, (-1) };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, objArray19);
        double[] doubleArray24 = new double[] { 100L, 52, '#' };
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException20, doubleArray24, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.BigMatrix bigMatrix30 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int34 = array2DRowRealMatrix33.getColumnDimension();
        double double35 = array2DRowRealMatrix33.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix33.createMatrix((int) (short) 1, (int) '#');
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix32.add(array2DRowRealMatrix33);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(bigMatrix30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        double[] doubleArray19 = blockRealMatrix15.getRow(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix12, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix15);
        int int21 = blockRealMatrix15.getColumnDimension();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix15, 10, 1000, (int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1,000 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.copy();
        double[] doubleArray6 = array2DRowRealMatrix2.getColumn(0);
        int int7 = array2DRowRealMatrix2.getColumnDimension();
        double[][] doubleArray8 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker1 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker1);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker3 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker3);
        levenbergMarquardtOptimizer0.setParRelativeTolerance(100.0d);
        int int7 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException1, (double) (-1L));
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable13, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException18 = new org.apache.commons.math.linear.InvalidMatrixException(localizable11, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException8, doubleArray9, localizable10, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException(localizable6, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray16);
        int int22 = maxEvaluationsExceededException21.getMaxEvaluations();
        java.lang.String str23 = maxEvaluationsExceededException21.getPattern();
        java.lang.String str24 = maxEvaluationsExceededException21.toString();
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) maxEvaluationsExceededException21);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxEvaluationsExceededException21);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: " + "'", str24.equals("org.apache.commons.math.MaxEvaluationsExceededException: "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double[] doubleArray6 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector10 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray6);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException15 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray14);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable19, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException24 = new org.apache.commons.math.linear.InvalidMatrixException(localizable17, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException15, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.exception.Localizable localizable26 = invalidMatrixException15.getLocalizablePattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable33 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException31, doubleArray32, localizable33, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray48 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        org.apache.commons.math.exception.Localizable localizable52 = null;
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable52, (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException57 = new org.apache.commons.math.linear.InvalidMatrixException(localizable50, (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException47, doubleArray48, localizable49, (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.optimization.OptimizationException optimizationException59 = new org.apache.commons.math.optimization.OptimizationException(localizable45, (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException42, (double) 1, "", (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException61 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", (java.lang.Object[]) doubleArray55);
        java.io.EOFException eOFException62 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray55);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException63 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable26, (java.lang.Object[]) doubleArray55);
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("", objArray66);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException68 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: ", objArray66);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException69 = new org.apache.commons.math.linear.MatrixIndexException(localizable26, objArray66);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException70 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "org.apache.commons.math.MathException: ", objArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException71, (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(eOFException62);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException63);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        int int6 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector12 = blockRealMatrix10.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix10.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable20, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException25 = new org.apache.commons.math.linear.InvalidMatrixException(localizable18, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException15, doubleArray16, localizable17, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable33 = null;
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable33, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException38 = new org.apache.commons.math.linear.InvalidMatrixException(localizable31, (java.lang.Object[]) doubleArray36);
        java.lang.Object[] objArray39 = invalidMatrixException38.getArguments();
        java.lang.NullPointerException nullPointerException40 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray39);
        org.apache.commons.math.exception.Localizable localizable42 = null;
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable44, (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException49 = new org.apache.commons.math.linear.InvalidMatrixException(localizable42, (java.lang.Object[]) doubleArray47);
        java.lang.Object[] objArray50 = new java.lang.Object[] { "hi!", 52, doubleArray47 };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException15, 1.0d, "", objArray50);
        boolean boolean53 = blockRealMatrix10.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector59 = blockRealMatrix57.getRowVector(0);
        blockRealMatrix10.setRowVector((int) (byte) 0, realVector59);
        double[][] doubleArray61 = blockRealMatrix10.getData();
        try {
            blockRealMatrix2.setRowMatrix(0, blockRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 52x1 but expected 1x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(nullPointerException40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException(0, (int) '4');
        java.lang.String str3 = nonSquareMatrixException2.toString();
        java.lang.String str4 = nonSquareMatrixException2.getPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix" + "'", str3.equals("org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a {0}x{1} matrix was provided instead of a square matrix" + "'", str4.equals("a {0}x{1} matrix was provided instead of a square matrix"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable12, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, doubleArray8, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        java.lang.Object[] objArray31 = invalidMatrixException30.getArguments();
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray31);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable36, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, (java.lang.Object[]) doubleArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", 52, doubleArray39 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException7, 1.0d, "", objArray42);
        boolean boolean45 = blockRealMatrix2.equals((java.lang.Object) 1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix2.scalarAdd((double) 0.0f);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = blockRealMatrix47.scalarMultiply((double) '#');
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable6, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException11 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException1, doubleArray2, localizable3, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable19 = null;
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable22, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException27 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException17, doubleArray18, localizable19, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.optimization.OptimizationException optimizationException29 = new org.apache.commons.math.optimization.OptimizationException(localizable15, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, (double) 1, "", (java.lang.Object[]) doubleArray25);
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        java.lang.Object[] objArray37 = new java.lang.Object[] { (short) 0, doubleArray36 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException30, (double) (byte) -1, "hi!", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException38);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector7 = blockRealMatrix2.getRowVector((int) (byte) 10);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) blockRealMatrix2, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(0);
        double[][] doubleArray11 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix14.scalarMultiply((double) (byte) 0);
        double double17 = blockRealMatrix14.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix2.subtract(blockRealMatrix14);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor20 = null;
        try {
            double double25 = blockRealMatrix19.walkInOptimizedOrder(realMatrixPreservingVisitor20, (int) (short) 0, (int) (short) 0, (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable9, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException14 = new org.apache.commons.math.linear.InvalidMatrixException(localizable7, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException4, doubleArray5, localizable6, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException(localizable2, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException17 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException17);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) (byte) 0);
        blockRealMatrix2.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        double[] doubleArray10 = blockRealMatrix2.getRow(0);
        int[] intArray11 = new int[] {};
        double[] doubleArray18 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix19 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray18);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray18);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl22 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix20, (double) (byte) -1);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = lUDecompositionImpl22.getL();
        int[] intArray24 = lUDecompositionImpl22.getPivot();
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable34, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable32, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException29, doubleArray30, localizable31, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.optimization.OptimizationException optimizationException41 = new org.apache.commons.math.optimization.OptimizationException(localizable27, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException42 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray37);
        try {
            blockRealMatrix2.copySubMatrix(intArray11, intArray24, doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: empty selected row index array");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(bigMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (short) -1);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = blockRealMatrix15.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = invalidMatrixException43.getArguments();
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray44);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", 52, doubleArray52 };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, 1.0d, "", objArray55);
        boolean boolean58 = blockRealMatrix15.equals((java.lang.Object) 1.0d);
        double double59 = blockRealMatrix15.getNorm();
        double[][] doubleArray60 = blockRealMatrix15.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector66 = blockRealMatrix64.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix67 = blockRealMatrix64.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix2.multiply(realMatrix67);
        blockRealMatrix68.multiplyEntry((int) ' ', (int) (short) 0, (double) 'a');
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException6 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray5);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable10, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException15 = new org.apache.commons.math.linear.InvalidMatrixException(localizable8, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException6, "", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable3, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) (-1), "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        double[] doubleArray13 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl17 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix15, (double) (byte) -1);
        int[] intArray18 = lUDecompositionImpl17.getPivot();
        int[] intArray19 = lUDecompositionImpl17.getPivot();
        double[] doubleArray26 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix27 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl30 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix28, (double) (byte) -1);
        int[] intArray31 = lUDecompositionImpl30.getPivot();
        int[] intArray32 = lUDecompositionImpl30.getPivot();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException35 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray34);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable39, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException44 = new org.apache.commons.math.linear.InvalidMatrixException(localizable37, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException35, "", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray52 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable53 = null;
        org.apache.commons.math.exception.Localizable localizable54 = null;
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable56, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException61 = new org.apache.commons.math.linear.InvalidMatrixException(localizable54, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException51, doubleArray52, localizable53, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException63 = new org.apache.commons.math.optimization.OptimizationException(localizable49, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45, "", (java.lang.Object[]) doubleArray59);
        try {
            blockRealMatrix2.copySubMatrix(intArray19, intArray32, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(bigMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(bigMatrix27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        double[][] doubleArray4 = array2DRowRealMatrix2.getData();
        java.io.ObjectInputStream objectInputStream6 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) array2DRowRealMatrix2, "org.apache.commons.math.MathException: ", objectInputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix8.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.multiply(realMatrix11);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        double[][] doubleArray18 = blockRealMatrix15.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = blockRealMatrix21.scalarMultiply((double) (byte) 0);
        double double24 = blockRealMatrix21.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix15.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector30 = blockRealMatrix28.getRowVector(0);
        double[] doubleArray32 = blockRealMatrix28.getRow(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix25, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix28);
        int int34 = blockRealMatrix28.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double40 = array2DRowRealMatrix39.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix39.copy();
        double double42 = array2DRowRealMatrix39.getFrobeniusNorm();
        double[][] doubleArray43 = array2DRowRealMatrix39.getData();
        try {
            blockRealMatrix35.setRowMatrix(1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 10x1 but expected 1x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        double[][] doubleArray4 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix7.scalarMultiply((double) (byte) 0);
        blockRealMatrix7.setEntry((int) ' ', (int) (byte) 1, (double) 52);
        double[] doubleArray15 = blockRealMatrix7.getRow(0);
        double[] doubleArray22 = new double[] { 0.0f, (-1), (byte) 100, (-1.0f), 0, '#' };
        org.apache.commons.math.linear.BigMatrix bigMatrix23 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray22);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray22, false);
        try {
            double[] doubleArray26 = array2DRowRealMatrix2.preMultiply(doubleArray15);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(bigMatrix23);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix6.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix6.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable13 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable16, (java.lang.Object[]) doubleArray19);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException21 = new org.apache.commons.math.linear.InvalidMatrixException(localizable14, (java.lang.Object[]) doubleArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException11, doubleArray12, localizable13, (java.lang.Object[]) doubleArray19);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[][] doubleArray32 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable29, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException34 = new org.apache.commons.math.linear.InvalidMatrixException(localizable27, (java.lang.Object[]) doubleArray32);
        java.lang.Object[] objArray35 = invalidMatrixException34.getArguments();
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray35);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable40, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException45 = new org.apache.commons.math.linear.InvalidMatrixException(localizable38, (java.lang.Object[]) doubleArray43);
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", 52, doubleArray43 };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException11, 1.0d, "", objArray46);
        boolean boolean49 = blockRealMatrix6.equals((java.lang.Object) 1.0d);
        double double50 = blockRealMatrix6.getNorm();
        double[][] doubleArray51 = blockRealMatrix6.getData();
        boolean boolean52 = array2DRowRealMatrix2.equals((java.lang.Object) doubleArray51);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(Double.NaN);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException8 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray6);
        java.text.ParseException parseException9 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', "hi!", objArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException10 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray6);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException11 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", objArray6);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) arrayIndexOutOfBoundsException11);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException8);
        org.junit.Assert.assertNotNull(parseException9);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.math.BigDecimal[] bigDecimalArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException6 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray5);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable10, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException15 = new org.apache.commons.math.linear.InvalidMatrixException(localizable8, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException6, "", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable3, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.exception.Localizable localizable18 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException23 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException17, localizable18, objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(10.0d, "org.apache.commons.math.MaxEvaluationsExceededException: ", objArray21);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException23);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, (java.lang.Object[]) doubleArray10);
        java.lang.Object[] objArray13 = invalidMatrixException12.getArguments();
        java.lang.NullPointerException nullPointerException14 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray13);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable18, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException23 = new org.apache.commons.math.linear.InvalidMatrixException(localizable16, (java.lang.Object[]) doubleArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", 52, doubleArray21 };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException(localizable2, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable34, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable32, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException29, doubleArray30, localizable31, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.exception.Localizable localizable43 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable48 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable50, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException55 = new org.apache.commons.math.linear.InvalidMatrixException(localizable48, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException45, doubleArray46, localizable47, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.optimization.OptimizationException optimizationException57 = new org.apache.commons.math.optimization.OptimizationException(localizable43, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException40, (double) 1, "", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException26, "org.apache.commons.math.linear.NonSquareMatrixException: a 0x52 matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.optimization.OptimizationException optimizationException60 = new org.apache.commons.math.optimization.OptimizationException(localizable1, (java.lang.Object[]) doubleArray53);
        java.lang.IllegalArgumentException illegalArgumentException61 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MaxEvaluationsExceededException: hi!", (java.lang.Object[]) doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(nullPointerException14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(illegalArgumentException61);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable5, (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException10 = new org.apache.commons.math.linear.InvalidMatrixException(localizable3, (java.lang.Object[]) doubleArray8);
        java.lang.Object[] objArray11 = invalidMatrixException10.getArguments();
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray11);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable16, (java.lang.Object[]) doubleArray19);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException21 = new org.apache.commons.math.linear.InvalidMatrixException(localizable14, (java.lang.Object[]) doubleArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", 52, doubleArray19 };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException24 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, objArray22);
        org.apache.commons.math.exception.Localizable localizable25 = matrixIndexException24.getLocalizablePattern();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) matrixIndexException24);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable25);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        double[][] doubleArray5 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) (byte) 0);
        double double11 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = blockRealMatrix15.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable25, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException(localizable23, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, doubleArray21, localizable22, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable38, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, (java.lang.Object[]) doubleArray41);
        java.lang.Object[] objArray44 = invalidMatrixException43.getArguments();
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray44);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable49, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, (java.lang.Object[]) doubleArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", 52, doubleArray52 };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException20, 1.0d, "", objArray55);
        boolean boolean58 = blockRealMatrix15.equals((java.lang.Object) 1.0d);
        double double59 = blockRealMatrix15.getNorm();
        double[][] doubleArray60 = blockRealMatrix15.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix63 = blockRealMatrix61.getRowMatrix((int) '#');
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(blockRealMatrix63);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable4, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException(localizable2, (java.lang.Object[]) doubleArray7);
        java.lang.Object[] objArray10 = invalidMatrixException9.getArguments();
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray10);
        org.apache.commons.math.exception.Localizable localizable13 = null;
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable15, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException20 = new org.apache.commons.math.linear.InvalidMatrixException(localizable13, (java.lang.Object[]) doubleArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", 52, doubleArray18 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[][] doubleArray32 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(100, (int) (byte) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable29, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException34 = new org.apache.commons.math.linear.InvalidMatrixException(localizable27, (java.lang.Object[]) doubleArray32);
        java.lang.Object[] objArray35 = invalidMatrixException34.getArguments();
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray35);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException37 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 10, "hi!", objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException22, "hi!", objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException22, (double) 10);
        double[] doubleArray41 = null;
        org.apache.commons.math.exception.Localizable localizable42 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        int int46 = array2DRowRealMatrix45.getColumnDimension();
        double[][] doubleArray47 = array2DRowRealMatrix45.getData();
        double[][] doubleArray48 = array2DRowRealMatrix45.getDataRef();
        try {
            org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException22, doubleArray41, localizable42, (java.lang.Object[]) doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply((double) 0L);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix8.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.multiply(realMatrix11);
        double double13 = blockRealMatrix12.getTrace();
        blockRealMatrix12.multiplyEntry(36, (int) (byte) -1, (double) 1.0f);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }
}

