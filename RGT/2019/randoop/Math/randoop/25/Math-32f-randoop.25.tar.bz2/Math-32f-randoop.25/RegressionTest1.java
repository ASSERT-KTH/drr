import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math3.util.FastMath.log(11.0d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47738944183057985d + "'", double2 == 0.47738944183057985d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-0.99999994f), (double) (short) 100, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = intervalsSet1.buildNew(euclidean1DBSPTree2);
        try {
            double double4 = intervalsSet3.getSup();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intervalsSet3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (-1L), (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        double double12 = vector3D9.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray17 = vector3D16.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D20, vector3D22);
        double double24 = vector3D23.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line25 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D16, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D10.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D3.subtract(0.01618564284234869d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray34 = vector3D33.toArray();
        double double35 = vector3D32.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = plane36.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        double double39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D10, vector3D37);
        double[] doubleArray40 = vector3D10.toArray();
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double double42 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray40);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D3, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D4, vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D1, (double) 0.0f, vector2D4);
        double double9 = vector2D8.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D14, vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D12, (double) 0.0f, vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D23, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D24, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D21, (double) 0.0f, vector2D24);
        boolean boolean29 = vector2D19.equals((java.lang.Object) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D31, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D34, vector2D35);
        double double37 = vector2D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D42, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D43, vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D40, (double) 0.0f, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D32.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D21, (double) 100L, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = vector2D49.getZero();
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D8, vector2D49);
        double double52 = vector2D49.getNorm1();
        org.apache.commons.math3.geometry.Space space53 = vector2D49.getSpace();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space53);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = line6.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D12, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D13, vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D10, (double) 0.0f, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D21, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D19, (double) 0.0f, vector2D22);
        boolean boolean27 = vector2D17.equals((java.lang.Object) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D29, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D33);
        double double35 = vector2D30.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D41, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D38, (double) 0.0f, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = vector2D30.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D19, (double) 100L, vector2D38);
        double double48 = line7.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D49, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D50, vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Line line55 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D50, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line56 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D57, vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D58, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Line line63 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D58, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line64 = line63.copySelf();
        boolean boolean65 = line56.isParallelTo(line64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean68 = vector1D66.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean71 = vector1D69.equals((java.lang.Object) 100L);
        double double72 = vector1D66.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D69);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double74 = vector1D69.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = line56.getPointAt(vector1D69, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = line7.intersection(line56);
        double double78 = line7.getOriginOffset();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line7);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.POSITIVE_INFINITY + "'", double74 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNull(vector2D77);
        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.47738944183057985d, 10.000000953674316d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.043760056189752d + "'", double2 == 13.043760056189752d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 10L, Double.POSITIVE_INFINITY, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D10, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D7, (double) 0.0f, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D1.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D16, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D17, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D23, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D29, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D30, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D27, (double) 0.0f, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D38, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D39, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D36, (double) 0.0f, vector2D39);
        boolean boolean44 = vector2D34.equals((java.lang.Object) vector2D36);
        line22.reset(vector2D23, vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D50, vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D51, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D48, (double) 0.0f, vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D59, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D60, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D57, (double) 0.0f, vector2D60);
        boolean boolean65 = vector2D55.equals((java.lang.Object) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D67, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D70, vector2D71);
        double double73 = vector2D68.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D78, vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D79, vector2D81);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D76, (double) 0.0f, vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = vector2D68.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D57, (double) 100L, vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D86 = vector2D85.getZero();
        boolean boolean87 = line22.contains(vector2D85);
        org.apache.commons.math3.geometry.euclidean.twod.Line line88 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment89 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D1, vector2D85, line88);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = segment89.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D91 = segment89.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.Line line92 = segment89.getLine();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertNotNull(vector2D86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(vector2D90);
        org.junit.Assert.assertNotNull(vector2D91);
        org.junit.Assert.assertNull(line92);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean9 = vector1D7.equals((java.lang.Object) 100L);
        double double10 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        double double11 = vector1D1.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(6.283185307179586d, vector1D1);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(5.464151336010201E-5d, 8.881784197001252E-16d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        java.text.NumberFormat numberFormat10 = null;
        java.lang.String str11 = vector3D9.toString(numberFormat10);
        double double12 = vector3D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{(Infinity); (Infinity); (Infinity)}" + "'", str11.equals("{(Infinity); (Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray3 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int4 = org.apache.commons.math3.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple5 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray3);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple6 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray3);
        double[] doubleArray10 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple12 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray10);
        double[] doubleArray16 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int17 = org.apache.commons.math3.util.MathUtils.hash(doubleArray16);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple18 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray16);
        double[] doubleArray19 = orderedTuple18.getComponents();
        int int20 = orderedTuple12.compareTo(orderedTuple18);
        int int21 = orderedTuple6.compareTo(orderedTuple18);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 206402655 + "'", int4 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 206402655 + "'", int11 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 206402655 + "'", int17 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D1.isNaN();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean9 = vector1D7.equals((java.lang.Object) 100L);
        double double10 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D1.subtract((double) (-1L), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D16, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D16, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D23, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D24, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line29 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = line29.copySelf();
        boolean boolean31 = line22.isParallelTo(line30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean34 = vector1D32.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) 100L);
        double double38 = vector1D32.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double40 = vector1D35.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = line22.getPointAt(vector1D35, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D44, vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D45, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line50 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D45, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D52, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D53, vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Line line58 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D53, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line59 = line58.copySelf();
        boolean boolean60 = line51.isParallelTo(line59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean63 = vector1D61.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean66 = vector1D64.equals((java.lang.Object) 100L);
        double double67 = vector1D61.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double69 = vector1D64.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D68);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = line51.getPointAt(vector1D64, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double76 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D73, vector1D75);
        double double77 = vector1D73.getNormSq();
        double double78 = vector1D64.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean81 = vector1D79.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D82 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean84 = vector1D82.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean87 = vector1D85.equals((java.lang.Object) 100L);
        double double88 = vector1D82.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D85);
        double double89 = vector1D79.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D82);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = vector1D64.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D79);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D92 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D93 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 144, vector1D11, Double.NaN, vector1D35, (-4.123630673989923d), vector1D64, 0.01618564284234869d, vector1D92);
        boolean boolean94 = vector1D92.isInfinite();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.POSITIVE_INFINITY + "'", double69 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 4.2602055991049024E16d + "'", double77 == 4.2602055991049024E16d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.06402655E8d + "'", double78 == 2.06402655E8d);
        org.junit.Assert.assertNotNull(vector1D79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(vector1D82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(vector1D85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D90);
        org.junit.Assert.assertNotNull(vector1D92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.486585557710477d + "'", double1 == 21.486585557710477d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet11 = plane8.wholeSpace();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(polyhedronsSet11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = polygonsSet1.buildNew(euclidean2DBSPTree2);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree4 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = polygonsSet1.buildNew(euclidean2DBSPTree4);
        try {
            org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(polygonsSet3);
        org.junit.Assert.assertNotNull(polygonsSet5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = polygonsSet1.buildNew(euclidean2DBSPTree2);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree4 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = polygonsSet1.buildNew(euclidean2DBSPTree4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D6, vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D7, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line12 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D7, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D14, vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D15, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = line20.copySelf();
        boolean boolean22 = line13.isParallelTo(line21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D23, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D24, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line29 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = line29.copySelf();
        boolean boolean31 = line21.isParallelTo(line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D33, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D33, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = line38.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D43, vector2D44);
        double double46 = vector2D41.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D51, vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D52, vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D49, (double) 0.0f, vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D41.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        double double58 = line38.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = line30.intersection(line38);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet60 = line38.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree62 = polygonsSet60.getTree(true);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet63 = polygonsSet1.buildNew(euclidean2DBSPTree62);
        org.junit.Assert.assertNotNull(polygonsSet3);
        org.junit.Assert.assertNotNull(polygonsSet5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNull(vector2D59);
        org.junit.Assert.assertNotNull(polygonsSet60);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree62);
        org.junit.Assert.assertNotNull(polygonsSet63);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        double double7 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean13 = vector1D11.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean16 = vector1D14.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        double double20 = vector1D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        double double21 = vector1D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D8, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree25);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint27 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet26);
        orientedPoint24.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean32 = vector1D30.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean35 = vector1D33.equals((java.lang.Object) 100L);
        double double36 = vector1D30.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double38 = vector1D33.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean42 = vector1D40.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean45 = vector1D43.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean48 = vector1D46.equals((java.lang.Object) 100L);
        double double49 = vector1D43.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        double double50 = vector1D40.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D37, 0.0d, vector1D40);
        double double52 = orientedPoint24.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        boolean boolean53 = orientedPoint24.isDirect();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-0.0d) + "'", double52 == (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 144, (double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine4 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion5 = subLine4.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion6 = subLine4.getRemainingRegion();
        boolean boolean7 = subLine4.isEmpty();
        org.junit.Assert.assertNotNull(euclidean1DRegion5);
        org.junit.Assert.assertNotNull(euclidean1DRegion6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        double double7 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean13 = vector1D11.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean16 = vector1D14.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        double double20 = vector1D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        double double21 = vector1D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D8, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree25);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint27 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet26);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree28 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet29 = intervalsSet26.buildNew(euclidean1DBSPTree28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean33 = vector1D31.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean36 = vector1D34.equals((java.lang.Object) 100L);
        double double37 = vector1D31.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D34.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean43 = vector1D41.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean46 = vector1D44.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean49 = vector1D47.equals((java.lang.Object) 100L);
        double double50 = vector1D44.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        double double51 = vector1D41.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D38, 0.0d, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint54 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D41, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree55 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet56 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree55);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint57 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint54, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet56);
        orientedPoint54.revertSelf();
        try {
            org.apache.commons.math3.geometry.partitioning.Side side59 = intervalsSet29.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(intervalsSet29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int[] intArray5 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5, (int) (short) 1);
        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7, (int) '#');
        int[] intArray15 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray17 = org.apache.commons.math3.util.MathArrays.copyOf(intArray15, (int) (short) 1);
        int[] intArray19 = org.apache.commons.math3.util.MathArrays.copyOf(intArray17, (int) '#');
        int[] intArray25 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray27 = org.apache.commons.math3.util.MathArrays.copyOf(intArray25, (int) (short) 1);
        int[] intArray29 = org.apache.commons.math3.util.MathArrays.copyOf(intArray27, (int) '#');
        double double30 = org.apache.commons.math3.util.MathArrays.distance(intArray17, intArray29);
        double double31 = org.apache.commons.math3.util.MathArrays.distance(intArray7, intArray17);
        int[] intArray37 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray39 = org.apache.commons.math3.util.MathArrays.copyOf(intArray37, (int) (short) 1);
        int int40 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray39);
        int[] intArray46 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray48 = org.apache.commons.math3.util.MathArrays.copyOf(intArray46, (int) (short) 1);
        int[] intArray50 = org.apache.commons.math3.util.MathArrays.copyOf(intArray48, (int) '#');
        int[] intArray56 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray58 = org.apache.commons.math3.util.MathArrays.copyOf(intArray56, (int) (short) 1);
        int[] intArray60 = org.apache.commons.math3.util.MathArrays.copyOf(intArray58, (int) '#');
        double double61 = org.apache.commons.math3.util.MathArrays.distance(intArray48, intArray60);
        int[] intArray67 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray69 = org.apache.commons.math3.util.MathArrays.copyOf(intArray67, (int) (short) 1);
        int[] intArray71 = org.apache.commons.math3.util.MathArrays.copyOf(intArray69, (int) '#');
        int int72 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray48, intArray69);
        double double73 = org.apache.commons.math3.util.MathArrays.distance(intArray7, intArray69);
        int[] intArray79 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray81 = org.apache.commons.math3.util.MathArrays.copyOf(intArray79, (int) (short) 1);
        int[] intArray83 = org.apache.commons.math3.util.MathArrays.copyOf(intArray81, (int) '#');
        int[] intArray89 = new int[] { (short) -1, (-1), ' ', 10, (short) -1 };
        int[] intArray91 = org.apache.commons.math3.util.MathArrays.copyOf(intArray89, (int) (short) 1);
        int[] intArray93 = org.apache.commons.math3.util.MathArrays.copyOf(intArray91, (int) '#');
        double double94 = org.apache.commons.math3.util.MathArrays.distance(intArray81, intArray93);
        int int95 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray7, intArray81);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 55);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        double double11 = plane8.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray14 = vector3D13.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D13, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray19 = vector3D18.toArray();
        double double20 = vector3D17.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = plane21.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        double double24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D9, vector3D22);
        boolean boolean25 = vector3D22.isInfinite();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        double double8 = vector3D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        double double18 = vector3D17.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D10, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line9.intersection(line19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D25, vector3D27);
        double double29 = vector3D28.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line30 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D21, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray32 = vector3D31.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D31, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray36 = vector3D35.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D37);
        double double39 = vector3D38.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line40 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D31, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = line30.intersection(line40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray43 = vector3D42.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D42, vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray47 = vector3D46.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D46, vector3D48);
        double double50 = vector3D49.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line51 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D42, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray53 = vector3D52.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D52, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray57 = vector3D56.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D56, vector3D58);
        double double60 = vector3D59.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line61 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D52, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = line51.intersection(line61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray64 = vector3D63.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D63, vector3D65);
        double double67 = vector3D66.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean69 = vector3D66.equals((java.lang.Object) mathIllegalStateException68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray71 = vector3D70.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D70, vector3D72);
        double double74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D66, vector3D72);
        double double75 = line61.getAbscissa(vector3D72);
        double double76 = line30.distance(vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = line19.intersection(line30);
        double double78 = vector3D77.getY();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + (-1.0d) + "'", double75 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList4 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList4);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform6 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion7 = polygonsSet5.applyTransform(euclidean2DTransform6);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion8 = polygonsSet5.copySelf();
        boolean boolean9 = polygonsSet3.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet5);
        double double10 = polygonsSet3.getBoundarySize();
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion7);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane2 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane(euclidean3DHyperplane0, euclidean2DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion3 = subPlane2.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        double double11 = vector3D8.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray20 = vector3D19.toArray();
        double double21 = vector3D18.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray25 = vector3D24.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D24, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray30 = vector3D29.toArray();
        double double31 = vector3D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane13, plane22, plane32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray36 = vector3D35.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D37);
        double double39 = vector3D38.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean41 = vector3D38.equals((java.lang.Object) mathIllegalStateException40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray43 = vector3D42.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D42, vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray48 = vector3D47.toArray();
        double double49 = vector3D46.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D44, vector3D47);
        double double51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D38, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray53 = vector3D52.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D52, vector3D54);
        double double56 = vector3D55.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException57 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean58 = vector3D55.equals((java.lang.Object) mathIllegalStateException57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray60 = vector3D59.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D59, vector3D61);
        double double63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D55, vector3D61);
        double double64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D47, vector3D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = plane22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane66 = subPlane2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean2DRegion3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(vector2D65);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double[] doubleArray3 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int4 = org.apache.commons.math3.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple5 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray3);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple6 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray3);
        double[] doubleArray10 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray10);
        double[] doubleArray15 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray15);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple17 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray15);
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray15);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) (byte) 0);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray20);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray10);
        double[] doubleArray26 = new double[] { 100L, 10.0d, (-1.0d) };
        double[] doubleArray29 = new double[] { Double.NEGATIVE_INFINITY, 0.0d };
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray26);
        double[] doubleArray35 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int36 = org.apache.commons.math3.util.MathUtils.hash(doubleArray35);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple37 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray35);
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray35);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray35, (double) (byte) -1);
        double double41 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 206402655 + "'", int4 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 206402655 + "'", int11 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 206402655 + "'", int16 == 206402655);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.50373127401788d + "'", double18 == 100.50373127401788d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 206402655 + "'", int36 == 206402655);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.50373127401788d + "'", double38 == 100.50373127401788d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.91743119266054d + "'", double41 == 100.91743119266054d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, 10.025154925187834d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.566370614359172d + "'", double2 == 12.566370614359172d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(14.142135623730951d, 100.50373127401787d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 3, (float) 1807551715);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = line6.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D11, vector2D12);
        double double14 = vector2D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D20, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D17, (double) 0.0f, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D9.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double26 = line6.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double[] doubleArray27 = vector2D17.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray27);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line14.copySelf();
        boolean boolean16 = line7.isParallelTo(line15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean22 = vector1D20.equals((java.lang.Object) 100L);
        double double23 = vector1D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double25 = vector1D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = line7.getPointAt(vector1D20, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D29, vector1D31);
        double double33 = vector1D29.getNormSq();
        double double34 = vector1D20.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean40 = vector1D38.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean43 = vector1D41.equals((java.lang.Object) 100L);
        double double44 = vector1D38.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        double double45 = vector1D35.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = vector1D46.negate();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.2602055991049024E16d + "'", double33 == 4.2602055991049024E16d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.06402655E8d + "'", double34 == 2.06402655E8d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D47);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 6, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 144, (double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine4 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane5 = subLine4.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane6 = subLine4.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion7 = euclidean2DAbstractSubHyperplane6.getRemainingRegion();
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane5);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane6);
        org.junit.Assert.assertNotNull(euclidean1DRegion7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(14.142135623730951d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(2.2250738585072014E-308d, (double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 100, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = polygonsSet1.buildNew(euclidean2DBSPTree2);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree4 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = polygonsSet1.buildNew(euclidean2DBSPTree4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree7 = polygonsSet1.getTree(false);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform8 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion9 = polygonsSet1.applyTransform(euclidean2DTransform8);
        org.junit.Assert.assertNotNull(polygonsSet3);
        org.junit.Assert.assertNotNull(polygonsSet5);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree7);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        double double7 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean13 = vector1D11.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean16 = vector1D14.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        double double20 = vector1D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        double double21 = vector1D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D8, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree25);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint27 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet26);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree28 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet29 = intervalsSet26.buildNew(euclidean1DBSPTree28);
        try {
            java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList30 = intervalsSet29.asList();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(intervalsSet29);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = polyhedronsSet5.translate(vector3D6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet5.getTree(false);
        euclidean3DBSPTree4.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane13 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = euclidean3DBSPTree4.split(euclidean3DSubHyperplane13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree16 = euclidean3DBSPTree4.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet17 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(euclidean3DBSPTree16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree18 = euclidean3DBSPTree16.getMinus();
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(polyhedronsSet7);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree16);
        org.junit.Assert.assertNull(euclidean3DBSPTree18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList4 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = polygonsSet5.buildNew(euclidean2DBSPTree6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet9 = polygonsSet5.buildNew(euclidean2DBSPTree8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree11 = polygonsSet5.getTree(false);
        boolean boolean12 = polygonsSet3.isEmpty(euclidean2DBSPTree11);
        org.junit.Assert.assertNotNull(polygonsSet7);
        org.junit.Assert.assertNotNull(polygonsSet9);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(21.486585557710477d, 0.0d, (double) (short) 10);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray2 = vector3D1.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D1, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray7 = vector3D6.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D6, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray12 = vector3D11.toArray();
        double double13 = vector3D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray18 = vector3D17.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D17, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        double double25 = vector3D24.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D17, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D11.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D4.subtract(0.01618564284234869d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray30 = vector3D29.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D29, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray35 = vector3D34.toArray();
        double double36 = vector3D33.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D31, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = plane37.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        double double40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D11, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation41 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet42 = polyhedronsSet0.rotate(vector3D38, rotation41);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion43 = polyhedronsSet0.copySelf();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet42);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion43);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double1 = vector1D0.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean4 = vector1D2.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean7 = vector1D5.equals((java.lang.Object) 100L);
        double double8 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        double double9 = vector1D5.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double11 = vector1D5.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D10.normalize();
        org.apache.commons.math3.geometry.Space space13 = vector1D10.getSpace();
        double double14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D0, vector1D10);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(space13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(14.142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999989593d + "'", double1 == 0.9999999999989593d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double2 = org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, (double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        double double8 = vector3D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        double double18 = vector3D17.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D10, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line9.intersection(line19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        double double25 = vector3D24.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean27 = vector3D24.equals((java.lang.Object) mathIllegalStateException26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        double double32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D24, vector3D30);
        double double33 = line19.getAbscissa(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        boolean boolean35 = line19.contains(vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Line line36 = line19.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray38 = vector3D37.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D37, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray43 = vector3D42.toArray();
        double double44 = vector3D41.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane45 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D39, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray47 = vector3D46.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D46, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray51 = vector3D50.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D50, vector3D52);
        double double54 = vector3D53.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line55 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D46, vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray57 = vector3D56.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D56, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray61 = vector3D60.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D60, vector3D62);
        double double64 = vector3D63.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line65 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D56, vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = line55.intersection(line65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = line55.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray69 = vector3D68.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D68, vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray73 = vector3D72.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D72, vector3D74);
        double double76 = vector3D75.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line77 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D68, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray79 = vector3D78.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D78, vector3D80);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray83 = vector3D82.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D82, vector3D84);
        double double86 = vector3D85.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line87 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D78, vector3D85);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = line77.intersection(line87);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = line77.getDirection();
        boolean boolean90 = line55.isSimilarTo(line77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = plane45.intersection(line55);
        double double92 = line19.distance(line55);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(line36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D88);
        org.junit.Assert.assertNotNull(vector3D89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(vector3D91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray4 = vector3D3.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D3, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray9 = vector3D8.toArray();
        double double10 = vector3D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane11);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane13 = plane11.wholeHyperplane();
        double double14 = subPlane13.getSize();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane15 = polyhedronsSet0.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray17 = vector3D16.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray27 = vector3D26.toArray();
        double double28 = vector3D25.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D23, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray33 = vector3D32.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D32, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray37 = vector3D36.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D36, vector3D38);
        double double40 = vector3D39.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line41 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D32, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D26.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D19.subtract(0.01618564284234869d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray45 = vector3D44.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D44, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray50 = vector3D49.toArray();
        double double51 = vector3D48.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane52 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = plane52.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D53);
        double double55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D26, vector3D53);
        double[] doubleArray56 = vector3D26.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet57 = polyhedronsSet0.translate(vector3D26);
        boolean boolean58 = polyhedronsSet57.isEmpty();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet59 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet61 = polyhedronsSet59.translate(vector3D60);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree63 = polyhedronsSet59.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet64 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet66 = polyhedronsSet64.translate(vector3D65);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree68 = polyhedronsSet64.getTree(false);
        euclidean3DBSPTree63.insertInTree(euclidean3DBSPTree68, false);
        boolean boolean71 = polyhedronsSet57.isEmpty(euclidean3DBSPTree68);
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean3DSubHyperplane15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(polyhedronsSet57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(polyhedronsSet61);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree63);
        org.junit.Assert.assertNotNull(polyhedronsSet66);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D5, vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D2, (double) 0.0f, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D13, vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D14, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D11, (double) 0.0f, vector2D14);
        boolean boolean19 = vector2D9.equals((java.lang.Object) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D21, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D24, vector2D25);
        double double27 = vector2D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D33, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D30, (double) 0.0f, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D22.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D11, (double) 100L, vector2D30);
        org.apache.commons.math3.geometry.Space space40 = vector2D30.getSpace();
        org.apache.commons.math3.geometry.Space space41 = vector2D30.getSpace();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(space40);
        org.junit.Assert.assertNotNull(space41);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(10.000000953674316d, 7.858950316551365d, (double) (-33553471L), 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.108225974025657E8d) + "'", double4 == (-2.108225974025657E8d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        double double7 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double9 = vector1D4.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        double double10 = vector1D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double double17 = vector3D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D20, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        double double27 = vector3D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane9, plane18, plane28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = plane28.getU();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane28.getV();
        double double34 = vector3D33.getNorm1();
        double double35 = vector3D33.getNorm1();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D0.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean5 = vector1D3.equals((java.lang.Object) 100L);
        double double6 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        double double7 = vector1D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean11 = vector1D9.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean14 = vector1D12.equals((java.lang.Object) 100L);
        double double15 = vector1D9.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double17 = vector1D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean24 = vector1D22.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean27 = vector1D25.equals((java.lang.Object) 100L);
        double double28 = vector1D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        double double29 = vector1D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D16, 0.0d, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint32 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D19, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D34, vector1D36);
        double double38 = vector1D19.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        double double39 = vector1D19.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray44 = vector3D43.toArray();
        double double45 = vector3D42.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        double double46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D41, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray48 = vector3D47.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D47, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray53 = vector3D52.toArray();
        double double54 = vector3D51.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane55 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D49, vector3D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D56, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D59, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D60, vector2D62);
        double double64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D56, vector2D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = plane55.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        double double66 = vector3D65.getX();
        double double67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D41, vector3D65);
        boolean boolean68 = vector1D40.equals((java.lang.Object) vector3D41);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279168d + "'", double1 == 4.158638853279168d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        double double7 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean13 = vector1D11.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean16 = vector1D14.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        double double20 = vector1D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        double double21 = vector1D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D8, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree25);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree28 = intervalsSet26.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D31, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint36 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D31, true);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane37 = subOrientedPoint29.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint36);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion38 = subOrientedPoint29.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion39 = subOrientedPoint29.getRemainingRegion();
        double double40 = subOrientedPoint29.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane41 = subOrientedPoint29.copySelf();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DBSPTree28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane37);
        org.junit.Assert.assertNotNull(euclidean1DRegion38);
        org.junit.Assert.assertNotNull(euclidean1DRegion39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane41);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        double double8 = vector3D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        double double18 = vector3D17.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D10, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line9.intersection(line19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = line9.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray23 = vector3D22.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D22, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray27 = vector3D26.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D26, vector3D28);
        double double30 = vector3D29.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D22, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = line9.closestPoint(line31);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D32);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        double double12 = vector3D9.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray17 = vector3D16.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D20, vector3D22);
        double double24 = vector3D23.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line25 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D16, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D10.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D3.subtract(0.01618564284234869d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray34 = vector3D33.toArray();
        double double35 = vector3D32.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = plane36.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        double double39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D10, vector3D37);
        double double40 = vector3D37.getNorm();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D2, vector3D4);
        double double6 = vector3D5.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean8 = vector3D5.equals((java.lang.Object) mathIllegalStateException7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D9, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        double double16 = vector3D13.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11, vector3D14);
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D5, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray20 = vector3D19.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D19, vector3D21);
        double double23 = vector3D22.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean25 = vector3D22.equals((java.lang.Object) mathIllegalStateException24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray27 = vector3D26.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D26, vector3D28);
        double double30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D22, vector3D28);
        double double31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D14, vector3D22);
        double double32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D1, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray35 = vector3D34.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D34, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray39 = vector3D38.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D38, vector3D40);
        double double42 = vector3D41.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line43 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D34, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray45 = vector3D44.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D44, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray49 = vector3D48.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D48, vector3D50);
        double double52 = vector3D51.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line53 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D44, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = line43.intersection(line53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = line43.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D22.subtract(Double.NEGATIVE_INFINITY, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray59 = vector3D58.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D58, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray64 = vector3D63.toArray();
        double double65 = vector3D62.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane66 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D60, vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        java.text.NumberFormat numberFormat68 = null;
        java.lang.String str69 = vector3D67.toString(numberFormat68);
        double double70 = vector3D63.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(350.0d, vector3D56, 48.0d, vector3D63);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "{(Infinity); (Infinity); (Infinity)}" + "'", str69.equals("{(Infinity); (Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Throwable[] throwableArray5 = mathIllegalArgumentException4.getSuppressed();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 10.000000953674316d, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = line6.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D11, vector2D12);
        double double14 = vector2D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D20, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D17, (double) 0.0f, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D9.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double26 = line6.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double[] doubleArray27 = vector2D17.toArray();
        double[] doubleArray31 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int32 = org.apache.commons.math3.util.MathUtils.hash(doubleArray31);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple33 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray31);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple34 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray31);
        double double35 = org.apache.commons.math3.util.MathArrays.distance(doubleArray27, doubleArray31);
        double[] doubleArray39 = new double[] { 100L, 10.0d, (-1.0d) };
        double[] doubleArray42 = new double[] { Double.NEGATIVE_INFINITY, 0.0d };
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, 4.482599606800581d);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection46 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray39, orderDirection46, true, false);
        boolean boolean52 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray27, orderDirection46, false, false);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 206402655 + "'", int32 == 206402655);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection46.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray2 = vector3D1.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D1, vector3D3);
        double double5 = vector3D4.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean7 = vector3D4.equals((java.lang.Object) mathIllegalStateException6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray9 = vector3D8.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D8, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray14 = vector3D13.toArray();
        double double15 = vector3D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10, vector3D13);
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D4, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray19 = vector3D18.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D18, vector3D20);
        double double22 = vector3D21.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean24 = vector3D21.equals((java.lang.Object) mathIllegalStateException23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D25, vector3D27);
        double double29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D21, vector3D27);
        double double30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D13, vector3D21);
        double double31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D0, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet32 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = polyhedronsSet32.translate(vector3D33);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree36 = polyhedronsSet32.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet37 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet39 = polyhedronsSet37.translate(vector3D38);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree41 = polyhedronsSet37.getTree(false);
        euclidean3DBSPTree36.insertInTree(euclidean3DBSPTree41, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree44 = euclidean3DBSPTree36.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane45 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree46 = euclidean3DBSPTree36.split(euclidean3DSubHyperplane45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree48 = euclidean3DBSPTree36.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane49 = euclidean3DBSPTree48.getCut();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray51 = vector3D50.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D50, vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray56 = vector3D55.toArray();
        double double57 = vector3D54.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane58 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D52, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane59 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray62 = vector3D61.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D61, vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray66 = vector3D65.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D65, vector3D67);
        double double69 = vector3D68.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line70 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D61, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D55.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        euclidean3DBSPTree48.setAttribute((java.lang.Object) vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D0.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(polyhedronsSet34);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree36);
        org.junit.Assert.assertNotNull(polyhedronsSet39);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree41);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree44);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree48);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray2 = vector3D1.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D1, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray7 = vector3D6.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D6, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray12 = vector3D11.toArray();
        double double13 = vector3D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray18 = vector3D17.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D17, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        double double25 = vector3D24.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D17, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D11.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D4.subtract(0.01618564284234869d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray30 = vector3D29.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D29, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray35 = vector3D34.toArray();
        double double36 = vector3D33.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D31, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = plane37.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        double double40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D11, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray45 = vector3D44.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D44, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray49 = vector3D48.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D48, vector3D50);
        double double52 = vector3D51.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line53 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D44, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray55 = vector3D54.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D54, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray59 = vector3D58.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D58, vector3D60);
        double double62 = vector3D61.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line63 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D54, vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = line53.intersection(line63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = line53.getDirection();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean68 = vector1D66.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean71 = vector1D69.equals((java.lang.Object) 100L);
        double double72 = vector1D66.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D69);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double74 = vector1D69.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = line53.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(4.158638853279168d, vector3D38, 2.418271175121957d, vector3D42, 0.0d, vector3D75);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.POSITIVE_INFINITY + "'", double74 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D75);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        float float2 = org.apache.commons.math3.util.FastMath.max(9.536743E-7f, (float) 14L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 14.0f + "'", float2 == 14.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 10L, (double) 206402655);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.31471527941076d + "'", double2 == 8.31471527941076d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane2 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane(euclidean3DHyperplane0, euclidean2DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion3 = subPlane2.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        double double11 = vector3D8.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray20 = vector3D19.toArray();
        double double21 = vector3D18.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray25 = vector3D24.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D24, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray30 = vector3D29.toArray();
        double double31 = vector3D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane13, plane22, plane32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray36 = vector3D35.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray41 = vector3D40.toArray();
        double double42 = vector3D39.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray45 = vector3D44.toArray();
        double double46 = plane43.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Line line47 = plane22.intersection(plane43);
        plane22.revertSelf();
        try {
            org.apache.commons.math3.geometry.partitioning.Side side49 = subPlane2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean2DRegion3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(line47);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        double double8 = vector3D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = line9.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = line9.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.threed.Line line17 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = line9.intersection(line17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector3D16);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = polyhedronsSet3.translate(vector3D4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree7 = polyhedronsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet8 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet10 = polyhedronsSet8.translate(vector3D9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = polyhedronsSet8.getTree(false);
        euclidean3DBSPTree7.insertInTree(euclidean3DBSPTree12, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree15 = euclidean3DBSPTree7.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane16 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = euclidean3DBSPTree7.split(euclidean3DSubHyperplane16);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane18 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree19 = euclidean3DBSPTree7.split(euclidean3DSubHyperplane18);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree20 = euclidean3DBSPTree7.copySelf();
        boolean boolean21 = polyhedronsSet2.isEmpty(euclidean3DBSPTree7);
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(polyhedronsSet5);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree7);
        org.junit.Assert.assertNotNull(polyhedronsSet10);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree19);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math3.util.FastMath.sin(2.06402655E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9285195385915858d) + "'", double1 == (-0.9285195385915858d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList9 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList9);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform11 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion12 = polygonsSet10.applyTransform(euclidean2DTransform11);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion13 = polygonsSet10.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane14 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) euclidean2DAbstractRegion13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D15, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        double double22 = vector3D19.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane23.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray27 = vector3D26.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D26, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray32 = vector3D31.toArray();
        double double33 = vector3D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray37 = vector3D36.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D36, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray42 = vector3D41.toArray();
        double double43 = vector3D40.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane45 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray47 = vector3D46.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D46, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray52 = vector3D51.toArray();
        double double53 = vector3D50.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane54 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D48, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane55 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane35, plane44, plane54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray60 = vector3D59.toArray();
        double double61 = vector3D58.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D59);
        double double62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D57, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane63 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D57);
        plane44.reset(plane63);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane65 = subPlane25.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane44);
        boolean boolean66 = subPlane25.isEmpty();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane67 = subPlane14.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane25);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion12);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane67);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.getZero();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) (byte) 10, (double) (-33553471L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.355347100000149E7d + "'", double2 == 3.355347100000149E7d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(12.566370614359172d, (double) 1072693248L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D5, vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D2, (double) 0.0f, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D13, vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D14, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D11, (double) 0.0f, vector2D14);
        boolean boolean19 = vector2D9.equals((java.lang.Object) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D21, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D24, vector2D25);
        double double27 = vector2D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D33, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D30, (double) 0.0f, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D22.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D11, (double) 100L, vector2D30);
        org.apache.commons.math3.geometry.Space space40 = vector2D30.getSpace();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) vector2D30);
        org.apache.commons.math3.geometry.Space space42 = vector2D30.getSpace();
        double double43 = vector2D30.getNormSq();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(space40);
        org.junit.Assert.assertNotNull(space42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line14.copySelf();
        boolean boolean16 = line7.isParallelTo(line15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean22 = vector1D20.equals((java.lang.Object) 100L);
        double double23 = vector1D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double25 = vector1D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = line7.getPointAt(vector1D20, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D29, vector1D31);
        double double33 = vector1D29.getNormSq();
        double double34 = vector1D20.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean40 = vector1D38.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean43 = vector1D41.equals((java.lang.Object) 100L);
        double double44 = vector1D38.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        double double45 = vector1D35.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        double double47 = vector1D46.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D46, vector1D48);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.2602055991049024E16d + "'", double33 == 4.2602055991049024E16d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.06402655E8d + "'", double34 == 2.06402655E8d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 144, (double) 10.000001f);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = intervalsSet2.buildNew(euclidean1DBSPTree3);
        try {
            double double5 = intervalsSet2.getBoundarySize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intervalsSet4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.0d, (double) 2.67523329E18f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6752332864138772E18d + "'", double2 == 2.6752332864138772E18d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line14.copySelf();
        boolean boolean16 = line7.isParallelTo(line15);
        double double17 = line7.getOriginOffset();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D20, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D21, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D28, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D29, vector2D31);
        double double33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D31);
        double double34 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D37, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D45, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D46, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D43, (double) 0.0f, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = vector2D37.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        boolean boolean52 = vector2D51.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D57, vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D58, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D55, (double) 0.0f, vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (short) 100, vector2D31, 1.5430806348152437d, vector2D51, 35.0d, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D62.negate();
        line7.reset(vector2D18, vector2D64);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D64);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(10.000001f, (double) 55);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.000002f + "'", float2 == 10.000002f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-33553472));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.05483113556160755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.938893903907228E-18d + "'", double1 == 6.938893903907228E-18d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D10, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line15);
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line16);
        double double18 = line8.getOffset(line17);
        line8.setAngle(1.1102230246251565E-16d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D24, vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D25, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D22, (double) 0.0f, vector2D25);
        double double30 = vector2D25.getNormSq();
        double double31 = vector2D25.getNorm();
        line8.reset(vector2D25, 0.24434609527920617d);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(14.000000000000002d, 0.0d, 2.06402655E8d, (-0.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval((double) (byte) 100, 12.566370614359172d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = polyhedronsSet5.translate(vector3D6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet5.getTree(false);
        euclidean3DBSPTree4.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane13 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = euclidean3DBSPTree4.split(euclidean3DSubHyperplane13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree16 = euclidean3DBSPTree4.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet17 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(euclidean3DBSPTree16);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet18 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet20 = polyhedronsSet18.translate(vector3D19);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree22 = polyhedronsSet18.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet25 = polyhedronsSet23.translate(vector3D24);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree27 = polyhedronsSet23.getTree(false);
        euclidean3DBSPTree22.insertInTree(euclidean3DBSPTree27, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree30 = euclidean3DBSPTree22.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree31 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) euclidean3DBSPTree22);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet32 = polyhedronsSet17.buildNew(euclidean3DBSPTree22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray34 = vector3D33.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D33, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray39 = vector3D38.toArray();
        double double40 = vector3D37.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane41);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane43 = plane41.wholeHyperplane();
        double double44 = subPlane43.getSize();
        double double45 = subPlane43.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree46 = euclidean3DBSPTree22.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane43);
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(polyhedronsSet7);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree16);
        org.junit.Assert.assertNotNull(polyhedronsSet20);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree22);
        org.junit.Assert.assertNotNull(polyhedronsSet25);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree27);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree30);
        org.junit.Assert.assertNotNull(polyhedronsSet32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree46);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = polyhedronsSet5.translate(vector3D6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet5.getTree(false);
        euclidean3DBSPTree4.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane13 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = euclidean3DBSPTree4.split(euclidean3DSubHyperplane13);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane15 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree16 = euclidean3DBSPTree4.split(euclidean3DSubHyperplane15);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray19 = vector3D18.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D18, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray24 = vector3D23.toArray();
        double double25 = vector3D22.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20, vector3D23);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList27 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet28 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList27);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform29 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion30 = polygonsSet28.applyTransform(euclidean2DTransform29);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion31 = polygonsSet28.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane32 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane26, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) euclidean2DAbstractRegion31);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree33 = euclidean3DBSPTree4.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane32);
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(polyhedronsSet7);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree16);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion30);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion31);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree33);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray4 = vector3D3.toArray();
        double double5 = vector3D2.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        double double6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D1, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane7 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D9, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray14 = vector3D13.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D13, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray19 = vector3D18.toArray();
        double double20 = vector3D17.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray23 = vector3D22.toArray();
        double double24 = plane21.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane25 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray27 = vector3D26.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D26, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray32 = vector3D31.toArray();
        double double33 = vector3D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = plane34.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D35);
        double double37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D22, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray39 = vector3D38.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D38, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray44 = vector3D43.toArray();
        double double45 = vector3D42.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D40, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane47 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane48 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D35, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1L), 100.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 55, vector3D1, (double) (-1L), vector3D12, 0.0d, vector3D50, 4.158638853279168d, vector3D54);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D50);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line14.copySelf();
        boolean boolean16 = line7.isParallelTo(line15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean22 = vector1D20.equals((java.lang.Object) 100L);
        double double23 = vector1D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double25 = vector1D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = line7.getPointAt(vector1D20, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D29, vector1D31);
        double double33 = vector1D29.getNormSq();
        double double34 = vector1D20.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean40 = vector1D38.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean43 = vector1D41.equals((java.lang.Object) 100L);
        double double44 = vector1D38.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        double double45 = vector1D35.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.Space space47 = vector1D20.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.2602055991049024E16d + "'", double33 == 4.2602055991049024E16d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.06402655E8d + "'", double34 == 2.06402655E8d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(space47);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) '4', (int) (short) -1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = polygonsSet1.buildNew(euclidean2DBSPTree2);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree4 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = polygonsSet1.buildNew(euclidean2DBSPTree4);
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion6 = polygonsSet5.copySelf();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(polygonsSet3);
        org.junit.Assert.assertNotNull(polygonsSet5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.geometry.partitioning.RegionFactory<org.apache.commons.math3.geometry.Space> spaceRegionFactory0 = new org.apache.commons.math3.geometry.partitioning.RegionFactory<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.Space> spaceRegion1 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.Space> spaceRegion2 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.Space> spaceRegion3 = spaceRegionFactory0.intersection(spaceRegion1, spaceRegion2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(7.858950316551365d, (double) 1.1920929E-7f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.925003421225483E-8d + "'", double3 == 5.925003421225483E-8d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D0.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean9 = vector1D7.equals((java.lang.Object) 100L);
        double double10 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D0.add((double) 10.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        boolean boolean12 = vector1D7.isInfinite();
        java.text.NumberFormat numberFormat13 = null;
        try {
            java.lang.String str14 = vector1D7.toString(numberFormat13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        float[] floatArray3 = new float[] { Float.NaN, 3, 3 };
        float[] floatArray4 = new float[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equals(floatArray3, floatArray4);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval((double) (short) 0, (double) (short) 10);
        double double3 = interval2.getMidPoint();
        double double4 = interval2.getLower();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = intervalsSet1.buildNew(euclidean1DBSPTree2);
        try {
            org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector4 = intervalsSet1.getBarycenter();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intervalsSet3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 10, 0.0f, (float) 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.geometry.partitioning.utilities.AVLTree<org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple> orderedTupleAVLTree0 = new org.apache.commons.math3.geometry.partitioning.utilities.AVLTree<org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple>();
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        double double8 = vector3D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        double double18 = vector3D17.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D10, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line9.intersection(line19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        double double25 = vector3D24.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean27 = vector3D24.equals((java.lang.Object) mathIllegalStateException26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        double double32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D24, vector3D30);
        double double33 = line19.getAbscissa(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        boolean boolean35 = line19.contains(vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Line line36 = line19.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = line36.getOrigin();
        double double38 = vector3D37.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D37.negate();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(line36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D39);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection2 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray6 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int7 = org.apache.commons.math3.util.MathUtils.hash(doubleArray6);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple8 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray6);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple9 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray6);
        double[] doubleArray13 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int14 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple15 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray13);
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray6, doubleArray13);
        double[] doubleArray20 = new double[] { 100L, 144.0d, 7.858950316551365d };
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray13, doubleArray21);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray1, orderDirection2, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection2 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection2.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 206402655 + "'", int7 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 206402655 + "'", int14 == 206402655);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        double double8 = vector3D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        double double18 = vector3D17.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D10, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line9.intersection(line19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        double double25 = vector3D24.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean27 = vector3D24.equals((java.lang.Object) mathIllegalStateException26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        double double32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D24, vector3D30);
        double double33 = line19.getAbscissa(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        boolean boolean35 = line19.contains(vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = line19.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray38 = vector3D37.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D37, vector3D39);
        double double41 = vector3D40.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean43 = vector3D40.equals((java.lang.Object) mathIllegalStateException42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray45 = vector3D44.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D44, vector3D46);
        double double48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D40, vector3D46);
        double double49 = vector3D40.getNorm();
        double double50 = vector3D36.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean4 = vector1D2.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean7 = vector1D5.equals((java.lang.Object) 100L);
        double double8 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double10 = vector1D5.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean14 = vector1D12.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean17 = vector1D15.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean20 = vector1D18.equals((java.lang.Object) 100L);
        double double21 = vector1D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        double double22 = vector1D12.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D9, 0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree26 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree26);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint28 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        try {
            boolean boolean30 = subOrientedPoint29.isEmpty();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 622876312, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = polyhedronsSet5.translate(vector3D6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet5.getTree(false);
        euclidean3DBSPTree4.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane13 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = euclidean3DBSPTree4.split(euclidean3DSubHyperplane13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree16 = euclidean3DBSPTree4.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.negate();
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(polyhedronsSet7);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree16);
        org.junit.Assert.assertNotNull(vector3D17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = polyhedronsSet5.translate(vector3D6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet5.getTree(false);
        euclidean3DBSPTree4.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane13 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = euclidean3DBSPTree4.split(euclidean3DSubHyperplane13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree16 = euclidean3DBSPTree4.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane17 = euclidean3DBSPTree16.getCut();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray19 = vector3D18.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D18, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray24 = vector3D23.toArray();
        double double25 = vector3D22.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane27 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray30 = vector3D29.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D29, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray34 = vector3D33.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D33, vector3D35);
        double double37 = vector3D36.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line38 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D23.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D36);
        euclidean3DBSPTree16.setAttribute((java.lang.Object) vector3D39);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree41 = euclidean3DBSPTree16.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree42 = euclidean3DBSPTree16.getParent();
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(polyhedronsSet7);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree16);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree41);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree42);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D0.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean9 = vector1D7.equals((java.lang.Object) 100L);
        double double10 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D0.add((double) 10.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        double double12 = vector1D7.getX();
        boolean boolean14 = vector1D7.equals((java.lang.Object) (byte) 10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean18 = vector1D16.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) 100L);
        double double22 = vector1D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double24 = vector1D19.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean27 = vector1D25.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean30 = vector1D28.equals((java.lang.Object) 100L);
        double double31 = vector1D25.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double33 = vector1D28.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        double double34 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D7.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D37, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Line line42 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D37, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line43 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D44, vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D45, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line50 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D45, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = line50.copySelf();
        boolean boolean52 = line43.isParallelTo(line51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean58 = vector1D56.equals((java.lang.Object) 100L);
        double double59 = vector1D53.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double61 = vector1D56.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = line43.getPointAt(vector1D56, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D65, vector1D67);
        double double69 = vector1D65.getNormSq();
        double double70 = vector1D56.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean73 = vector1D71.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean76 = vector1D74.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean79 = vector1D77.equals((java.lang.Object) 100L);
        double double80 = vector1D74.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D77);
        double double81 = vector1D71.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D82 = vector1D56.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D71);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean85 = vector1D83.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean88 = vector1D86.equals((java.lang.Object) 100L);
        double double89 = vector1D83.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D86);
        double double90 = vector1D86.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double92 = vector1D86.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D91);
        double double93 = vector1D82.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D91);
        double double94 = vector1D19.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D91);
        double double95 = vector1D19.getNorm1();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 4.2602055991049024E16d + "'", double69 == 4.2602055991049024E16d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 2.06402655E8d + "'", double70 == 2.06402655E8d);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D82);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(vector1D86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + Double.POSITIVE_INFINITY + "'", double92 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + Double.POSITIVE_INFINITY + "'", double93 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + Double.POSITIVE_INFINITY + "'", double94 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = polyhedronsSet3.translate(vector3D4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree7 = polyhedronsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet8 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet10 = polyhedronsSet8.translate(vector3D9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = polyhedronsSet8.getTree(false);
        euclidean3DBSPTree7.insertInTree(euclidean3DBSPTree12, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree15 = euclidean3DBSPTree7.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane16 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = euclidean3DBSPTree7.split(euclidean3DSubHyperplane16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray19 = vector3D18.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D18, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray23 = vector3D22.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D22, vector3D24);
        double double26 = vector3D25.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line27 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = line27.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        euclidean3DBSPTree17.setAttribute((java.lang.Object) line27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree34 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree1, spaceBSPTree2, (java.lang.Object) euclidean3DBSPTree17);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane35 = euclidean3DBSPTree17.getCut();
        org.junit.Assert.assertNotNull(polyhedronsSet5);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree7);
        org.junit.Assert.assertNotNull(polyhedronsSet10);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane35);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector1 = polyhedronsSet0.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D2, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray8 = vector3D7.toArray();
        double double9 = vector3D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray12 = vector3D11.toArray();
        double double13 = plane10.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D15, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        double double22 = vector3D19.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = plane23.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        double double26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D11, vector3D24);
        org.apache.commons.math3.geometry.partitioning.Region.Location location27 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1L), 100.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray32 = vector3D31.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D31, vector3D33);
        double double35 = vector3D34.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray39 = vector3D38.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D38, vector3D40);
        double double42 = vector3D41.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean44 = vector3D41.equals((java.lang.Object) mathIllegalStateException43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray46 = vector3D45.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D45, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray51 = vector3D50.toArray();
        double double52 = vector3D49.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D47, vector3D50);
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D41, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray56 = vector3D55.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D55, vector3D57);
        double double59 = vector3D58.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException60 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean61 = vector3D58.equals((java.lang.Object) mathIllegalStateException60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray63 = vector3D62.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D62, vector3D64);
        double double66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D58, vector3D64);
        double double67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D50, vector3D58);
        double double68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D37, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray71 = vector3D70.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D70, vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray75 = vector3D74.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D74, vector3D76);
        double double78 = vector3D77.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line79 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D70, vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray81 = vector3D80.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D80, vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray85 = vector3D84.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D84, vector3D86);
        double double88 = vector3D87.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line89 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D80, vector3D87);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D90 = line79.intersection(line89);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = line79.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D92 = vector3D58.subtract(Double.NEGATIVE_INFINITY, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D91);
        double double93 = vector3D92.getNormInf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D94 = vector3D34.subtract(4.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D92);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane95 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D30, vector3D94);
        org.junit.Assert.assertNotNull(euclidean3DVector1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertTrue("'" + location27 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location27.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(vector3D86);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D90);
        org.junit.Assert.assertNotNull(vector3D91);
        org.junit.Assert.assertNotNull(vector3D92);
        org.junit.Assert.assertEquals((double) double93, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D94);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D12, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D13, vector2D15);
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = plane8.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double19 = vector3D18.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D20, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        double double27 = vector3D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D18.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray32 = vector3D31.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D31, vector3D33);
        double double35 = vector3D34.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean37 = vector3D34.equals((java.lang.Object) mathIllegalStateException36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray39 = vector3D38.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D38, vector3D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D34, vector3D40);
        double double43 = vector3D30.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line14.copySelf();
        boolean boolean16 = line7.isParallelTo(line15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D18, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D18, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = line23.copySelf();
        boolean boolean25 = line15.isParallelTo(line24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D27, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Line line32 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D27, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = line32.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D34, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D37, vector2D38);
        double double40 = vector2D35.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D45, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D46, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D43, (double) 0.0f, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = vector2D35.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double52 = line32.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = line24.intersection(line32);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet54 = line32.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree56 = polygonsSet54.getTree(true);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet57 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree56);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNull(vector2D53);
        org.junit.Assert.assertNotNull(polygonsSet54);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree56);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line14.copySelf();
        boolean boolean16 = line7.isParallelTo(line15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D18, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D18, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = line23.copySelf();
        boolean boolean25 = line15.isParallelTo(line24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D27, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Line line32 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D27, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = line32.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D34, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D37, vector2D38);
        double double40 = vector2D35.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D45, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D46, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D43, (double) 0.0f, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = vector2D35.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double52 = line32.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = line24.intersection(line32);
        line24.setAngle(11.0d);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNull(vector2D53);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 144, (double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine4 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane5 = subLine4.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane6 = subLine4.copySelf();
        double double7 = subLine4.getSize();
        boolean boolean8 = subLine4.isEmpty();
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane5);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-133.99999904632568d) + "'", double7 == (-133.99999904632568d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray2 = vector3D1.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D1, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray7 = vector3D6.toArray();
        double double8 = vector3D5.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray13 = vector3D12.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D12, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray17 = vector3D16.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D16, vector3D18);
        double double20 = vector3D19.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line21 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D12, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D6.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation23 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet24 = polyhedronsSet0.rotate(vector3D22, rotation23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D25, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray30 = vector3D29.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D29, vector3D31);
        double double33 = vector3D32.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line34 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D25, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray36 = vector3D35.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray41 = vector3D40.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D40, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray46 = vector3D45.toArray();
        double double47 = vector3D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane48 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D42, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray52 = vector3D51.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D51, vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray56 = vector3D55.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D55, vector3D57);
        double double59 = vector3D58.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line60 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D51, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D45.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D38.subtract(0.01618564284234869d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray64 = vector3D63.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D63, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray69 = vector3D68.toArray();
        double double70 = vector3D67.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane71 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D65, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = plane71.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        double double74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D45, vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = vector3D25.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        double double76 = vector3D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(polyhedronsSet24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D4, vector3D6);
        double double8 = vector3D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray15 = vector3D14.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D16);
        double double18 = vector3D17.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D10, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line9.intersection(line19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D23);
        double double25 = vector3D24.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean27 = vector3D24.equals((java.lang.Object) mathIllegalStateException26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        double double32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D24, vector3D30);
        double double33 = line19.getAbscissa(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        boolean boolean35 = line19.contains(vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Line line36 = line19.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = line36.getOrigin();
        double double38 = vector3D37.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet39 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet41 = polyhedronsSet39.translate(vector3D40);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree43 = polyhedronsSet39.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet44 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet46 = polyhedronsSet44.translate(vector3D45);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree48 = polyhedronsSet44.getTree(false);
        euclidean3DBSPTree43.insertInTree(euclidean3DBSPTree48, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree51 = euclidean3DBSPTree43.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane52 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree53 = euclidean3DBSPTree43.split(euclidean3DSubHyperplane52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree55 = euclidean3DBSPTree43.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D54);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane56 = euclidean3DBSPTree55.getCut();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray58 = vector3D57.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D57, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray63 = vector3D62.toArray();
        double double64 = vector3D61.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane65 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D59, vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane66 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray69 = vector3D68.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D68, vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray73 = vector3D72.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D72, vector3D74);
        double double76 = vector3D75.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line77 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D68, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D62.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        euclidean3DBSPTree55.setAttribute((java.lang.Object) vector3D78);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = vector3D37.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D78);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(line36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet41);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree43);
        org.junit.Assert.assertNotNull(polyhedronsSet46);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree48);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree51);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree55);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D80);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D0.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean6 = vector1D4.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean9 = vector1D7.equals((java.lang.Object) 100L);
        double double10 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D0.add((double) 10.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean14 = vector1D12.equals((java.lang.Object) 100L);
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D7, vector1D12);
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        org.apache.commons.math3.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable17, objArray18);
        java.lang.Throwable[] throwableArray20 = mathIllegalArgumentException19.getSuppressed();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) double15, localizable16, (java.lang.Object[]) throwableArray20);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = intervalsSet1.buildNew(euclidean1DBSPTree2);
        try {
            double double4 = intervalsSet3.getBoundarySize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intervalsSet3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = polyhedronsSet5.translate(vector3D6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet5.getTree(false);
        euclidean3DBSPTree4.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree13 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) euclidean3DBSPTree4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = euclidean3DBSPTree13.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet15 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(polyhedronsSet7);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray3 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int4 = org.apache.commons.math3.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple5 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray3);
        double[] doubleArray9 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple11 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray9);
        double[] doubleArray12 = orderedTuple11.getComponents();
        int int13 = orderedTuple5.compareTo(orderedTuple11);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane14 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint16 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane14, euclidean1DRegion15);
        double double17 = subOrientedPoint16.getSize();
        boolean boolean18 = orderedTuple5.equals((java.lang.Object) subOrientedPoint16);
        org.apache.commons.math3.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable19, objArray20);
        boolean boolean22 = orderedTuple5.equals((java.lang.Object) localizable19);
        double[] doubleArray26 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray26);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple28 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray26);
        int int29 = orderedTuple5.compareTo(orderedTuple28);
        double[] doubleArray33 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple35 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray33);
        double[] doubleArray39 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int40 = org.apache.commons.math3.util.MathUtils.hash(doubleArray39);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple41 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray39);
        double[] doubleArray42 = orderedTuple41.getComponents();
        int int43 = orderedTuple35.compareTo(orderedTuple41);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane44 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion45 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint46 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane44, euclidean1DRegion45);
        double double47 = subOrientedPoint46.getSize();
        boolean boolean48 = orderedTuple35.equals((java.lang.Object) subOrientedPoint46);
        org.apache.commons.math3.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable49, objArray50);
        boolean boolean52 = orderedTuple35.equals((java.lang.Object) localizable49);
        double[] doubleArray56 = new double[] { 100.0f, (-1.0f), (short) 10 };
        int int57 = org.apache.commons.math3.util.MathUtils.hash(doubleArray56);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple58 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray56);
        int int59 = orderedTuple35.compareTo(orderedTuple58);
        int int60 = orderedTuple28.compareTo(orderedTuple58);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 206402655 + "'", int4 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 206402655 + "'", int10 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 206402655 + "'", int27 == 206402655);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 206402655 + "'", int34 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 206402655 + "'", int40 == 206402655);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 206402655 + "'", int57 == 206402655);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.translate(vector3D1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = polyhedronsSet5.translate(vector3D6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet5.getTree(false);
        euclidean3DBSPTree4.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree13 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) euclidean3DBSPTree4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = euclidean3DBSPTree4.getParent();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D15, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        double double22 = vector3D19.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane23.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree26 = euclidean3DBSPTree4.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane25);
        org.junit.Assert.assertNotNull(polyhedronsSet2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(polyhedronsSet7);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree26);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (byte) 0, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = line6.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D11, vector2D12);
        double double14 = vector2D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D20, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D17, (double) 0.0f, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D9.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double26 = line6.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = line6.copySelf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line28);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D10, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line15);
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line16);
        double double18 = line8.getOffset(line17);
        line8.revertSelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D20, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D21, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line26 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D21, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D29, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D30, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D30, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line36 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line35);
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line36);
        double double38 = line28.getOffset(line37);
        double double39 = line8.getOffset(line37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D41, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D41, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = line46.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D48, vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D51, vector2D52);
        double double54 = vector2D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D59, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D60, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D57, (double) 0.0f, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D49.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        double double66 = line46.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = line37.intersection(line46);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertNull(vector2D67);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line14.copySelf();
        boolean boolean16 = line7.isParallelTo(line15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean22 = vector1D20.equals((java.lang.Object) 100L);
        double double23 = vector1D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double25 = vector1D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = line7.getPointAt(vector1D20, 10.025154925187834d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 206402655);
        double double32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D29, vector1D31);
        double double33 = vector1D29.getNormSq();
        double double34 = vector1D20.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double37 = vector1D36.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean41 = vector1D39.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean44 = vector1D42.equals((java.lang.Object) 100L);
        double double45 = vector1D39.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D42);
        double double46 = vector1D42.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double48 = vector1D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean51 = vector1D50.isNaN();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean58 = vector1D56.equals((java.lang.Object) 100L);
        double double59 = vector1D53.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double61 = vector1D56.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = vector1D50.subtract((double) (-1L), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(14.000000000000002d, vector1D36, 0.8414709848078965d, vector1D47, 10.025154925187834d, vector1D60);
        double double64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D20, vector1D63);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.2602055991049024E16d + "'", double33 == 4.2602055991049024E16d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.06402655E8d + "'", double34 == 2.06402655E8d);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.POSITIVE_INFINITY + "'", double64 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion3 = subOrientedPoint2.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion4 = subOrientedPoint2.getRemainingRegion();
        org.junit.Assert.assertNull(euclidean1DRegion3);
        org.junit.Assert.assertNull(euclidean1DRegion4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane2 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane(euclidean3DHyperplane0, euclidean2DRegion1);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane3 = subPlane2.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane4 = subPlane2.copySelf();
        try {
            boolean boolean5 = subPlane2.isEmpty();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean3DHyperplane3);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D0.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean5 = vector1D3.equals((java.lang.Object) 100L);
        double double6 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        double double7 = vector1D0.getNormInf();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double double17 = vector3D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D20, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        double double27 = vector3D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane9, plane18, plane28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray32 = vector3D31.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D31, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray37 = vector3D36.toArray();
        double double38 = vector3D35.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray41 = vector3D40.toArray();
        double double42 = plane39.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Line line43 = plane18.intersection(plane39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D44, vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D47, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D48, vector2D50);
        double double52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D44, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D53, vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D54, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D58, vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D61, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D62, vector2D64);
        double double66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D58, vector2D64);
        double double67 = vector2D56.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D64);
        double double68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D50, vector2D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = plane18.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray71 = vector3D70.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D70, vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray75 = vector3D74.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D74, vector3D76);
        double double78 = vector3D77.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line79 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D70, vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray81 = vector3D80.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D80, vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray85 = vector3D84.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D84, vector3D86);
        double double88 = vector3D87.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Line line89 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D80, vector3D87);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D90 = line79.intersection(line89);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = line79.getDirection();
        double double92 = vector3D91.getDelta();
        double double93 = vector3D69.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D91);
        double double94 = vector3D91.getX();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(line43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(vector3D86);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D90);
        org.junit.Assert.assertNotNull(vector3D91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertEquals((double) double93, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + (-1.0d) + "'", double94 == (-1.0d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D10, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line15);
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line16);
        double double18 = line8.getOffset(line17);
        line8.setAngle(1.1102230246251565E-16d);
        double double21 = line8.getOriginOffset();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D0.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean5 = vector1D3.equals((java.lang.Object) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean8 = vector1D6.equals((java.lang.Object) 100L);
        double double9 = vector1D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        double double10 = vector1D0.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray12 = vector3D11.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D11, vector3D13);
        double double15 = vector3D14.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean17 = vector3D14.equals((java.lang.Object) mathIllegalStateException16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray19 = vector3D18.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D18, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray24 = vector3D23.toArray();
        double double25 = vector3D22.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20, vector3D23);
        double double27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D14, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D28, vector3D30);
        double double32 = vector3D31.getNorm();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math3.exception.MathIllegalStateException();
        boolean boolean34 = vector3D31.equals((java.lang.Object) mathIllegalStateException33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray36 = vector3D35.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D37);
        double double39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D31, vector3D37);
        double double40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D23, vector3D31);
        boolean boolean41 = vector1D3.equals((java.lang.Object) vector3D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = vector1D3.negate();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector1D42);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double double7 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double double17 = vector3D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D20, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        double double27 = vector3D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane9, plane18, plane28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = plane28.getU();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D37, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D34, (double) 0.0f, vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D45, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D46, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D43, (double) 0.0f, vector2D46);
        boolean boolean51 = vector2D41.equals((java.lang.Object) vector2D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = plane28.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D53, vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D54, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D62, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D63, vector2D65);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, vector2D60, (double) 0.0f, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = vector2D54.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = vector2D41.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D70, vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D71, vector2D73);
        org.apache.commons.math3.geometry.euclidean.twod.Line line76 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D71, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine77 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D69, vector2D71);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertEquals((double) double74, Double.NaN, 0);
    }
}

