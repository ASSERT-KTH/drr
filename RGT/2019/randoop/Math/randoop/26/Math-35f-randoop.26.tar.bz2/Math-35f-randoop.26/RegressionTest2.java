import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, number1, true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 100, true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 0L, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList0 = null;
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation3 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList0, 2, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1L), localizedFormats2, (-1L), localizedFormats4, localizedFormats5, localizedFormats6 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray8);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) 2, (java.lang.Number) 0L);
        mathIllegalArgumentException9.addSuppressed((java.lang.Throwable) outOfRangeException13);
        java.lang.Number number15 = outOfRangeException13.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0L + "'", number15.equals(0L));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        int int11 = elitisticListPopulation5.getPopulationSize();
        java.lang.String str12 = elitisticListPopulation5.toString();
        double double13 = elitisticListPopulation5.getElitismRate();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[null]" + "'", str12.equals("[null]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) 10.0f, true);
        java.lang.String str5 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "orthogonality tolerance is too small ({0}), solution is orthogonal to the jacobian" + "'", str5.equals("orthogonality tolerance is too small ({0}), solution is orthogonal to the jacobian"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (short) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList0 = null;
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation3 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList0, (int) '#', (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, 0.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, (int) (short) 100, (double) 0.0f);
        double double23 = elitisticListPopulation22.getElitismRate();
        try {
            elitisticListPopulation22.setElitismRate((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 10L, (java.lang.Number) (-1));
        java.lang.String str5 = outOfRangeException4.toString();
        java.lang.Throwable[] throwableArray6 = outOfRangeException4.getSuppressed();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10L + "'", number7.equals(10L));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation5.nextGeneration();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(population9);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (short) -1, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) 52, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class ({0}) does not implement Comparable" + "'", str1.equals("class ({0}) does not implement Comparable"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        java.lang.Object[] objArray1 = null;
        java.lang.Object[] objArray2 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray1);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray1);
        java.lang.Throwable[] throwableArray4 = mathIllegalArgumentException3.getSuppressed();
        java.lang.Object[] objArray5 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = outOfRangeException4.getContext();
        java.lang.Number number15 = outOfRangeException4.getLo();
        java.lang.String str16 = outOfRangeException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str16.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str10 = outOfRangeException9.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str16 = outOfRangeException15.toString();
        outOfRangeException9.addSuppressed((java.lang.Throwable) outOfRangeException15);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext18.setValue("hi!", (java.lang.Object) localizedFormats20);
        java.util.Set<java.lang.String> strSet22 = exceptionContext18.getKeys();
        java.util.Set<java.lang.String> strSet23 = exceptionContext18.getKeys();
        java.util.Set<java.lang.String> strSet24 = exceptionContext18.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1L), localizedFormats28, (-1L), localizedFormats30, localizedFormats31, localizedFormats32 };
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray34);
        java.lang.Object[] objArray36 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray34);
        exceptionContext18.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray36);
        java.lang.Number number39 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number39, (java.lang.Number) (short) 100, (java.lang.Number) 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str10.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str16.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNotNull(strSet22);
        org.junit.Assert.assertNotNull(strSet23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (short) 10, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray7 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, chromosomeArray7);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, 100, (double) (byte) 0);
        int int13 = elitisticListPopulation12.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome14 = null;
        elitisticListPopulation12.addChromosome(chromosome14);
        java.lang.String str16 = elitisticListPopulation12.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray17 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList18 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, chromosomeArray17);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, 100, (double) (byte) 0);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18);
        elitisticListPopulation12.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray26 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList27 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, chromosomeArray26);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation31 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, 100, (double) (byte) 0);
        int int32 = elitisticListPopulation31.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome33 = null;
        elitisticListPopulation31.addChromosome(chromosome33);
        java.lang.String str35 = elitisticListPopulation31.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray36 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList37 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, chromosomeArray36);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation41 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, 100, (double) (byte) 0);
        elitisticListPopulation31.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray46 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList47 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, chromosomeArray46);
        elitisticListPopulation45.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation52 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, (int) (byte) 100, 0.0d);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray55 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList56 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList56, chromosomeArray55);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation60 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList56, 100, (double) (byte) 0);
        int int61 = elitisticListPopulation60.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome62 = null;
        elitisticListPopulation60.addChromosome(chromosome62);
        java.lang.String str64 = elitisticListPopulation60.toString();
        org.apache.commons.math3.genetics.Population population65 = elitisticListPopulation60.nextGeneration();
        int int66 = elitisticListPopulation60.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray67 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList68 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList68, chromosomeArray67);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation72 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList68, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList73 = elitisticListPopulation72.getChromosomes();
        elitisticListPopulation60.setChromosomes(chromosomeList73);
        elitisticListPopulation5.setChromosomes(chromosomeList73);
        int int76 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setElitismRate(0.0d);
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome79 = elitisticListPopulation5.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(chromosomeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[null]" + "'", str16.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chromosomeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[null]" + "'", str35.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chromosomeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chromosomeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "[null]" + "'", str64.equals("[null]"));
        org.junit.Assert.assertNotNull(population65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(chromosomeArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(chromosomeList73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 100 + "'", int76 == 100);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, number1, true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f), (java.lang.Number) 1L, true);
        java.lang.String str5 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "number of robustness iterations ({0})" + "'", str5.equals("number of robustness iterations ({0})"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        int int9 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation5.addChromosome(chromosome10);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray12 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, chromosomeArray12);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation17 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, 100, (double) (byte) 0);
        elitisticListPopulation17.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor20 = elitisticListPopulation17.iterator();
        elitisticListPopulation17.setPopulationLimit(0);
        double double23 = elitisticListPopulation17.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList24 = elitisticListPopulation17.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList24);
        double double26 = elitisticListPopulation5.getElitismRate();
        int int27 = elitisticListPopulation5.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(chromosomeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chromosomeItor20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(chromosomeList24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str10 = outOfRangeException9.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str16 = outOfRangeException15.toString();
        outOfRangeException9.addSuppressed((java.lang.Throwable) outOfRangeException15);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException9);
        java.lang.Throwable[] throwableArray19 = outOfRangeException9.getSuppressed();
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str10.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str16.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        double double9 = elitisticListPopulation5.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation5.addChromosome(chromosome10);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor12 = elitisticListPopulation5.iterator();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(chromosomeItor12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        int int11 = elitisticListPopulation5.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray12 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, chromosomeArray12);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation17 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, 100, (double) (byte) 0);
        int int18 = elitisticListPopulation17.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome19 = null;
        elitisticListPopulation17.addChromosome(chromosome19);
        java.lang.String str21 = elitisticListPopulation17.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray22 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList23 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, chromosomeArray22);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation27 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, 100, (double) (byte) 0);
        elitisticListPopulation17.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation32 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, 100, (double) 0.0f);
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation35 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, 52, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(chromosomeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[null]" + "'", str21.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "must have n >= 0 for n!, got n = {0}" + "'", str1.equals("must have n >= 0 for n!, got n = {0}"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.MUTATION_RATE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0d), false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MUTATION_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MUTATION_RATE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation5.getChromosomes();
        elitisticListPopulation5.setElitismRate((double) 1L);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation5.getChromosomes();
        elitisticListPopulation5.setPopulationLimit((int) (short) 100);
        org.apache.commons.math3.genetics.Chromosome chromosome14 = null;
        elitisticListPopulation5.addChromosome(chromosome14);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertNotNull(chromosomeItor9);
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertNotNull(chromosomeList11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (-1L), (java.lang.Number) (short) 10);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (byte) 0, (java.lang.Number) 0, true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = numberIsTooLargeException10.getContext();
        outOfRangeException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(exceptionContext12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number13 = outOfRangeException4.getLo();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str19 = outOfRangeException18.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str25 = outOfRangeException24.toString();
        outOfRangeException18.addSuppressed((java.lang.Throwable) outOfRangeException24);
        java.lang.Number number27 = outOfRangeException18.getLo();
        java.lang.Number number28 = outOfRangeException18.getHi();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Number number30 = outOfRangeException18.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException18);
        java.lang.Number number32 = outOfRangeException18.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 100 + "'", number13.equals((short) 100));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str19.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str25.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (short) 100 + "'", number27.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) -1 + "'", number28.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 100 + "'", number30.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (short) -1 + "'", number32.equals((short) -1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, (int) (byte) 1, 0.0d);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation19.getChromosomes();
        java.lang.Class<?> wildcardClass21 = chromosomeList20.getClass();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        elitisticListPopulation5.setPopulationLimit((int) (byte) -1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList9 = elitisticListPopulation5.getChromosomes();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome10 = elitisticListPopulation5.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(chromosomeList9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, (java.lang.Number) (-1.0d), false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation5.iterator();
        java.lang.String str8 = elitisticListPopulation5.toString();
        int int9 = elitisticListPopulation5.getPopulationLimit();
        double double10 = elitisticListPopulation5.getElitismRate();
        int int11 = elitisticListPopulation5.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList12 = elitisticListPopulation5.getChromosomes();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chromosomeList12);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.BETA;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BETA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BETA));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray7 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, chromosomeArray7);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, 100, (double) (byte) 0);
        int int13 = elitisticListPopulation12.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome14 = null;
        elitisticListPopulation12.addChromosome(chromosome14);
        java.lang.String str16 = elitisticListPopulation12.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray17 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList18 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, chromosomeArray17);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, 100, (double) (byte) 0);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18);
        elitisticListPopulation12.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray26 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList27 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, chromosomeArray26);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation31 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, 100, (double) (byte) 0);
        int int32 = elitisticListPopulation31.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome33 = null;
        elitisticListPopulation31.addChromosome(chromosome33);
        java.lang.String str35 = elitisticListPopulation31.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray36 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList37 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, chromosomeArray36);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation41 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, 100, (double) (byte) 0);
        elitisticListPopulation31.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray46 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList47 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, chromosomeArray46);
        elitisticListPopulation45.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation52 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, (int) (byte) 100, 0.0d);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.Chromosome chromosome55 = null;
        elitisticListPopulation5.addChromosome(chromosome55);
        org.apache.commons.math3.genetics.Population population57 = elitisticListPopulation5.nextGeneration();
        org.apache.commons.math3.genetics.Population population58 = elitisticListPopulation5.nextGeneration();
        double double59 = elitisticListPopulation5.getElitismRate();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(chromosomeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[null]" + "'", str16.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chromosomeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[null]" + "'", str35.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chromosomeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(population57);
        org.junit.Assert.assertNotNull(population58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        java.util.Set<java.lang.String> strSet17 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet18 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet19 = exceptionContext13.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1L), localizedFormats23, (-1L), localizedFormats25, localizedFormats26, localizedFormats27 };
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray28);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray29);
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        exceptionContext13.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray31);
        java.lang.Throwable throwable33 = exceptionContext13.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        exceptionContext13.setValue("all ordinatae must be finite real numbers, but {0}-th is {1}", (java.lang.Object) localizedFormats35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwable33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        java.util.Set<java.lang.String> strSet17 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet18 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet19 = exceptionContext13.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray22);
        java.lang.String str24 = mathIllegalArgumentException23.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext25 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException23);
        exceptionContext13.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (10)", (java.lang.Object) mathIllegalArgumentException23);
        java.lang.Throwable[] throwableArray27 = mathIllegalArgumentException23.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.MathIllegalArgumentException: invalid rounding method {0}, valid methods: {1} ({2}), {3} ({4}), {5} ({6}), {7} ({8}), {9} ({10}), {11} ({12}), {13} ({14}), {15} ({16})" + "'", str24.equals("org.apache.commons.math3.exception.MathIllegalArgumentException: invalid rounding method {0}, valid methods: {1} ({2}), {3} ({4}), {5} ({6}), {7} ({8}), {9} ({10}), {11} ({12}), {13} ({14}), {15} ({16})"));
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, (int) (byte) 1, 0.0d);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation19.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray21 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList22 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList22, chromosomeArray21);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation26 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList22, 100, (double) (byte) 0);
        int int27 = elitisticListPopulation26.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList28 = elitisticListPopulation26.getChromosomes();
        elitisticListPopulation19.setChromosomes(chromosomeList28);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertNotNull(chromosomeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertNotNull(chromosomeList28);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation5.iterator();
        int int8 = elitisticListPopulation5.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 100L, true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Population population7 = elitisticListPopulation5.nextGeneration();
        elitisticListPopulation5.setPopulationLimit((int) (short) 0);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        int int16 = elitisticListPopulation15.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome17 = null;
        elitisticListPopulation15.addChromosome(chromosome17);
        java.lang.String str19 = elitisticListPopulation15.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray20 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, chromosomeArray20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, 100, (double) (byte) 0);
        elitisticListPopulation15.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation29 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray30 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList31 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31, chromosomeArray30);
        elitisticListPopulation29.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation36 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31, (int) (short) 1, (double) 0L);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray38 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList39 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList39, chromosomeArray38);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation43 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList39, 100, (double) (byte) 0);
        elitisticListPopulation43.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor46 = elitisticListPopulation43.iterator();
        elitisticListPopulation43.setPopulationLimit(0);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray49 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList50 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList50, chromosomeArray49);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation54 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList50, 100, (double) (byte) 0);
        elitisticListPopulation54.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor57 = elitisticListPopulation54.iterator();
        elitisticListPopulation54.setPopulationLimit(0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList60 = elitisticListPopulation54.getChromosomes();
        elitisticListPopulation43.setChromosomes(chromosomeList60);
        elitisticListPopulation5.setChromosomes(chromosomeList60);
        double double63 = elitisticListPopulation5.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray64 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList65 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList65, chromosomeArray64);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation69 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList65, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList70 = elitisticListPopulation69.getChromosomes();
        elitisticListPopulation69.setElitismRate((double) 1L);
        org.apache.commons.math3.genetics.Population population73 = elitisticListPopulation69.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray74 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList75 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean76 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList75, chromosomeArray74);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation79 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList75, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor80 = elitisticListPopulation79.iterator();
        elitisticListPopulation79.setPopulationLimit((int) (byte) -1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList83 = elitisticListPopulation79.getChromosomes();
        elitisticListPopulation69.setChromosomes(chromosomeList83);
        elitisticListPopulation5.setChromosomes(chromosomeList83);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(population7);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[null]" + "'", str19.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chromosomeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chromosomeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(chromosomeItor46);
        org.junit.Assert.assertNotNull(chromosomeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(chromosomeItor57);
        org.junit.Assert.assertNotNull(chromosomeList60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(chromosomeArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(chromosomeList70);
        org.junit.Assert.assertNotNull(population73);
        org.junit.Assert.assertNotNull(chromosomeArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(chromosomeItor80);
        org.junit.Assert.assertNotNull(chromosomeList83);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        elitisticListPopulation5.setPopulationLimit((int) '4');
        int int11 = elitisticListPopulation5.getPopulationSize();
        java.lang.String str12 = elitisticListPopulation5.toString();
        java.lang.String str13 = elitisticListPopulation5.toString();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[]" + "'", str12.equals("[]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[]" + "'", str13.equals("[]"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        int int9 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor10 = elitisticListPopulation5.iterator();
        int int11 = elitisticListPopulation5.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(chromosomeItor10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 1, (java.lang.Number) (byte) 0, (java.lang.Number) (-1L));
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.0d, (java.lang.Number) 1.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (byte) 1, (java.lang.Number) (short) 10);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str18 = outOfRangeException17.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str24 = outOfRangeException23.toString();
        outOfRangeException17.addSuppressed((java.lang.Throwable) outOfRangeException23);
        java.lang.Throwable[] throwableArray26 = outOfRangeException17.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray26);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray26);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str18.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str24.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 10L, (java.lang.Number) (-1));
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        double double9 = elitisticListPopulation5.getElitismRate();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome chromosome11 = null;
        elitisticListPopulation5.addChromosome(chromosome11);
        java.lang.String str13 = elitisticListPopulation5.toString();
        int int14 = elitisticListPopulation5.getPopulationSize();
        try {
            org.apache.commons.math3.genetics.Population population15 = elitisticListPopulation5.nextGeneration();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[null, null]" + "'", str13.equals("[null, null]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        elitisticListPopulation5.setPopulationLimit((int) '4');
        java.lang.String str11 = elitisticListPopulation5.toString();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor12 = elitisticListPopulation5.iterator();
        int int13 = elitisticListPopulation5.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) -1, (java.lang.Number) 1.0d, number2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("permutation k ({0}) must be positive");
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, 0.0d);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray20 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, chromosomeArray20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, 100, (double) (byte) 0);
        int int26 = elitisticListPopulation25.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome27 = null;
        elitisticListPopulation25.addChromosome(chromosome27);
        java.lang.String str29 = elitisticListPopulation25.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray30 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList31 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31, chromosomeArray30);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation35 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31, 100, (double) (byte) 0);
        elitisticListPopulation25.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31);
        elitisticListPopulation25.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray39 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList40 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40, chromosomeArray39);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation44 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40, 100, (double) (byte) 0);
        int int45 = elitisticListPopulation44.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome46 = null;
        elitisticListPopulation44.addChromosome(chromosome46);
        java.lang.String str48 = elitisticListPopulation44.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray49 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList50 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList50, chromosomeArray49);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation54 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList50, 100, (double) (byte) 0);
        elitisticListPopulation44.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList50);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation58 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList50, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray59 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList60 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList60, chromosomeArray59);
        elitisticListPopulation58.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList60);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation65 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList60, (int) (byte) 100, 0.0d);
        elitisticListPopulation25.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList60);
        elitisticListPopulation19.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList60);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray68 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList69 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean70 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList69, chromosomeArray68);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation73 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList69, 100, (double) (byte) 0);
        int int74 = elitisticListPopulation73.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome75 = null;
        elitisticListPopulation73.addChromosome(chromosome75);
        double double77 = elitisticListPopulation73.getElitismRate();
        org.apache.commons.math3.genetics.Population population78 = elitisticListPopulation73.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome chromosome79 = null;
        elitisticListPopulation73.addChromosome(chromosome79);
        double double81 = elitisticListPopulation73.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList82 = elitisticListPopulation73.getChromosomes();
        elitisticListPopulation19.setChromosomes(chromosomeList82);
        java.lang.String str84 = elitisticListPopulation19.toString();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "[null]" + "'", str29.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chromosomeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "[null]" + "'", str48.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(chromosomeArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(chromosomeArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 100 + "'", int74 == 100);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(population78);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(chromosomeList82);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "[null, null]" + "'", str84.equals("[null, null]"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        double double9 = elitisticListPopulation5.getElitismRate();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        elitisticListPopulation5.setElitismRate((double) 1.0f);
        int int13 = elitisticListPopulation5.getPopulationSize();
        double double14 = elitisticListPopulation5.getElitismRate();
        java.lang.String str15 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome16 = null;
        elitisticListPopulation5.addChromosome(chromosome16);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[null]" + "'", str15.equals("[null]"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        elitisticListPopulation5.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation5.iterator();
        elitisticListPopulation5.setPopulationLimit(0);
        double double11 = elitisticListPopulation5.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList12 = elitisticListPopulation5.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList12, (int) (byte) 1, (double) (short) 0);
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList12, 0, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(chromosomeList12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-1L), (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str10 = outOfRangeException9.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str16 = outOfRangeException15.toString();
        outOfRangeException9.addSuppressed((java.lang.Throwable) outOfRangeException15);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        java.lang.Class<?> wildcardClass21 = localizedFormats20.getClass();
        exceptionContext18.setValue("hi!", (java.lang.Object) localizedFormats20);
        java.lang.Object obj24 = exceptionContext18.getValue("org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)");
        java.lang.Object obj26 = exceptionContext18.getValue("invalid row dimension: {0} (must be positive)");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.String str28 = localizedFormats27.getSourceString();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException30 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1.0d);
        boolean boolean31 = notPositiveException30.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray32 = notPositiveException30.getSuppressed();
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray32);
        exceptionContext18.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray33);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext36 = mathIllegalArgumentException35.getContext();
        java.lang.Number number37 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number37, (java.lang.Number) 100.0d, false);
        boolean boolean41 = numberIsTooLargeException40.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass42 = numberIsTooLargeException40.getClass();
        mathIllegalArgumentException35.addSuppressed((java.lang.Throwable) numberIsTooLargeException40);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException40);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str10.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str16.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "class ({0}) does not implement Comparable" + "'", str28.equals("class ({0}) does not implement Comparable"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(exceptionContext36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number13 = outOfRangeException4.getLo();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str19 = outOfRangeException18.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str25 = outOfRangeException24.toString();
        outOfRangeException18.addSuppressed((java.lang.Throwable) outOfRangeException24);
        java.lang.Number number27 = outOfRangeException18.getLo();
        java.lang.Number number28 = outOfRangeException18.getHi();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Number number30 = outOfRangeException18.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext32 = outOfRangeException18.getContext();
        java.lang.Object obj34 = exceptionContext32.getValue("empty polynomials coefficients array");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 100 + "'", number13.equals((short) 100));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str19.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str25.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (short) 100 + "'", number27.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) -1 + "'", number28.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 100 + "'", number30.equals((short) 100));
        org.junit.Assert.assertNotNull(exceptionContext32);
        org.junit.Assert.assertNull(obj34);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        java.lang.Throwable throwable6 = exceptionContext5.getThrowable();
        java.lang.Throwable throwable7 = null;
        try {
            throwable6.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwable6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number13 = outOfRangeException10.getLo();
        java.lang.Number number14 = outOfRangeException10.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 100 + "'", number13.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1L), localizedFormats2, (-1L), localizedFormats4, localizedFormats5, localizedFormats6 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray11 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList12 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList12, chromosomeArray11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList12, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor17 = elitisticListPopulation16.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray18 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList19 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList19, chromosomeArray18);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation23 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList19, 100, (double) (byte) 0);
        int int24 = elitisticListPopulation23.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome25 = null;
        elitisticListPopulation23.addChromosome(chromosome25);
        java.lang.String str27 = elitisticListPopulation23.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray28 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList29, chromosomeArray28);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation33 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList29, 100, (double) (byte) 0);
        elitisticListPopulation23.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList29);
        elitisticListPopulation23.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray37 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList38 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList38, chromosomeArray37);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation42 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList38, 100, (double) (byte) 0);
        int int43 = elitisticListPopulation42.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome44 = null;
        elitisticListPopulation42.addChromosome(chromosome44);
        java.lang.String str46 = elitisticListPopulation42.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray47 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList48 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList48, chromosomeArray47);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation52 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList48, 100, (double) (byte) 0);
        elitisticListPopulation42.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList48);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation56 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList48, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray57 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList58 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList58, chromosomeArray57);
        elitisticListPopulation56.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList58);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation63 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList58, (int) (byte) 100, 0.0d);
        elitisticListPopulation23.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList58);
        elitisticListPopulation16.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList58);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray66 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList67 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList67, chromosomeArray66);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation71 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList67, 100, (double) (byte) 0);
        int int72 = elitisticListPopulation71.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome73 = null;
        elitisticListPopulation71.addChromosome(chromosome73);
        java.lang.String str75 = elitisticListPopulation71.toString();
        org.apache.commons.math3.genetics.Population population76 = elitisticListPopulation71.nextGeneration();
        int int77 = elitisticListPopulation71.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray78 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList79 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean80 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList79, chromosomeArray78);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation83 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList79, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList84 = elitisticListPopulation83.getChromosomes();
        elitisticListPopulation71.setChromosomes(chromosomeList84);
        elitisticListPopulation16.setChromosomes(chromosomeList84);
        elitisticListPopulation5.setChromosomes(chromosomeList84);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation90 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList84, 1, (double) 0.0f);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertNotNull(chromosomeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chromosomeItor17);
        org.junit.Assert.assertNotNull(chromosomeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[null]" + "'", str27.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chromosomeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "[null]" + "'", str46.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(chromosomeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(chromosomeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "[null]" + "'", str75.equals("[null]"));
        org.junit.Assert.assertNotNull(population76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(chromosomeArray78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(chromosomeList84);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) -1, (java.lang.Number) 1.0d, number2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (byte) -1, (java.lang.Number) 10L, (java.lang.Number) (-1));
        java.lang.String str11 = outOfRangeException10.toString();
        java.lang.Throwable[] throwableArray12 = outOfRangeException10.getSuppressed();
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Throwable[] throwableArray14 = outOfRangeException3.getSuppressed();
        java.lang.Number number15 = outOfRangeException3.getHi();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 10L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10L + "'", number5.equals(10L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.0d, (java.lang.Number) (byte) 1, false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        elitisticListPopulation5.setElitismRate(0.0d);
        org.apache.commons.math3.genetics.Chromosome chromosome8 = null;
        elitisticListPopulation5.addChromosome(chromosome8);
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(population10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2, false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) 1L, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        java.lang.Class<?> wildcardClass16 = localizedFormats15.getClass();
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10.0f, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Number number23 = numberIsTooLargeException21.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) 0 + "'", number23.equals((byte) 0));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str20 = outOfRangeException19.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str26 = outOfRangeException25.toString();
        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException25);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext28 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext28.setValue("hi!", (java.lang.Object) localizedFormats30);
        exceptionContext13.setValue("", (java.lang.Object) exceptionContext28);
        java.lang.Throwable throwable33 = exceptionContext28.getThrowable();
        java.lang.Object obj35 = exceptionContext28.getValue("numerator");
        java.util.Set<java.lang.String> strSet36 = exceptionContext28.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str20.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str26.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNotNull(throwable33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNotNull(strSet36);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, 0.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, (int) (short) 100, (double) 0.0f);
        int int23 = elitisticListPopulation22.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor24 = elitisticListPopulation22.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray25 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList26 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList26, chromosomeArray25);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation30 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList26, 100, (double) (byte) 0);
        int int31 = elitisticListPopulation30.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome32 = null;
        elitisticListPopulation30.addChromosome(chromosome32);
        java.lang.String str34 = elitisticListPopulation30.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray35 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList36 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList36, chromosomeArray35);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation40 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList36, 100, (double) (byte) 0);
        elitisticListPopulation30.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList36);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation44 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList36, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray45 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList46 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList46, chromosomeArray45);
        elitisticListPopulation44.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList46);
        elitisticListPopulation22.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList46);
        elitisticListPopulation22.setElitismRate((double) (short) 1);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor24);
        org.junit.Assert.assertNotNull(chromosomeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "[null]" + "'", str34.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(chromosomeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (byte) 1);
        java.lang.String str2 = notPositiveException1.toString();
        java.lang.Throwable[] throwableArray3 = notPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)" + "'", str2.equals("org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) -1, (java.lang.Number) 1.0d, number2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (byte) -1, (java.lang.Number) 10L, (java.lang.Number) (-1));
        java.lang.String str11 = outOfRangeException10.toString();
        java.lang.Throwable[] throwableArray12 = outOfRangeException10.getSuppressed();
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number14 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (short) 10, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        double double9 = elitisticListPopulation5.getElitismRate();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        elitisticListPopulation5.setPopulationLimit((int) (short) 100);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(population10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) 10L, false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        java.util.Set<java.lang.String> strSet17 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet18 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet19 = exceptionContext13.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        exceptionContext13.setValue("org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points", (java.lang.Object) localizedFormats21);
        java.lang.Throwable throwable23 = exceptionContext13.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Number) (byte) -1, (java.lang.Number) 10L, (java.lang.Number) (-1));
        java.lang.String str30 = outOfRangeException29.toString();
        java.lang.Throwable[] throwableArray31 = outOfRangeException29.getSuppressed();
        exceptionContext13.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Object[]) throwableArray31);
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertNotNull(throwable23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points" + "'", str30.equals("org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 10.0d, (java.lang.Number) 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        int int11 = elitisticListPopulation5.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome12 = null;
        elitisticListPopulation5.addChromosome(chromosome12);
        org.apache.commons.math3.genetics.Chromosome chromosome14 = null;
        elitisticListPopulation5.addChromosome(chromosome14);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        elitisticListPopulation5.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation5.iterator();
        elitisticListPopulation5.setPopulationLimit(0);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray11 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList12 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList12, chromosomeArray11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList12, 100, (double) (byte) 0);
        elitisticListPopulation16.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor19 = elitisticListPopulation16.iterator();
        elitisticListPopulation16.setPopulationLimit(0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList22 = elitisticListPopulation16.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList22);
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation26 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList22, 0, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor8);
        org.junit.Assert.assertNotNull(chromosomeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chromosomeItor19);
        org.junit.Assert.assertNotNull(chromosomeList22);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        elitisticListPopulation5.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Chromosome chromosome8 = null;
        elitisticListPopulation5.addChromosome(chromosome8);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        int int16 = elitisticListPopulation15.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome17 = null;
        elitisticListPopulation15.addChromosome(chromosome17);
        java.lang.String str19 = elitisticListPopulation15.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray20 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, chromosomeArray20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, 100, (double) (byte) 0);
        elitisticListPopulation15.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation29 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray30 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList31 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31, chromosomeArray30);
        elitisticListPopulation29.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation36 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31, (int) (short) 1, (double) 0L);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList31);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[null]" + "'", str19.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chromosomeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        elitisticListPopulation5.setPopulationLimit(1);
        java.lang.String str8 = elitisticListPopulation5.toString();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (byte) 1, (java.lang.Number) (short) 10);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 0, (java.lang.Number) 0, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number13 = outOfRangeException4.getLo();
        java.lang.Number number14 = outOfRangeException4.getLo();
        java.lang.Number number15 = outOfRangeException4.getHi();
        java.lang.Number number16 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 100 + "'", number13.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) -1 + "'", number15.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) -1 + "'", number16.equals((short) -1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) ' ', (double) (byte) 0);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
//        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException2);
//        java.util.Set<java.lang.String> strSet4 = exceptionContext3.getKeys();
//        try {
//            java.lang.Throwable throwable5 = exceptionContext3.getThrowable();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(strSet4);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str6 = outOfRangeException5.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str12 = outOfRangeException11.toString();
        outOfRangeException5.addSuppressed((java.lang.Throwable) outOfRangeException11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException5);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext14.setValue("hi!", (java.lang.Object) localizedFormats16);
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        exceptionContext14.addMessage(localizable18, objArray19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1L), localizedFormats23, (-1L), localizedFormats25, localizedFormats26, localizedFormats27 };
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray28);
        exceptionContext14.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray28);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1L), localizedFormats33, (-1L), localizedFormats35, localizedFormats36, localizedFormats37 };
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray39);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException42 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (byte) 1);
        boolean boolean43 = notPositiveException42.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray44 = notPositiveException42.getSuppressed();
        exceptionContext14.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats31, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats47, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str52 = outOfRangeException51.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats53, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str58 = outOfRangeException57.toString();
        outOfRangeException51.addSuppressed((java.lang.Throwable) outOfRangeException57);
        java.lang.Number number60 = outOfRangeException51.getLo();
        java.lang.Number number61 = outOfRangeException51.getHi();
        java.lang.Throwable[] throwableArray62 = outOfRangeException51.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext63 = outOfRangeException51.getContext();
        java.util.Set<java.lang.String> strSet64 = exceptionContext63.getKeys();
        java.lang.Throwable throwable65 = exceptionContext63.getThrowable();
        mathIllegalArgumentException46.addSuppressed(throwable65);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str6.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str12.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats47.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str52.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats53.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str58.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (short) 100 + "'", number60.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (short) -1 + "'", number61.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(exceptionContext63);
        org.junit.Assert.assertNotNull(strSet64);
        org.junit.Assert.assertNotNull(throwable65);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 0.0f, (java.lang.Number) (short) -1);
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-1), number5, true);
        java.lang.Number number8 = numberIsTooLargeException7.getMax();
        java.lang.Number number9 = numberIsTooLargeException7.getMax();
        java.lang.Number number10 = numberIsTooLargeException7.getMax();
        java.lang.Number number11 = numberIsTooLargeException7.getMax();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (byte) 0, false);
        numberIsTooLargeException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException15);
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException15);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = outOfRangeException3.getContext();
        java.lang.Number number19 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(exceptionContext18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0f + "'", number19.equals(0.0f));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) 100, (java.lang.Number) (short) 1);
        java.lang.String str5 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0} is not a power of 2 plus one" + "'", str5.equals("{0} is not a power of 2 plus one"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation5.iterator();
        java.lang.String str8 = elitisticListPopulation5.toString();
        int int9 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList16);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList16, (int) (byte) 1, (double) 0L);
        int int21 = elitisticListPopulation20.getPopulationSize();
        java.lang.String str22 = elitisticListPopulation20.toString();
        int int23 = elitisticListPopulation20.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[]" + "'", str22.equals("[]"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        elitisticListPopulation5.setPopulationLimit(100);
        double double19 = elitisticListPopulation5.getElitismRate();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor20 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Population population21 = elitisticListPopulation5.nextGeneration();
        double double22 = elitisticListPopulation5.getElitismRate();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome23 = elitisticListPopulation5.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(chromosomeItor20);
        org.junit.Assert.assertNotNull(population21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        int int11 = elitisticListPopulation5.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray12 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, chromosomeArray12);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation17 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList18 = elitisticListPopulation17.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList18);
        org.apache.commons.math3.genetics.Population population20 = elitisticListPopulation5.nextGeneration();
        int int21 = elitisticListPopulation5.getPopulationSize();
        int int22 = elitisticListPopulation5.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(chromosomeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chromosomeList18);
        org.junit.Assert.assertNotNull(population20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray20 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, chromosomeArray20);
        elitisticListPopulation19.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation26 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, (int) (byte) 100, 0.0d);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList27 = elitisticListPopulation26.getChromosomes();
        double double28 = elitisticListPopulation26.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome29 = null;
        elitisticListPopulation26.addChromosome(chromosome29);
        int int31 = elitisticListPopulation26.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor32 = elitisticListPopulation26.iterator();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chromosomeList27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(chromosomeItor32);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        java.lang.Object obj18 = exceptionContext13.getValue("invalid row dimension: {0} (must be positive)");
        java.util.Set<java.lang.String> strSet19 = exceptionContext13.getKeys();
        java.lang.Throwable throwable20 = exceptionContext13.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, (java.lang.Number) 100.0f, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext27 = outOfRangeException26.getContext();
        java.util.Set<java.lang.String> strSet28 = exceptionContext27.getKeys();
        java.lang.Object obj30 = exceptionContext27.getValue("org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)");
        exceptionContext13.setValue("", (java.lang.Object) exceptionContext27);
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats33, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str38 = outOfRangeException37.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats39, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str44 = outOfRangeException43.toString();
        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException43);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext46 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException37);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext47 = outOfRangeException37.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable49 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (-1L), localizedFormats51, (-1L), localizedFormats53, localizedFormats54, localizedFormats55 };
        java.lang.Object[] objArray57 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray56);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable49, objArray57);
        exceptionContext47.setValue("scale ({0})", (java.lang.Object) localizable49);
        java.lang.Throwable throwable60 = exceptionContext47.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats62 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats66 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1L), localizedFormats64, (-1L), localizedFormats66, localizedFormats67, localizedFormats68 };
        java.lang.Object[] objArray70 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray69);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats62, objArray70);
        java.lang.Object[] objArray72 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray70);
        exceptionContext47.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats61, objArray70);
        exceptionContext27.addMessage(localizable32, objArray70);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertNotNull(throwable20);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str38.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str44.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(exceptionContext47);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats53.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats54.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats55.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwable60);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats61.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats62 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats62.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats64.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats66 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats66.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats67.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats68.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Continued fraction convergents diverged to +/- infinity for value {0}" + "'", str1.equals("Continued fraction convergents diverged to +/- infinity for value {0}"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 100);
        java.lang.String str5 = outOfRangeException4.toString();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: row index 100 out of allowed range [10, 100]" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: row index 100 out of allowed range [10, 100]"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-1), number1, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (byte) 0, false);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        java.lang.Number number13 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertNotNull(chromosomeList3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (byte) 0);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notPositiveException1.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1L), localizedFormats9, (-1L), localizedFormats11, localizedFormats12, localizedFormats13 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray15);
        exceptionContext3.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray15);
        java.lang.Throwable throwable18 = exceptionContext3.getThrowable();
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 10);
        java.lang.Number number24 = outOfRangeException23.getLo();
        exceptionContext3.setValue("org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (0)", (java.lang.Object) outOfRangeException23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwable18);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10.0d + "'", number24.equals(10.0d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (short) 10, false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1L), localizedFormats2, (-1L), localizedFormats4, localizedFormats5, localizedFormats6 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        elitisticListPopulation5.setPopulationLimit(100);
        int int19 = elitisticListPopulation5.getPopulationSize();
        org.apache.commons.math3.genetics.Population population20 = elitisticListPopulation5.nextGeneration();
        int int21 = elitisticListPopulation5.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome22 = null;
        elitisticListPopulation5.addChromosome(chromosome22);
        int int24 = elitisticListPopulation5.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(population20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number13 = outOfRangeException4.getLo();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str19 = outOfRangeException18.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str25 = outOfRangeException24.toString();
        outOfRangeException18.addSuppressed((java.lang.Throwable) outOfRangeException24);
        java.lang.Number number27 = outOfRangeException18.getLo();
        java.lang.Number number28 = outOfRangeException18.getHi();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Number number30 = outOfRangeException4.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = outOfRangeException4.getContext();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray33 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList34 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList34, chromosomeArray33);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation38 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList34, 100, (double) (byte) 0);
        int int39 = elitisticListPopulation38.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor40 = elitisticListPopulation38.iterator();
        java.lang.String str41 = elitisticListPopulation38.toString();
        int int42 = elitisticListPopulation38.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray43 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList44 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList44, chromosomeArray43);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation48 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList44, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList49 = elitisticListPopulation48.getChromosomes();
        elitisticListPopulation38.setChromosomes(chromosomeList49);
        org.apache.commons.math3.genetics.Population population51 = elitisticListPopulation38.nextGeneration();
        org.apache.commons.math3.genetics.Population population52 = elitisticListPopulation38.nextGeneration();
        exceptionContext31.setValue("org.apache.commons.math3.exception.OutOfRangeException: row index 100 out of allowed range [10, 100]", (java.lang.Object) elitisticListPopulation38);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        java.lang.Object[] objArray55 = null;
        exceptionContext31.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats54, objArray55);
        java.util.Set<java.lang.String> strSet57 = exceptionContext31.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats58, (java.lang.Number) 100, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats63, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str68 = outOfRangeException67.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats69, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str74 = outOfRangeException73.toString();
        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException73);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext76 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException67);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats78 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext76.setValue("hi!", (java.lang.Object) localizedFormats78);
        java.lang.Object obj81 = exceptionContext76.getValue("[]");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats82 = org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats83 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats85 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats87 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats88 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats89 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray90 = new java.lang.Object[] { (-1L), localizedFormats85, (-1L), localizedFormats87, localizedFormats88, localizedFormats89 };
        java.lang.Object[] objArray91 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray90);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats83, objArray91);
        java.lang.Object[] objArray93 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray91);
        java.lang.Object[] objArray94 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray91);
        exceptionContext76.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats82, objArray91);
        exceptionContext31.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats58, objArray91);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 100 + "'", number13.equals((short) 100));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str19.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str25.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (short) 100 + "'", number27.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) -1 + "'", number28.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 100 + "'", number30.equals((short) 100));
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertNotNull(chromosomeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "[]" + "'", str41.equals("[]"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(chromosomeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(chromosomeList49);
        org.junit.Assert.assertNotNull(population51);
        org.junit.Assert.assertNotNull(population52);
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats54.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertNotNull(strSet57);
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats58.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats63.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str68.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats69.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str74.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats78 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats78.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNull(obj81);
        org.junit.Assert.assertTrue("'" + localizedFormats82 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats82.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats83 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats83.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats85 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats85.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats87 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats87.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats88 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats88.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats89 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats89.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertNotNull(objArray94);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, (java.lang.Number) 1.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        java.lang.String str8 = localizedFormats7.getSourceString();
        exceptionContext5.setValue("scale must be positive ({0})", (java.lang.Object) localizedFormats7);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 10);
        exceptionContext5.setValue("hi!", (java.lang.Object) 10.0d);
        java.util.Set<java.lang.String> strSet16 = exceptionContext5.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "binary mutation works on BinaryChromosome only" + "'", str8.equals("binary mutation works on BinaryChromosome only"));
        org.junit.Assert.assertNotNull(strSet16);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d), (java.lang.Number) 10, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str17 = outOfRangeException16.toString();
        outOfRangeException10.addSuppressed((java.lang.Throwable) outOfRangeException16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        java.lang.Class<?> wildcardClass22 = localizedFormats21.getClass();
        exceptionContext19.setValue("hi!", (java.lang.Object) localizedFormats21);
        java.lang.Object obj25 = exceptionContext19.getValue("org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)");
        java.lang.Object obj27 = exceptionContext19.getValue("invalid row dimension: {0} (must be positive)");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.String str29 = localizedFormats28.getSourceString();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException31 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1.0d);
        boolean boolean32 = notPositiveException31.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray33 = notPositiveException31.getSuppressed();
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray33);
        exceptionContext19.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray34);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray34);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray34);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1), (java.lang.Number) 52, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str17.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "class ({0}) does not implement Comparable" + "'", str29.equals("class ({0}) does not implement Comparable"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        java.lang.Object[] objArray2 = null;
        java.lang.Object[] objArray3 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray2);
        java.lang.Throwable[] throwableArray5 = mathIllegalArgumentException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray5);
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        java.lang.Object obj8 = exceptionContext6.getValue("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str15 = outOfRangeException14.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str21 = outOfRangeException20.toString();
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException20);
        java.lang.Number number23 = outOfRangeException14.getLo();
        java.lang.Number number24 = outOfRangeException14.getHi();
        java.lang.Throwable[] throwableArray25 = outOfRangeException14.getSuppressed();
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException29 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 1);
        java.lang.Number number30 = notPositiveException29.getMin();
        java.lang.Number number31 = notPositiveException29.getArgument();
        boolean boolean32 = notPositiveException29.getBoundIsAllowed();
        exceptionContext6.setValue("", (java.lang.Object) boolean32);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str15.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str21.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 100 + "'", number23.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) -1 + "'", number24.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0 + "'", number30.equals(0));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (short) 1 + "'", number31.equals((short) 1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100, (java.lang.Number) 0L, (java.lang.Number) (short) 100);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        int int9 = elitisticListPopulation5.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        int int9 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation5.addChromosome(chromosome10);
        java.lang.String str12 = elitisticListPopulation5.toString();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[null]" + "'", str12.equals("[null]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (byte) 100, false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        int int9 = elitisticListPopulation5.getPopulationLimit();
        int int10 = elitisticListPopulation5.getPopulationLimit();
        int int11 = elitisticListPopulation5.getPopulationSize();
        double double12 = elitisticListPopulation5.getElitismRate();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, number2, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation5.getChromosomes();
        elitisticListPopulation5.setElitismRate((double) 1L);
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation5.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        int int16 = elitisticListPopulation15.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome17 = null;
        elitisticListPopulation15.addChromosome(chromosome17);
        java.lang.String str19 = elitisticListPopulation15.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray20 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, chromosomeArray20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, 100, (double) (byte) 0);
        elitisticListPopulation15.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList28 = elitisticListPopulation5.getChromosomes();
        int int29 = elitisticListPopulation5.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[null]" + "'", str19.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chromosomeList28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        elitisticListPopulation5.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation5.iterator();
        elitisticListPopulation5.setPopulationLimit(0);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray11 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList12 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList12, chromosomeArray11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList12, 100, (double) (byte) 0);
        elitisticListPopulation16.setPopulationLimit(1);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor19 = elitisticListPopulation16.iterator();
        elitisticListPopulation16.setPopulationLimit(0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList22 = elitisticListPopulation16.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList22);
        int int24 = elitisticListPopulation5.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList25 = elitisticListPopulation5.getChromosomes();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor8);
        org.junit.Assert.assertNotNull(chromosomeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chromosomeItor19);
        org.junit.Assert.assertNotNull(chromosomeList22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(chromosomeList25);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        elitisticListPopulation5.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray19 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList20, chromosomeArray19);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList20, 100, (double) (byte) 0);
        int int25 = elitisticListPopulation24.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome26 = null;
        elitisticListPopulation24.addChromosome(chromosome26);
        java.lang.String str28 = elitisticListPopulation24.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray29 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList30 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30, chromosomeArray29);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation34 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30, 100, (double) (byte) 0);
        elitisticListPopulation24.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation38 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray39 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList40 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40, chromosomeArray39);
        elitisticListPopulation38.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40, (int) (byte) 100, 0.0d);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor47 = elitisticListPopulation5.iterator();
        int int48 = elitisticListPopulation5.getPopulationLimit();
        java.lang.String str49 = elitisticListPopulation5.toString();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "[null]" + "'", str28.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chromosomeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(chromosomeItor47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "[]" + "'", str49.equals("[]"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100, (java.lang.Number) (short) 1, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 100);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        boolean boolean12 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number13 = numberIsTooLargeException4.getMax();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = numberIsTooLargeException4.getContext();
        java.lang.Number number15 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 1 + "'", number13.equals((short) 1));
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) -1, number2, false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100, (java.lang.Number) (short) 1, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        elitisticListPopulation5.setPopulationLimit((int) '4');
        int int11 = elitisticListPopulation5.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor12 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray13 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList14, chromosomeArray13);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList14, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor19 = elitisticListPopulation18.iterator();
        elitisticListPopulation18.setPopulationLimit((int) (byte) -1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList22 = elitisticListPopulation18.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList22);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor12);
        org.junit.Assert.assertNotNull(chromosomeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chromosomeItor19);
        org.junit.Assert.assertNotNull(chromosomeList22);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        elitisticListPopulation5.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray19 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList20, chromosomeArray19);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList20, 100, (double) (byte) 0);
        int int25 = elitisticListPopulation24.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome26 = null;
        elitisticListPopulation24.addChromosome(chromosome26);
        java.lang.String str28 = elitisticListPopulation24.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray29 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList30 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30, chromosomeArray29);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation34 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30, 100, (double) (byte) 0);
        elitisticListPopulation24.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation38 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList30, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray39 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList40 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40, chromosomeArray39);
        elitisticListPopulation38.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40, (int) (byte) 100, 0.0d);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList40);
        java.lang.String str47 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Population population48 = elitisticListPopulation5.nextGeneration();
        int int49 = elitisticListPopulation5.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor50 = elitisticListPopulation5.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList51 = elitisticListPopulation5.getChromosomes();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "[null]" + "'", str28.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chromosomeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "[]" + "'", str47.equals("[]"));
        org.junit.Assert.assertNotNull(population48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor50);
        org.junit.Assert.assertNotNull(chromosomeList51);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        int int7 = elitisticListPopulation5.getPopulationSize();
        java.lang.String str8 = elitisticListPopulation5.toString();
        int int9 = elitisticListPopulation5.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        elitisticListPopulation5.setPopulationLimit(100);
        double double19 = elitisticListPopulation5.getElitismRate();
        java.lang.String str20 = elitisticListPopulation5.toString();
        double double21 = elitisticListPopulation5.getElitismRate();
        double double22 = elitisticListPopulation5.getElitismRate();
        elitisticListPopulation5.setElitismRate((double) 1);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "[]" + "'", str20.equals("[]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str6 = outOfRangeException5.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str12 = outOfRangeException11.toString();
        outOfRangeException5.addSuppressed((java.lang.Throwable) outOfRangeException11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException5);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext14.setValue("hi!", (java.lang.Object) localizedFormats16);
        java.lang.Object obj19 = exceptionContext14.getValue("[]");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1L), localizedFormats23, (-1L), localizedFormats25, localizedFormats26, localizedFormats27 };
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray28);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray29);
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        java.lang.Object[] objArray32 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        exceptionContext14.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray29);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str6.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str12.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        org.apache.commons.math3.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = null;
        exceptionContext13.addMessage(localizable17, objArray18);
        java.lang.Object obj21 = exceptionContext13.getValue("{0} values have been added before statistic is configured");
        java.lang.Object obj23 = exceptionContext13.getValue("invalid row dimension: {0} (must be positive)");
        java.lang.Throwable throwable24 = exceptionContext13.getThrowable();
        java.lang.Throwable throwable25 = exceptionContext13.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(throwable25);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 0.0d, (java.lang.Number) (short) 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        elitisticListPopulation5.setPopulationLimit(100);
        int int19 = elitisticListPopulation5.getPopulationSize();
        java.lang.String str20 = elitisticListPopulation5.toString();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = elitisticListPopulation5.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray22 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList23 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, chromosomeArray22);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation27 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, 100, (double) (byte) 0);
        int int28 = elitisticListPopulation27.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome29 = null;
        elitisticListPopulation27.addChromosome(chromosome29);
        java.lang.String str31 = elitisticListPopulation27.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray32 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList33 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList33, chromosomeArray32);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation37 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList33, 100, (double) (byte) 0);
        elitisticListPopulation27.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList33);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation41 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList33, (int) '#', (double) 1L);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList33);
        elitisticListPopulation5.setPopulationLimit(2);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "[]" + "'", str20.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeList21);
        org.junit.Assert.assertNotNull(chromosomeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "[null]" + "'", str31.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        int int7 = elitisticListPopulation5.getPopulationSize();
        int int8 = elitisticListPopulation5.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 2, true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (byte) 1);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str8 = outOfRangeException7.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str14 = outOfRangeException13.toString();
        outOfRangeException7.addSuppressed((java.lang.Throwable) outOfRangeException13);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException7);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext16.setValue("hi!", (java.lang.Object) localizedFormats18);
        java.lang.Object obj21 = exceptionContext16.getValue("invalid row dimension: {0} (must be positive)");
        java.util.Set<java.lang.String> strSet22 = exceptionContext16.getKeys();
        java.lang.Throwable throwable23 = exceptionContext16.getThrowable();
        java.lang.String str24 = throwable23.toString();
        notPositiveException1.addSuppressed(throwable23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str8.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str14.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(strSet22);
        org.junit.Assert.assertNotNull(throwable23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str24.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 100, number1, (java.lang.Number) 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        int int10 = elitisticListPopulation5.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation5.iterator();
        java.lang.String str8 = elitisticListPopulation5.toString();
        int int9 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList16);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList16, (int) (byte) 1, (double) 0L);
        org.apache.commons.math3.genetics.Population population21 = elitisticListPopulation20.nextGeneration();
        org.apache.commons.math3.genetics.Population population22 = elitisticListPopulation20.nextGeneration();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertNotNull(population21);
        org.junit.Assert.assertNotNull(population22);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        int int10 = elitisticListPopulation5.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor10 = elitisticListPopulation5.iterator();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor11 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome chromosome12 = null;
        elitisticListPopulation5.addChromosome(chromosome12);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeItor10);
        org.junit.Assert.assertNotNull(chromosomeItor11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        java.util.Set<java.lang.String> strSet17 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet18 = exceptionContext13.getKeys();
        java.util.Set<java.lang.String> strSet19 = exceptionContext13.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        exceptionContext13.setValue("org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points", (java.lang.Object) localizedFormats21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Number) (-1.0d), (java.lang.Number) 10L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str33 = outOfRangeException32.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext34 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException32);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats36, (java.lang.Number) (short) 100, (java.lang.Number) (short) 1, true);
        exceptionContext34.setValue("", (java.lang.Object) (short) 1);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats45, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str50 = outOfRangeException49.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats51, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str56 = outOfRangeException55.toString();
        outOfRangeException49.addSuppressed((java.lang.Throwable) outOfRangeException55);
        java.lang.Throwable[] throwableArray58 = outOfRangeException49.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats44, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats43, (java.lang.Object[]) throwableArray58);
        exceptionContext34.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats42, (java.lang.Object[]) throwableArray58);
        java.lang.Object[] objArray62 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray58);
        java.lang.Object[] objArray63 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray58);
        exceptionContext13.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str33.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats42.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats44.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str50.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str56.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray63);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(1, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, (java.lang.Number) (short) -1, true);
        java.lang.Number number6 = numberIsTooLargeException5.getMax();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, (java.lang.Number) 1, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 100);
        java.lang.String str11 = outOfRangeException10.toString();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: row index 100 out of allowed range [10, 100]" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: row index 100 out of allowed range [10, 100]"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        java.lang.Class<?> wildcardClass16 = localizedFormats15.getClass();
        exceptionContext13.setValue("hi!", (java.lang.Object) localizedFormats15);
        java.lang.Object obj19 = exceptionContext13.getValue("org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)");
        java.lang.Object obj21 = exceptionContext13.getValue("invalid row dimension: {0} (must be positive)");
        java.lang.Object obj23 = exceptionContext13.getValue("scale ({0})");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray32 = null;
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable31, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, objArray33);
        exceptionContext13.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.NotPositiveException notPositiveException4 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = localizedFormats0.getLocalizedString(locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) 100, false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 52, (java.lang.Number) 1L, (java.lang.Number) (short) -1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0.0f);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass3 = notPositiveException1.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str6 = outOfRangeException5.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException5);
        java.lang.Object obj9 = exceptionContext7.getValue("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str16 = outOfRangeException15.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str22 = outOfRangeException21.toString();
        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException21);
        java.lang.Number number24 = outOfRangeException15.getLo();
        java.lang.Number number25 = outOfRangeException15.getHi();
        java.lang.Throwable[] throwableArray26 = outOfRangeException15.getSuppressed();
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray26);
        java.lang.Throwable[] throwableArray29 = mathIllegalArgumentException28.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str6.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str16.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str22.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) 100 + "'", number24.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (short) -1 + "'", number25.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray29);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, number1, false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number2, (java.lang.Number) 52, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_SQUARE_OPERATOR;
        java.lang.Number number7 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, number7, (java.lang.Number) 0L, false);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooLargeException10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "unable to bracket optimum in line search" + "'", str1.equals("unable to bracket optimum in line search"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_SQUARE_OPERATOR + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_SQUARE_OPERATOR));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 100.0f, false);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, (java.lang.Number) 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray7 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, chromosomeArray7);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, 100, (double) (byte) 0);
        int int13 = elitisticListPopulation12.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome14 = null;
        elitisticListPopulation12.addChromosome(chromosome14);
        java.lang.String str16 = elitisticListPopulation12.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray17 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList18 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, chromosomeArray17);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, 100, (double) (byte) 0);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18);
        elitisticListPopulation12.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray26 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList27 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, chromosomeArray26);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation31 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, 100, (double) (byte) 0);
        int int32 = elitisticListPopulation31.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome33 = null;
        elitisticListPopulation31.addChromosome(chromosome33);
        java.lang.String str35 = elitisticListPopulation31.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray36 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList37 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, chromosomeArray36);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation41 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, 100, (double) (byte) 0);
        elitisticListPopulation31.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray46 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList47 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, chromosomeArray46);
        elitisticListPopulation45.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation52 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, (int) (byte) 100, 0.0d);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray55 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList56 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList56, chromosomeArray55);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation60 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList56, 100, (double) (byte) 0);
        int int61 = elitisticListPopulation60.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome62 = null;
        elitisticListPopulation60.addChromosome(chromosome62);
        java.lang.String str64 = elitisticListPopulation60.toString();
        org.apache.commons.math3.genetics.Population population65 = elitisticListPopulation60.nextGeneration();
        int int66 = elitisticListPopulation60.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray67 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList68 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList68, chromosomeArray67);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation72 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList68, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList73 = elitisticListPopulation72.getChromosomes();
        elitisticListPopulation60.setChromosomes(chromosomeList73);
        elitisticListPopulation5.setChromosomes(chromosomeList73);
        java.lang.String str76 = elitisticListPopulation5.toString();
        double double77 = elitisticListPopulation5.getElitismRate();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(chromosomeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[null]" + "'", str16.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chromosomeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[null]" + "'", str35.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chromosomeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chromosomeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "[null]" + "'", str64.equals("[null]"));
        org.junit.Assert.assertNotNull(population65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(chromosomeArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(chromosomeList73);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "[]" + "'", str76.equals("[]"));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = outOfRangeException4.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), localizedFormats18, (-1L), localizedFormats20, localizedFormats21, localizedFormats22 };
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray23);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable16, objArray24);
        exceptionContext14.setValue("scale ({0})", (java.lang.Object) localizable16);
        java.lang.Throwable throwable27 = exceptionContext14.getThrowable();
        java.lang.Throwable throwable28 = exceptionContext14.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math3.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray32 = null;
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable31, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray33);
        exceptionContext14.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, objArray33);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException39 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats37, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException42 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1.0d);
        boolean boolean43 = notPositiveException42.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray44 = notPositiveException42.getSuppressed();
        java.lang.Object[] objArray45 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray44);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats40, objArray45);
        exceptionContext14.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats37, objArray45);
        java.lang.Class<?> wildcardClass48 = objArray45.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwable27);
        org.junit.Assert.assertNotNull(throwable28);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(wildcardClass48);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (short) 10, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d);
        java.lang.Throwable[] throwableArray3 = notPositiveException2.getSuppressed();
        boolean boolean4 = notPositiveException2.getBoundIsAllowed();
        java.lang.Number number5 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException3 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0d);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (short) -1, false);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = localizedFormats0.getLocalizedString(locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "binary mutation works on BinaryChromosome only" + "'", str1.equals("binary mutation works on BinaryChromosome only"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit((int) (byte) 10);
        elitisticListPopulation5.setPopulationLimit((int) '4');
        java.lang.String str11 = elitisticListPopulation5.toString();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor12 = elitisticListPopulation5.iterator();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome13 = elitisticListPopulation5.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) (short) 10, true);
        java.lang.String str10 = numberIsTooSmallException9.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Number) 10.0f, (java.lang.Number) (byte) 0, true);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException15);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException15);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (10)" + "'", str10.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (10)"));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (byte) 1, (java.lang.Number) (short) 10);
        java.lang.String str5 = outOfRangeException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: no optimum computed yet" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: no optimum computed yet"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Number) 0.0f, (java.lang.Number) 1.0f, true);
        outOfRangeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext21 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException18);
        java.lang.Object obj23 = exceptionContext21.getValue("");
        java.lang.Object obj25 = exceptionContext21.getValue("[null, null]");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 100 + "'", number6.equals((byte) 100));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation5.iterator();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray9 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList10, chromosomeArray9);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation14 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList10, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList15 = elitisticListPopulation14.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList15);
        int int17 = elitisticListPopulation5.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertNotNull(chromosomeItor8);
        org.junit.Assert.assertNotNull(chromosomeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chromosomeList15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str7 = outOfRangeException6.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str13 = outOfRangeException12.toString();
        outOfRangeException6.addSuppressed((java.lang.Throwable) outOfRangeException12);
        java.lang.Throwable[] throwableArray15 = outOfRangeException6.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray15);
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str7.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str13.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, number2, (java.lang.Number) (short) 1);
        java.lang.Number number6 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L, number6, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray7 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, chromosomeArray7);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList8, 100, (double) (byte) 0);
        int int13 = elitisticListPopulation12.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome14 = null;
        elitisticListPopulation12.addChromosome(chromosome14);
        java.lang.String str16 = elitisticListPopulation12.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray17 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList18 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, chromosomeArray17);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18, 100, (double) (byte) 0);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList18);
        elitisticListPopulation12.setPopulationLimit(100);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray26 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList27 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, chromosomeArray26);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation31 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList27, 100, (double) (byte) 0);
        int int32 = elitisticListPopulation31.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome33 = null;
        elitisticListPopulation31.addChromosome(chromosome33);
        java.lang.String str35 = elitisticListPopulation31.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray36 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList37 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, chromosomeArray36);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation41 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, 100, (double) (byte) 0);
        elitisticListPopulation31.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList37, (int) '#', (double) 1L);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray46 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList47 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, chromosomeArray46);
        elitisticListPopulation45.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation52 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47, (int) (byte) 100, 0.0d);
        elitisticListPopulation12.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList47);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray55 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList56 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList56, chromosomeArray55);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation60 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList56, 100, (double) (byte) 0);
        int int61 = elitisticListPopulation60.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome62 = null;
        elitisticListPopulation60.addChromosome(chromosome62);
        java.lang.String str64 = elitisticListPopulation60.toString();
        org.apache.commons.math3.genetics.Population population65 = elitisticListPopulation60.nextGeneration();
        int int66 = elitisticListPopulation60.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray67 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList68 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList68, chromosomeArray67);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation72 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList68, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList73 = elitisticListPopulation72.getChromosomes();
        elitisticListPopulation60.setChromosomes(chromosomeList73);
        elitisticListPopulation5.setChromosomes(chromosomeList73);
        int int76 = elitisticListPopulation5.getPopulationLimit();
        elitisticListPopulation5.setPopulationLimit(10);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(chromosomeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[null]" + "'", str16.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chromosomeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[null]" + "'", str35.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chromosomeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chromosomeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "[null]" + "'", str64.equals("[null]"));
        org.junit.Assert.assertNotNull(population65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(chromosomeArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(chromosomeList73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 100 + "'", int76 == 100);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        double double9 = elitisticListPopulation5.getElitismRate();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome chromosome11 = null;
        elitisticListPopulation5.addChromosome(chromosome11);
        double double13 = elitisticListPopulation5.getElitismRate();
        int int14 = elitisticListPopulation5.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome15 = null;
        elitisticListPopulation5.addChromosome(chromosome15);
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome17 = elitisticListPopulation5.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "string \"{0}\" unparseable (from position {1})" + "'", str1.equals("string \"{0}\" unparseable (from position {1})"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        java.lang.Throwable throwable14 = exceptionContext13.getThrowable();
        java.lang.Object obj16 = exceptionContext13.getValue("");
        java.util.Set<java.lang.String> strSet17 = exceptionContext13.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(throwable14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(strSet17);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation5.iterator();
        java.lang.String str8 = elitisticListPopulation5.toString();
        int int9 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList16);
        org.apache.commons.math3.genetics.Population population18 = elitisticListPopulation5.nextGeneration();
        int int19 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray20 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, chromosomeArray20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertNotNull(population18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(chromosomeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) -1, (java.lang.Number) 1.0d, number2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (byte) -1, (java.lang.Number) 10L, (java.lang.Number) (-1));
        java.lang.String str11 = outOfRangeException10.toString();
        java.lang.Throwable[] throwableArray12 = outOfRangeException10.getSuppressed();
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number14 = outOfRangeException3.getHi();
        java.lang.Number number15 = outOfRangeException3.getHi();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: non-invertible affine transform collapses some lines into single points"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notPositiveException2.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation5.getChromosomes();
        elitisticListPopulation5.setElitismRate((double) 1L);
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation5.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        int int16 = elitisticListPopulation15.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome17 = null;
        elitisticListPopulation15.addChromosome(chromosome17);
        java.lang.String str19 = elitisticListPopulation15.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray20 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, chromosomeArray20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21, 100, (double) (byte) 0);
        elitisticListPopulation15.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList21);
        org.apache.commons.math3.genetics.Chromosome chromosome28 = null;
        elitisticListPopulation5.addChromosome(chromosome28);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor30 = elitisticListPopulation5.iterator();
        elitisticListPopulation5.setElitismRate((double) (byte) 0);
        org.apache.commons.math3.genetics.Population population33 = elitisticListPopulation5.nextGeneration();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[null]" + "'", str19.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chromosomeItor30);
        org.junit.Assert.assertNotNull(population33);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1L), localizedFormats4, (-1L), localizedFormats6, localizedFormats7, localizedFormats8 };
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1L), localizedFormats9, (-1L), localizedFormats11, localizedFormats12, localizedFormats13 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray15);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray15);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 0L, (java.lang.Number) (byte) 100, (java.lang.Number) (short) 100);
        java.lang.String str22 = localizedFormats6.getSourceString();
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = localizedFormats6.getLocalizedString(locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "unable to first guess the harmonic coefficients" + "'", str22.equals("unable to first guess the harmonic coefficients"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0, (java.lang.Number) 100, (java.lang.Number) 1.0f);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = outOfRangeException4.getContext();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 100, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation5.iterator();
        java.lang.String str8 = elitisticListPopulation5.toString();
        int int9 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation5.setChromosomes(chromosomeList16);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList16, (int) (byte) 1, (double) 0L);
        int int21 = elitisticListPopulation20.getPopulationSize();
        int int22 = elitisticListPopulation20.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList23 = elitisticListPopulation20.getChromosomes();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(chromosomeList23);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 10);
        java.util.Locale locale3 = null;
        try {
            java.lang.String str4 = localizedFormats0.getLocalizedString(locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 52, number1, true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str11 = outOfRangeException10.toString();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str20 = outOfRangeException19.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str26 = outOfRangeException25.toString();
        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException25);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext28 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        exceptionContext28.setValue("hi!", (java.lang.Object) localizedFormats30);
        exceptionContext13.setValue("", (java.lang.Object) exceptionContext28);
        java.lang.Throwable throwable33 = exceptionContext13.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats34, (java.lang.Number) (byte) 0, (java.lang.Number) 0, true);
        throwable33.addSuppressed((java.lang.Throwable) numberIsTooLargeException38);
        boolean boolean40 = numberIsTooLargeException38.getBoundIsAllowed();
        boolean boolean41 = numberIsTooLargeException38.getBoundIsAllowed();
        java.lang.Number number42 = numberIsTooLargeException38.getArgument();
        java.lang.Number number43 = numberIsTooLargeException38.getMax();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10.0d, (java.lang.Number) (short) 100, true);
        numberIsTooLargeException38.addSuppressed((java.lang.Throwable) numberIsTooLargeException47);
        boolean boolean49 = numberIsTooLargeException47.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str11.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str20.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str26.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertNotNull(throwable33);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (byte) 0 + "'", number42.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0 + "'", number43.equals(0));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray6 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList7, chromosomeArray6);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation11 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList7, 100, (double) (byte) 0);
        int int12 = elitisticListPopulation11.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome13 = null;
        elitisticListPopulation11.addChromosome(chromosome13);
        java.lang.String str15 = elitisticListPopulation11.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray16 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList17 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList17, chromosomeArray16);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation21 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList17, 100, (double) (byte) 0);
        elitisticListPopulation11.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList17);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList17, 100, 0.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList17, (int) (short) 100, (double) 0.0f);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList17);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList30 = elitisticListPopulation5.getChromosomes();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[null]" + "'", str15.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chromosomeList30);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation5.iterator();
        org.apache.commons.math3.genetics.Population population7 = elitisticListPopulation5.nextGeneration();
        elitisticListPopulation5.setPopulationLimit((int) (short) 0);
        java.lang.String str10 = elitisticListPopulation5.toString();
        int int11 = elitisticListPopulation5.getPopulationLimit();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertNotNull(population7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[]" + "'", str10.equals("[]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        org.apache.commons.math3.genetics.Chromosome chromosome9 = null;
        elitisticListPopulation5.addChromosome(chromosome9);
        org.apache.commons.math3.genetics.Chromosome chromosome11 = null;
        elitisticListPopulation5.addChromosome(chromosome11);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str6 = outOfRangeException5.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException5);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) (short) 100, (java.lang.Number) (short) 1, true);
        exceptionContext7.setValue("", (java.lang.Object) (short) 1);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str23 = outOfRangeException22.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1);
        java.lang.String str29 = outOfRangeException28.toString();
        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException28);
        java.lang.Throwable[] throwableArray31 = outOfRangeException22.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray31);
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray31);
        java.lang.Object[] objArray35 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray31);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str6.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str23.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}" + "'", str29.equals("org.apache.commons.math3.exception.OutOfRangeException: got 100x100 but expected -1x{3}"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray10 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, chromosomeArray10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, 100, (double) (byte) 0);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList11, (int) '#', (double) 1L);
        double double20 = elitisticListPopulation19.getElitismRate();
        org.apache.commons.math3.genetics.Population population21 = elitisticListPopulation19.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor22 = elitisticListPopulation19.iterator();
        elitisticListPopulation19.setPopulationLimit(52);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(population21);
        org.junit.Assert.assertNotNull(chromosomeItor22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, 100, (double) (byte) 0);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation5.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation5.toString();
        org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation5.nextGeneration();
        int int11 = elitisticListPopulation5.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray12 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, chromosomeArray12);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation17 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList13, 100, (double) (byte) 0);
        int int18 = elitisticListPopulation17.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome19 = null;
        elitisticListPopulation17.addChromosome(chromosome19);
        java.lang.String str21 = elitisticListPopulation17.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray22 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList23 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, chromosomeArray22);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation27 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23, 100, (double) (byte) 0);
        elitisticListPopulation17.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23);
        elitisticListPopulation5.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList23);
        elitisticListPopulation5.setPopulationLimit(2);
        elitisticListPopulation5.setPopulationLimit((int) ' ');
        java.lang.String str34 = elitisticListPopulation5.toString();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertNotNull(population10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(chromosomeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[null]" + "'", str21.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "[]" + "'", str34.equals("[]"));
    }
}

