import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        int int5 = nonLinearConjugateGradientOptimizer4.getMaxIterations();
        double[] doubleArray6 = nonLinearConjugateGradientOptimizer4.getStartPoint();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(doubleArray6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a');
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        try {
            java.lang.StringBuffer stringBuffer7 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4, stringBuffer5, fieldPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        try {
            org.apache.commons.math3.linear.RealVector realVector53 = blockRealMatrix49.getRowVector(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition1 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray9 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType3, goalType4, goalType5, goalType6, goalType7, goalType8 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray9, orderDirection10, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 1L, (int) '#', orderDirection10, true);
        int int15 = nonMonotonicSequenceException14.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = nonMonotonicSequenceException14.getDirection();
        java.lang.Number number17 = nonMonotonicSequenceException14.getArgument();
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType3.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) 1 + "'", number17.equals((short) 1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        org.apache.commons.math3.optim.PointValuePair pointValuePair7 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) 0L);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction1 = null;
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver2 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution6 = null;
        try {
            double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide(50, univariateFunction1, univariateFunctionBracketedUnivariateSolver2, 1.0E-15d, 6.283185307179587d, 35.0d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10.0f, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        double[] doubleArray4 = levenbergMarquardtOptimizer3.getLowerBound();
        int int5 = levenbergMarquardtOptimizer3.getEvaluations();
        double[] doubleArray6 = levenbergMarquardtOptimizer3.getStartPoint();
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(doubleArray6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.getRowMatrix(6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        try {
            org.apache.commons.math3.linear.RealVector realVector53 = blockRealMatrix49.getColumnVector((-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        double[] doubleArray57 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray57, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition61 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix59, (double) (short) 0);
        double[] doubleArray62 = eigenDecomposition61.getRealEigenvalues();
        double[] doubleArray63 = eigenDecomposition61.getRealEigenvalues();
        double[] doubleArray65 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair68 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess69 = new org.apache.commons.math3.optim.InitialGuess(doubleArray65);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds70 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray63, doubleArray65);
        double[] doubleArray76 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix78 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray76, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition80 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix78, (double) (short) 0);
        double[] doubleArray81 = eigenDecomposition80.getRealEigenvalues();
        double[] doubleArray82 = eigenDecomposition80.getRealEigenvalues();
        double[] doubleArray84 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair87 = new org.apache.commons.math3.optim.PointValuePair(doubleArray84, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess88 = new org.apache.commons.math3.optim.InitialGuess(doubleArray84);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds89 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray82, doubleArray84);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition90 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray65, doubleArray84);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[][] doubleArray92 = array2DRowRealMatrix91.getData();
        try {
            blockRealMatrix49.setSubMatrix(doubleArray92, 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[][] doubleArray41 = array2DRowRealMatrix39.getDataRef();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor42.start((int) '4', 36, (int) (short) 1, 0, (int) ' ', 1);
        try {
            double double54 = array2DRowRealMatrix39.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42, (int) (short) -1, (int) '#', (int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing(univariateFunction0, 2.2250738585072014E-308d, 5200.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double2 = org.apache.commons.math3.util.FastMath.pow(2.718281828459045d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getMaxIterations();
        double double5 = brentOptimizer3.getMax();
        int int6 = brentOptimizer3.getIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor52 = null;
        try {
            double double53 = blockRealMatrix49.walkInOptimizedOrder(realMatrixChangingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        double double36 = arrayRealVector26.getMinValue();
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        double double56 = arrayRealVector46.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector46.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector26.combineToSelf(0.0d, 22026.465794806718d, realVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector59);
        double double62 = arrayRealVector59.getEntry((int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-10.0d) + "'", double36 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-10.0d) + "'", double56 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        double double12 = lUDecomposition11.getDeterminant();
        double double13 = lUDecomposition11.getDeterminant();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver14 = lUDecomposition11.getSolver();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 174.53292519943295d + "'", double12 == 174.53292519943295d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 174.53292519943295d + "'", double13 == 174.53292519943295d);
        org.junit.Assert.assertNotNull(decompositionSolver14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-3.481799283000183d), 32.0d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) -1, 9.148345846451205E150d);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair6 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(101.53096491487338d, 32.0d);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair9 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(101.53096491487338d, 32.0d);
        boolean boolean10 = simpleUnivariateValueChecker2.converged(10, univariatePointValuePair6, univariatePointValuePair9);
        double double11 = univariatePointValuePair9.getPoint();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 101.53096491487338d + "'", double11 == 101.53096491487338d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(32.0d, 0.9967368836335428d, (double) (byte) 100, (double) (-1074790400), (double) 10L);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray8 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix10, (double) (short) 0);
        double[] doubleArray18 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = diagonalMatrix10.add(diagonalMatrix20);
        double[] doubleArray27 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29, (double) (short) 0);
        double[] doubleArray37 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = diagonalMatrix29.add(diagonalMatrix39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix10.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix40);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition43 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix10, (double) (short) 1);
        java.lang.StringBuffer stringBuffer44 = null;
        java.text.FieldPosition fieldPosition45 = null;
        try {
            java.lang.StringBuffer stringBuffer46 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix10, stringBuffer44, fieldPosition45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(diagonalMatrix21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(diagonalMatrix40);
        org.junit.Assert.assertNotNull(realMatrix41);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(1.58601345231343E15d, 0.057629502154529534d, 1.7453292519943295d, (double) 0, (double) 10.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray45 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray45, true);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray45);
        try {
            double[] doubleArray49 = array2DRowRealMatrix39.preMultiply(doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        try {
            blockRealMatrix49.multiplyEntry(32, (-1074790369), 1421.221456714817d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((-1074790400), 36.0d, (double) 32, (-0.9999999999999999d), (double) 0, 5155.99724417334d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        try {
            blockRealMatrix49.addToEntry((int) (byte) 10, (int) (short) 0, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        double double12 = lUDecomposition11.getDeterminant();
        int[] intArray13 = lUDecomposition11.getPivot();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 174.53292519943295d + "'", double12 == 174.53292519943295d);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4);
        int int7 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray6);
        int[] intArray11 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math3.random.MersenneTwister(intArray11);
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11);
        int[] intArray17 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math3.random.MersenneTwister(intArray17);
        int int19 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray13, intArray17);
        int[] intArray21 = org.apache.commons.math3.util.MathArrays.copyOf(intArray17, 52);
        int int22 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray6, intArray21);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getHi();
        org.apache.commons.math3.analysis.function.Sinc sinc4 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder0.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc4, goalType5, (double) 35, 174.53292519943295d);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure9 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure10 = sinc4.value(derivativeStructure9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker8 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(5155.99724417334d, 1.0d, 0.0d, (double) 32, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker8);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(Double.NaN, 0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker5);
        int int7 = nonLinearConjugateGradientOptimizer6.getEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10.0f, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess11 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair18 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair17);
        double[] doubleArray19 = doubleArrayPair18.getKey();
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        int int22 = org.apache.commons.math3.util.MathUtils.hash(doubleArray19);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray7, doubleArray19);
        double[] doubleArray24 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair25 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray24);
        double[] doubleArray26 = pointVectorValuePair25.getValue();
        double[] doubleArray27 = pointVectorValuePair25.getValue();
        double[] doubleArray29 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess33 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray36 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair40 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair39);
        double[] doubleArray41 = doubleArrayPair40.getKey();
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector43 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray41);
        int int44 = org.apache.commons.math3.util.MathUtils.hash(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray29, doubleArray41);
        double[] doubleArray46 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getValue();
        double[] doubleArray49 = pointVectorValuePair47.getValue();
        double[] doubleArray50 = pointVectorValuePair47.getValue();
        double[] doubleArray51 = pointVectorValuePair47.getValueRef();
        try {
            boolean boolean52 = simpleVectorValueChecker2.converged((-1074790369), pointVectorValuePair25, pointVectorValuePair47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1074790369) + "'", int22 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNull(doubleArray26);
        org.junit.Assert.assertNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1074790369) + "'", int44 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNull(doubleArray48);
        org.junit.Assert.assertNull(doubleArray49);
        org.junit.Assert.assertNull(doubleArray50);
        org.junit.Assert.assertNull(doubleArray51);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        int int51 = diagonalMatrix7.getRowDimension();
        double[] doubleArray58 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition62 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix60, (double) (short) 0);
        double[] doubleArray63 = eigenDecomposition62.getRealEigenvalues();
        double[] doubleArray64 = eigenDecomposition62.getRealEigenvalues();
        double[] doubleArray66 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair69 = new org.apache.commons.math3.optim.PointValuePair(doubleArray66, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess70 = new org.apache.commons.math3.optim.InitialGuess(doubleArray66);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds71 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray64, doubleArray66);
        double[] doubleArray72 = simpleBounds71.getUpper();
        double[] doubleArray73 = simpleBounds71.getUpper();
        try {
            diagonalMatrix7.setColumn((int) (short) 1, doubleArray73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder1 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double2 = bracketFinder1.getFMid();
        org.apache.commons.math3.analysis.function.Sinc sinc4 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder1.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc4, goalType5, 0.0d, 6.0d);
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver9 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution13 = null;
        try {
            double double14 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide((-1), (org.apache.commons.math3.analysis.UnivariateFunction) sinc4, univariateFunctionBracketedUnivariateSolver9, (double) (short) 1, (double) 35L, (double) '#', allowedSolution13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(143.22214567148168d, (double) 1);
        double[] doubleArray3 = simplexOptimizer2.getUpperBound();
        org.junit.Assert.assertNull(doubleArray3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-1074790369), (double) (byte) 0);
        double double3 = searchInterval2.getMax();
        double double4 = searchInterval2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-5.373951845E8d) + "'", double4 == (-5.373951845E8d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula5 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker6 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula5, pointValuePairConvergenceChecker6, univariateSolver7, preconditioner8);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula5, pointValuePairConvergenceChecker10);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker14 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer15 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula5, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker14);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver18 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double19 = brentSolver18.getFunctionValueAccuracy();
        double double20 = brentSolver18.getMax();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner21 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker14, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver18, preconditioner21);
        double double23 = brentSolver18.getStartValue();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula5.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-15d + "'", double19 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[] doubleArray43 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair47 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair46);
        double[] doubleArray48 = doubleArrayPair47.getKey();
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix39.operate(doubleArray49);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor51 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor51.start((int) '4', 36, (int) (short) 1, 0, (int) ' ', 1);
        defaultRealMatrixPreservingVisitor51.visit((int) '#', (int) (short) 100, (double) 2147483647);
        try {
            double double67 = array2DRowRealMatrix39.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51, (int) '4', (int) '4', (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-1), 1);
        int int3 = nonSquareMatrixException2.getDimension();
        int int4 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        double[] doubleArray16 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) (short) 0);
        double[] doubleArray26 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = diagonalMatrix18.add(diagonalMatrix28);
        double[] doubleArray35 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37, (double) (short) 0);
        double[] doubleArray45 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray45, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = diagonalMatrix37.add(diagonalMatrix47);
        double[] doubleArray54 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56, (double) (short) 0);
        double[] doubleArray64 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix66 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray64, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix67 = diagonalMatrix56.add(diagonalMatrix66);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = diagonalMatrix37.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix67);
        double double69 = diagonalMatrix67.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor70 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double71 = diagonalMatrix67.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor70);
        double double72 = diagonalMatrix28.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor70);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix73 = diagonalMatrix7.add(diagonalMatrix28);
        try {
            diagonalMatrix28.setEntry(50, 35, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(diagonalMatrix29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(diagonalMatrix48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(diagonalMatrix67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 47.490658503988655d + "'", double69 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(diagonalMatrix73);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getNorm();
        double double2 = arrayRealVector0.getMinValue();
        arrayRealVector0.set((double) 5.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = openMapRealMatrix6.createMatrix(0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix(obj0, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(1.58601345231343E15d, (double) 52);
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType10 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray11 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType5, goalType6, goalType7, goalType8, goalType9, goalType10 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray11, orderDirection12, true);
        org.apache.commons.math3.exception.ConvergenceException convergenceException15 = new org.apache.commons.math3.exception.ConvergenceException(localizable4, (java.lang.Object[]) goalTypeArray11);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math3.exception.NotFiniteNumberException(number3, (java.lang.Object[]) goalTypeArray11);
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair17 = simplexOptimizer2.optimize((org.apache.commons.math3.optim.OptimizationData[]) goalTypeArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType9 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType9.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType10 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType10.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction6 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction7 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction6);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction8 = modelFunction7.getModelFunction();
        boolean boolean9 = doubleArrayPair5.equals((java.lang.Object) multivariateVectorFunction8);
        double[] doubleArray10 = doubleArrayPair5.getFirst();
        double[] doubleArray12 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) (byte) 10, false);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (byte) 1);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray10, doubleArray17);
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray31);
        org.apache.commons.math3.optim.PointValuePair pointValuePair41 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) 0.0f);
        try {
            double double42 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray10, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNull(multivariateVectorFunction8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double double39 = diagonalMatrix37.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor40 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double41 = diagonalMatrix37.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor40);
        double[] doubleArray47 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition51 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49, (double) (short) 0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = diagonalMatrix37.add(diagonalMatrix49);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition53 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 47.490658503988655d + "'", double39 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(diagonalMatrix52);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval(1.5707963267948966d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1.571 is larger than, or equal to, the maximum (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        double[] doubleArray13 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray5, doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        double[] doubleArray19 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess23 = new org.apache.commons.math3.optim.InitialGuess(doubleArray19);
        double[] doubleArray26 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair29 = new org.apache.commons.math3.optim.PointValuePair(doubleArray26, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair30 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair29);
        double[] doubleArray31 = doubleArrayPair30.getKey();
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray31);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray19, doubleArray31);
        try {
            double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray13, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1074790369) + "'", int34 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double double39 = diagonalMatrix37.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor40 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double41 = diagonalMatrix37.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor40);
        double[] doubleArray47 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition51 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49, (double) (short) 0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = diagonalMatrix37.add(diagonalMatrix49);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix37.power((int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 47.490658503988655d + "'", double39 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(diagonalMatrix52);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        double[] doubleArray21 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, (double) (short) 0);
        double[] doubleArray26 = eigenDecomposition25.getRealEigenvalues();
        double[] doubleArray27 = eigenDecomposition25.getRealEigenvalues();
        double[] doubleArray29 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess33 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds34 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray27, doubleArray29);
        double[] doubleArray40 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix42, (double) (short) 0);
        double[] doubleArray45 = eigenDecomposition44.getRealEigenvalues();
        double[] doubleArray46 = eigenDecomposition44.getRealEigenvalues();
        double[] doubleArray48 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair51 = new org.apache.commons.math3.optim.PointValuePair(doubleArray48, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess52 = new org.apache.commons.math3.optim.InitialGuess(doubleArray48);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds53 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray46, doubleArray48);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray48);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        double[][] doubleArray57 = array2DRowRealMatrix55.getDataRef();
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException58 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable15, (java.lang.Object[]) doubleArray57);
        try {
            openMapRealMatrix6.setSubMatrix(doubleArray57, (-1), (-614277696));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 10L, 2.154434690031884d, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (2.154)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair6 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair5);
        double[] doubleArray7 = doubleArrayPair6.getKey();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        double[] doubleArray11 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) (byte) 10, false);
        double double15 = org.apache.commons.math3.util.MathArrays.distance(doubleArray7, doubleArray11);
        double[] doubleArray16 = null;
        try {
            double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray11, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector16.append(arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.mapDivideToSelf(32.0d);
        arrayRealVector7.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor29 = null;
        try {
            double double32 = arrayRealVector16.walkInOptimizedOrder(realVectorPreservingVisitor29, 100, (-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix17, 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = openMapRealMatrix13.multiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(1.0E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) Double.NaN, (java.lang.Number) 100.0d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        int int10 = diagonalMatrix7.getColumnDimension();
        double[] doubleArray12 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12);
        double[] doubleArray18 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray18);
        double[] doubleArray28 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, true);
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray18, doubleArray28);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray28, 11.0d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[][] doubleArray35 = diagonalMatrix34.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix34);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 11.0d + "'", double31 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (-1074790400), 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747903999999998E9d) + "'", double2 == (-1.0747903999999998E9d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math3.util.FastMath.log10(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(1.5860134523134298E15d, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5860134523134295E15d + "'", double2 == 1.5860134523134295E15d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 35, (double) 52.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(1.5860134523134298E15d, (double) Float.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        double[] doubleArray38 = simpleBounds37.getUpper();
        double[] doubleArray44 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition48 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46, (double) (short) 0);
        double[] doubleArray49 = eigenDecomposition48.getRealEigenvalues();
        double[] doubleArray50 = eigenDecomposition48.getRealEigenvalues();
        double[] doubleArray52 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair55 = new org.apache.commons.math3.optim.PointValuePair(doubleArray52, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray52);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds57 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray50, doubleArray52);
        double[] doubleArray58 = simpleBounds57.getUpper();
        double[] doubleArray59 = simpleBounds57.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition63 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray38, doubleArray59, 2.718281828459045d);
        try {
            double[] doubleArray64 = diagonalMatrix18.operate(doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, false);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double24 = arrayRealVector20.walkInDefaultOrder(realVectorPreservingVisitor21, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) (short) 1, 0.9622348015636448d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.0E-15d, 1.5860134523134298E15d, 1864881824);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 1);
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, 7.0710678118654755d, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(1.5860134523134308E15d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[] doubleArray43 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair47 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair46);
        double[] doubleArray48 = doubleArrayPair47.getKey();
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix39.operate(doubleArray49);
        double[] doubleArray56 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray56, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition60 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix58, (double) (short) 0);
        double[] doubleArray61 = eigenDecomposition60.getRealEigenvalues();
        double[] doubleArray62 = eigenDecomposition60.getRealEigenvalues();
        double[] doubleArray64 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair67 = new org.apache.commons.math3.optim.PointValuePair(doubleArray64, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess68 = new org.apache.commons.math3.optim.InitialGuess(doubleArray64);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds69 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray62, doubleArray64);
        double[] doubleArray75 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix77 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray75, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition79 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix77, (double) (short) 0);
        double[] doubleArray80 = eigenDecomposition79.getRealEigenvalues();
        double[] doubleArray81 = eigenDecomposition79.getRealEigenvalues();
        double[] doubleArray83 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair86 = new org.apache.commons.math3.optim.PointValuePair(doubleArray83, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess87 = new org.apache.commons.math3.optim.InitialGuess(doubleArray83);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds88 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray81, doubleArray83);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition89 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray64, doubleArray83);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix90 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        int int91 = array2DRowRealMatrix90.getColumnDimension();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition93 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix90, (double) '4');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = array2DRowRealMatrix39.multiply(array2DRowRealMatrix90);
        double[][] doubleArray95 = array2DRowRealMatrix94.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix94);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 5200.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double[] doubleArray17 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector16.append((double) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor22 = null;
        try {
            double double25 = arrayRealVector21.walkInOptimizedOrder(realVectorChangingVisitor22, (int) (short) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 5L, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray17);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray17, 11.0d);
        boolean boolean23 = eigenDecomposition22.hasComplexEigenvalues();
        boolean boolean24 = eigenDecomposition22.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11.0d + "'", double20 == 11.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 2635.706903978693d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException(localizable1, (java.lang.Number) 10, (java.lang.Number) (-1.0f), (java.lang.Number) 10);
        java.lang.Number number6 = outOfRangeException5.getLo();
        java.lang.Throwable[] throwableArray7 = outOfRangeException5.getSuppressed();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        mathArithmeticException8.addSuppressed((java.lang.Throwable) notPositiveException10);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0f) + "'", number6.equals((-1.0f)));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(3.3019272488946267d, 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray9 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType3, goalType4, goalType5, goalType6, goalType7, goalType8 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray9, orderDirection10, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 1L, (int) '#', orderDirection10, true);
        int int15 = nonMonotonicSequenceException14.getIndex();
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.1102230246251565E-16d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonicSequenceException14, localizable16, (java.lang.Object[]) doubleArray18);
        int int21 = nonMonotonicSequenceException14.getIndex();
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType3.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { Double.NaN };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, 50, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 50 is larger than the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        int int40 = array2DRowRealMatrix39.getColumnDimension();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition42 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix39, (double) '4');
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix39.copy();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(realMatrix43);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor41 = null;
        try {
            double double42 = array2DRowRealMatrix39.walkInRowOrder(realMatrixChangingVisitor41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        java.lang.String str18 = diagonalMatrix17.toString();
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition47 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix45, (double) (short) 0);
        double[] doubleArray53 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix55 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray53, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = diagonalMatrix45.add(diagonalMatrix55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = diagonalMatrix26.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition59 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = diagonalMatrix17.add(diagonalMatrix26);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = diagonalMatrix7.subtract(diagonalMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix63 = diagonalMatrix61.power(0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str18.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(diagonalMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(diagonalMatrix60);
        org.junit.Assert.assertNotNull(diagonalMatrix61);
        org.junit.Assert.assertNotNull(realMatrix63);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 1, (double) 32, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray8 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair11);
        double[] doubleArray13 = doubleArrayPair12.getKey();
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray13);
        double[] doubleArray18 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getValue();
        double[] doubleArray21 = pointVectorValuePair19.getValue();
        double[] doubleArray22 = pointVectorValuePair19.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074790369) + "'", int16 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNull(doubleArray20);
        org.junit.Assert.assertNull(doubleArray21);
        org.junit.Assert.assertNull(doubleArray22);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        try {
            org.apache.commons.math3.linear.RealVector realVector51 = blockRealMatrix49.getColumnVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(4.644483341943245d, 5.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray1, (-0.9999999999999999d), (double) (-1L));
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, 1.1102230246251565E-16d, true);
        double[] doubleArray11 = pointValuePair10.getKey();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray3 = new double[] { 100L, 0.0f, (-1074790400) };
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray3, (java.lang.Double) 47.490658503988655d);
        java.lang.Object obj6 = null;
        boolean boolean7 = doubleArrayPair5.equals(obj6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker5);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver10 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner11 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver10, preconditioner11);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double double18 = brentSolver10.solve((int) '4', (org.apache.commons.math3.analysis.UnivariateFunction) sinc15, (double) 32, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [32, 16.5]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -100 + "'", byte2 == (byte) -100);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013707783890401887d + "'", double1 == 0.013707783890401887d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getUpper();
        double[] doubleArray40 = simpleBounds38.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray19, doubleArray40, 2.718281828459045d);
        double[] doubleArray51 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix53, (double) (short) 0);
        double[] doubleArray56 = eigenDecomposition55.getRealEigenvalues();
        double[] doubleArray57 = eigenDecomposition55.getRealEigenvalues();
        double[] doubleArray59 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair62 = new org.apache.commons.math3.optim.PointValuePair(doubleArray59, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess63 = new org.apache.commons.math3.optim.InitialGuess(doubleArray59);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds64 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray57, doubleArray59);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray57);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex66 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray57);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds67 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray19, doubleArray57);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex68 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder1 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double2 = bracketFinder1.getFMid();
        org.apache.commons.math3.analysis.function.Sinc sinc4 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder1.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc4, goalType5, 0.0d, 6.0d);
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver9 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution13 = null;
        try {
            double double14 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide(0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc4, univariateFunctionBracketedUnivariateSolver9, 2.220446049250313E-16d, 1.7453292519943295d, (double) (byte) 100, allowedSolution13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) -100, (float) (byte) 100, (float) 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("[", (int) (byte) -1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.5860134523134295E15d, 0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        double double12 = lUDecomposition11.getDeterminant();
        double double13 = lUDecomposition11.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = lUDecomposition11.getL();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = lUDecomposition11.getU();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 174.53292519943295d + "'", double12 == 174.53292519943295d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 174.53292519943295d + "'", double13 == 174.53292519943295d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "", "; ", "}", "", "}", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        boolean boolean15 = openMapRealMatrix13.isSquare();
        double[] doubleArray21 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        java.lang.String str24 = diagonalMatrix23.toString();
        double[] doubleArray30 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, (double) (short) 0);
        double[] doubleArray40 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = diagonalMatrix32.add(diagonalMatrix42);
        double[] doubleArray49 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition53 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix51, (double) (short) 0);
        double[] doubleArray59 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray59, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = diagonalMatrix51.add(diagonalMatrix61);
        org.apache.commons.math3.linear.RealMatrix realMatrix63 = diagonalMatrix32.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix62);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition65 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix66 = diagonalMatrix23.add(diagonalMatrix32);
        double[] doubleArray67 = diagonalMatrix66.getDataRef();
        try {
            double[] doubleArray68 = openMapRealMatrix13.operate(doubleArray67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str24.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(diagonalMatrix43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(diagonalMatrix62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(diagonalMatrix66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        double[] doubleArray16 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) (short) 0);
        double[] doubleArray26 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = diagonalMatrix18.add(diagonalMatrix28);
        double[] doubleArray35 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37, (double) (short) 0);
        double[] doubleArray45 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray45, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = diagonalMatrix37.add(diagonalMatrix47);
        double[] doubleArray54 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56, (double) (short) 0);
        double[] doubleArray64 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix66 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray64, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix67 = diagonalMatrix56.add(diagonalMatrix66);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = diagonalMatrix37.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix67);
        double double69 = diagonalMatrix67.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor70 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double71 = diagonalMatrix67.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor70);
        double double72 = diagonalMatrix28.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor70);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix73 = diagonalMatrix7.add(diagonalMatrix28);
        double double74 = diagonalMatrix7.getNorm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(diagonalMatrix29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(diagonalMatrix48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(diagonalMatrix67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 47.490658503988655d + "'", double69 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(diagonalMatrix73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.0d + "'", double74 == 10.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 5, (float) 9L, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = objectiveFunction1.getObjectiveFunction();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = objectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNull(multivariateFunction2);
        org.junit.Assert.assertNull(multivariateFunction3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        double[][] doubleArray52 = null;
        try {
            blockRealMatrix49.setSubMatrix(doubleArray52, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        arrayRealVector7.set(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 3.8146973E-6f, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.scalarAdd(0.0d);
        double[] doubleArray29 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix31 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix31, (double) (short) 0);
        double[] doubleArray39 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = diagonalMatrix31.add(diagonalMatrix41);
        double[] doubleArray48 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix50, (double) (short) 0);
        double[] doubleArray58 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = diagonalMatrix50.add(diagonalMatrix60);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = diagonalMatrix31.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix61);
        double double63 = diagonalMatrix61.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor64 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double65 = diagonalMatrix61.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor64);
        try {
            double double70 = diagonalMatrix21.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor64, 0, 100, 2147483647, (-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(diagonalMatrix42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(diagonalMatrix61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 47.490658503988655d + "'", double63 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) 0.0f);
        double[] doubleArray25 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray25, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair29 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair28);
        double[] doubleArray30 = doubleArrayPair29.getKey();
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray30);
        double[] doubleArray37 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix39, (double) (short) 0);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray43 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray45 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray45, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess49 = new org.apache.commons.math3.optim.InitialGuess(doubleArray45);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray45);
        double double51 = org.apache.commons.math3.util.MathArrays.distance(doubleArray31, doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, doubleArray31);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex56 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray12, (double) (byte) 10, 1.2339186085744818d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 153.22214567148168d + "'", double51 == 153.22214567148168d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix43.getRowMatrix(5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition47 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix43);
        double double48 = lUDecomposition47.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-260124651757769029L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.blockInverse((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double3 = brentSolver2.getFunctionValueAccuracy();
        double double4 = brentSolver2.getMax();
        int int5 = brentSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) 0.0f);
        double[] doubleArray25 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray25, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair29 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair28);
        double[] doubleArray30 = doubleArrayPair29.getKey();
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray30);
        double[] doubleArray37 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix39, (double) (short) 0);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray43 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray45 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray45, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess49 = new org.apache.commons.math3.optim.InitialGuess(doubleArray45);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray45);
        double double51 = org.apache.commons.math3.util.MathArrays.distance(doubleArray31, doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, doubleArray31);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType57 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType58 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType59 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType60 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType61 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType62 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray63 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType57, goalType58, goalType59, goalType60, goalType61, goalType62 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection64 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray63, orderDirection64, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException68 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 1L, (int) '#', orderDirection64, true);
        int int69 = nonMonotonicSequenceException68.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection70 = nonMonotonicSequenceException68.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection71 = nonMonotonicSequenceException68.getDirection();
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray12, orderDirection71, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not increasing (10 > 1.745)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 153.22214567148168d + "'", double51 == 153.22214567148168d);
        org.junit.Assert.assertTrue("'" + goalType57 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType57.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType58 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType58.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType59 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType59.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType60 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType60.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType61 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType61.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType62 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType62.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray63);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 35 + "'", int69 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix6, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x35) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray13);
        try {
            int int16 = multiDimensionMismatchException14.getExpectedDimension((int) (byte) -100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long[] longArray3 = new long[] { 0L, 32, (-1) };
        long[] longArray7 = new long[] { 0L, 32, (-1) };
        long[] longArray11 = new long[] { 0L, 32, (-1) };
        long[] longArray15 = new long[] { 0L, 32, (-1) };
        long[] longArray19 = new long[] { 0L, 32, (-1) };
        long[][] longArray20 = new long[][] { longArray3, longArray7, longArray11, longArray15, longArray19 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray20);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray20);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray20);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray20);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((-3.481799283000183d), (double) 36, (double) 50, (-3.481799283000183d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-299.43473833801573d) + "'", double4 == (-299.43473833801573d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray16 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        java.lang.String str19 = diagonalMatrix18.toString();
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray35 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix27.add(diagonalMatrix37);
        double[] doubleArray44 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition48 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46, (double) (short) 0);
        double[] doubleArray54 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = diagonalMatrix46.add(diagonalMatrix56);
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = diagonalMatrix27.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix57);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition60 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = diagonalMatrix18.add(diagonalMatrix27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = diagonalMatrix8.subtract(diagonalMatrix27);
        double[][] doubleArray63 = diagonalMatrix27.getData();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str19.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(diagonalMatrix57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(diagonalMatrix61);
        org.junit.Assert.assertNotNull(diagonalMatrix62);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (byte) 0);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 1);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray8);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction10 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator11 = null;
        try {
            multiDirectionalSimplex9.iterate(multivariateFunction10, pointValuePairComparator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 52, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition47 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix45, (double) (short) 0);
        double[] doubleArray53 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix55 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray53, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = diagonalMatrix45.add(diagonalMatrix55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = diagonalMatrix26.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56);
        double double58 = diagonalMatrix56.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor59 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double60 = diagonalMatrix56.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        double double61 = diagonalMatrix17.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor62 = null;
        try {
            double double67 = diagonalMatrix17.walkInRowOrder(realMatrixChangingVisitor62, (int) (short) 100, (int) (byte) -1, 100, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(diagonalMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 47.490658503988655d + "'", double58 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 36, (-5.373951845E8d), (double) (-614277696));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.68825475E7d + "'", double3 == 7.68825475E7d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        double[] doubleArray40 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair43 = new org.apache.commons.math3.optim.PointValuePair(doubleArray40, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess44 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray46 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray46, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair50 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair49);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction51 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction52 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction51);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction53 = modelFunction52.getModelFunction();
        boolean boolean54 = doubleArrayPair50.equals((java.lang.Object) multivariateVectorFunction53);
        double[] doubleArray55 = doubleArrayPair50.getFirst();
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray55);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma57 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray56);
        double double58 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray13, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNull(multivariateVectorFunction53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.0d + "'", double58 == 2.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor51 = null;
        try {
            double double52 = diagonalMatrix50.walkInRowOrder(realMatrixPreservingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray55 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix57, (double) (short) 0);
        double[] doubleArray60 = eigenDecomposition59.getRealEigenvalues();
        double[] doubleArray61 = eigenDecomposition59.getRealEigenvalues();
        org.apache.commons.math3.linear.RealVector realVector62 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray61);
        try {
            double[] doubleArray63 = blockRealMatrix49.operate(doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector62);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = lUDecomposition40.getP();
        org.apache.commons.math3.linear.MatrixUtils.checkSymmetric(realMatrix41, 3.3019272488946267d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix41);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int2 = org.apache.commons.math3.util.FastMath.min(36, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = openMapRealMatrix2.copy();
        double[] doubleArray11 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13, (double) (short) 0);
        boolean boolean16 = diagonalMatrix13.isTransposable();
        double[] doubleArray22 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix24, (double) (short) 0);
        double[] doubleArray32 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = diagonalMatrix24.add(diagonalMatrix34);
        double[] doubleArray41 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition45 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix43, (double) (short) 0);
        double[] doubleArray51 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = diagonalMatrix43.add(diagonalMatrix53);
        double[] doubleArray60 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray60, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition64 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix62, (double) (short) 0);
        double[] doubleArray70 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix72 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray70, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix73 = diagonalMatrix62.add(diagonalMatrix72);
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = diagonalMatrix43.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix73);
        double double75 = diagonalMatrix73.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor76 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double77 = diagonalMatrix73.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor76);
        double double78 = diagonalMatrix34.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix79 = diagonalMatrix13.add(diagonalMatrix34);
        try {
            openMapRealMatrix4.setRowMatrix(0, (org.apache.commons.math3.linear.RealMatrix) diagonalMatrix34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 1x35");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(diagonalMatrix35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(diagonalMatrix54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(diagonalMatrix73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 47.490658503988655d + "'", double75 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(diagonalMatrix79);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray14, doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray41 = array2DRowRealMatrix40.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException42 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        java.text.ParsePosition parsePosition3 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[" + "'", str1.equals("["));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        double double36 = arrayRealVector26.getMinValue();
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        double double56 = arrayRealVector46.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector46.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector26.combineToSelf(0.0d, 22026.465794806718d, realVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector59);
        org.apache.commons.math3.linear.RealVector realVector63 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector59.combine(153.22214567148168d, (double) 2147483647, realVector63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-10.0d) + "'", double36 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-10.0d) + "'", double56 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(32.0d, (double) 10.0f);
        double double3 = simpleVectorValueChecker2.getRelativeThreshold();
        double double4 = simpleVectorValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.setMaximalCount((int) (short) -1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = blockRealMatrix49.scalarAdd((double) (-614277696));
        double[] doubleArray60 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray60, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition64 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix62, (double) (short) 0);
        double[] doubleArray70 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix72 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray70, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix73 = diagonalMatrix62.add(diagonalMatrix72);
        double[] doubleArray79 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray79, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition83 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix81, (double) (short) 0);
        double[] doubleArray89 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix91 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray89, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix92 = diagonalMatrix81.add(diagonalMatrix91);
        org.apache.commons.math3.linear.RealMatrix realMatrix93 = diagonalMatrix62.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix92);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition95 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix62, (double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix96 = lUDecomposition95.getP();
        try {
            blockRealMatrix49.setColumnMatrix((int) (short) -1, realMatrix96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(diagonalMatrix73);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(diagonalMatrix92);
        org.junit.Assert.assertNotNull(realMatrix93);
        org.junit.Assert.assertNotNull(realMatrix96);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) 1.0f);
        double double2 = bracketingStep1.getBracketingStep();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAddToSelf(11.0d);
        java.lang.String str10 = arrayRealVector7.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{111; 1; 12.745329252; 12; 1; 112.5309649149}" + "'", str10.equals("{111; 1; 12.745329252; 12; 1; 112.5309649149}"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((-0.7249165551445564d), (double) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) 'a');
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = blockRealMatrix49.scalarAdd((double) (-614277696));
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor54 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double59 = blockRealMatrix49.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor54, (int) (short) -1, 52, (int) 'a', 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (short) 0, 0.0d, 7.0710678118654755d, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.553603672697958d + "'", double4 == 5.553603672697958d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray8 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair11);
        double[] doubleArray13 = doubleArrayPair12.getKey();
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray13);
        double[] doubleArray18 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getSecond();
        double[] doubleArray21 = pointVectorValuePair19.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074790369) + "'", int16 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNull(doubleArray20);
        org.junit.Assert.assertNull(doubleArray21);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix8, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix15, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix15);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix19 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix15);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix12.subtract(openMapRealMatrix19);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.add(openMapRealMatrix19);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double23 = openMapRealMatrix21.walkInRowOrder(realMatrixChangingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray6, doubleArray14);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale(0.057629502154529534d, doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = diagonalMatrix37.power((int) 'a');
        double[] doubleArray41 = diagonalMatrix37.getDataRef();
        int int42 = diagonalMatrix37.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix37, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 5 + "'", int42 == 5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver4 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker3, univariateSolver4);
        double[] doubleArray6 = nonLinearConjugateGradientOptimizer5.getUpperBound();
        double[] doubleArray7 = nonLinearConjugateGradientOptimizer5.getStartPoint();
        int int8 = nonLinearConjugateGradientOptimizer5.getMaxEvaluations();
        int int9 = nonLinearConjugateGradientOptimizer5.getIterations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = nonLinearConjugateGradientOptimizer5.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double double39 = diagonalMatrix37.getTrace();
        int int40 = diagonalMatrix37.getRowDimension();
        int int41 = diagonalMatrix37.getColumnDimension();
        try {
            double[] doubleArray43 = diagonalMatrix37.getRow((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 47.490658503988655d + "'", double39 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 5 + "'", int40 == 5);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getDataRef();
        double[] doubleArray46 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray46);
        try {
            double[] doubleArray50 = array2DRowRealMatrix39.preMultiply(doubleArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        double double9 = arrayRealVector7.getMinValue();
        double double10 = arrayRealVector7.getLInfNorm();
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector18.append(arrayRealVector26);
        double double28 = arrayRealVector18.getMinValue();
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector38.append(arrayRealVector46);
        double double48 = arrayRealVector38.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector38.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector18.combineToSelf(0.0d, 22026.465794806718d, realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, arrayRealVector18);
        try {
            arrayRealVector7.setEntry((int) '#', (double) (-260124651757769029L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-10.0d) + "'", double9 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 101.53096491487338d + "'", double10 == 101.53096491487338d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-10.0d) + "'", double28 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-10.0d) + "'", double48 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction6 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction7 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction6);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction8 = modelFunction7.getModelFunction();
        boolean boolean9 = doubleArrayPair5.equals((java.lang.Object) multivariateVectorFunction8);
        double[] doubleArray10 = doubleArrayPair5.getFirst();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNull(multivariateVectorFunction8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.0d, (double) (short) 1, (double) (short) 10);
        double[] doubleArray4 = levenbergMarquardtOptimizer3.getStartPoint();
        double[] doubleArray5 = levenbergMarquardtOptimizer3.getUpperBound();
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector16.append(arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.mapDivideToSelf(32.0d);
        arrayRealVector7.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector16.append((double) 'a');
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor31 = null;
        try {
            double double32 = arrayRealVector16.walkInDefaultOrder(realVectorPreservingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.util.MathUtils.checkFinite((-0.7249165551445564d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        java.io.ObjectInputStream objectInputStream42 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) array2DRowRealMatrix39, "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", objectInputStream42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double[] doubleArray12 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix14, (double) (short) 0);
        double[] doubleArray17 = eigenDecomposition16.getRealEigenvalues();
        double[] doubleArray18 = eigenDecomposition16.getRealEigenvalues();
        double[] doubleArray20 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray20);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds25 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray20);
        double[] doubleArray26 = simpleBounds25.getUpper();
        double[] doubleArray27 = simpleBounds25.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, false);
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, 3.970291913552122d);
        double[] doubleArray32 = pointValuePair31.getKey();
        try {
            double[] doubleArray33 = openMapRealMatrix6.operate(doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        double[] doubleArray22 = target21.getTarget();
        double[] doubleArray28 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, true);
        double[] doubleArray36 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray28, doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray36);
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.9967368836335428d, (java.lang.Number) 52.0f, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray17);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray17, 11.0d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector32.append(arrayRealVector40);
        try {
            org.apache.commons.math3.linear.RealVector realVector42 = diagonalMatrix23.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11.0d + "'", double20 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector41);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double2 = org.apache.commons.math3.util.FastMath.pow(6.283185307179586d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.589560061550897E7d + "'", double2 == 9.589560061550897E7d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(32.0d, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(1.9155040003582885E22d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3, (double) 10L, 6.0d, (double) 5.0f, 0.0d);
        double double9 = levenbergMarquardtOptimizer8.getChiSquare();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction6 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction7 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction6);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction8 = modelFunction7.getModelFunction();
        boolean boolean9 = doubleArrayPair5.equals((java.lang.Object) multivariateVectorFunction8);
        double[] doubleArray10 = doubleArrayPair5.getFirst();
        java.lang.Double double11 = doubleArrayPair5.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNull(multivariateVectorFunction8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11.equals(10.0d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, 0.0d, (double) 32, 1.0d, (double) 100L);
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray8);
        double[] doubleArray15 = initialGuess14.getInitialGuess();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math3.util.FastMath.atan(153.22214567148168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5642699477411193d + "'", double1 == 1.5642699477411193d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        double[] doubleArray46 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray46, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess50 = new org.apache.commons.math3.optim.InitialGuess(doubleArray46);
        double[] doubleArray53 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair56 = new org.apache.commons.math3.optim.PointValuePair(doubleArray53, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair57 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair56);
        double[] doubleArray58 = doubleArrayPair57.getKey();
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray58);
        org.apache.commons.math3.linear.RealVector realVector60 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        int int61 = org.apache.commons.math3.util.MathUtils.hash(doubleArray58);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray58);
        try {
            double[] doubleArray63 = array2DRowRealMatrix43.operate(doubleArray62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1074790369) + "'", int61 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1074790369), (float) 32, (float) 1864881824);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 2.3978952727983707d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.9967368836335428d, (java.lang.Number) 4.641588833612779d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, 0.0d, (double) 32, 1.0d, (double) 100L);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction14 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator15 = null;
        try {
            nelderMeadSimplex13.iterate(multivariateFunction14, pointValuePairComparator15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathIllegalArgumentException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        int int41 = array2DRowRealMatrix39.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        double[] doubleArray5 = pointValuePair4.getKey();
        double[] doubleArray12 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix14, (double) (short) 0);
        double[] doubleArray17 = eigenDecomposition16.getRealEigenvalues();
        double[] doubleArray18 = eigenDecomposition16.getRealEigenvalues();
        double[] doubleArray20 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray20);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds25 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray20);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray18);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition27 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        double double9 = arrayRealVector7.getMinValue();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor10 = null;
        try {
            double double13 = arrayRealVector7.walkInDefaultOrder(realVectorPreservingVisitor10, 0, (int) (byte) -100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-10.0d) + "'", double9 == (-10.0d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        double[] doubleArray59 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray59, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition63 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix61, (double) (short) 0);
        double[] doubleArray64 = eigenDecomposition63.getRealEigenvalues();
        double[] doubleArray65 = eigenDecomposition63.getRealEigenvalues();
        double[] doubleArray67 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair70 = new org.apache.commons.math3.optim.PointValuePair(doubleArray67, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess71 = new org.apache.commons.math3.optim.InitialGuess(doubleArray67);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds72 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray65, doubleArray67);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.scale(9.148345846451205E150d, doubleArray67);
        try {
            blockRealMatrix49.setRow((int) (byte) 100, doubleArray67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10.0f, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        double[] doubleArray4 = levenbergMarquardtOptimizer3.getLowerBound();
        int int5 = levenbergMarquardtOptimizer3.getEvaluations();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        long[] longArray10 = new long[] { 0L, 32, (-1) };
        long[] longArray14 = new long[] { 0L, 32, (-1) };
        long[] longArray18 = new long[] { 0L, 32, (-1) };
        long[] longArray22 = new long[] { 0L, 32, (-1) };
        long[] longArray26 = new long[] { 0L, 32, (-1) };
        long[][] longArray27 = new long[][] { longArray10, longArray14, longArray18, longArray22, longArray26 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray27);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) levenbergMarquardtOptimizer3, localizable6, (java.lang.Object[]) longArray27);
        try {
            double[] doubleArray30 = levenbergMarquardtOptimizer3.getTarget();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector16.append(arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.mapDivideToSelf(32.0d);
        arrayRealVector7.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        java.lang.Double[] doubleArray43 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector36.append(arrayRealVector44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector44.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector44, false);
        java.lang.Double[] doubleArray56 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        double[] doubleArray58 = arrayRealVector57.getDataRef();
        java.lang.Double[] doubleArray67 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray67);
        java.lang.Double[] doubleArray75 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector68.append(arrayRealVector76);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector68.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = arrayRealVector57.combine((double) (short) -1, (double) (byte) -1, realVector79);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = arrayRealVector49.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector49);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertNotNull(arrayRealVector80);
        org.junit.Assert.assertNotNull(arrayRealVector81);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((-299.43473833801573d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.5185445730663955E129d) + "'", double1 == (-5.5185445730663955E129d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "hi!");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray20 = simpleBounds18.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, false);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, 3.970291913552122d);
        java.lang.Double double25 = pointValuePair24.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.970291913552122d + "'", double25.equals(3.970291913552122d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        int int10 = diagonalMatrix7.getColumnDimension();
        try {
            diagonalMatrix7.setEntry(0, (int) (short) 10, 4.641588833612779d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 4.642 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10.0f, (double) 10.0f);
        double[] doubleArray5 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess9 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray12 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair16 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair15);
        double[] doubleArray17 = doubleArrayPair16.getKey();
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray17);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        int int20 = org.apache.commons.math3.util.MathUtils.hash(doubleArray17);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray5, doubleArray17);
        double[] doubleArray22 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray21, doubleArray22);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        double[] doubleArray25 = pointVectorValuePair23.getValue();
        double[] doubleArray27 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray27);
        double[] doubleArray34 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray34, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair38 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair37);
        double[] doubleArray39 = doubleArrayPair38.getKey();
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray39);
        int int42 = org.apache.commons.math3.util.MathUtils.hash(doubleArray39);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray27, doubleArray39);
        double[] doubleArray44 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray43, doubleArray44);
        double[] doubleArray46 = pointVectorValuePair45.getValue();
        double[] doubleArray47 = pointVectorValuePair45.getValue();
        java.lang.Object obj48 = null;
        boolean boolean49 = pointVectorValuePair45.equals(obj48);
        try {
            boolean boolean50 = simpleVectorValueChecker2.converged(0, pointVectorValuePair23, pointVectorValuePair45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1074790369) + "'", int20 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNull(doubleArray24);
        org.junit.Assert.assertNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1074790369) + "'", int42 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNull(doubleArray46);
        org.junit.Assert.assertNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{111; 1; 12.745329252; 12; 1; 112.5309649149}", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value(1.2339186085744818d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction4 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc1);
        try {
            double[] doubleArray9 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 2.3978952727983707d, (double) 52, 3.3019272488946267d, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [52, 2.398]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7648732279940101d + "'", double3 == 0.7648732279940101d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        diagonalMatrix7.setEntry((int) (byte) -1, 1, 0.0d);
        double[] doubleArray18 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20, (double) (short) 0);
        boolean boolean23 = diagonalMatrix20.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition25 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20, 3.970291913552122d);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = diagonalMatrix7.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        java.lang.Double[] doubleArray58 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58);
        java.lang.Double[] doubleArray66 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector59.append(arrayRealVector67);
        double double69 = arrayRealVector59.getMinValue();
        double double70 = arrayRealVector59.getNorm();
        try {
            diagonalMatrix16.setColumnVector((-1074790400), (org.apache.commons.math3.linear.RealVector) arrayRealVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(arrayRealVector68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + (-10.0d) + "'", double69 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 143.22214567148168d + "'", double70 == 143.22214567148168d);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
//        long long6 = mersenneTwister4.nextLong(10L);
//        int[] intArray7 = null;
//        mersenneTwister4.setSeed(intArray7);
//        int int10 = mersenneTwister4.nextInt(5);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray55 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        double[] doubleArray63 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix65 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray63, true);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray55, doubleArray63);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray63);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix49.subtract(realMatrix67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x6 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix67);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray17);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray17, 11.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11.0d + "'", double20 == 11.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getUpper();
        double[] doubleArray40 = simpleBounds38.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray19, doubleArray40, 2.718281828459045d);
        double[] doubleArray51 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix53, (double) (short) 0);
        double[] doubleArray56 = eigenDecomposition55.getRealEigenvalues();
        double[] doubleArray57 = eigenDecomposition55.getRealEigenvalues();
        double[] doubleArray59 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair62 = new org.apache.commons.math3.optim.PointValuePair(doubleArray59, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess63 = new org.apache.commons.math3.optim.InitialGuess(doubleArray59);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds64 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray57, doubleArray59);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray57);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex66 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray57);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds67 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray19, doubleArray57);
        double[] doubleArray69 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair72 = new org.apache.commons.math3.optim.PointValuePair(doubleArray69, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex73 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray69);
        double[] doubleArray75 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair78 = new org.apache.commons.math3.optim.PointValuePair(doubleArray75, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex79 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray75);
        double[] doubleArray85 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix87 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray85, true);
        double double88 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray75, doubleArray85);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition90 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray69, doubleArray85, 11.0d);
        try {
            double[] doubleArray91 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray57, doubleArray69);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 11.0d + "'", double88 == 11.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(5.553603672697958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 129.0850508233241d + "'", double1 == 129.0850508233241d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray16 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = diagonalMatrix8.add(diagonalMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = diagonalMatrix19.scalarAdd((double) (byte) 0);
        double[][] doubleArray22 = diagonalMatrix19.getData();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray22);
        double[][] doubleArray24 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(diagonalMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math3.util.FastMath.log10(1.0E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.0d) + "'", double1 == (-5.0d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray13);
        java.lang.Integer[] intArray15 = multiDimensionMismatchException14.getExpectedDimensions();
        java.lang.Integer[] intArray16 = multiDimensionMismatchException14.getExpectedDimensions();
        java.lang.Integer[] intArray17 = multiDimensionMismatchException14.getWrongDimensions();
        java.lang.Integer[] intArray18 = multiDimensionMismatchException14.getWrongDimensions();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[] doubleArray43 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair47 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair46);
        double[] doubleArray48 = doubleArrayPair47.getKey();
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix39.operate(doubleArray49);
        double[] doubleArray56 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray56, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition60 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix58, (double) (short) 0);
        double[] doubleArray61 = eigenDecomposition60.getRealEigenvalues();
        double[] doubleArray62 = eigenDecomposition60.getRealEigenvalues();
        double[] doubleArray64 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair67 = new org.apache.commons.math3.optim.PointValuePair(doubleArray64, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess68 = new org.apache.commons.math3.optim.InitialGuess(doubleArray64);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds69 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray62, doubleArray64);
        double[] doubleArray75 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix77 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray75, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition79 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix77, (double) (short) 0);
        double[] doubleArray80 = eigenDecomposition79.getRealEigenvalues();
        double[] doubleArray81 = eigenDecomposition79.getRealEigenvalues();
        double[] doubleArray83 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair86 = new org.apache.commons.math3.optim.PointValuePair(doubleArray83, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess87 = new org.apache.commons.math3.optim.InitialGuess(doubleArray83);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds88 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray81, doubleArray83);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition89 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray64, doubleArray83);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix90 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        int int91 = array2DRowRealMatrix90.getColumnDimension();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition93 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix90, (double) '4');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = array2DRowRealMatrix39.multiply(array2DRowRealMatrix90);
        double double95 = array2DRowRealMatrix94.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 1.0d + "'", double95 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = blockRealMatrix49.scalarAdd((double) (-614277696));
        java.lang.Double[] doubleArray60 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray60);
        double[] doubleArray62 = arrayRealVector61.getDataRef();
        java.lang.Double[] doubleArray71 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray71);
        java.lang.Double[] doubleArray79 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray79);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = arrayRealVector72.append(arrayRealVector80);
        org.apache.commons.math3.linear.RealVector realVector83 = arrayRealVector72.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = arrayRealVector61.combine((double) (short) -1, (double) (byte) -1, realVector83);
        org.apache.commons.math3.linear.RealVector realVector85 = blockRealMatrix49.operate(realVector83);
        try {
            double[] doubleArray87 = blockRealMatrix49.getColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(arrayRealVector81);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(arrayRealVector84);
        org.junit.Assert.assertNotNull(realVector85);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) 0.0f);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair23 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair22);
        int[] intArray27 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math3.random.MersenneTwister(intArray27);
        int[] intArray29 = org.apache.commons.math3.util.MathArrays.copyOf(intArray27);
        int[] intArray33 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister34 = new org.apache.commons.math3.random.MersenneTwister(intArray33);
        int int35 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray29, intArray33);
        int[] intArray37 = org.apache.commons.math3.util.MathArrays.copyOf(intArray33, 52);
        boolean boolean38 = pointValuePair22.equals((java.lang.Object) 52);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math3.util.MathUtils.checkFinite(1.0E-15d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getRowSuffix();
        java.lang.String str3 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray20 = simpleBounds18.getUpper();
        double[] doubleArray22 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22);
        double[] doubleArray28 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray28);
        double[] doubleArray38 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38, true);
        double double41 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray28, doubleArray38);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray22, doubleArray38, 11.0d);
        double double44 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray20, doubleArray38);
        double[] doubleArray50 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52, (double) (short) 0);
        double[] doubleArray55 = eigenDecomposition54.getRealEigenvalues();
        double[] doubleArray56 = eigenDecomposition54.getRealEigenvalues();
        double[] doubleArray58 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray58, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess62 = new org.apache.commons.math3.optim.InitialGuess(doubleArray58);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds63 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray56, doubleArray58);
        double[] doubleArray64 = simpleBounds63.getUpper();
        double[] doubleArray65 = simpleBounds63.getUpper();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair66 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 11.0d + "'", double41 == 11.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 11.0d + "'", double44 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (-1.0d), (double) 52L, (double) (-1L), (-5.0d), objArray5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "[", "", numberFormat8);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat10 = new org.apache.commons.math3.linear.RealVectorFormat("}", "{", "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]", numberFormat8);
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[" + "'", str7.equals("["));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        diagonalMatrix7.setEntry(35, (int) (byte) 1, (double) (byte) 0);
        int int23 = diagonalMatrix7.getRowDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix26, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix26);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix26);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix33, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix36 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix33);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix37 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix33);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix38 = openMapRealMatrix30.subtract(openMapRealMatrix37);
        double[] doubleArray44 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition48 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46, (double) (short) 0);
        double[] doubleArray54 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = diagonalMatrix46.add(diagonalMatrix56);
        double[] doubleArray63 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix65 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray63, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition67 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix65, (double) (short) 0);
        double[] doubleArray73 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix75 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray73, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix76 = diagonalMatrix65.add(diagonalMatrix75);
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = diagonalMatrix46.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix76);
        double double78 = diagonalMatrix76.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor79 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double80 = diagonalMatrix76.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor79);
        defaultRealMatrixPreservingVisitor79.start(32, 0, 5, 36, (int) (short) 100, 36);
        double double88 = openMapRealMatrix30.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor79);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix89 = diagonalMatrix7.preMultiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertNotNull(openMapRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(diagonalMatrix57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(diagonalMatrix76);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 47.490658503988655d + "'", double78 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(5);
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker5);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver10 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner11 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver10, preconditioner11);
        int int13 = nonLinearConjugateGradientOptimizer12.getIterations();
        int int14 = nonLinearConjugateGradientOptimizer12.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{111; 1; 12.745329252; 12; 1; 112.5309649149}", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double3 = brentSolver2.getFunctionValueAccuracy();
        org.apache.commons.math3.analysis.function.Sinc sinc6 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = sinc6.derivative();
        try {
            double double9 = brentSolver2.solve(2147483647, univariateFunction7, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [�, �], values: [�, �]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertNotNull(univariateFunction7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor40 = null;
        try {
            double double45 = array2DRowRealMatrix39.walkInRowOrder(realMatrixChangingVisitor40, (int) (byte) 100, 100, (int) ' ', (-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getUpper();
        double[] doubleArray40 = simpleBounds38.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray19, doubleArray40, 2.718281828459045d);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray40);
        double[] doubleArray47 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair50 = new org.apache.commons.math3.optim.PointValuePair(doubleArray47, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess51 = new org.apache.commons.math3.optim.InitialGuess(doubleArray47);
        double[] doubleArray53 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair56 = new org.apache.commons.math3.optim.PointValuePair(doubleArray53, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair57 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair56);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction58 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction59 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction58);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction60 = modelFunction59.getModelFunction();
        boolean boolean61 = doubleArrayPair57.equals((java.lang.Object) multivariateVectorFunction60);
        double[] doubleArray62 = doubleArrayPair57.getFirst();
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray62);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) doubleArray63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNull(multivariateVectorFunction60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double double39 = diagonalMatrix37.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor40 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double41 = diagonalMatrix37.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor40);
        double[] doubleArray47 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition51 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49, (double) (short) 0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = diagonalMatrix37.add(diagonalMatrix49);
        double[][] doubleArray53 = diagonalMatrix37.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex54 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 47.490658503988655d + "'", double39 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(diagonalMatrix52);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1L, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair11 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair10);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction12 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction13 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction12);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction14 = modelFunction13.getModelFunction();
        boolean boolean15 = doubleArrayPair11.equals((java.lang.Object) multivariateVectorFunction14);
        double[] doubleArray16 = doubleArrayPair11.getFirst();
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray1, doubleArray16);
        org.apache.commons.math3.optim.nonlinear.vector.Target target18 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNull(multivariateVectorFunction14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair11 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair10);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction12 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction13 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction12);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction14 = modelFunction13.getModelFunction();
        boolean boolean15 = doubleArrayPair11.equals((java.lang.Object) multivariateVectorFunction14);
        double[] doubleArray16 = doubleArrayPair11.getFirst();
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray1, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 50);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNull(multivariateVectorFunction14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        java.lang.Double double5 = pointValuePair4.getValue();
        double[] doubleArray6 = pointValuePair4.getFirst();
        double[] doubleArray7 = pointValuePair4.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5.equals(10.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 1, (double) 1L, 2.718281828459045d, (-0.9999999999999999d), 143.22214567148168d);
        double[] doubleArray6 = levenbergMarquardtOptimizer5.getUpperBound();
        int int7 = levenbergMarquardtOptimizer5.getIterations();
        double[] doubleArray8 = levenbergMarquardtOptimizer5.getLowerBound();
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(doubleArray8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-5.0d), 7.0710678118654755d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0710678118654755d + "'", double2 == 2.0710678118654755d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(0, 6, (double) (byte) 0);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        int int5 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math3.util.MathUtils.checkFinite(1.5707963267948966d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = openMapRealMatrix2.add(openMapRealMatrix7);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix11, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix11);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix11);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix18, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix18);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix18);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix15.subtract(openMapRealMatrix22);
        double[] doubleArray29 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix31 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix31, (double) (short) 0);
        double[] doubleArray39 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = diagonalMatrix31.add(diagonalMatrix41);
        double[] doubleArray48 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix50, (double) (short) 0);
        double[] doubleArray58 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = diagonalMatrix50.add(diagonalMatrix60);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = diagonalMatrix31.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix61);
        double double63 = diagonalMatrix61.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor64 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double65 = diagonalMatrix61.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor64);
        defaultRealMatrixPreservingVisitor64.start(32, 0, 5, 36, (int) (short) 100, 36);
        double double73 = openMapRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor64);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix74 = openMapRealMatrix15.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix75 = openMapRealMatrix2.subtract(openMapRealMatrix74);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix4);
        org.junit.Assert.assertNotNull(openMapRealMatrix8);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(diagonalMatrix42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(diagonalMatrix61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 47.490658503988655d + "'", double63 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix74);
        org.junit.Assert.assertNotNull(openMapRealMatrix75);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        double double4 = brentOptimizer3.getMin();
        int int5 = brentOptimizer3.getMaxEvaluations();
        double double6 = brentOptimizer3.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String[] strArray6 = new java.lang.String[] { "[", "{111; 1; 12.745329252; 12; 1; 112.5309649149}", "hi!", "; ", "", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" };
        java.lang.Number number7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType14 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType15 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType16 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType17 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType18 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray19 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType13, goalType14, goalType15, goalType16, goalType17, goalType18 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection20 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray19, orderDirection20, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 1L, (int) '#', orderDirection20, true);
        int int25 = nonMonotonicSequenceException24.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = nonMonotonicSequenceException24.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number7, (java.lang.Number) (-3.481799283000183d), 0, orderDirection26, true);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray6, orderDirection26, false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + goalType13 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType13.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType14 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType14.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType15 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType15.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType16 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType16.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType17 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType17.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType18 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType18.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.3400289243906618d, (double) 100, (double) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (byte) -100, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-100.0f) + "'", float2 == (-100.0f));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(28.638866890843786d, 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 52.0f, 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        double double3 = blockRealMatrix2.getNorm();
        double[] doubleArray5 = blockRealMatrix2.getColumn(32);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        java.lang.Double[] doubleArray30 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector23.append(arrayRealVector31);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector23.mapDivideToSelf(32.0d);
        arrayRealVector14.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector23.append((double) 'a');
        try {
            blockRealMatrix2.setColumnVector((int) (short) 1, realVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 7x1 but expected 36x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix43.getRowMatrix(5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition47 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = lUDecomposition47.getP();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNull(realMatrix48);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(6.283185307179586d, 0.0d, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.Number number0 = null;
        double[] doubleArray8 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix10, (double) (short) 0);
        double[] doubleArray18 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = diagonalMatrix10.add(diagonalMatrix20);
        double[] doubleArray27 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29, (double) (short) 0);
        double[] doubleArray37 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = diagonalMatrix29.add(diagonalMatrix39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix10.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix40);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = diagonalMatrix40.power((int) 'a');
        double[] doubleArray44 = diagonalMatrix40.getDataRef();
        double[] doubleArray50 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52, (double) (short) 0);
        double[] doubleArray55 = eigenDecomposition54.getRealEigenvalues();
        double[] doubleArray56 = eigenDecomposition54.getRealEigenvalues();
        double[] doubleArray58 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray58, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess62 = new org.apache.commons.math3.optim.InitialGuess(doubleArray58);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds63 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray56, doubleArray58);
        double[] doubleArray69 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix71 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray69, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition73 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix71, (double) (short) 0);
        double[] doubleArray74 = eigenDecomposition73.getRealEigenvalues();
        double[] doubleArray75 = eigenDecomposition73.getRealEigenvalues();
        double[] doubleArray77 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair80 = new org.apache.commons.math3.optim.PointValuePair(doubleArray77, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess81 = new org.apache.commons.math3.optim.InitialGuess(doubleArray77);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds82 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray75, doubleArray77);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition83 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray58, doubleArray77);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection84 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray77, orderDirection84, false);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray44, orderDirection84, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException90 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, (java.lang.Number) 0.9967368836335428d, 3, orderDirection84, true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(diagonalMatrix21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(diagonalMatrix40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection84.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((-1074790400), (int) (byte) 0, 100.0d);
        int int4 = nonSymmetricMatrixException3.getColumn();
        int int5 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = sinc1.derivative();
        double double4 = sinc1.value(129.0850508233241d);
        org.junit.Assert.assertNotNull(univariateFunction2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-6.510623880059051E-4d) + "'", double4 == (-6.510623880059051E-4d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19, (double) (short) 0);
        boolean boolean22 = diagonalMatrix19.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition23 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19);
        double[] doubleArray29 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix31 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix31, (double) (short) 0);
        double[] doubleArray39 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = diagonalMatrix31.add(diagonalMatrix41);
        double[] doubleArray48 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix50, (double) (short) 0);
        double[] doubleArray58 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = diagonalMatrix50.add(diagonalMatrix60);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = diagonalMatrix31.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix61);
        double double63 = diagonalMatrix61.getTrace();
        int int64 = diagonalMatrix61.getRowDimension();
        int int65 = diagonalMatrix61.getColumnDimension();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix66 = diagonalMatrix19.add(diagonalMatrix61);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix66);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix72 = diagonalMatrix7.getSubMatrix((int) (byte) 100, (int) (byte) 100, (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(diagonalMatrix42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(diagonalMatrix61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 47.490658503988655d + "'", double63 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 5 + "'", int64 == 5);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 5 + "'", int65 == 5);
        org.junit.Assert.assertNotNull(diagonalMatrix66);
        org.junit.Assert.assertNotNull(realMatrix67);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray13);
        try {
            int int16 = multiDimensionMismatchException14.getExpectedDimension(5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray14);
        java.lang.Integer[] intArray16 = multiDimensionMismatchException15.getExpectedDimensions();
        org.apache.commons.math3.exception.ConvergenceException convergenceException17 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) intArray16);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int6 = openMapRealMatrix5.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix5.add(openMapRealMatrix10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            openMapRealMatrix2.addToEntry(0, (-614277696), (-1.0747903999999998E9d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-614,277,696)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertNotNull(openMapRealMatrix12);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19, (double) (short) 0);
        double[] doubleArray27 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = diagonalMatrix19.add(diagonalMatrix29);
        double[] doubleArray36 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition40 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix38, (double) (short) 0);
        double[] doubleArray46 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = diagonalMatrix38.add(diagonalMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix19.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        double double51 = diagonalMatrix49.getTrace();
        int int52 = diagonalMatrix49.getRowDimension();
        int int53 = diagonalMatrix49.getColumnDimension();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = diagonalMatrix7.add(diagonalMatrix49);
        double[] doubleArray60 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray60, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition64 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix62, (double) (short) 0);
        double[] doubleArray65 = eigenDecomposition64.getRealEigenvalues();
        double[] doubleArray66 = eigenDecomposition64.getRealEigenvalues();
        double[] doubleArray68 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair71 = new org.apache.commons.math3.optim.PointValuePair(doubleArray68, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess72 = new org.apache.commons.math3.optim.InitialGuess(doubleArray68);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds73 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray66, doubleArray68);
        double[] doubleArray74 = simpleBounds73.getUpper();
        double[] doubleArray75 = simpleBounds73.getUpper();
        try {
            double[] doubleArray76 = diagonalMatrix7.operate(doubleArray75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(diagonalMatrix30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(diagonalMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 47.490658503988655d + "'", double51 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 5 + "'", int52 == 5);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5 + "'", int53 == 5);
        org.junit.Assert.assertNotNull(diagonalMatrix54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        int int1 = maxIter0.getMaxIter();
        int int2 = maxIter0.getMaxIter();
        org.junit.Assert.assertNotNull(maxIter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("}", "[", "[");
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int6 = openMapRealMatrix5.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix5.add(openMapRealMatrix10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition14 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2, (-5.373951845E8d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x35) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertNotNull(openMapRealMatrix12);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getMaxIterations();
        double double5 = brentOptimizer3.getMax();
        int int6 = brentOptimizer3.getMaxEvaluations();
        int int7 = brentOptimizer3.getIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray26 = arrayRealVector25.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray26, 0.0d, (double) 32, 1.0d, (double) 100L);
        arrayRealVector16.setSubVector((int) (short) 0, doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(0.7648732279940101d, 0.9999999999999999d, 52);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, 0.0d, (double) 32, 1.0d, (double) 100L);
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray8);
        java.io.ObjectInputStream objectInputStream16 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) doubleArray8, "{111; 1; 12.745329252; 12; 1; 112.5309649149}", objectInputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = eigenDecomposition9.getD();
        boolean boolean13 = eigenDecomposition9.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix16, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double[] doubleArray22 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix24, (double) (short) 0);
        double[] doubleArray27 = eigenDecomposition26.getRealEigenvalues();
        double[] doubleArray28 = eigenDecomposition26.getRealEigenvalues();
        double[] doubleArray30 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair33 = new org.apache.commons.math3.optim.PointValuePair(doubleArray30, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess34 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds35 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray28, doubleArray30);
        double[] doubleArray36 = simpleBounds35.getUpper();
        java.lang.Double[] doubleArray43 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        java.lang.Double[] doubleArray51 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector44.append(arrayRealVector52);
        double double54 = arrayRealVector44.getMinValue();
        double[] doubleArray55 = arrayRealVector44.toArray();
        double double56 = arrayRealVector44.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36, arrayRealVector44);
        double double58 = arrayRealVector15.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-10.0d) + "'", double54 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-10.0d) + "'", double56 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20512.583010743117d + "'", double58 == 20512.583010743117d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math3.util.FastMath.log(1.58601345231343E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((-100.0f), 1.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-99.99999f) + "'", float2 == (-99.99999f));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector34.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector7.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        java.lang.Double[] doubleArray72 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector65.append(arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector73.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector46.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector79, false);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor82 = null;
        try {
            double double83 = arrayRealVector79.walkInDefaultOrder(realVectorChangingVisitor82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        double double9 = arrayRealVector7.getMinValue();
        double double10 = arrayRealVector7.getLInfNorm();
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector18.append(arrayRealVector26);
        double double28 = arrayRealVector18.getMinValue();
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector38.append(arrayRealVector46);
        double double48 = arrayRealVector38.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector38.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector18.combineToSelf(0.0d, 22026.465794806718d, realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, arrayRealVector18);
        java.lang.Double[] doubleArray59 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59);
        java.lang.Double[] doubleArray67 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector60.append(arrayRealVector68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector7.append(arrayRealVector69);
        java.lang.Double[] doubleArray77 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77);
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector78.mapAddToSelf(11.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector69.projection(realVector80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 12 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-10.0d) + "'", double9 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 101.53096491487338d + "'", double10 == 101.53096491487338d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-10.0d) + "'", double28 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-10.0d) + "'", double48 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector80);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        double[] doubleArray6 = doubleArrayPair5.getKey();
        java.lang.Double double7 = doubleArrayPair5.getValue();
        java.lang.Double double8 = doubleArrayPair5.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8.equals(10.0d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        double double36 = arrayRealVector26.getMinValue();
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        double double56 = arrayRealVector46.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector46.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector26.combineToSelf(0.0d, 22026.465794806718d, realVector58);
        double double60 = arrayRealVector15.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26);
        double[] doubleArray67 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix69 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray67, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition71 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix69, (double) (short) 0);
        double[] doubleArray72 = eigenDecomposition71.getRealEigenvalues();
        double[] doubleArray73 = eigenDecomposition71.getRealEigenvalues();
        org.apache.commons.math3.linear.RealVector realVector74 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray73);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector26.append(realVector74);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-10.0d) + "'", double36 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-10.0d) + "'", double56 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 5155.99724417334d + "'", double60 == 5155.99724417334d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realVector75);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(3.8146973E-6f, (double) (-1074790369));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.814697E-6f + "'", float2 == 3.814697E-6f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition19 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix17, (double) (short) 0);
        double[] doubleArray20 = eigenDecomposition19.getRealEigenvalues();
        double[] doubleArray21 = eigenDecomposition19.getRealEigenvalues();
        double[] doubleArray23 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair26 = new org.apache.commons.math3.optim.PointValuePair(doubleArray23, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray23);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds28 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray21, doubleArray23);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix36, (double) (short) 0);
        double[] doubleArray39 = eigenDecomposition38.getRealEigenvalues();
        double[] doubleArray40 = eigenDecomposition38.getRealEigenvalues();
        double[] doubleArray42 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess46 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds47 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray40, doubleArray42);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition48 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray23, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[][] doubleArray50 = array2DRowRealMatrix49.getData();
        double[][] doubleArray51 = array2DRowRealMatrix49.getDataRef();
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException52 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable9, (java.lang.Object[]) doubleArray51);
        try {
            openMapRealMatrix2.copySubMatrix((int) 'a', (int) (byte) 1, (int) 'a', 100, doubleArray51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.0d, (double) 100, 9.148345846451205E150d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 3, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction6 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction7 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction6);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction8 = modelFunction7.getModelFunction();
        boolean boolean9 = doubleArrayPair5.equals((java.lang.Object) multivariateVectorFunction8);
        double[] doubleArray10 = doubleArrayPair5.getFirst();
        double[] doubleArray12 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12);
        double[] doubleArray18 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray18);
        double[] doubleArray28 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, true);
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray18, doubleArray28);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray28, 11.0d);
        double[] doubleArray35 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray35);
        double[] doubleArray41 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair44 = new org.apache.commons.math3.optim.PointValuePair(doubleArray41, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex45 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray41);
        double[] doubleArray51 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double double54 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray41, doubleArray51);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition56 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray51, 11.0d);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds57 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray28, doubleArray35);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray35, (double) 35);
        double[] doubleArray60 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition61 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNull(multivariateVectorFunction8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 11.0d + "'", double31 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 11.0d + "'", double54 == 11.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker5);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker9 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker9);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula11 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker12 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver13 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner14 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer15 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula11, pointValuePairConvergenceChecker12, univariateSolver13, preconditioner14);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker16 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula11, pointValuePairConvergenceChecker16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker20 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer21 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula11, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker20);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker20);
        int int23 = nonLinearConjugateGradientOptimizer22.getIterations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula11.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(1421.221456714817d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5342243947810865d + "'", double2 == 1.5342243947810865d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        int int51 = diagonalMatrix50.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = blockRealMatrix49.scalarAdd((double) (-614277696));
        double double54 = blockRealMatrix49.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix49.createMatrix(50, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 5.260239166121122E9d + "'", double54 == 5.260239166121122E9d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        java.lang.Double double5 = pointValuePair4.getValue();
        double[] doubleArray6 = pointValuePair4.getKey();
        double[] doubleArray7 = pointValuePair4.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5.equals(10.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(1.0E-5d, 32.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        double double36 = arrayRealVector26.getMinValue();
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        double double56 = arrayRealVector46.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector46.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector26.combineToSelf(0.0d, 22026.465794806718d, realVector58);
        double double60 = arrayRealVector15.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector15.mapAddToSelf((-10.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-10.0d) + "'", double36 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-10.0d) + "'", double56 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 5155.99724417334d + "'", double60 == 5155.99724417334d);
        org.junit.Assert.assertNotNull(realVector62);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        double[] doubleArray6 = doubleArrayPair5.getKey();
        double[] doubleArray7 = doubleArrayPair5.getKey();
        double[] doubleArray8 = doubleArrayPair5.getFirst();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        double[] doubleArray6 = doubleArrayPair5.getKey();
        double[] doubleArray7 = doubleArrayPair5.getKey();
        java.lang.Double double8 = doubleArrayPair5.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8.equals(10.0d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) 0.0f);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair23 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair22);
        java.lang.Object obj24 = null;
        boolean boolean25 = pointValuePair22.equals(obj24);
        double[] doubleArray26 = pointValuePair22.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix6, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix6);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix6);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix13, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix13);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix13);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = openMapRealMatrix10.subtract(openMapRealMatrix17);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix18);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        double double3 = blockRealMatrix2.getNorm();
        double[] doubleArray5 = blockRealMatrix2.getColumn(32);
        double[] doubleArray11 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13, (double) (short) 0);
        double[] doubleArray21 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix13.add(diagonalMatrix23);
        double[] doubleArray30 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, (double) (short) 0);
        double[] doubleArray40 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = diagonalMatrix32.add(diagonalMatrix42);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = diagonalMatrix13.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix43);
        double double45 = diagonalMatrix43.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double47 = diagonalMatrix43.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        defaultRealMatrixPreservingVisitor46.visit(6, (int) (short) 0, 1.0d);
        double double52 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        try {
            double[] doubleArray54 = blockRealMatrix2.getRow(1864881824);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,864,881,824)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(diagonalMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 47.490658503988655d + "'", double45 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double[] doubleArray11 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13, (double) (short) 0);
        double[] doubleArray21 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix13.add(diagonalMatrix23);
        double[] doubleArray30 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, (double) (short) 0);
        double[] doubleArray40 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = diagonalMatrix32.add(diagonalMatrix42);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = diagonalMatrix13.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix43);
        double double45 = diagonalMatrix43.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double47 = diagonalMatrix43.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        defaultRealMatrixPreservingVisitor46.visit(6, (int) (short) 0, 1.0d);
        try {
            double double56 = openMapRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46, 100, 1, (int) (byte) 10, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(diagonalMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 47.490658503988655d + "'", double45 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = lUDecomposition11.getP();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((-5.0d), (double) 100, (double) 3.8146973E-6f, (-10.0d), 1.5860134523134295E15d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = blockRealMatrix49.scalarAdd((double) (-614277696));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor54 = null;
        try {
            double double55 = blockRealMatrix49.walkInOptimizedOrder(realMatrixChangingVisitor54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = diagonalMatrix37.power((int) 'a');
        double[] doubleArray41 = diagonalMatrix37.getDataRef();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix44 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix44, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix47 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix44);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix48 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix44);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix51 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix51, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix54 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix51);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix55 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix51);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix56 = openMapRealMatrix48.subtract(openMapRealMatrix55);
        boolean boolean57 = openMapRealMatrix55.isSquare();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix37, (org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 10x35");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealMatrix56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize(35);
        int int2 = populationSize1.getPopulationSize();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2204460492503128E-16d + "'", double1 == 2.2204460492503128E-16d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math3.exception.ConvergenceException convergenceException0 = new org.apache.commons.math3.exception.ConvergenceException();
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair6 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair5);
        double[] doubleArray7 = doubleArrayPair6.getKey();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray7);
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray19 = eigenDecomposition18.getRealEigenvalues();
        double[] doubleArray20 = eigenDecomposition18.getRealEigenvalues();
        double[] doubleArray22 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds27 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray20, doubleArray22);
        double double28 = org.apache.commons.math3.util.MathArrays.distance(doubleArray8, doubleArray20);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray20, 7.896296018267969E13d, (-10.0d));
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) 0, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 153.22214567148168d + "'", double28 == 153.22214567148168d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (-1), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray50 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52, (double) (short) 0);
        double[] doubleArray55 = eigenDecomposition54.getRealEigenvalues();
        double[] doubleArray56 = eigenDecomposition54.getRealEigenvalues();
        double[] doubleArray58 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray58, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess62 = new org.apache.commons.math3.optim.InitialGuess(doubleArray58);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds63 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray56, doubleArray58);
        double[] doubleArray64 = simpleBounds63.getUpper();
        java.lang.Double[] doubleArray71 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray71);
        java.lang.Double[] doubleArray79 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray79);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = arrayRealVector72.append(arrayRealVector80);
        double double82 = arrayRealVector72.getMinValue();
        double[] doubleArray83 = arrayRealVector72.toArray();
        double double84 = arrayRealVector72.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64, arrayRealVector72);
        array2DRowRealMatrix43.setRowVector(5, (org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        double double87 = arrayRealVector72.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector89 = arrayRealVector72.mapMultiply(1.5707963267948966d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(arrayRealVector81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + (-10.0d) + "'", double82 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + (-10.0d) + "'", double84 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 101.53096491487338d + "'", double87 == 101.53096491487338d);
        org.junit.Assert.assertNotNull(realVector89);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, 47.490658503988655d, 0.0d, 0.0d);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getHi();
        double double7 = noBracketingException4.getHi();
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException23 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable9, intArray16, intArray22);
        java.lang.Integer[] intArray24 = multiDimensionMismatchException23.getExpectedDimensions();
        java.lang.Integer[] intArray25 = multiDimensionMismatchException23.getExpectedDimensions();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException4, localizable8, (java.lang.Object[]) intArray25);
        org.apache.commons.math3.exception.util.Localizable localizable27 = null;
        java.lang.Integer[] intArray34 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray40 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException41 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable27, intArray34, intArray40);
        java.lang.Integer[] intArray42 = multiDimensionMismatchException41.getExpectedDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException43 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray25, intArray42);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 47.490658503988655d + "'", double5 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 47.490658503988655d + "'", double6 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 47.490658503988655d + "'", double7 == 47.490658503988655d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        double[] doubleArray9 = arrayRealVector8.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, 0.0d, (double) 32, 1.0d, (double) 100L);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.scale(7.896296018267969E13d, doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        double double4 = brentOptimizer3.getMin();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = brentOptimizer3.getGoalType();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(goalType5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) 0.0f);
        double[] doubleArray25 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray25, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair29 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair28);
        double[] doubleArray30 = doubleArrayPair29.getKey();
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray30);
        double[] doubleArray37 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix39, (double) (short) 0);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray43 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray45 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray45, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess49 = new org.apache.commons.math3.optim.InitialGuess(doubleArray45);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray45);
        double double51 = org.apache.commons.math3.util.MathArrays.distance(doubleArray31, doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, doubleArray31);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        double[] doubleArray64 = arrayRealVector63.getDataRef();
        java.lang.Double[] doubleArray73 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        java.lang.Double[] doubleArray81 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray81);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector74.append(arrayRealVector82);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector74.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = arrayRealVector63.combine((double) (short) -1, (double) (byte) -1, realVector85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector53.combine(0.0d, (double) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double89 = arrayRealVector88.getNorm();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = arrayRealVector86.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 153.22214567148168d + "'", double51 == 153.22214567148168d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(arrayRealVector86);
        org.junit.Assert.assertNotNull(arrayRealVector87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector34.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector7.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        java.lang.Double[] doubleArray72 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector65.append(arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector73.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector46.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector79, false);
        double[] doubleArray82 = arrayRealVector79.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair6 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair5);
        double[] doubleArray7 = doubleArrayPair6.getKey();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, false);
        try {
            double double13 = diagonalMatrix10.getEntry(2147483647, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        float float1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, 0.0d, (double) 32, 1.0d, (double) 100L);
        double[] doubleArray15 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray21 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair25 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair24);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction26 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction27 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction26);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction28 = modelFunction27.getModelFunction();
        boolean boolean29 = doubleArrayPair25.equals((java.lang.Object) multivariateVectorFunction28);
        double[] doubleArray30 = doubleArrayPair25.getFirst();
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray30);
        try {
            nelderMeadSimplex13.build(doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNull(multivariateVectorFunction28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        long long6 = mersenneTwister4.nextLong(10L);
        boolean boolean7 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-1), 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = nonSquareMatrixException2.getContext();
        int int4 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = eigenDecomposition9.hasComplexEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = eigenDecomposition9.getD();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector18.append(arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector18.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector7.combine((double) (short) -1, (double) (byte) -1, realVector29);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor31 = null;
        try {
            double double34 = arrayRealVector7.walkInOptimizedOrder(realVectorPreservingVisitor31, (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) 0.0f);
        boolean boolean24 = pointValuePair22.equals((java.lang.Object) (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10.0f, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        double[] doubleArray6 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess10 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair17 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair16);
        double[] doubleArray18 = doubleArrayPair17.getKey();
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        int int21 = org.apache.commons.math3.util.MathUtils.hash(doubleArray18);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray6, doubleArray18);
        double[] doubleArray23 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray22, doubleArray23);
        double[] doubleArray25 = pointVectorValuePair24.getValue();
        double[] doubleArray26 = pointVectorValuePair24.getValue();
        double[] doubleArray28 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess32 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray35 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair39 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair38);
        double[] doubleArray40 = doubleArrayPair39.getKey();
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray40);
        org.apache.commons.math3.linear.RealVector realVector42 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        int int43 = org.apache.commons.math3.util.MathUtils.hash(doubleArray40);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray28, doubleArray40);
        double[] doubleArray45 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair46 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray44, doubleArray45);
        double[] doubleArray47 = pointVectorValuePair46.getValue();
        double[] doubleArray48 = pointVectorValuePair46.getValue();
        double[] doubleArray49 = pointVectorValuePair46.getValue();
        double[] doubleArray50 = pointVectorValuePair46.getValueRef();
        try {
            boolean boolean51 = simpleVectorValueChecker2.converged((int) (byte) 1, pointVectorValuePair24, pointVectorValuePair46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074790369) + "'", int21 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNull(doubleArray25);
        org.junit.Assert.assertNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1074790369) + "'", int43 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNull(doubleArray47);
        org.junit.Assert.assertNull(doubleArray48);
        org.junit.Assert.assertNull(doubleArray49);
        org.junit.Assert.assertNull(doubleArray50);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        double double4 = brentOptimizer3.getMin();
        double double5 = brentOptimizer3.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.InitialGuess initialGuess21 = new org.apache.commons.math3.optim.InitialGuess(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            boolean boolean2 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix0, (double) 50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double double39 = diagonalMatrix37.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor40 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double41 = diagonalMatrix37.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor40);
        double[] doubleArray42 = diagonalMatrix37.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 47.490658503988655d + "'", double39 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int[] intArray8 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        long long11 = mersenneTwister9.nextLong(10L);
        int[] intArray12 = null;
        mersenneTwister9.setSeed(intArray12);
        mersenneTwister9.setSeed(100L);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula17 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker18 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver19 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner20 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer21 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, pointValuePairConvergenceChecker18, univariateSolver19, preconditioner20);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker22 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer23 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, pointValuePairConvergenceChecker22);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker26 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer27 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker26);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula28 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver30 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner31 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer32 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula28, pointValuePairConvergenceChecker29, univariateSolver30, preconditioner31);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker33 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer34 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula28, pointValuePairConvergenceChecker33);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker37 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer38 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula28, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer39 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer40 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(6, 0.0d, true, (int) (byte) 100, (int) '#', (org.apache.commons.math3.random.RandomGenerator) mersenneTwister9, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        java.util.List<java.lang.Double> doubleList41 = cMAESOptimizer40.getStatisticsFitnessHistory();
        double[] doubleArray47 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition51 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49, (double) (short) 0);
        boolean boolean52 = eigenDecomposition51.hasComplexEigenvalues();
        org.apache.commons.math3.exception.util.Localizable localizable53 = null;
        org.apache.commons.math3.exception.util.Localizable localizable54 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType55 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType56 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType57 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType58 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType59 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType60 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray61 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType55, goalType56, goalType57, goalType58, goalType59, goalType60 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection62 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray61, orderDirection62, true);
        org.apache.commons.math3.exception.ConvergenceException convergenceException65 = new org.apache.commons.math3.exception.ConvergenceException(localizable54, (java.lang.Object[]) goalTypeArray61);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) boolean52, localizable53, (java.lang.Object[]) goalTypeArray61);
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair67 = cMAESOptimizer40.optimize((org.apache.commons.math3.optim.OptimizationData[]) goalTypeArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertTrue("'" + formula17 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula17.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula28 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula28.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(doubleList41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + goalType55 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType55.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType56 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType56.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType57 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType57.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType58 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType58.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType59 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType59.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType60 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType60.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray61);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection62.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapMultiplyToSelf(0.0d);
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, (double) 10.0f, (double) (-260124651757769029L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        java.lang.String str3 = blockRealMatrix2.toString();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = diagonalMatrix7.scalarAdd(1.9155040003582885E22d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 19,155,040,003,582,885,000,000 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker5);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker9 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker9);
        int int11 = nonLinearConjugateGradientOptimizer10.getEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition15 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x35) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        int int10 = diagonalMatrix7.getColumnDimension();
        double[] doubleArray12 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12);
        double[] doubleArray18 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray18);
        double[] doubleArray28 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, true);
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray18, doubleArray28);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray28, 11.0d);
        double[] doubleArray35 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray35);
        double[] doubleArray41 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair44 = new org.apache.commons.math3.optim.PointValuePair(doubleArray41, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex45 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray41);
        double[] doubleArray51 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double double54 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray41, doubleArray51);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition56 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray51, 11.0d);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds57 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray28, doubleArray35);
        double[] doubleArray58 = diagonalMatrix7.preMultiply(doubleArray28);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor59 = null;
        try {
            double double60 = diagonalMatrix7.walkInRowOrder(realMatrixChangingVisitor59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 11.0d + "'", double31 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 11.0d + "'", double54 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        int int15 = openMapRealMatrix13.getColumnDimension();
        int int16 = openMapRealMatrix13.getColumnDimension();
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.scalarAdd((double) (byte) 0);
        double[][] doubleArray21 = diagonalMatrix18.getData();
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver23 = eigenDecomposition22.getSolver();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = eigenDecomposition22.getVT();
        double[] doubleArray25 = eigenDecomposition22.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(decompositionSolver23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.scalarAdd((double) (byte) 0);
        boolean boolean22 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) 52.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix18.transpose();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double double17 = arrayRealVector7.getMinValue();
        double double18 = arrayRealVector7.getNorm();
        double double19 = arrayRealVector7.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-10.0d) + "'", double17 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 143.22214567148168d + "'", double18 == 143.22214567148168d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.53096491487338d + "'", double19 == 101.53096491487338d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray20 = simpleBounds18.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, false);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, 3.970291913552122d);
        double[] doubleArray30 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, (double) (short) 0);
        double[] doubleArray35 = eigenDecomposition34.getRealEigenvalues();
        double[] doubleArray36 = eigenDecomposition34.getRealEigenvalues();
        double[] doubleArray38 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair41 = new org.apache.commons.math3.optim.PointValuePair(doubleArray38, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray38);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds43 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray36, doubleArray38);
        double[] doubleArray44 = simpleBounds43.getUpper();
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray45, true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray9 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType3, goalType4, goalType5, goalType6, goalType7, goalType8 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray9, orderDirection10, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 1L, (int) '#', orderDirection10, true);
        int int15 = nonMonotonicSequenceException14.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = nonMonotonicSequenceException14.getDirection();
        int int17 = nonMonotonicSequenceException14.getIndex();
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType3.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int int2 = org.apache.commons.math3.util.FastMath.max((-1074790369), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) (short) 100);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) -1, (double) 36, (double) (-100.0f), (-1.0442860327005317d));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextGaussian();
//        int[] intArray5 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
//        long long8 = mersenneTwister6.nextLong(10L);
//        byte[] byteArray12 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
//        mersenneTwister6.nextBytes(byteArray12);
//        int[] intArray17 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math3.random.MersenneTwister(intArray17);
//        long long20 = mersenneTwister18.nextLong(10L);
//        byte[] byteArray24 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
//        mersenneTwister18.nextBytes(byteArray24);
//        mersenneTwister6.nextBytes(byteArray24);
//        mersenneTwister0.nextBytes(byteArray24);
//        int[] intArray31 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister32 = new org.apache.commons.math3.random.MersenneTwister(intArray31);
//        int[] intArray36 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister37 = new org.apache.commons.math3.random.MersenneTwister(intArray36);
//        long long39 = mersenneTwister37.nextLong(10L);
//        byte[] byteArray43 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
//        mersenneTwister37.nextBytes(byteArray43);
//        int[] intArray48 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister49 = new org.apache.commons.math3.random.MersenneTwister(intArray48);
//        long long51 = mersenneTwister49.nextLong(10L);
//        byte[] byteArray55 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
//        mersenneTwister49.nextBytes(byteArray55);
//        mersenneTwister37.nextBytes(byteArray55);
//        mersenneTwister32.nextBytes(byteArray55);
//        mersenneTwister0.nextBytes(byteArray55);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3498688633518105d + "'", double1 == 0.3498688633518105d);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9L + "'", long20 == 9L);
//        org.junit.Assert.assertNotNull(byteArray24);
//        org.junit.Assert.assertNotNull(intArray31);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9L + "'", long39 == 9L);
//        org.junit.Assert.assertNotNull(byteArray43);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9L + "'", long51 == 9L);
//        org.junit.Assert.assertNotNull(byteArray55);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray3 = new double[] { 100L, 0.0f, (-1074790400) };
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray3, (java.lang.Double) 47.490658503988655d);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = weight6.getWeight();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = weight6.getWeight();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType2 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray8 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType2, goalType3, goalType4, goalType5, goalType6, goalType7 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray8, orderDirection9, true);
        org.apache.commons.math3.exception.ConvergenceException convergenceException12 = new org.apache.commons.math3.exception.ConvergenceException(localizable1, (java.lang.Object[]) goalTypeArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) goalTypeArray8);
        org.junit.Assert.assertTrue("'" + goalType2 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType2.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType3.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray8 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray15 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray22 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray29 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray36 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray43 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException46 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1.0E-5d, (java.lang.Object[]) doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 10, (java.lang.Number) (-1.0f), (java.lang.Number) 10);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0f) + "'", number7.equals((-1.0f)));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int[] intArray8 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        long long11 = mersenneTwister9.nextLong(10L);
        int[] intArray12 = null;
        mersenneTwister9.setSeed(intArray12);
        mersenneTwister9.setSeed(100L);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula17 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker18 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver19 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner20 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer21 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, pointValuePairConvergenceChecker18, univariateSolver19, preconditioner20);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker22 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer23 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, pointValuePairConvergenceChecker22);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker24 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer25 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, pointValuePairConvergenceChecker24);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula26 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker27 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver28 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner29 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer30 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula26, pointValuePairConvergenceChecker27, univariateSolver28, preconditioner29);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker31 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer32 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula26, pointValuePairConvergenceChecker31);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker35 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer36 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula26, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker35);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula37 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker38 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver39 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner40 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer41 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula37, pointValuePairConvergenceChecker38, univariateSolver39, preconditioner40);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker42 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer43 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula37, pointValuePairConvergenceChecker42);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker46 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer47 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula37, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker46);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer48 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula26, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker46);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver51 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double52 = brentSolver51.getFunctionValueAccuracy();
        int int53 = brentSolver51.getEvaluations();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner54 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer55 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker46, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver51, preconditioner54);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer56 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(5, 4.641588833612779d, false, 1864881824, (int) '4', (org.apache.commons.math3.random.RandomGenerator) mersenneTwister9, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker46);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertTrue("'" + formula17 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula17.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula26 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula26.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula37 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula37.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0E-15d + "'", double52 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(9.589560061550897E7d, (double) 'a');
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 50, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 49.99999999999999d + "'", double2 == 49.99999999999999d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 35, (-10.0d));
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.0d, 4.644483341943245d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = eigenDecomposition38.getV();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getPrefix();
        java.lang.String str3 = realMatrixFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[" + "'", str2.equals("["));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[" + "'", str3.equals("["));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction0);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction2 = objectiveFunctionGradient1.getObjectiveFunctionGradient();
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction3 = objectiveFunctionGradient1.getObjectiveFunctionGradient();
        org.junit.Assert.assertNull(multivariateVectorFunction2);
        org.junit.Assert.assertNull(multivariateVectorFunction3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        double[] doubleArray4 = blockRealMatrix2.getRow(32);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getColumnMatrix((int) (byte) -100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition47 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix45, (double) (short) 0);
        double[] doubleArray53 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix55 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray53, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = diagonalMatrix45.add(diagonalMatrix55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = diagonalMatrix26.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56);
        double double58 = diagonalMatrix56.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor59 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double60 = diagonalMatrix56.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        double double61 = diagonalMatrix17.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        java.lang.Class<?> wildcardClass62 = diagonalMatrix17.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(diagonalMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 47.490658503988655d + "'", double58 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray8 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair11);
        double[] doubleArray13 = doubleArrayPair12.getKey();
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray13);
        double[] doubleArray18 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074790369) + "'", int16 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray14);
        java.lang.Integer[] intArray16 = multiDimensionMismatchException15.getExpectedDimensions();
        java.lang.Integer[] intArray17 = multiDimensionMismatchException15.getExpectedDimensions();
        org.apache.commons.math3.exception.ConvergenceException convergenceException18 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) intArray17);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 10, 0.0f, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor41 = null;
        try {
            double double42 = array2DRowRealMatrix39.walkInColumnOrder(realMatrixChangingVisitor41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1L), 1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray8 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair11);
        double[] doubleArray13 = doubleArrayPair12.getKey();
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray13);
        double[] doubleArray18 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getValue();
        double[] doubleArray21 = pointVectorValuePair19.getValue();
        java.lang.Object obj22 = null;
        boolean boolean23 = pointVectorValuePair19.equals(obj22);
        double[] doubleArray24 = pointVectorValuePair19.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074790369) + "'", int16 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNull(doubleArray20);
        org.junit.Assert.assertNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(doubleArray24);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math3.util.FastMath.rint(5.260239166121122E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.260239166E9d + "'", double1 == 5.260239166E9d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, 0.0d, (double) 32, 1.0d, (double) 100L);
        double[] doubleArray20 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix22, (double) (short) 0);
        double[] doubleArray25 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray26 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray28 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess32 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds33 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray26, doubleArray28);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray26);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition35 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray8, doubleArray34);
        try {
            org.apache.commons.math3.linear.RealVector realVector37 = eigenDecomposition35.getEigenvector((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector34.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector7.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        java.lang.Double[] doubleArray72 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector65.append(arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector73.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector46.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        java.lang.Double[] doubleArray85 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray85);
        java.lang.Double[] doubleArray93 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray93);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector86.append(arrayRealVector94);
        double double96 = arrayRealVector86.getMinValue();
        double double97 = arrayRealVector86.getNorm();
        double double98 = arrayRealVector77.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        double[] doubleArray99 = arrayRealVector77.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(arrayRealVector95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + (-10.0d) + "'", double96 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 143.22214567148168d + "'", double97 == 143.22214567148168d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 5299.219389844822d + "'", double98 == 5299.219389844822d);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction0);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction2 = modelFunction1.getModelFunction();
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction3 = modelFunction1.getModelFunction();
        org.junit.Assert.assertNull(multivariateVectorFunction2);
        org.junit.Assert.assertNull(multivariateVectorFunction3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double3 = brentSolver2.getFunctionValueAccuracy();
        double double4 = brentSolver2.getMax();
        int int5 = brentSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(1.58601345231343E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(100, (int) (byte) 100);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector11.append(arrayRealVector19);
        double double21 = arrayRealVector11.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector11.mapMultiply(0.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = realVector23.mapSubtract((double) 1L);
        java.lang.String str26 = realVectorFormat3.format(realVector25);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix2, realVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-10.0d) + "'", double21 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{-1; -1; -1; -1; -1; -1}" + "'", str26.equals("{-1; -1; -1; -1; -1; -1}"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19, (double) (short) 0);
        double[] doubleArray27 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = diagonalMatrix19.add(diagonalMatrix29);
        double[] doubleArray36 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition40 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix38, (double) (short) 0);
        double[] doubleArray46 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = diagonalMatrix38.add(diagonalMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix19.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        double double51 = diagonalMatrix49.getTrace();
        int int52 = diagonalMatrix49.getRowDimension();
        int int53 = diagonalMatrix49.getColumnDimension();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = diagonalMatrix7.add(diagonalMatrix49);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        java.lang.Double[] doubleArray70 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector63.append(arrayRealVector71);
        java.lang.Double[] doubleArray81 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray81);
        java.lang.Double[] doubleArray89 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray89);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = arrayRealVector82.append(arrayRealVector90);
        org.apache.commons.math3.linear.RealVector realVector93 = arrayRealVector90.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = arrayRealVector63.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector90);
        boolean boolean95 = arrayRealVector63.isNaN();
        double double96 = arrayRealVector63.getMinValue();
        try {
            diagonalMatrix54.setRowVector(50, (org.apache.commons.math3.linear.RealVector) arrayRealVector63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(diagonalMatrix30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(diagonalMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 47.490658503988655d + "'", double51 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 5 + "'", int52 == 5);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5 + "'", int53 == 5);
        org.junit.Assert.assertNotNull(diagonalMatrix54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(arrayRealVector91);
        org.junit.Assert.assertNotNull(realVector93);
        org.junit.Assert.assertNotNull(arrayRealVector94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + (-10.0d) + "'", double96 == (-10.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(32, 36.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 1, (double) 1864881824);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix8, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix15, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix15);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix19 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix15);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix12.subtract(openMapRealMatrix19);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.add(openMapRealMatrix19);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix24 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int25 = openMapRealMatrix24.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix24);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix21.subtract(openMapRealMatrix26);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector17.append(arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector25.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.analysis.function.Sinc sinc33 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double35 = sinc33.value(1.2339186085744818d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector9.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc33);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.7648732279940101d + "'", double35 == 0.7648732279940101d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 6, (-5.373951845E8d), 32.0d, 0.0d, 1.58601345231343E15d, 0.3498688633518105d, (double) (-1.0f), 7.68825475E7d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.548934225679262E14d + "'", double8 == 5.548934225679262E14d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getHi();
        int int3 = bracketFinder0.getEvaluations();
        int int4 = bracketFinder0.getEvaluations();
        double double5 = bracketFinder0.getMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        long long6 = mersenneTwister4.nextLong(10L);
        mersenneTwister4.clear();
        boolean boolean8 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix48 = array2DRowRealMatrix43.getSubMatrix(0, 32, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) 0.0f);
        double[] doubleArray25 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray25, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair29 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair28);
        double[] doubleArray30 = doubleArrayPair29.getKey();
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray30);
        double[] doubleArray37 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix39, (double) (short) 0);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray43 = eigenDecomposition41.getRealEigenvalues();
        double[] doubleArray45 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray45, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess49 = new org.apache.commons.math3.optim.InitialGuess(doubleArray45);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray45);
        double double51 = org.apache.commons.math3.util.MathArrays.distance(doubleArray31, doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, doubleArray31);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        double[] doubleArray64 = arrayRealVector63.getDataRef();
        java.lang.Double[] doubleArray73 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        java.lang.Double[] doubleArray81 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray81);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector74.append(arrayRealVector82);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector74.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = arrayRealVector63.combine((double) (short) -1, (double) (byte) -1, realVector85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector53.combine(0.0d, (double) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        double double88 = arrayRealVector87.getMaxValue();
        int int89 = arrayRealVector87.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 153.22214567148168d + "'", double51 == 153.22214567148168d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(arrayRealVector86);
        org.junit.Assert.assertNotNull(arrayRealVector87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 10.3125d + "'", double88 == 10.3125d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 4 + "'", int89 == 4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner4 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, pointValuePairConvergenceChecker2, univariateSolver3, preconditioner4);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker6 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, pointValuePairConvergenceChecker6);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula12 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker13 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver14 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner15 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer16 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula12, pointValuePairConvergenceChecker13, univariateSolver14, preconditioner15);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker17 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer18 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula12, pointValuePairConvergenceChecker17);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula12, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer23 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver26 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double27 = brentSolver26.getFunctionValueAccuracy();
        double double28 = brentSolver26.getStartValue();
        double double29 = brentSolver26.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner30 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer31 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver26, preconditioner30);
        double[] doubleArray32 = nonLinearConjugateGradientOptimizer31.getUpperBound();
        org.junit.Assert.assertTrue("'" + formula1 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula1.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula12 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula12.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0E-15d + "'", double27 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNull(doubleArray32);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector17.append(arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector25.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double double32 = arrayRealVector31.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3655.1147369354417d + "'", double32 == 3655.1147369354417d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = blockRealMatrix49.scalarAdd((double) (-614277696));
        double double54 = blockRealMatrix49.getFrobeniusNorm();
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        double[] doubleArray64 = arrayRealVector63.getDataRef();
        double double65 = arrayRealVector63.getMinValue();
        double double66 = arrayRealVector63.getLInfNorm();
        try {
            blockRealMatrix49.setColumnVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 5.260239166121122E9d + "'", double54 == 5.260239166121122E9d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-10.0d) + "'", double65 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 101.53096491487338d + "'", double66 == 101.53096491487338d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math3.optim.MaxEval maxEval0 = org.apache.commons.math3.optim.MaxEval.unlimited();
        int int1 = maxEval0.getMaxEval();
        int int2 = maxEval0.getMaxEval();
        org.junit.Assert.assertNotNull(maxEval0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, (double) (short) 1, 1.7453292519943295d, 101.53096491487338d, objArray5);
        double double7 = noBracketingException6.getFHi();
        try {
            java.lang.String str8 = noBracketingException6.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 101.53096491487338d + "'", double7 == 101.53096491487338d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        int int40 = array2DRowRealMatrix39.getColumnDimension();
        double[][] doubleArray41 = array2DRowRealMatrix39.getDataRef();
        double[][] doubleArray42 = array2DRowRealMatrix39.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-1), 1);
        java.lang.Number number3 = nonSquareMatrixException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1) + "'", number3.equals((-1)));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextGaussian();
//        int[] intArray5 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
//        long long8 = mersenneTwister6.nextLong(10L);
//        byte[] byteArray12 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
//        mersenneTwister6.nextBytes(byteArray12);
//        int[] intArray17 = new int[] { 100, (byte) -1, (byte) 100 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math3.random.MersenneTwister(intArray17);
//        long long20 = mersenneTwister18.nextLong(10L);
//        byte[] byteArray24 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
//        mersenneTwister18.nextBytes(byteArray24);
//        mersenneTwister6.nextBytes(byteArray24);
//        mersenneTwister0.nextBytes(byteArray24);
//        boolean boolean28 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11350790814140313d) + "'", double1 == (-0.11350790814140313d));
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9L + "'", long20 == 9L);
//        org.junit.Assert.assertNotNull(byteArray24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double3 = brentSolver2.getFunctionValueAccuracy();
        int int4 = brentSolver2.getEvaluations();
        double double5 = brentSolver2.getMin();
        double double6 = brentSolver2.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math3.util.FastMath.cos(1.3400289243906618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22872465026558655d + "'", double1 == 0.22872465026558655d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix7, 5, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        int int6 = nelderMeadSimplex5.getDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 1);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition9 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(1.5860134523134295E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.69314718055995d + "'", double1 == 35.69314718055995d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double[] doubleArray7 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix9, (double) (short) 0);
        double[] doubleArray12 = eigenDecomposition11.getRealEigenvalues();
        double[] doubleArray13 = eigenDecomposition11.getRealEigenvalues();
        double[] doubleArray15 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds20 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray15);
        double[] doubleArray26 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition30 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix28, (double) (short) 0);
        double[] doubleArray31 = eigenDecomposition30.getRealEigenvalues();
        double[] doubleArray32 = eigenDecomposition30.getRealEigenvalues();
        double[] doubleArray34 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray34, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds39 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray32, doubleArray34);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition40 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray15, doubleArray34);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray42 = array2DRowRealMatrix41.getData();
        double[][] doubleArray43 = array2DRowRealMatrix41.getDataRef();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(5, (-1074790400), doubleArray43, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,074,790,400 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray1, (-0.9999999999999999d), (double) (-1L));
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, 1.1102230246251565E-16d, true);
        double[] doubleArray16 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) (short) 0);
        int int21 = diagonalMatrix18.getColumnDimension();
        double[] doubleArray23 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair26 = new org.apache.commons.math3.optim.PointValuePair(doubleArray23, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray23);
        double[] doubleArray29 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex33 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray29);
        double[] doubleArray39 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        double double42 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray29, doubleArray39);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray23, doubleArray39, 11.0d);
        double[] doubleArray46 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray46, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex50 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray46);
        double[] doubleArray52 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair55 = new org.apache.commons.math3.optim.PointValuePair(doubleArray52, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex56 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray52);
        double[] doubleArray62 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix64 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray62, true);
        double double65 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray52, doubleArray62);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition67 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray46, doubleArray62, 11.0d);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds68 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray39, doubleArray46);
        double[] doubleArray69 = diagonalMatrix18.preMultiply(doubleArray39);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair70 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 11.0d + "'", double42 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 11.0d + "'", double65 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver(9.148345846451205E150d, 7.0710678118654755d, 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        double double3 = blockRealMatrix2.getNorm();
        double[] doubleArray5 = blockRealMatrix2.getColumn(32);
        try {
            double double8 = blockRealMatrix2.getEntry(0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray13);
        java.lang.Integer[] intArray15 = multiDimensionMismatchException14.getExpectedDimensions();
        java.lang.Integer[] intArray16 = multiDimensionMismatchException14.getExpectedDimensions();
        java.lang.Integer[] intArray17 = multiDimensionMismatchException14.getWrongDimensions();
        java.lang.Throwable[] throwableArray18 = multiDimensionMismatchException14.getSuppressed();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula5 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker6 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula5, pointValuePairConvergenceChecker6, univariateSolver7, preconditioner8);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula5, pointValuePairConvergenceChecker10);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker14 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer15 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula5, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker14);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver18 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double19 = brentSolver18.getFunctionValueAccuracy();
        double double20 = brentSolver18.getMax();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner21 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker14, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver18, preconditioner21);
        double[] doubleArray25 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray25, (double) (byte) 10, false);
        double[] doubleArray29 = pointValuePair28.getKey();
        double[] doubleArray36 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition40 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix38, (double) (short) 0);
        double[] doubleArray41 = eigenDecomposition40.getRealEigenvalues();
        double[] doubleArray42 = eigenDecomposition40.getRealEigenvalues();
        double[] doubleArray44 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair47 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess48 = new org.apache.commons.math3.optim.InitialGuess(doubleArray44);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds49 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray44);
        double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray42);
        org.apache.commons.math3.optim.PointValuePair pointValuePair52 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, (double) 0.0f);
        double[] doubleArray53 = pointValuePair52.getPointRef();
        boolean boolean54 = simpleValueChecker14.converged((int) (byte) 1, pointValuePair28, pointValuePair52);
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula5.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-15d + "'", double19 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getMaxIterations();
        double double5 = brentOptimizer3.getMax();
        int int6 = brentOptimizer3.getMaxEvaluations();
        int int7 = brentOptimizer3.getMaxEvaluations();
        int int8 = brentOptimizer3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double double50 = blockRealMatrix49.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 5.260239166121122E9d + "'", double50 == 5.260239166121122E9d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.createMatrix((-614277696), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -614,277,696 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[] doubleArray43 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair47 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair46);
        double[] doubleArray48 = doubleArrayPair47.getKey();
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix39.operate(doubleArray49);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray57, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition61 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix59, (double) (short) 0);
        double[] doubleArray62 = eigenDecomposition61.getRealEigenvalues();
        double[] doubleArray63 = eigenDecomposition61.getRealEigenvalues();
        double[] doubleArray65 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair68 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess69 = new org.apache.commons.math3.optim.InitialGuess(doubleArray65);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds70 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray63, doubleArray65);
        double[] doubleArray71 = simpleBounds70.getUpper();
        double[] doubleArray77 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix79 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray77, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition81 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix79, (double) (short) 0);
        double[] doubleArray82 = eigenDecomposition81.getRealEigenvalues();
        double[] doubleArray83 = eigenDecomposition81.getRealEigenvalues();
        double[] doubleArray85 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair88 = new org.apache.commons.math3.optim.PointValuePair(doubleArray85, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess89 = new org.apache.commons.math3.optim.InitialGuess(doubleArray85);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds90 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray83, doubleArray85);
        double[] doubleArray91 = simpleBounds90.getUpper();
        double[] doubleArray92 = simpleBounds90.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray92, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition96 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray71, doubleArray92, 2.718281828459045d);
        double[] doubleArray97 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray49, doubleArray92);
        double[] doubleArray98 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertNotNull(doubleArray98);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(5, (-6.510623880059051E-4d), (double) 5L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math3.util.FastMath.tan(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(Double.NEGATIVE_INFINITY, 0.057629502154529534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector34.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector7.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        java.lang.Double[] doubleArray72 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector65.append(arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector73.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector46.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector77, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction6 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction7 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction6);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction8 = modelFunction7.getModelFunction();
        boolean boolean9 = doubleArrayPair5.equals((java.lang.Object) multivariateVectorFunction8);
        double[] doubleArray10 = doubleArrayPair5.getFirst();
        double[] doubleArray12 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12);
        double[] doubleArray18 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray18);
        double[] doubleArray28 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, true);
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray18, doubleArray28);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray28, 11.0d);
        double[] doubleArray35 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray35);
        double[] doubleArray41 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair44 = new org.apache.commons.math3.optim.PointValuePair(doubleArray41, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex45 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray41);
        double[] doubleArray51 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double double54 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray41, doubleArray51);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition56 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray51, 11.0d);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds57 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray28, doubleArray35);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray35, (double) 35);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = eigenDecomposition59.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = eigenDecomposition59.getV();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNull(multivariateVectorFunction8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 11.0d + "'", double31 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 11.0d + "'", double54 == 11.0d);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realMatrix61);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int[] intArray8 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        long long11 = mersenneTwister9.nextLong(10L);
        int[] intArray12 = null;
        mersenneTwister9.setSeed(intArray12);
        mersenneTwister9.setSeed(100L);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula17 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker18 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver19 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner20 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer21 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, pointValuePairConvergenceChecker18, univariateSolver19, preconditioner20);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker22 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer23 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, pointValuePairConvergenceChecker22);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker26 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer27 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker26);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula28 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver30 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner31 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer32 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula28, pointValuePairConvergenceChecker29, univariateSolver30, preconditioner31);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker33 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer34 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula28, pointValuePairConvergenceChecker33);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker37 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer38 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula28, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer39 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula17, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer40 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(6, 0.0d, true, (int) (byte) 100, (int) '#', (org.apache.commons.math3.random.RandomGenerator) mersenneTwister9, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        java.util.List<java.lang.Double> doubleList41 = cMAESOptimizer40.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList42 = cMAESOptimizer40.getStatisticsMeanHistory();
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertTrue("'" + formula17 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula17.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula28 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula28.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(doubleList41);
        org.junit.Assert.assertNotNull(realMatrixList42);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector26.append(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector34.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector7.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        boolean boolean39 = arrayRealVector7.isNaN();
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector47.append(arrayRealVector55);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65);
        java.lang.Double[] doubleArray73 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector66.append(arrayRealVector74);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector74.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = arrayRealVector47.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        java.lang.Double[] doubleArray85 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray85);
        java.lang.Double[] doubleArray93 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray93);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector86.append(arrayRealVector94);
        double double96 = arrayRealVector47.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector94);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector97 = arrayRealVector7.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector99 = arrayRealVector97.mapSubtractToSelf(52.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(arrayRealVector78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(arrayRealVector95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector97);
        org.junit.Assert.assertNotNull(realVector99);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction0);
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction2 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.junit.Assert.assertNull(multivariateMatrixFunction2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = lUDecomposition40.getU();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = lUDecomposition40.getL();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix5, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix12, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = openMapRealMatrix9.subtract(openMapRealMatrix16);
        java.lang.String str18 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix16);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition19 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x35) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[" + "'", str1.equals("["));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(openMapRealMatrix17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]" + "'", str18.equals("[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray14 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray21 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray28 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray35 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray42 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray43 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28, doubleArray35, doubleArray42 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException45 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext46 = mathArithmeticException45.getContext();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(exceptionContext46);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter(10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        double[] doubleArray11 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13, (double) (short) 0);
        double[] doubleArray16 = eigenDecomposition15.getRealEigenvalues();
        double[] doubleArray17 = eigenDecomposition15.getRealEigenvalues();
        double[] doubleArray19 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess23 = new org.apache.commons.math3.optim.InitialGuess(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds24 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray17, doubleArray19);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray17);
        org.apache.commons.math3.optim.PointValuePair pointValuePair27 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) 0.0f);
        double[] doubleArray28 = pointValuePair27.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        boolean boolean41 = array2DRowRealMatrix39.isTransposable();
        double[] doubleArray43 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess47 = new org.apache.commons.math3.optim.InitialGuess(doubleArray43);
        double[] doubleArray49 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair52 = new org.apache.commons.math3.optim.PointValuePair(doubleArray49, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair53 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair52);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction54 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction55 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction54);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction56 = modelFunction55.getModelFunction();
        boolean boolean57 = doubleArrayPair53.equals((java.lang.Object) multivariateVectorFunction56);
        double[] doubleArray58 = doubleArrayPair53.getFirst();
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray43, doubleArray58);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) doubleArray59);
        double[] doubleArray61 = array2DRowRealMatrix39.preMultiply(doubleArray59);
        double double62 = array2DRowRealMatrix39.getNorm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNull(multivariateVectorFunction56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str10 = realMatrixFormat9.getPrefix();
        java.text.NumberFormat numberFormat11 = realMatrixFormat9.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "[", "", numberFormat11);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat13 = new org.apache.commons.math3.linear.RealMatrixFormat("{", "{-1; -1; -1; -1; -1; -1}", "hi!", "hi!", "}", "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]", numberFormat11);
        org.junit.Assert.assertNotNull(realMatrixFormat9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[" + "'", str10.equals("["));
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("{-1; -1; -1; -1; -1; -1}", 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double double17 = arrayRealVector7.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector7.mapMultiply(0.0d);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector27.append(arrayRealVector35);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector46.append(arrayRealVector54);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector54.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector27.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65);
        java.lang.Double[] doubleArray73 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector66.append(arrayRealVector74);
        double double76 = arrayRealVector27.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.RealVector realVector77 = realVector19.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-10.0d) + "'", double17 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(realVector77);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 0);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(36, 100);
        double[] doubleArray4 = blockRealMatrix2.getRow(32);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair11 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair10);
        double[] doubleArray12 = doubleArrayPair11.getKey();
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray12);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12, false);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 36x100 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix8, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix15, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix15);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix19 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix15);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix12.subtract(openMapRealMatrix19);
        double[] doubleArray26 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition30 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix28, (double) (short) 0);
        double[] doubleArray36 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix28.add(diagonalMatrix38);
        double[] doubleArray45 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray45, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix47, (double) (short) 0);
        double[] doubleArray55 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = diagonalMatrix47.add(diagonalMatrix57);
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = diagonalMatrix28.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix58);
        double double60 = diagonalMatrix58.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor61 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double62 = diagonalMatrix58.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor61);
        defaultRealMatrixPreservingVisitor61.start(32, 0, 5, 36, (int) (short) 100, 36);
        double double70 = openMapRealMatrix12.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor61);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix71 = openMapRealMatrix5.add(openMapRealMatrix12);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(diagonalMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 47.490658503988655d + "'", double60 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix71);
    }
}

