import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double[] doubleArray5 = new double[] { 0.0f, '4', 100, 100.0f, 0.0f };
        double[] doubleArray6 = null;
        try {
            double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray5, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3, 1, (-1), 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (byte) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double[] doubleArray5 = new double[] { 0L, (short) 100, 100.0d, 10L, 10.0d };
        double[] doubleArray9 = new double[] { (short) 0, (-1), 10.0f };
        try {
            double double10 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.RealVector realVector3 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector4 = openMapRealMatrix2.operate(realVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter((int) ' ');
        int int2 = maxIter1.getMaxIter();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 1.0f, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.53096491487338d + "'", double2 == 101.53096491487338d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, (int) (byte) 1, 0, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor5, 1, (int) (short) 10, 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.RealVector realVector6 = null;
        try {
            openMapRealMatrix2.setRowVector(0, realVector6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int2 = org.apache.commons.math3.util.FastMath.min((-1), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.0d, (double) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 10L, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.0d) + "'", double2 == (-10.0d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2, (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x35) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        try {
            openMapRealMatrix2.multiplyEntry((int) (byte) 100, 32, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { 0, (short) 0, (byte) 100, (short) 0 };
        try {
            int int6 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 10.0d, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        try {
            openMapRealMatrix2.setEntry(36, (-1), (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double[] doubleArray1 = new double[] { 1.0d };
        double[] doubleArray3 = new double[] { 1.0d };
        double[] doubleArray5 = new double[] { 1.0d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (short) 100, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) ' ', "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) -1, 1.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) maxIter0);
        org.junit.Assert.assertNotNull(maxIter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int[] intArray3 = null;
        int[] intArray4 = new int[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray6, doubleArray7 };
        try {
            openMapRealMatrix2.copySubMatrix(intArray3, intArray4, doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector24.append(arrayRealVector32);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector16.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 12 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(arrayRealVector33);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((-10.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 32, (double) 1L, 0.0d, (double) (byte) 1, 0.0d, (-10.0d), (double) 0.0f, (double) 1L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        try {
            double double12 = diagonalMatrix7.getEntry((int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (-1.0f), (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) ' ', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition3 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x35) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(32.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (short) 1, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor17 = null;
        try {
            double double18 = arrayRealVector7.walkInOptimizedOrder(realVectorPreservingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        double[] doubleArray10 = new double[] { 1.7453292519943295d, (byte) 100, (short) 1 };
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        try {
            openMapRealMatrix2.copySubMatrix(0, 1, (int) '#', (int) (byte) 0, doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = diagonalMatrix7.walkInRowOrder(realMatrixPreservingVisitor10, (int) (short) 1, (int) (short) -1, (int) (short) 10, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor1, 100, (int) (short) 1, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.1102230246251565E-16d, (double) (-1), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor8 = null;
        try {
            double double9 = arrayRealVector7.walkInOptimizedOrder(realVectorPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1, (int) 'a', (int) (byte) 10, (-1), 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getRowDimension();
        try {
            double[] doubleArray3 = array2DRowRealMatrix0.getColumn(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 35, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        try {
            diagonalMatrix17.setRow((int) (byte) 10, doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray0, doubleArray1, doubleArray2 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathInternalError0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray14);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray14);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (byte) 10, (double) 100L, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException3 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, localizable1, objArray2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix37, (int) (short) -1, (int) 'a', 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        try {
            openMapRealMatrix2.addToEntry((int) '4', (int) 'a', 1.1102230246251565E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-1.0d), (double) (short) 100, 100.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (short) 0, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math3.util.FastMath.min(100.0d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            double[] doubleArray13 = array2DRowRealMatrix11.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 35, (-10.0d));
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair4 = null;
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair5 = null;
        try {
            boolean boolean6 = simpleUnivariateValueChecker2.converged((int) (short) 0, univariatePointValuePair4, univariatePointValuePair5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 36, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.148345846451205E150d + "'", double2 == 9.148345846451205E150d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 1.0f, (double) '#', 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector16.append(arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.mapDivideToSelf(32.0d);
        arrayRealVector7.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction29 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector16.map(univariateFunction29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix1 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            array2DRowRealMatrix11.multiplyEntry((int) 'a', (int) ' ', (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double[] doubleArray4 = new double[] { 'a', 0.0f, (short) 10, 100.0f };
        double[] doubleArray9 = new double[] { 'a', 0.0f, (short) 10, 100.0f };
        double[] doubleArray14 = new double[] { 'a', 0.0f, (short) 10, 100.0f };
        double[] doubleArray19 = new double[] { 'a', 0.0f, (short) 10, 100.0f };
        double[] doubleArray24 = new double[] { 'a', 0.0f, (short) 10, 100.0f };
        double[] doubleArray29 = new double[] { 'a', 0.0f, (short) 10, 100.0f };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        int int3 = nonLinearConjugateGradientOptimizer2.getMaxIterations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) '4', (-10.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.0d) + "'", double2 == (-10.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor19 = null;
        try {
            double double20 = arrayRealVector7.walkInOptimizedOrder(realVectorPreservingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        try {
            boolean boolean4 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection1.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(101.53096491487338d, (double) (byte) 0, 101.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, (double) (short) 100, (double) (byte) 100, (-0.9999999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException(number0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double[] doubleArray17 = arrayRealVector16.toArray();
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector27.append(arrayRealVector35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector27.mapDivideToSelf(32.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector16.combine((double) (short) 1, (double) 32, realVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 12 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor17 = null;
        try {
            double double20 = arrayRealVector16.walkInDefaultOrder(realVectorPreservingVisitor17, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double[] doubleArray41 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair44 = new org.apache.commons.math3.optim.PointValuePair(doubleArray41, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex45 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray41);
        double[] doubleArray51 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double double54 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray41, doubleArray51);
        try {
            diagonalMatrix37.setRow(32, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 11.0d + "'", double54 == 11.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray13 = new double[] { (byte) 10, 0.0d, 1.7453292519943295d, '4' };
        try {
            double[] doubleArray14 = diagonalMatrix7.preMultiply(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math3.linear.SingularMatrixException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = singularMatrixException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7249165551445564d) + "'", double1 == (-0.7249165551445564d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (short) 100, (double) (byte) 1, (-10.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray13);
        try {
            int int16 = multiDimensionMismatchException14.getWrongDimension((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double[] doubleArray6 = new double[] { 100.0f, '4', (-10.0d), (-0.7249165551445564d), (-1), ' ' };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray7, 9.148345846451205E150d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double double17 = arrayRealVector7.getMinValue();
        arrayRealVector7.set((double) 10.0f);
        java.io.ObjectOutputStream objectOutputStream20 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, objectOutputStream20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-10.0d) + "'", double17 == (-10.0d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence(11.0d, 1.7453292519943295d, 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10.0f, (double) 0L, 11.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13);
        double[] doubleArray23 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double double26 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray13, doubleArray23);
        try {
            double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray11, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 11.0d + "'", double26 == 11.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int3 = openMapRealMatrix2.getColumnDimension();
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.createMatrix(32, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray27 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray32 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray33 = new double[][] { doubleArray27, doubleArray32 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        try {
            diagonalMatrix18.copySubMatrix((int) (byte) 0, 0, (int) (short) 100, 32, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", "", "", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", "");
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (short) 10, 9L, 101.53096491487338d, (-1), (short) -1 };
        try {
            array2DRowRealMatrix0.setColumn(0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.text.NumberFormat numberFormat0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        java.lang.Double[] doubleArray55 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55);
        java.lang.Double[] doubleArray63 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector56.append(arrayRealVector64);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector56.mapDivideToSelf(32.0d);
        arrayRealVector47.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        try {
            diagonalMatrix7.setColumnVector((int) (byte) 10, (org.apache.commons.math3.linear.RealVector) arrayRealVector47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(realVector67);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = diagonalMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor19, 1, 0, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.append(arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double[] doubleArray17 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor18 = null;
        try {
            double double21 = arrayRealVector16.walkInOptimizedOrder(realVectorChangingVisitor18, (int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 2147483647, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(10.0d, (-0.9999999999999999d), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor44 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double49 = array2DRowRealMatrix43.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44, (int) (byte) 10, (int) (short) 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(10.0d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(6.283185307179586d, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179587d + "'", double2 == 6.283185307179587d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor17 = null;
        try {
            double double18 = arrayRealVector7.walkInDefaultOrder(realVectorChangingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        java.lang.Double[] doubleArray43 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector36.append(arrayRealVector44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector36.mapDivideToSelf(32.0d);
        arrayRealVector27.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        try {
            diagonalMatrix18.setColumnVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x1 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector47);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        diagonalMatrix7.setEntry(35, (int) (byte) 1, (double) (byte) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix7.getRowMatrix((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor40 = null;
        try {
            double double45 = array2DRowRealMatrix39.walkInRowOrder(realMatrixChangingVisitor40, (int) ' ', (int) (short) 100, (-1), 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '4', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix7, 1);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.multiply(openMapRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(11.0d, (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        double[] doubleArray10 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition14 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12, (double) (short) 0);
        double[] doubleArray20 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = diagonalMatrix12.add(diagonalMatrix22);
        diagonalMatrix12.setEntry(35, (int) (byte) 1, (double) (byte) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = openMapRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x35 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(diagonalMatrix23);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = array2DRowRealMatrix11.walkInColumnOrder(realMatrixChangingVisitor12, (int) (short) -1, (int) (short) 100, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        try {
            array2DRowRealMatrix39.setEntry((int) (short) -1, (int) 'a', (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double2 = org.apache.commons.math3.util.Precision.round(2.718281828459045d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7182818285d + "'", double2 == 2.7182818285d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor1, 0, 36, 36, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 35, (-10.0d));
        double double3 = simpleUnivariateValueChecker2.getRelativeThreshold();
        double double4 = simpleUnivariateValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-10.0d) + "'", double4 == (-10.0d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) (short) 0, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999998d) + "'", double1 == (-0.9999999999999998d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray21 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair25 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair24);
        double[] doubleArray26 = doubleArrayPair25.getKey();
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray26);
        try {
            double[] doubleArray28 = diagonalMatrix17.preMultiply(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0L, (double) 100L, (double) (short) 100, (double) '4', (double) 9L, 2.2250738585072014E-308d, 0.0d, (double) 35);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5200.0d + "'", double8 == 5200.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) intArray14);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        boolean boolean39 = eigenDecomposition38.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) '4', (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair6 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair5);
        double[] doubleArray7 = doubleArrayPair6.getKey();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray7);
        double[] doubleArray11 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair15 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair14);
        double[] doubleArray16 = doubleArrayPair15.getKey();
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray16);
        double[] doubleArray23 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition27 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix25, (double) (short) 0);
        double[] doubleArray28 = eigenDecomposition27.getRealEigenvalues();
        double[] doubleArray29 = eigenDecomposition27.getRealEigenvalues();
        double[] doubleArray31 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess35 = new org.apache.commons.math3.optim.InitialGuess(doubleArray31);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds36 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray29, doubleArray31);
        double double37 = org.apache.commons.math3.util.MathArrays.distance(doubleArray17, doubleArray29);
        try {
            double double38 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray8, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 153.22214567148168d + "'", double37 == 153.22214567148168d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 10, 10.0f, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getNorm();
        double double2 = arrayRealVector0.getMinValue();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor3 = null;
        try {
            double double4 = arrayRealVector0.walkInOptimizedOrder(realVectorChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        double[] doubleArray21 = new double[] {};
        try {
            double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray12, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing(univariateFunction0, (double) (byte) 100, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = openMapRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, (double) (short) -1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (-1L), 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        try {
            double double53 = diagonalMatrix50.getEntry(36, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 101.53096491487338d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray1);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) nullArgumentException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector16.map(univariateFunction17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(7.896296018267969E13d, (-10.0d), 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (byte) 10, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(1.7453292519943295d, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1.745 is larger than, or equal to, the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor9 = null;
        try {
            double double12 = arrayRealVector7.walkInOptimizedOrder(realVectorChangingVisitor9, 52, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double[] doubleArray17 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor45 = null;
        try {
            double double46 = array2DRowRealMatrix43.walkInRowOrder(realMatrixChangingVisitor45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) ' ', (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection0 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.junit.Assert.assertTrue("'" + orderDirection0 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection0.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 32, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        long long6 = mersenneTwister4.nextLong(10L);
        byte[] byteArray10 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
        mersenneTwister4.nextBytes(byteArray10);
        double double12 = mersenneTwister4.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9967368836335428d + "'", double12 == 0.9967368836335428d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.scalarAdd((double) (byte) 0);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector28.append(arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector28.mapDivideToSelf(32.0d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, realVector39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(realVector39);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getIterations();
        double[] doubleArray2 = levenbergMarquardtOptimizer0.getUpperBound();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(doubleArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        int[] intArray9 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        int int11 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray9);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math3.random.MersenneTwister(intArray16);
        int[] intArray18 = org.apache.commons.math3.util.MathArrays.copyOf(intArray16);
        int int19 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray18);
        try {
            int int20 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray9, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", "", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", "", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (byte) 1);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (byte) 1 + "'", number2.equals((byte) 1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int[] intArray44 = null;
        int[] intArray45 = new int[] {};
        int[] intArray49 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister50 = new org.apache.commons.math3.random.MersenneTwister(intArray49);
        int[] intArray51 = org.apache.commons.math3.util.MathArrays.copyOf(intArray49);
        int int52 = org.apache.commons.math3.util.MathArrays.distance1(intArray45, intArray51);
        double[] doubleArray59 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray66 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray73 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray80 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray87 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray94 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray95 = new double[][] { doubleArray59, doubleArray66, doubleArray73, doubleArray80, doubleArray87, doubleArray94 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix96 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray95);
        try {
            array2DRowRealMatrix43.copySubMatrix(intArray44, intArray51, doubleArray95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        try {
            double double13 = eigenDecomposition9.getRealEigenvalue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor44 = null;
        try {
            double double45 = array2DRowRealMatrix43.walkInColumnOrder(realMatrixChangingVisitor44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double double11 = eigenDecomposition9.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 174.53292519943295d + "'", double11 == 174.53292519943295d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = diagonalMatrix7.walkInColumnOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, 2.2250738585072014E-308d, 143.22214567148168d, (double) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(32.0d, (double) 10.0f);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair4 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair5 = null;
        try {
            boolean boolean6 = simpleVectorValueChecker2.converged(2147483647, pointVectorValuePair4, pointVectorValuePair5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray49 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition53 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix51, (double) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix43.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x6 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        diagonalMatrix7.setEntry((int) (byte) -1, 1, 0.0d);
        double[] doubleArray15 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        try {
            diagonalMatrix7.setRow((int) (byte) 1, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 1x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) (short) -1, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (short) -1, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math3.util.FastMath.rint((-0.7249165551445564d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.0d, 0.0d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(35, 100);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(10.0d, (double) 9L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, (-0.0d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.getRowMatrix((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray17);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray17, 11.0d);
        double[] doubleArray23 = eigenDecomposition22.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11.0d + "'", double20 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix7.getColumnMatrix(1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor17 = null;
        try {
            double double20 = arrayRealVector15.walkInOptimizedOrder(realVectorChangingVisitor17, (int) (short) 10, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, 174.53292519943295d, (double) 0L, 6.283185307179587d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(5200.0d, (double) (byte) 10, pointValuePairConvergenceChecker2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 5, 0.0f, 52.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(52, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence((double) 100.0f, (double) 0.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double[] doubleArray39 = null;
        try {
            double[] doubleArray40 = diagonalMatrix37.preMultiply(doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (byte) -1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2);
        int int4 = nonLinearConjugateGradientOptimizer3.getMaxEvaluations();
        int int5 = nonLinearConjugateGradientOptimizer3.getMaxEvaluations();
        double[] doubleArray6 = nonLinearConjugateGradientOptimizer3.getLowerBound();
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType10 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType11 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType12 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray14 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType8, goalType9, goalType10, goalType11, goalType12, goalType13 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray14, orderDirection15, true);
        org.apache.commons.math3.exception.ConvergenceException convergenceException18 = new org.apache.commons.math3.exception.ConvergenceException(localizable7, (java.lang.Object[]) goalTypeArray14);
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair19 = nonLinearConjugateGradientOptimizer3.optimize((org.apache.commons.math3.optim.OptimizationData[]) goalTypeArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType9 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType9.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType10 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType10.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType11.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType12 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType12.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType13 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType13.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray14);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix7, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        int[] intArray9 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        int[] intArray11 = org.apache.commons.math3.util.MathArrays.copyOf(intArray9);
        int[] intArray15 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math3.random.MersenneTwister(intArray15);
        int int17 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray11, intArray15);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray15);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getRowDimension();
        try {
            array2DRowRealMatrix0.setEntry(10, 0, 32.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 0.0f, "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        try {
            double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(2147483647, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double[] doubleArray17 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor18 = null;
        try {
            double double19 = arrayRealVector16.walkInDefaultOrder(realVectorPreservingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds20 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = openMapRealMatrix2.subtract(openMapRealMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix5, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) Double.NaN, (java.lang.Number) 100.0d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-0.9999999999999999d), 35.0d, (double) 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray11 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double double14 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray11);
        double[] doubleArray15 = null;
        try {
            double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 11.0d + "'", double14 == 11.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = simpleBounds19.getUpper();
        double[] doubleArray21 = simpleBounds19.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, false);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray20 = simpleBounds18.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, false);
        java.io.ObjectOutputStream objectOutputStream23 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector22, objectOutputStream23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double double17 = arrayRealVector7.getMinValue();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor18 = null;
        try {
            double double21 = arrayRealVector7.walkInOptimizedOrder(realVectorChangingVisitor18, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-10.0d) + "'", double17 == (-10.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math3.util.FastMath.tan(143.22214567148168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.481799283000183d) + "'", double1 == (-3.481799283000183d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(2.7182818285d, (double) 100.0f, 101.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 10L, (int) '#', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -1, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((-1.0f), (float) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "[", "[");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor44 = null;
        try {
            double double49 = array2DRowRealMatrix43.walkInColumnOrder(realMatrixChangingVisitor44, (int) '#', 5, 2147483647, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 10, (java.lang.Number) (-1.0f), (java.lang.Number) 10);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Throwable[] throwableArray6 = outOfRangeException4.getSuppressed();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0f) + "'", number7.equals((-1.0f)));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(2.7182818285d, 143.22214567148168d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair6 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair5);
        double[] doubleArray7 = doubleArrayPair6.getKey();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray7);
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray19 = eigenDecomposition18.getRealEigenvalues();
        double[] doubleArray20 = eigenDecomposition18.getRealEigenvalues();
        double[] doubleArray22 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds27 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray20, doubleArray22);
        double double28 = org.apache.commons.math3.util.MathArrays.distance(doubleArray8, doubleArray20);
        double double29 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 153.22214567148168d + "'", double28 == 153.22214567148168d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 143.22214567148168d + "'", double29 == 143.22214567148168d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("", "[", "hi!", "[", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double2 = org.apache.commons.math3.util.FastMath.min(101.53096491487338d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 100);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (short) 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.append(arrayRealVector27);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector38.append(arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector46.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector19.combine(0.0d, (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        try {
            org.apache.commons.math3.linear.RealVector realVector51 = diagonalMatrix7.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        int int10 = diagonalMatrix7.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = diagonalMatrix7.getColumnVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (short) 100, 2.2250738585072014E-308d, 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        int int51 = diagonalMatrix7.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor52 = null;
        try {
            double double53 = diagonalMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(7.896296018267969E13d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double double39 = diagonalMatrix37.getTrace();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor40 = null;
        try {
            double double41 = diagonalMatrix37.walkInRowOrder(realMatrixChangingVisitor40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 47.490658503988655d + "'", double39 == 47.490658503988655d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, (double) (short) 1, 1.7453292519943295d, 101.53096491487338d, objArray5);
        double double7 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 'a', (double) 0.0f, (double) 35.000004f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition47 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix45, (double) (short) 0);
        double[] doubleArray53 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix55 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray53, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = diagonalMatrix45.add(diagonalMatrix55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = diagonalMatrix26.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56);
        double double58 = diagonalMatrix56.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor59 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double60 = diagonalMatrix56.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        double double61 = diagonalMatrix17.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        double double62 = diagonalMatrix17.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor63 = null;
        try {
            double double68 = diagonalMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor63, 5, 0, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(diagonalMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 47.490658503988655d + "'", double58 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor39 = null;
        try {
            double double40 = diagonalMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.58601345231343E15d + "'", double1 == 1.58601345231343E15d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        boolean boolean12 = eigenDecomposition9.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        long long2 = org.apache.commons.math3.util.FastMath.max(35L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.util.MathUtils.checkFinite(5200.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix43.getRowMatrix(5);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        java.lang.Double[] doubleArray70 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector63.append(arrayRealVector71);
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector63.mapDivideToSelf(32.0d);
        arrayRealVector54.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector63.append((double) 'a');
        try {
            org.apache.commons.math3.linear.RealVector realVector78 = array2DRowRealMatrix43.operate(realVector77);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 7 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realVector77);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray7 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix9, (double) (short) 0);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = diagonalMatrix9.add(diagonalMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = diagonalMatrix20.scalarAdd((double) (byte) 0);
        double[][] doubleArray23 = diagonalMatrix20.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, 0, doubleArray23, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(diagonalMatrix20);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector9.append(arrayRealVector17);
        double double19 = arrayRealVector9.getMinValue();
        arrayRealVector9.set((double) 10.0f);
        java.lang.StringBuffer stringBuffer22 = null;
        java.text.FieldPosition fieldPosition23 = null;
        try {
            java.lang.StringBuffer stringBuffer24 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector9, stringBuffer22, fieldPosition23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-10.0d) + "'", double19 == (-10.0d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        int int40 = array2DRowRealMatrix39.getColumnDimension();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor41 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double46 = array2DRowRealMatrix39.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor41, (int) (byte) 0, 100, (int) (short) -1, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector8.append(arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector16.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, false);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        double[] doubleArray30 = arrayRealVector29.getDataRef();
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector40.append(arrayRealVector48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector40.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector29.combine((double) (short) -1, (double) (byte) -1, realVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector21.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0, arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(5200.0d, (double) (short) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 1.1102230246251565E-16d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double double3 = arrayRealVector2.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1102230246251565E-16d + "'", double3 == 1.1102230246251565E-16d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        long long6 = mersenneTwister4.nextLong(10L);
        byte[] byteArray10 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
        mersenneTwister4.nextBytes(byteArray10);
        double double12 = mersenneTwister4.nextDouble();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9622348015636448d + "'", double12 == 0.9622348015636448d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        long long2 = org.apache.commons.math3.util.FastMath.max(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 1, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        long long6 = mersenneTwister4.nextLong(10L);
        byte[] byteArray10 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
        mersenneTwister4.nextBytes(byteArray10);
        int[] intArray15 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math3.random.MersenneTwister(intArray15);
        long long18 = mersenneTwister16.nextLong(10L);
        byte[] byteArray22 = new byte[] { (byte) 10, (byte) -1, (byte) 0 };
        mersenneTwister16.nextBytes(byteArray22);
        mersenneTwister4.nextBytes(byteArray22);
        int int25 = mersenneTwister4.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9L + "'", long18 == 9L);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1864881824 + "'", int25 == 1864881824);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval(35.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [35, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 10L, (double) 100.0f, (double) (-1L), (double) 100.0f, 0.9622348015636448d, (-10.0d), 10.0d, 174.53292519943295d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2635.706903978693d + "'", double8 == 2635.706903978693d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 1);
        double[] doubleArray43 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair47 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair46);
        double[] doubleArray48 = doubleArrayPair47.getKey();
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray48);
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray48);
        int int51 = org.apache.commons.math3.util.MathUtils.hash(doubleArray48);
        try {
            double[] doubleArray52 = diagonalMatrix7.preMultiply(doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1074790369) + "'", int51 == (-1074790369));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(100);
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix1, (int) (short) 1, 32);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int8 = openMapRealMatrix7.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(153.22214567148168d, (double) 36);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3400289243906618d + "'", double2 == 1.3400289243906618d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.combine((double) '4', (double) 0.0f, realVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.createMatrix(35, 6);
        double[] doubleArray19 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray24 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        try {
            array2DRowRealMatrix11.setSubMatrix(doubleArray25, 2147483647, 1864881824);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(35.0d, 52);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 'a', 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100, 47.490658503988655d);
        double double3 = arrayRealVector2.getLInfNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 47.490658503988655d + "'", double3 == 47.490658503988655d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            double double22 = arrayRealVector20.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray12 = eigenDecomposition10.getRealEigenvalues();
        double[] doubleArray14 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds19 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray12);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition47 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix45, (double) (short) 0);
        double[] doubleArray53 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix55 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray53, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = diagonalMatrix45.add(diagonalMatrix55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = diagonalMatrix26.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56);
        double double58 = diagonalMatrix56.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor59 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double60 = diagonalMatrix56.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        double double61 = diagonalMatrix17.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        int int62 = diagonalMatrix17.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(diagonalMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 47.490658503988655d + "'", double58 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 5 + "'", int62 == 5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        double[] doubleArray8 = null;
        try {
            double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray5, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, false);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        double[] doubleArray29 = arrayRealVector28.getDataRef();
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector39.append(arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector39.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector28.combine((double) (short) -1, (double) (byte) -1, realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor53 = null;
        try {
            double double54 = arrayRealVector28.walkInOptimizedOrder(realVectorChangingVisitor53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[][] doubleArray41 = array2DRowRealMatrix39.getDataRef();
        java.lang.Double[] doubleArray48 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48);
        java.lang.Double[] doubleArray56 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector49.append(arrayRealVector57);
        try {
            org.apache.commons.math3.linear.RealVector realVector59 = array2DRowRealMatrix39.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(arrayRealVector58);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((-10.0d), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -10 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, (double) (short) 0);
        double[] doubleArray16 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = diagonalMatrix8.add(diagonalMatrix18);
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray35 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix27.add(diagonalMatrix37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = diagonalMatrix8.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix38);
        double double40 = diagonalMatrix38.getTrace();
        java.lang.StringBuffer stringBuffer41 = null;
        java.text.FieldPosition fieldPosition42 = null;
        try {
            java.lang.StringBuffer stringBuffer43 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix38, stringBuffer41, fieldPosition42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(diagonalMatrix19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 47.490658503988655d + "'", double40 == 47.490658503988655d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 100, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray2, (double) 10.0f);
        try {
            double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray0, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double[] doubleArray3 = new double[] { 100L, 0.0f, (-1074790400) };
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray3, (java.lang.Double) 47.490658503988655d);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math3.util.FastMath.rint(6.283185307179587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor8 = null;
        try {
            double double11 = arrayRealVector7.walkInOptimizedOrder(realVectorChangingVisitor8, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray5 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        int int8 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray7);
        try {
            int int9 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getUpper();
        double[] doubleArray40 = simpleBounds38.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray19, doubleArray40, 2.718281828459045d);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray14 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray21 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray28 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray35 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray42 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray43 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28, doubleArray35, doubleArray42 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException45 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray43);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray43, 2.718281828459045d, 1.58601345231343E15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector16.append(arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.mapDivideToSelf(32.0d);
        arrayRealVector7.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector16.append((double) 100);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair5 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        double[] doubleArray6 = doubleArrayPair5.getKey();
        java.lang.Double double7 = doubleArrayPair5.getValue();
        java.lang.Double double8 = doubleArrayPair5.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8.equals(10.0d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix11.power((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray20 = simpleBounds18.getUpper();
        double[] doubleArray22 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22);
        double[] doubleArray28 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray28);
        double[] doubleArray38 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38, true);
        double double41 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray28, doubleArray38);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray22, doubleArray38, 11.0d);
        double double44 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray20, doubleArray38);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 11.0d + "'", double41 == 11.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 11.0d + "'", double44 == 11.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray20 = simpleBounds18.getUpper();
        double[] doubleArray21 = simpleBounds18.getUpper();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealVector realVector2 = array2DRowRealMatrix0.getRowVector((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = diagonalMatrix7.isTransposable();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7);
        double double12 = lUDecomposition11.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = lUDecomposition11.getU();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 174.53292519943295d + "'", double12 == 174.53292519943295d);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("[", "hi!", "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}", numberFormat3);
        java.lang.String str5 = realVectorFormat4.getSeparator();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str5.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector9.append(arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapMultiplyToSelf((double) 36);
        java.lang.StringBuffer stringBuffer21 = null;
        java.text.FieldPosition fieldPosition22 = null;
        try {
            java.lang.StringBuffer stringBuffer23 = realVectorFormat1.format(realVector20, stringBuffer21, fieldPosition22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        double[] doubleArray9 = arrayRealVector8.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, 0.0d, (double) 32, 1.0d, (double) 100L);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.scale(7.896296018267969E13d, doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) (byte) 10, false);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray9, doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        double[] doubleArray51 = diagonalMatrix50.getDataRef();
        int int52 = diagonalMatrix50.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 5 + "'", int52 == 5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (byte) 0, (float) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        double double39 = diagonalMatrix37.getTrace();
        int int40 = diagonalMatrix37.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 47.490658503988655d + "'", double39 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 5 + "'", int40 == 5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        try {
            openMapRealMatrix2.addToEntry((int) '#', (int) '#', (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (byte) 100, (double) 0, 3.970291913552122d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray34 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = diagonalMatrix26.add(diagonalMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 1);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver41 = lUDecomposition40.getSolver();
        double double42 = lUDecomposition40.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(decompositionSolver41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 174.53292519943295d + "'", double42 == 174.53292519943295d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 1.58601345231343E15d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,586,013,452,313,430, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray11 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair15 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair14);
        double[] doubleArray16 = doubleArrayPair15.getKey();
        try {
            double[] doubleArray17 = diagonalMatrix7.preMultiply(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, false);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double22 = arrayRealVector15.walkInDefaultOrder(realVectorPreservingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.9622348015636448d, 32.0d, 22026.465794806718d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3019272488946267d + "'", double1 == 3.3019272488946267d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix43.getRowMatrix(5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix50 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix50, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix53 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix50);
        try {
            array2DRowRealMatrix43.setRowMatrix(0, (org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x35 but expected 1x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(realMatrix46);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-1074790400), (int) (byte) 100);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(32.0d, (double) 10.0f);
        double double3 = simpleVectorValueChecker2.getRelativeThreshold();
        double double4 = simpleVectorValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.resetCount();
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray9 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType3, goalType4, goalType5, goalType6, goalType7, goalType8 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray9, orderDirection10, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 1L, (int) '#', orderDirection10, true);
        int int15 = nonMonotonicSequenceException14.getIndex();
        java.lang.Number number16 = nonMonotonicSequenceException14.getPrevious();
        boolean boolean17 = nonMonotonicSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType3.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1L + "'", number16.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(32, 1864881824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 100, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[][] doubleArray2 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix((int) '4', (int) ' ', doubleArray2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathUnsupportedOperationException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        double[] doubleArray16 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair19 = new org.apache.commons.math3.optim.PointValuePair(doubleArray16, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16);
        double[] doubleArray22 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22);
        double[] doubleArray32 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        double double35 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray22, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray16, doubleArray32, 11.0d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        double[][] doubleArray39 = diagonalMatrix38.getData();
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix40 = openMapRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x35 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 11.0d + "'", double35 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.9999999999999998d), (java.lang.Number) 1.0f, false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, 10.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.9999999999999999d, (double) 1.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.scalarAdd((double) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double26 = diagonalMatrix18.walkInColumnOrder(realMatrixChangingVisitor21, 36, (int) (byte) -1, (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(1864881824, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(1.58601345231343E15d, (double) 52);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray9 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType3, goalType4, goalType5, goalType6, goalType7, goalType8 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray9, orderDirection10, true);
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair13 = simplexOptimizer2.optimize((org.apache.commons.math3.optim.OptimizationData[]) goalTypeArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType3.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[][] doubleArray41 = array2DRowRealMatrix39.getDataRef();
        try {
            array2DRowRealMatrix39.multiplyEntry((int) '4', 2147483647, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint(0.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5d) + "'", double2 == (-0.5d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray7 = initialGuess6.getInitialGuess();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        int[] intArray9 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        int int11 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray9);
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray9, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.analysis.function.Sinc sinc2 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver3 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution7 = null;
        try {
            double double8 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide((int) ' ', (org.apache.commons.math3.analysis.UnivariateFunction) sinc2, univariateFunctionBracketedUnivariateSolver3, (-10.0d), 0.0d, (double) ' ', allowedSolution7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(4.641588833612779d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.9967368836335428d, (java.lang.Number) 10.0f, (java.lang.Number) 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getRowDimension();
        double[] doubleArray7 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix9, (double) (short) 0);
        double[] doubleArray12 = eigenDecomposition11.getRealEigenvalues();
        double[] doubleArray13 = eigenDecomposition11.getRealEigenvalues();
        double[] doubleArray15 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds20 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray15);
        double[] doubleArray26 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition30 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix28, (double) (short) 0);
        double[] doubleArray31 = eigenDecomposition30.getRealEigenvalues();
        double[] doubleArray32 = eigenDecomposition30.getRealEigenvalues();
        double[] doubleArray34 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray34, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds39 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray32, doubleArray34);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition40 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray15, doubleArray34);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray42 = array2DRowRealMatrix41.getDataRef();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x35 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.createMatrix(35, 6);
        double[] doubleArray20 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix22, (double) (short) 0);
        double[] doubleArray25 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray26 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray28 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess32 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds33 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray26, doubleArray28);
        double[] doubleArray39 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix41, (double) (short) 0);
        double[] doubleArray44 = eigenDecomposition43.getRealEigenvalues();
        double[] doubleArray45 = eigenDecomposition43.getRealEigenvalues();
        double[] doubleArray47 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair50 = new org.apache.commons.math3.optim.PointValuePair(doubleArray47, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess51 = new org.apache.commons.math3.optim.InitialGuess(doubleArray47);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds52 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray45, doubleArray47);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition53 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray28, doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        int int55 = array2DRowRealMatrix54.getColumnDimension();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix11.subtract(array2DRowRealMatrix54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x4 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-614277696) + "'", int1 == (-614277696));
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 50);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 10, 10, 32, 10, 100, 100 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { 36, 36, (-1), (-1), 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) intArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizable1 };
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException19 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, objArray18);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        java.lang.String str3 = realVectorFormat1.getSeparator();
        java.text.NumberFormat numberFormat4 = realVectorFormat1.getFormat();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder0.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, goalType4, 0.0d, 6.0d);
        double double9 = sinc3.value((double) (byte) 100);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 11.0d, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [11, 10]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.005063656411097588d) + "'", double9 == (-0.005063656411097588d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, univariateSolver2, preconditioner3);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker5);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver10 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner11 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver10, preconditioner11);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double double18 = brentSolver10.solve((int) (short) 10, (org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 11.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [11, 5]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math3.util.FastMath.floor(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, false);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        double[] doubleArray29 = arrayRealVector28.getDataRef();
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector39.append(arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector39.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector28.combine((double) (short) -1, (double) (byte) -1, realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapSubtractToSelf(0.9622348015636448d);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor55 = null;
        try {
            double double56 = arrayRealVector52.walkInOptimizedOrder(realVectorPreservingVisitor55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector54);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 0L, Double.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double2 = org.apache.commons.math3.util.FastMath.max(6.0d, 101.53096491487338d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.53096491487338d + "'", double2 == 101.53096491487338d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        double[] doubleArray20 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix22, (double) (short) 0);
        double[] doubleArray30 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = diagonalMatrix22.add(diagonalMatrix32);
        double[] doubleArray39 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix41, (double) (short) 0);
        double[] doubleArray49 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = diagonalMatrix41.add(diagonalMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = diagonalMatrix22.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        double double54 = diagonalMatrix52.getTrace();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor55 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double56 = diagonalMatrix52.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor55);
        defaultRealMatrixPreservingVisitor55.visit(6, (int) (short) 0, 1.0d);
        try {
            double double65 = openMapRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor55, 52, (int) ' ', 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(diagonalMatrix33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(diagonalMatrix52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 47.490658503988655d + "'", double54 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 52, (java.lang.Number) 1.3400289243906618d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector27.append(arrayRealVector35);
        double double37 = arrayRealVector27.getMinValue();
        double[] doubleArray38 = arrayRealVector27.toArray();
        double double39 = arrayRealVector27.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, arrayRealVector27);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor41 = null;
        try {
            double double42 = arrayRealVector40.walkInDefaultOrder(realVectorPreservingVisitor41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-10.0d) + "'", double37 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-10.0d) + "'", double39 == (-10.0d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        try {
            openMapRealMatrix5.multiplyEntry(100, (int) (byte) -1, 7.896296018267969E13d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 1);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) 10.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray8);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction10 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator11 = null;
        try {
            multiDirectionalSimplex9.evaluate(multivariateFunction10, pointValuePairComparator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, false);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        double[] doubleArray29 = arrayRealVector28.getDataRef();
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector39.append(arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector39.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector28.combine((double) (short) -1, (double) (byte) -1, realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector28.append((-10.0d));
        arrayRealVector28.unitize();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector54);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((-1), 3.3019272488946267d, 2.718281828459045d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getMid();
        double double3 = bracketFinder0.getFHi();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.mapSubtractToSelf((double) 10);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = openMapRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5, (int) (short) -1, 1864881824, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(openMapRealMatrix4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        double[] doubleArray43 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair47 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair46);
        double[] doubleArray48 = doubleArrayPair47.getKey();
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix39.operate(doubleArray49);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor51 = null;
        try {
            double double52 = array2DRowRealMatrix39.walkInColumnOrder(realMatrixChangingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1.0f, 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (-614277696));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-614277696) + "'", int1 == (-614277696));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5, 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math3.util.FastMath.rint(1.3400289243906618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapAdd(1.9155040003582885E22d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math3.util.FastMath.rint(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix39.createMatrix(0, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) '#', (float) (short) -1, (float) 50);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 35.000004f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getDataRef();
        try {
            double[] doubleArray42 = array2DRowRealMatrix39.getRow(1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(3.3019272488946267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.057629502154529534d + "'", double1 == 0.057629502154529534d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        java.lang.String str3 = realVectorFormat1.getSeparator();
        java.lang.String str4 = realVectorFormat1.getSuffix();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "}" + "'", str4.equals("}"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector15.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, false);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        double[] doubleArray29 = arrayRealVector28.getDataRef();
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector39.append(arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector39.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector28.combine((double) (short) -1, (double) (byte) -1, realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        try {
            double double54 = arrayRealVector20.getEntry((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, (double) (short) 0);
        double[] doubleArray29 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray30 = eigenDecomposition28.getRealEigenvalues();
        double[] doubleArray32 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray40 = array2DRowRealMatrix39.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix39, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getUpper();
        double[] doubleArray40 = simpleBounds38.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray19, doubleArray40, 2.718281828459045d);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray40);
        double[] doubleArray46 = target45.getTarget();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        float[] floatArray5 = new float[] { (byte) -1, (short) 0, 10, (short) 100, (short) 100 };
        float[] floatArray12 = new float[] { ' ', 36, '4', 32, (short) -1, 0 };
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(floatArray5, floatArray12);
        float[] floatArray19 = new float[] { (byte) -1, (short) 0, 10, (short) 100, (short) 100 };
        float[] floatArray26 = new float[] { ' ', 36, '4', 32, (short) -1, 0 };
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(floatArray19, floatArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray5, floatArray26);
        float[] floatArray34 = new float[] { (byte) -1, (short) 0, 10, (short) 100, (short) 100 };
        float[] floatArray41 = new float[] { ' ', 36, '4', 32, (short) -1, 0 };
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equals(floatArray34, floatArray41);
        float[] floatArray48 = new float[] { (byte) -1, (short) 0, 10, (short) 100, (short) 100 };
        float[] floatArray55 = new float[] { ' ', 36, '4', 32, (short) -1, 0 };
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equals(floatArray48, floatArray55);
        boolean boolean57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray34, floatArray55);
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(floatArray5, floatArray34);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver(143.22214567148168d, 3.3019272488946267d, (double) (short) 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver6 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, pointValuePairConvergenceChecker5, univariateSolver6, preconditioner7);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, pointValuePairConvergenceChecker9);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker13 = new org.apache.commons.math3.optim.SimpleValueChecker(101.53096491487338d, 1.58601345231343E15d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer14 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker13);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((-10.0d), 2.3978952727983707d, 11.0d, (double) (byte) -1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -10 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + formula4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula4.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        int[] intArray9 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        int int11 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray9);
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray9, 52);
        try {
            int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.util.MathUtils.checkFinite(3.3019272488946267d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (-1074790400));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair11 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair10);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction12 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction13 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction12);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction14 = modelFunction13.getModelFunction();
        boolean boolean15 = doubleArrayPair11.equals((java.lang.Object) multivariateVectorFunction14);
        double[] doubleArray16 = doubleArrayPair11.getFirst();
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray1, doubleArray16);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
        double[] doubleArray19 = sigma18.getSigma();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType23 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType24 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType25 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType26 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType27 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType28 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray29 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType23, goalType24, goalType25, goalType26, goalType27, goalType28 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection30 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray29, orderDirection30, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException34 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 1L, (int) '#', orderDirection30, true);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray19, orderDirection30, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNull(multivariateVectorFunction14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + goalType23 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType23.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType24 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType24.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType25 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType25.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType26 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType26.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType27 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType27.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType28 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType28.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray29);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        boolean boolean17 = arrayRealVector16.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 50);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0710678118654755d + "'", double1 == 7.0710678118654755d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        long long5 = mersenneTwister4.nextLong();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-260124651757769029L) + "'", long5 == (-260124651757769029L));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.641588833612779d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.641588833612779d + "'", double2 == 4.641588833612779d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 52, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double2 = org.apache.commons.math3.util.FastMath.min(1.3400289243906618d, 5155.99724417334d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3400289243906618d + "'", double2 == 1.3400289243906618d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double double17 = arrayRealVector7.getMinValue();
        arrayRealVector7.set((double) 10.0f);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector7.mapMultiplyToSelf((double) 0L);
        double[] doubleArray22 = arrayRealVector7.toArray();
        double[] doubleArray23 = null;
        try {
            double double24 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray22, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-10.0d) + "'", double17 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(6, 32.0d, 0.0d, 2.3978952727983707d, 0.0d);
        double[] doubleArray11 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13, (double) (short) 0);
        double[] doubleArray16 = eigenDecomposition15.getRealEigenvalues();
        double[] doubleArray17 = eigenDecomposition15.getRealEigenvalues();
        double[] doubleArray19 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess23 = new org.apache.commons.math3.optim.InitialGuess(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds24 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray17, doubleArray19);
        double[] doubleArray25 = simpleBounds24.getUpper();
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        java.lang.Double[] doubleArray40 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector33.append(arrayRealVector41);
        double double43 = arrayRealVector33.getMinValue();
        double[] doubleArray44 = arrayRealVector33.toArray();
        double double45 = arrayRealVector33.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, arrayRealVector33);
        try {
            nelderMeadSimplex5.build(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-10.0d) + "'", double43 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-10.0d) + "'", double45 == (-10.0d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 10L, 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(11.0d, (double) (-1), (double) (short) 10, 143.22214567148168d, 0.0d, 1.2339186085744818d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1421.221456714817d + "'", double6 == 1421.221456714817d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        try {
            double[] doubleArray51 = blockRealMatrix49.getRow((-614277696));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-614,277,696)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor50 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor50.start((int) '4', 36, (int) (short) 1, 0, (int) ' ', 1);
        try {
            double double62 = blockRealMatrix49.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor50, 0, 36, 52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        diagonalMatrix7.setEntry(35, (int) (byte) 1, (double) (byte) 0);
        boolean boolean23 = diagonalMatrix7.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector8.append(arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector16.mapMultiplyToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, false);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        double[] doubleArray30 = arrayRealVector29.getDataRef();
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector40.append(arrayRealVector48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector40.mapDivideToSelf(32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector29.combine((double) (short) -1, (double) (byte) -1, realVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector21.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        java.lang.Double[] doubleArray60 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray60);
        java.lang.Double[] doubleArray68 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector61.append(arrayRealVector69);
        double double71 = arrayRealVector61.getMinValue();
        java.lang.Double[] doubleArray80 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray80);
        java.lang.Double[] doubleArray88 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray88);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = arrayRealVector81.append(arrayRealVector89);
        double double91 = arrayRealVector81.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector93 = arrayRealVector81.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = arrayRealVector61.combineToSelf(0.0d, 22026.465794806718d, realVector93);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector53.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        java.lang.StringBuffer stringBuffer96 = null;
        java.text.FieldPosition fieldPosition97 = null;
        try {
            java.lang.StringBuffer stringBuffer98 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector95, stringBuffer96, fieldPosition97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + (-10.0d) + "'", double71 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(arrayRealVector90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + (-10.0d) + "'", double91 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector93);
        org.junit.Assert.assertNotNull(arrayRealVector94);
        org.junit.Assert.assertNotNull(arrayRealVector95);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray13 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray20 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray27 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray34 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray41 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix43.getRowMatrix(5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition47 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver48 = lUDecomposition47.getSolver();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(decompositionSolver48);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.scalarAdd((double) (byte) 0);
        double[][] doubleArray21 = diagonalMatrix18.getData();
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix18.scalarAdd((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder4 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double5 = bracketFinder4.getFMid();
        org.apache.commons.math3.analysis.function.Sinc sinc7 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder4.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc7, goalType8, 0.0d, 6.0d);
        double double13 = sinc7.value((double) (byte) 100);
        try {
            double double17 = brentSolver2.solve((-1074790400), (org.apache.commons.math3.analysis.UnivariateFunction) sinc7, 6.283185307179586d, 0.0d, 6.283185307179587d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [6.283, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.005063656411097588d) + "'", double13 == (-0.005063656411097588d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray20 = simpleBounds18.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, false);
        double double23 = arrayRealVector22.getMinValue();
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 1.1102230246251565E-16d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        double double27 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(101.53096491487338d, 32.0d);
        double double3 = univariatePointValuePair2.getValue();
        double double4 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 101.53096491487338d + "'", double4 == 101.53096491487338d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 5, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.append(arrayRealVector15);
        double double17 = arrayRealVector7.getMinValue();
        double[] doubleArray18 = arrayRealVector7.toArray();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector7.mapSubtract((double) 1864881824);
        double double21 = arrayRealVector7.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-10.0d) + "'", double17 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 101.53096491487338d + "'", double21 == 101.53096491487338d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math3.util.FastMath.acos(2.7182818285d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.mapSubtractToSelf(2.7182818285d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor50 = null;
        try {
            double double51 = blockRealMatrix49.walkInOptimizedOrder(realMatrixChangingVisitor50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction1 = null;
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver2 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution6 = null;
        try {
            double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide((int) (short) 0, univariateFunction1, univariateFunctionBracketedUnivariateSolver2, (double) 5.0f, 35.0d, (-0.7249165551445564d), allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(Float.NaN, (float) (-260124651757769029L), (float) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, 47.490658503988655d, 0.0d, 0.0d);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getHi();
        double double7 = noBracketingException4.getLo();
        double double8 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 47.490658503988655d + "'", double5 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 47.490658503988655d + "'", double6 == 47.490658503988655d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 47.490658503988655d + "'", double8 == 47.490658503988655d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        double double3 = brentSolver2.getFunctionValueAccuracy();
        double double4 = brentSolver2.getMax();
        double double5 = brentSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        try {
            blockRealMatrix49.setEntry((int) 'a', 52, (double) 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(10, (int) '#');
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix6.subtract(openMapRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = openMapRealMatrix14.transpose();
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(1.5707963267948966d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int2 = org.apache.commons.math3.util.FastMath.max(52, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        double[] doubleArray9 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair12 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair13 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair12);
        double[] doubleArray14 = doubleArrayPair13.getKey();
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        int int17 = org.apache.commons.math3.util.MathUtils.hash(doubleArray14);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray2, doubleArray14);
        try {
            double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray0, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1074790369) + "'", int17 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1074790400), (java.lang.Number) 1.0d, false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray8 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair11);
        double[] doubleArray13 = doubleArrayPair12.getKey();
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray13);
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) doubleArray1, localizable18, objArray19);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074790369) + "'", int16 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray8 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, 0.0d, (double) 32, 1.0d, (double) 100L);
        double[] doubleArray20 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix22, (double) (short) 0);
        double[] doubleArray25 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray26 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray28 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess32 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds33 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray26, doubleArray28);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.scale(11.0d, doubleArray26);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition35 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray8, doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = eigenDecomposition35.getVT();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 35L, (double) 0.0f);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        double[] doubleArray12 = arrayRealVector11.getDataRef();
        double double13 = arrayRealVector11.getMinValue();
        double double14 = arrayRealVector11.getLInfNorm();
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector22.append(arrayRealVector30);
        double double32 = arrayRealVector22.getMinValue();
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        java.lang.Double[] doubleArray49 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector42.append(arrayRealVector50);
        double double52 = arrayRealVector42.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector42.mapMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector22.combineToSelf(0.0d, 22026.465794806718d, realVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector22);
        org.apache.commons.math3.analysis.function.Sinc sinc58 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector56.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc58);
        try {
            double double61 = brentSolver2.solve(2147483647, (org.apache.commons.math3.analysis.UnivariateFunction) sinc58, (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [�, �], values: [�, �]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-10.0d) + "'", double13 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.53096491487338d + "'", double14 == 101.53096491487338d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-10.0d) + "'", double32 == (-10.0d));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-10.0d) + "'", double52 == (-10.0d));
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector59);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        boolean boolean10 = eigenDecomposition9.hasComplexEigenvalues();
        try {
            double double12 = eigenDecomposition9.getRealEigenvalue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        java.lang.Number number4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType10 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType11 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray12 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType6, goalType7, goalType8, goalType9, goalType10, goalType11 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection13 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray12, orderDirection13, true);
        org.apache.commons.math3.exception.ConvergenceException convergenceException16 = new org.apache.commons.math3.exception.ConvergenceException(localizable5, (java.lang.Object[]) goalTypeArray12);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException17 = new org.apache.commons.math3.exception.NotFiniteNumberException(number4, (java.lang.Object[]) goalTypeArray12);
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair18 = brentOptimizer3.optimize((org.apache.commons.math3.optim.OptimizationData[]) goalTypeArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType9 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType9.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType10 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType10.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType11.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int[] intArray3 = new int[] { 100, (byte) -1, (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        long long6 = mersenneTwister4.nextLong(10L);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        mersenneTwister4.nextBytes(byteArray10);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, pointVectorValuePairConvergenceChecker1, (double) (-1), 1.9155040003582885E22d, (double) (-614277696), 0.9622348015636448d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1074790400));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray16 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray30 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray37 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[] doubleArray44 = new double[] { (short) 100, (byte) 100, 0, 10.0d, (-0.9999999999999999d), 2147483647 };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(0.9999999999999999d);
        double[] doubleArray54 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair57 = new org.apache.commons.math3.optim.PointValuePair(doubleArray54, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess58 = new org.apache.commons.math3.optim.InitialGuess(doubleArray54);
        double[] doubleArray61 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray61, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair65 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair64);
        double[] doubleArray66 = doubleArrayPair65.getKey();
        double[] doubleArray67 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray66);
        org.apache.commons.math3.linear.RealVector realVector68 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray66);
        int int69 = org.apache.commons.math3.util.MathUtils.hash(doubleArray66);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray54, doubleArray66);
        try {
            blockRealMatrix49.setColumn((int) ' ', doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1074790369) + "'", int69 == (-1074790369));
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat1.parse("[", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        java.lang.String str8 = diagonalMatrix7.toString();
        double[] doubleArray14 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 0);
        double[] doubleArray24 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = diagonalMatrix16.add(diagonalMatrix26);
        double[] doubleArray33 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35, (double) (short) 0);
        double[] doubleArray43 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = diagonalMatrix35.add(diagonalMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix16.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix46);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition49 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, (double) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = diagonalMatrix7.add(diagonalMatrix16);
        double[] doubleArray51 = diagonalMatrix50.getDataRef();
        double double52 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}" + "'", str8.equals("DiagonalMatrix{{10.0,0.0,0.0,0.0,0.0},{0.0,1.0,0.0,0.0,0.0},{0.0,0.0,1.745329252,0.0,0.0},{0.0,0.0,0.0,1.0,0.0},{0.0,0.0,0.0,0.0,10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(diagonalMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(diagonalMatrix50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 28.638866890843786d + "'", double52 == 28.638866890843786d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 100, (int) (byte) 100);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowPrefix();
        java.lang.String str4 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[" + "'", str2.equals("["));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "; " + "'", str4.equals("; "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getCount();
        try {
            incrementor0.incrementCount(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray15 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = diagonalMatrix7.add(diagonalMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.scalarAdd((double) (byte) 0);
        double[][] doubleArray21 = diagonalMatrix18.getData();
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        double[] doubleArray28 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition32 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix30, (double) (short) 0);
        double[] doubleArray33 = eigenDecomposition32.getRealEigenvalues();
        double[] doubleArray34 = eigenDecomposition32.getRealEigenvalues();
        double[] doubleArray36 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess40 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds41 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray34, doubleArray36);
        double[] doubleArray47 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition51 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49, (double) (short) 0);
        double[] doubleArray52 = eigenDecomposition51.getRealEigenvalues();
        double[] doubleArray53 = eigenDecomposition51.getRealEigenvalues();
        double[] doubleArray55 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair58 = new org.apache.commons.math3.optim.PointValuePair(doubleArray55, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess59 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds60 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray53, doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition61 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray36, doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray63 = array2DRowRealMatrix62.getData();
        double[] doubleArray66 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair69 = new org.apache.commons.math3.optim.PointValuePair(doubleArray66, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair70 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair69);
        double[] doubleArray71 = doubleArrayPair70.getKey();
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray71);
        double[] doubleArray73 = array2DRowRealMatrix62.operate(doubleArray72);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix74 = diagonalMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(diagonalMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray2 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) (byte) 10, false);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair6 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair5);
        double[] doubleArray7 = doubleArrayPair6.getKey();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.scale(143.22214567148168d, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = weight9.getWeight();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble(0.057629502154529534d, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        java.lang.String str3 = realVectorFormat1.getSuffix();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getHi();
        double double3 = bracketFinder0.getFLo();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) -1, (float) '4', (float) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (-1L), numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.9999999999999999d, (double) Float.NaN, (-0.005063656411097588d), 153.22214567148168d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.1102230246251565E-16d, (-0.5d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray11 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double double14 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray11);
        double[] doubleArray20 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix22, (double) (short) 0);
        double[] doubleArray25 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray26 = eigenDecomposition24.getRealEigenvalues();
        double[] doubleArray28 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess32 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds33 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray26, doubleArray28);
        double[] doubleArray34 = simpleBounds33.getUpper();
        double[] doubleArray35 = simpleBounds33.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35, false);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray1, doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 11.0d + "'", double14 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray4 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[] doubleArray9 = new double[] { 0.0d, (-1), 0.0d, (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.createMatrix(35, 6);
        boolean boolean16 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix14, 100.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double[] doubleArray5 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, (double) (short) 0);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray11 = eigenDecomposition9.getRealEigenvalues();
        double[] doubleArray13 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds18 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray13);
        double[] doubleArray19 = simpleBounds18.getUpper();
        double[] doubleArray25 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (double) (short) 0);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray31 = eigenDecomposition29.getRealEigenvalues();
        double[] doubleArray33 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getUpper();
        double[] doubleArray40 = simpleBounds38.getUpper();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, false);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray19, doubleArray40, 2.718281828459045d);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, 0.0d, 3.3019272488946267d, (-3.481799283000183d), (double) (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double[] doubleArray8 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix10, (double) (short) 0);
        double[] doubleArray13 = eigenDecomposition12.getRealEigenvalues();
        double[] doubleArray14 = eigenDecomposition12.getRealEigenvalues();
        double[] doubleArray16 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair19 = new org.apache.commons.math3.optim.PointValuePair(doubleArray16, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess20 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray14, doubleArray16);
        double[] doubleArray27 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29, (double) (short) 0);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        double[] doubleArray33 = eigenDecomposition31.getRealEigenvalues();
        double[] doubleArray35 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 10, false);
        org.apache.commons.math3.optim.InitialGuess initialGuess39 = new org.apache.commons.math3.optim.InitialGuess(doubleArray35);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds40 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray33, doubleArray35);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray16, doubleArray35);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection42 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray35, orderDirection42, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 9.148345846451205E150d, (java.lang.Number) 5200.0d, (int) (byte) 10, orderDirection42, false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getPrefix();
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) str2, "", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[" + "'", str2.equals("["));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) 100.0f, 0.0d, 101.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double[] doubleArray1 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray7 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7);
        double[] doubleArray17 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, true);
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray17);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray17, 11.0d);
        double[] doubleArray24 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair27 = new org.apache.commons.math3.optim.PointValuePair(doubleArray24, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24);
        double[] doubleArray30 = new double[] { (short) -1 };
        org.apache.commons.math3.optim.PointValuePair pointValuePair33 = new org.apache.commons.math3.optim.PointValuePair(doubleArray30, (double) (byte) 10, false);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex34 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray30);
        double[] doubleArray40 = new double[] { 10L, 1, 1.7453292519943295d, 1.0f, 10L };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        double double43 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray30, doubleArray40);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition45 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray24, doubleArray40, 11.0d);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds46 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray17, doubleArray24);
        double[] doubleArray47 = simpleBounds46.getLower();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11.0d + "'", double20 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 11.0d + "'", double43 == 11.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math3.util.FastMath.rint(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d, (-10.0d), 1.7453292519943295d, 1.0d, (-10.0d), 101.53096491487338d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector8.append(arrayRealVector16);
        double[] doubleArray18 = arrayRealVector17.toArray();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.append((double) (byte) 1);
        java.lang.StringBuffer stringBuffer21 = null;
        java.text.FieldPosition fieldPosition22 = null;
        try {
            java.lang.StringBuffer stringBuffer23 = realVectorFormat0.format(realVector20, stringBuffer21, fieldPosition22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.3978952727983707d, 35.0d, univariatePointValuePairConvergenceChecker2);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType8 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray10 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType4, goalType5, goalType6, goalType7, goalType8, goalType9 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray10, orderDirection11, true);
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair14 = brentOptimizer3.optimize((org.apache.commons.math3.optim.OptimizationData[]) goalTypeArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType8.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType9 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType9.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) Double.NaN, (java.lang.Number) 100.0d, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }
}

