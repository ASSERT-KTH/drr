import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[][] doubleArray39 = blockRealMatrix38.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int42 = arrayRealVector41.getMinIndex();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector41.mapMultiplyToSelf((-1.0d));
        try {
            blockRealMatrix38.setColumnVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix7.createMatrix((-127), 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray20 = arrayRealVector19.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor4, (int) (byte) 10, 100, (int) (byte) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        double[] doubleArray14 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray14);
        double[] doubleArray18 = array2DRowRealMatrix7.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor19 = null;
        try {
            double double20 = array2DRowRealMatrix7.walkInRowOrder(realMatrixPreservingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.transpose();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -52 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double[] doubleArray4 = new double[] { 10.0f, 1L, 0.0f, 1.1102230246251565E-16d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double double20 = blockRealMatrix18.getNorm();
        double[] doubleArray27 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray27);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair32 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1), false);
        double[] doubleArray33 = pointValuePair32.getFirst();
        double[] doubleArray34 = pointValuePair32.getPoint();
        try {
            blockRealMatrix18.setColumn(10, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0E-323d + "'", double20 == 3.0E-323d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        double double21 = arrayRealVector20.getMaxValue();
        double double22 = arrayRealVector20.getNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10000.0d + "'", double21 == 10000.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10000.0d + "'", double22 == 10000.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.scalarMultiply((double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(22.03034064887984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1262.2455404163143d + "'", double1 == 1262.2455404163143d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double double20 = arrayRealVector5.getLInfNorm();
        double double21 = arrayRealVector5.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 10, 1, 10, (int) 'a');
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor1 = null;
        try {
            double double2 = arrayRealVector0.walkInOptimizedOrder(realVectorPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat2.parse("{100}");
        boolean boolean5 = arrayRealVector4.isNaN();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        double double9 = arrayRealVector2.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector2.mapAdd(5.298292365610485d);
        double double32 = arrayRealVector2.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.NEGATIVE_INFINITY + "'", double32 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 1, 52);
        int int3 = dimensionMismatchException2.getDimension();
        java.lang.Number number4 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction12 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector2.map(univariateFunction12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        java.lang.String str6 = matrixDimensionMismatchException4.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 6x0 but expected 32x1" + "'", str6.equals("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 6x0 but expected 32x1"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(1.4210804127942926d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.4219100018218d + "'", double1 == 81.4219100018218d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("{{1.5430806348},{100},{1.5430806348}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double double30 = blockRealMatrix27.getNorm();
        double double31 = blockRealMatrix27.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix27.getRowMatrix((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double39 = blockRealMatrix33.walkInColumnOrder(realMatrixChangingVisitor34, 100, (int) (byte) -1, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.5E-323d + "'", double30 == 1.5E-323d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.5E-323d + "'", double31 == 1.5E-323d);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        double double30 = arrayRealVector2.getMaxValue();
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, arrayRealVector36);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        double[] doubleArray44 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, doubleArray44);
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = arrayRealVector40.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        arrayRealVector40.set((double) 1847674149);
        java.lang.String str53 = arrayRealVector40.toString();
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector2.append((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{1,847,674,149}" + "'", str53.equals("{1,847,674,149}"));
        org.junit.Assert.assertNotNull(realVector54);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "{1,847,674,149}", "", "<=", "{100}", "{{1.5430806348},{100},{1.5430806348}}");
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) '#', 1.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.999996f + "'", float2 == 34.999996f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0f));
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        int int5 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray7 = new double[] { 4.9E-324d };
        double[] doubleArray9 = new double[] { 4.9E-324d };
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray15 = array2DRowRealMatrix13.getColumn(0);
        try {
            double[] doubleArray16 = array2DRowRealMatrix0.preMultiply(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        double double21 = arrayRealVector19.getLInfNorm();
        boolean boolean22 = arrayRealVector19.isNaN();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10000.0d + "'", double21 == 10000.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix10.walkInRowOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 52, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 97.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapMultiplyToSelf(0.0d);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.352555865969627d + "'", double1 == 6.352555865969627d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((-0.8414709848078965d), (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 52, 0, 0 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-788545902) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray7, intArray9);
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { (-52), 1, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray9, intArray14);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) intArray9);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException21 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = matrixDimensionMismatchException21.getContext();
        java.lang.Integer[] intArray23 = matrixDimensionMismatchException21.getExpectedDimensions();
        mathArithmeticException16.addSuppressed((java.lang.Throwable) matrixDimensionMismatchException21);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.transpose();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Class<?> wildcardClass7 = arrayRealVector6.getClass();
        double[] doubleArray9 = new double[] { 4.9E-324d };
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[][] doubleArray14 = new double[][] { doubleArray9, doubleArray11, doubleArray13 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray18 = new double[] { 4.9E-324d };
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[][] doubleArray23 = new double[][] { doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix16.add(blockRealMatrix25);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        double[] doubleArray33 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray33);
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray33);
        double[] doubleArray37 = new double[] { 4.9E-324d };
        double[] doubleArray39 = new double[] { 4.9E-324d };
        double[] doubleArray41 = new double[] { 4.9E-324d };
        double[][] doubleArray42 = new double[][] { doubleArray37, doubleArray39, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray45 = array2DRowRealMatrix43.getColumn(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, doubleArray45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector16.mapMultiply((-1.0d));
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        java.lang.Double[] doubleArray36 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, arrayRealVector37);
        java.lang.Class<?> wildcardClass39 = arrayRealVector38.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, (org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector16.mapMultiply(0.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.7224284372420832d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7224284372420832d + "'", double2 == 0.7224284372420832d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.9837179422651126d, (java.lang.Number) 42642.9965834628d, false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(1.3322676295501878E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3322676295501878E-15d + "'", double1 == 1.3322676295501878E-15d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix9.getRowVector(1);
        int int12 = array2DRowRealMatrix9.getRowDimension();
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[] doubleArray16 = new double[] { 4.9E-324d };
        double[] doubleArray18 = new double[] { 4.9E-324d };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        double[] doubleArray23 = new double[] { 4.9E-324d };
        double[] doubleArray25 = new double[] { 4.9E-324d };
        double[] doubleArray27 = new double[] { 4.9E-324d };
        double[][] doubleArray28 = new double[][] { doubleArray23, doubleArray25, doubleArray27 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix21.add(blockRealMatrix30);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        double[] doubleArray38 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray38);
        double[] doubleArray40 = blockRealMatrix31.preMultiply(doubleArray38);
        int int41 = blockRealMatrix31.getRowDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix9, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) 100L, true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double double30 = blockRealMatrix27.getNorm();
        double[][] doubleArray31 = blockRealMatrix27.getData();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.5E-323d + "'", double30 == 1.5E-323d);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        double double30 = arrayRealVector2.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector2.mapAdd((double) (-788545902));
        java.lang.Double[] doubleArray36 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, arrayRealVector40);
        java.lang.Double[] doubleArray43 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        double[] doubleArray48 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector44, doubleArray48);
        java.lang.Double[] doubleArray51 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = arrayRealVector44.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector40.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        java.lang.Double[] doubleArray56 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        double[] doubleArray61 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, doubleArray61);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = arrayRealVector57.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector44, arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector2.combine(55.798810960089604d, 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor69 = null;
        try {
            double double70 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertNotNull(arrayRealVector68);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[][] doubleArray39 = blockRealMatrix38.getData();
        double[] doubleArray41 = new double[] { 4.9E-324d };
        double[] doubleArray43 = new double[] { 4.9E-324d };
        double[] doubleArray45 = new double[] { 4.9E-324d };
        double[][] doubleArray46 = new double[][] { doubleArray41, doubleArray43, doubleArray45 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray49 = array2DRowRealMatrix47.getColumn(0);
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[] doubleArray55 = new double[] { 4.9E-324d };
        double[][] doubleArray56 = new double[][] { doubleArray51, doubleArray53, doubleArray55 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray56);
        double[] doubleArray60 = new double[] { 4.9E-324d };
        double[] doubleArray62 = new double[] { 4.9E-324d };
        double[] doubleArray64 = new double[] { 4.9E-324d };
        double[][] doubleArray65 = new double[][] { doubleArray60, doubleArray62, doubleArray64 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix58.add(blockRealMatrix67);
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = array2DRowRealMatrix47.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix67);
        double double70 = blockRealMatrix67.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix38.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix67);
        double[][] doubleArray72 = blockRealMatrix71.getData();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.5E-323d + "'", double70 == 1.5E-323d);
        org.junit.Assert.assertNotNull(blockRealMatrix71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "<=", "<=", "<=", "hi!", "hi!");
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        java.lang.String str8 = realMatrixFormat6.getColumnSeparator();
        java.lang.String str9 = realMatrixFormat6.getRowSeparator();
        java.lang.String str10 = realMatrixFormat6.getRowSuffix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "<=" + "'", str10.equals("<="));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector9.set((double) 1847674149);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector9.append((double) 1);
        double double24 = arrayRealVector9.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.847674149E9d + "'", double24 == 1.847674149E9d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        int int21 = arrayRealVector20.getMaxIndex();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector20);
        double[] doubleArray23 = arrayRealVector20.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.text.NumberFormat numberFormat10 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat11 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat10);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("{100}", "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}", "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}", "hi!", "{100; 100}", "{100; 100}", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat("<=", "{100}", "hi!", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat14 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat10);
        java.lang.StringBuffer stringBuffer15 = null;
        java.text.FieldPosition fieldPosition16 = null;
        try {
            java.lang.StringBuffer stringBuffer17 = org.apache.commons.math3.util.CompositeFormat.formatDouble(81.4219100018218d, numberFormat10, stringBuffer15, fieldPosition16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        double[] doubleArray27 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray27);
        double double29 = arrayRealVector23.getLInfNorm();
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double[] doubleArray39 = arrayRealVector38.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.154262241479262d + "'", double1 == 14.154262241479262d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (byte) 100, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector6.unitVector();
        arrayRealVector6.unitize();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[][] doubleArray39 = blockRealMatrix38.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor40 = null;
        try {
            double double45 = blockRealMatrix38.walkInOptimizedOrder(realMatrixPreservingVisitor40, (-52), 52, (int) 'a', (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 6.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.0d) + "'", double2 == (-6.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        double[] doubleArray14 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray14);
        double[] doubleArray18 = array2DRowRealMatrix7.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor19 = null;
        try {
            double double20 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixPreservingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        java.lang.String str30 = array2DRowRealMatrix7.toString();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, 32, (int) (short) 0, (int) (short) 0, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str30.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        org.apache.commons.math3.linear.RealVector realVector10 = array2DRowRealMatrix7.getColumnVector(0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector9.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship23 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str24 = relationship23.toString();
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        double[] doubleArray31 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = arrayRealVector27.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint38 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector9, 1.0d, relationship23, (org.apache.commons.math3.linear.RealVector) arrayRealVector35, (double) (-1));
        org.apache.commons.math3.optimization.linear.Relationship relationship39 = linearConstraint38.getRelationship();
        double[] doubleArray41 = new double[] { 4.9E-324d };
        double[] doubleArray43 = new double[] { 4.9E-324d };
        double[] doubleArray45 = new double[] { 4.9E-324d };
        double[][] doubleArray46 = new double[][] { doubleArray41, doubleArray43, doubleArray45 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        double[] doubleArray50 = new double[] { 4.9E-324d };
        double[] doubleArray52 = new double[] { 4.9E-324d };
        double[] doubleArray54 = new double[] { 4.9E-324d };
        double[][] doubleArray55 = new double[][] { doubleArray50, doubleArray52, doubleArray54 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix48.add(blockRealMatrix57);
        double[] doubleArray60 = blockRealMatrix57.getRow(1);
        boolean boolean61 = linearConstraint38.equals((java.lang.Object) doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + relationship23 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship23.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "<=" + "'", str24.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + relationship39 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship39.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        arrayRealVector16.unitize();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        double[] doubleArray27 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray27);
        double double29 = arrayRealVector23.getLInfNorm();
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapAddToSelf(0.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[][] doubleArray11 = array2DRowRealMatrix10.getData();
        double[][] doubleArray12 = array2DRowRealMatrix10.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 32);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.3010299956639813d, 2.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.8813735870195429d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8813735870195429d + "'", double2 == 0.8813735870195429d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        java.lang.Double[] doubleArray30 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        double[] doubleArray35 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = arrayRealVector31.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector31);
        double double42 = arrayRealVector18.getL1Norm();
        boolean boolean43 = array2DRowRealMatrix7.equals((java.lang.Object) double42);
        double[] doubleArray45 = new double[] { 4.9E-324d };
        double[] doubleArray47 = new double[] { 4.9E-324d };
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[][] doubleArray50 = new double[][] { doubleArray45, doubleArray47, doubleArray49 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix53);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor55 = null;
        try {
            double double60 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixPreservingVisitor55, (int) (short) -1, (int) '#', 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) '#');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        java.lang.Double[] doubleArray30 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        double[] doubleArray35 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = arrayRealVector31.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector31);
        double double42 = arrayRealVector18.getL1Norm();
        boolean boolean43 = array2DRowRealMatrix7.equals((java.lang.Object) double42);
        double[] doubleArray45 = new double[] { 4.9E-324d };
        double[] doubleArray47 = new double[] { 4.9E-324d };
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[][] doubleArray50 = new double[][] { doubleArray45, doubleArray47, doubleArray49 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix53);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor55 = null;
        try {
            double double56 = array2DRowRealMatrix7.walkInRowOrder(realMatrixPreservingVisitor55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray10 = array2DRowRealMatrix9.getDataRef();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix9.walkInOptimizedOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double[] doubleArray16 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, doubleArray16);
        java.lang.Double[] doubleArray19 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = arrayRealVector12.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray29 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray29);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = arrayRealVector25.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, arrayRealVector42);
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, arrayRealVector51);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        double[] doubleArray59 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray59);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = arrayRealVector55.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector51.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector39.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        double double67 = arrayRealVector39.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector39.mapAdd((double) (-788545902));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector39);
        int int71 = arrayRealVector39.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector73 = arrayRealVector39.mapAddToSelf(1.5607966601082315d);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector39.getSubVector((int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(arrayRealVector66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.NEGATIVE_INFINITY + "'", double67 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(realVector76);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector9.set((double) 1847674149);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector27);
        java.lang.Double[] doubleArray30 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        double[] doubleArray35 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = arrayRealVector31.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector27.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector41.copy();
        double double43 = arrayRealVector42.getMaxValue();
        double double44 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 10000.0d + "'", double43 == 10000.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.847674149E13d + "'", double44 == 1.847674149E13d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        int int21 = arrayRealVector20.getMaxIndex();
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector27);
        java.lang.Double[] doubleArray30 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, arrayRealVector34);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        double[] doubleArray42 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector38, doubleArray42);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = arrayRealVector38.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        double[] doubleArray55 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, doubleArray55);
        java.lang.Double[] doubleArray58 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = arrayRealVector51.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector38, arrayRealVector51);
        java.lang.String str62 = arrayRealVector38.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector28.append(arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector63.copy();
        java.lang.Double[] doubleArray66 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66);
        java.lang.Double[] doubleArray69 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector67, arrayRealVector70);
        java.lang.Double[] doubleArray73 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        double[] doubleArray78 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector74, doubleArray78);
        java.lang.Double[] doubleArray81 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray81);
        org.apache.commons.math3.linear.RealMatrix realMatrix83 = arrayRealVector74.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = arrayRealVector70.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector74.append((double) (-1));
        org.apache.commons.math3.linear.RealMatrix realMatrix87 = arrayRealVector64.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20, arrayRealVector74);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "{100}" + "'", str62.equals("{100}"));
        org.junit.Assert.assertNotNull(arrayRealVector63);
        org.junit.Assert.assertNotNull(arrayRealVector64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(realMatrix83);
        org.junit.Assert.assertNotNull(arrayRealVector84);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(realMatrix87);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 1.5430806348152437d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (short) 100, false);
        double[] doubleArray16 = pointValuePair15.getKey();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray2 = new double[] { (short) 1, 3.732511156817248d };
        double[] doubleArray5 = new double[] { (short) 1, 3.732511156817248d };
        double[] doubleArray8 = new double[] { (short) 1, 3.732511156817248d };
        double[] doubleArray11 = new double[] { (short) 1, 3.732511156817248d };
        double[] doubleArray14 = new double[] { (short) 1, 3.732511156817248d };
        double[] doubleArray17 = new double[] { (short) 1, 3.732511156817248d };
        double[][] doubleArray18 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        double[] doubleArray80 = new double[] { 4.9E-324d };
        double[] doubleArray82 = new double[] { 4.9E-324d };
        double[] doubleArray84 = new double[] { 4.9E-324d };
        double[][] doubleArray85 = new double[][] { doubleArray80, doubleArray82, doubleArray84 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math3.linear.RealMatrix realMatrix87 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray85);
        try {
            blockRealMatrix76.setSubMatrix(doubleArray85, 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realMatrix87);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (byte) 10, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>> arrayRealVectorPair2 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>>(arrayRealVector0, (java.lang.Comparable<java.lang.String>) "");
        java.lang.Object obj3 = null;
        boolean boolean4 = arrayRealVectorPair2.equals(obj3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVectorPair2.getKey();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(arrayRealVector5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("hi!", (int) '#');
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((-52), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -52 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) matrixDimensionMismatchException4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double double30 = blockRealMatrix27.getNorm();
        double double31 = blockRealMatrix27.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix27.getRowMatrix((int) (short) 1);
        double double34 = blockRealMatrix27.getNorm();
        try {
            blockRealMatrix27.addToEntry((int) (byte) 100, (int) '4', 6.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.5E-323d + "'", double30 == 1.5E-323d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.5E-323d + "'", double31 == 1.5E-323d);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.5E-323d + "'", double34 == 1.5E-323d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix(obj0, "{{100,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,10,0},{0,0,0,0,1.5430806348}}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 100L, (-126.99999f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 1847674149L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2247997404034294E7d + "'", double1 == 3.2247997404034294E7d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) (-52), false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooLargeException3.getContext();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector5.mapDivide(2.4013321812311688d);
        double[] doubleArray32 = arrayRealVector5.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 32, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.0d + "'", double2 == 30.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        java.lang.String str1 = realMatrixFormat0.getRowSuffix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double2 = arrayRealVector1.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector1.mapDivide((double) (-1.0f));
        java.lang.String str5 = realVectorFormat0.format(realVector4);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray20 = arrayRealVector19.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double23 = array2DRowRealMatrix22.getNorm();
        double double24 = array2DRowRealMatrix22.getNorm();
        int int25 = array2DRowRealMatrix22.getRowDimension();
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math3.optimization.linear.Relationship relationship79 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str80 = relationship79.toString();
        java.lang.String str81 = relationship79.toString();
        boolean boolean82 = blockRealMatrix17.equals((java.lang.Object) relationship79);
        org.apache.commons.math3.linear.RealMatrix realMatrix83 = blockRealMatrix17.transpose();
        int int84 = blockRealMatrix17.getRowDimension();
        double double85 = blockRealMatrix17.getNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertTrue("'" + relationship79 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship79.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "<=" + "'", str80.equals("<="));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "<=" + "'", str81.equals("<="));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(realMatrix83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 3 + "'", int84 == 3);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.5E-323d + "'", double85 == 1.5E-323d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (-52), (double) 3, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        double[] doubleArray25 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray25);
        double[] doubleArray27 = blockRealMatrix18.preMultiply(doubleArray25);
        double[] doubleArray33 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-788545902), (java.lang.Number) 2.6881171418161356E43d, true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        boolean boolean19 = blockRealMatrix17.isTransposable();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix17.copy();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "<=", "<=", "<=", "hi!", "hi!");
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        java.lang.String str8 = realMatrixFormat6.getColumnSeparator();
        java.lang.String str9 = realMatrixFormat6.getRowSuffix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<=" + "'", str9.equals("<="));
    }
}

