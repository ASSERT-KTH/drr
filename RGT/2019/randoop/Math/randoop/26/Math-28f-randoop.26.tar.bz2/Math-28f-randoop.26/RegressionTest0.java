import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.RealVector realVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, realVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.text.NumberFormat numberFormat0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math3.util.FastMath.rint((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(10.000000000000002d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.000000000000004d + "'", double2 == 20.000000000000004d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (byte) 0, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1847674149 + "'", int1 == 1847674149);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-788545902) + "'", int1 == (-788545902));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        double[] doubleArray7 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, doubleArray7);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = arrayRealVector3.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) 'a', (-788545902), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction20 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector9.map(univariateFunction20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) '#', 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 100, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "<=", "<=", "<=", "hi!", "hi!");
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = null;
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        try {
            java.lang.StringBuffer stringBuffer10 = realMatrixFormat6.format(realMatrix7, stringBuffer8, fieldPosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math3.util.FastMath.exp(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806754d + "'", double1 == 22026.465794806754d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        double[] doubleArray7 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, doubleArray7);
        try {
            double[] doubleArray9 = array2DRowRealMatrix0.preMultiply(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, 0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.apache.commons.math3.optimization.linear.AbstractLinearOptimizer.DEFAULT_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.multiplyEntry(100, 10, (double) (-788545902));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector11);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor17 = null;
        try {
            double double18 = arrayRealVector16.walkInOptimizedOrder(realVectorChangingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math3.util.FastMath.rint(22026.465794806754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.0d + "'", double1 == 22026.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, arrayRealVector13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        double[] doubleArray21 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray21);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector13.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        arrayRealVector17.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector6.append(arrayRealVector17);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector30);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException5 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 100.0f, (java.lang.Object[]) doubleArray3);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable7, (java.lang.Number) 100.0f, (java.lang.Object[]) doubleArray10);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException5, localizable6, (java.lang.Object[]) doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealVector realVector2 = array2DRowRealMatrix0.getRowVector(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) -1, 1847674149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("hi!", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 1847674149);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9738729699514619d + "'", double1 == 0.9738729699514619d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int[] intArray1 = null;
        int[] intArray6 = new int[] { 0, (byte) 10, (-788545902), (byte) 1 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.getSubMatrix(intArray1, intArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int[] intArray3 = new int[] { (-1) };
        int[] intArray6 = new int[] { 100, 1847674149 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.getSubMatrix(intArray3, intArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        double[] doubleArray26 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray26);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = arrayRealVector22.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector22);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor33 = null;
        try {
            double double34 = arrayRealVector22.walkInDefaultOrder(realVectorChangingVisitor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix31);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1, (-788545902), (int) ' ', (-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-788,545,902)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, arrayRealVector7);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        double[] doubleArray15 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray15);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = arrayRealVector11.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        arrayRealVector11.set((double) 1847674149);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.optimization.linear.UnboundedSolutionException unboundedSolutionException0 = new org.apache.commons.math3.optimization.linear.UnboundedSolutionException();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math3.util.FastMath.acos(1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector9.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship23 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str24 = relationship23.toString();
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        double[] doubleArray31 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = arrayRealVector27.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint38 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector9, 1.0d, relationship23, (org.apache.commons.math3.linear.RealVector) arrayRealVector35, (double) (-1));
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor39 = null;
        try {
            double double42 = arrayRealVector35.walkInDefaultOrder(realVectorPreservingVisitor39, (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + relationship23 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship23.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "<=" + "'", str24.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.optimization.GoalType goalType0 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor30 = null;
        try {
            double double33 = arrayRealVector29.walkInDefaultOrder(realVectorChangingVisitor30, 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, (int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int21 = arrayRealVector20.getMinIndex();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector20.mapAddToSelf((double) ' ');
        try {
            double double24 = arrayRealVector9.dotProduct(realVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5 };
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray6, 6, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 6 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Object obj0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkNotNull(obj0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, arrayRealVector13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        double[] doubleArray21 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray21);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector13.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        arrayRealVector17.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship31 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str32 = relationship31.toString();
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        double[] doubleArray39 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, doubleArray39);
        java.lang.Double[] doubleArray42 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = arrayRealVector35.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint46 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector17, 1.0d, relationship31, (org.apache.commons.math3.linear.RealVector) arrayRealVector43, (double) (-1));
        org.apache.commons.math3.optimization.linear.Relationship relationship47 = linearConstraint46.getRelationship();
        java.lang.Double[] doubleArray49 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        double[] doubleArray54 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, doubleArray54);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray54);
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint58 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 10L, relationship47, doubleArray54, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + relationship31 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship31.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "<=" + "'", str32.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertTrue("'" + relationship47 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship47.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix56);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 'a', 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 10L, (double) 0L, Double.NaN);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 10L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.optimization.GoalType goalType0 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        org.apache.commons.math3.linear.RealVector realVector1 = null;
        try {
            java.lang.String str2 = realVectorFormat0.format(realVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double13 = arrayRealVector12.getMaxValue();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int[] intArray5 = new int[] { 1, (short) 0, (byte) -1, 0 };
        int[] intArray9 = new int[] { 52, '4', 100 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix0.getSubMatrix(intArray5, intArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), false);
        org.apache.commons.math3.optimization.linear.Relationship relationship12 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str13 = relationship12.toString();
        double[] doubleArray14 = new double[] {};
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint16 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (-1.0d), relationship12, doubleArray14, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship12 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship12.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "<=" + "'", str13.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray7 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray7);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix0.preMultiply(realMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math3.util.FastMath.log10(20.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3010299956639813d + "'", double1 == 1.3010299956639813d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        java.lang.String str30 = arrayRealVector5.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int32 = arrayRealVector31.getMinIndex();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector31.mapMultiplyToSelf((-1.0d));
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector5.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{100}" + "'", str30.equals("{100}"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("<=", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector0.mapDivide((double) (-1.0f));
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        double[] doubleArray10 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray10);
        double double12 = arrayRealVector6.getLInfNorm();
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector15.mapSubtract(0.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector0.ebeMultiply(realVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (short) 10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray8 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        try {
            array2DRowRealMatrix0.setColumn((int) (byte) 0, doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) (-52), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        int[] intArray14 = new int[] { 100, (short) 100, 0, 52, (byte) -1 };
        int[] intArray21 = new int[] { (-1), (short) -1, (short) 0, (byte) 10, 100, (-1) };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix8, intArray14, intArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 10.0f, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.0d + "'", double2 == 20.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray7 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray7);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix0.multiply(realMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray7 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray7);
        try {
            double[] doubleArray10 = array2DRowRealMatrix0.operate(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(20.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7144176165949068d + "'", double1 == 2.7144176165949068d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(10);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix7, (org.apache.commons.math3.linear.AnyMatrix) realMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) (-788545902));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.preMultiply(realMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(572.9577951308232d, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 572.9577951308232d + "'", double2 == 572.9577951308232d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getMaxValue();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor2 = null;
        try {
            double double5 = arrayRealVector0.walkInOptimizedOrder(realVectorChangingVisitor2, (-788545902), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-788,545,902)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double2 = org.apache.commons.math3.util.Precision.round(0.0d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int4 = arrayRealVector3.getMinIndex();
        double double5 = arrayRealVector3.getL1Norm();
        try {
            array2DRowRealMatrix0.setRowVector((-1), (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector17 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector11.subtract(realVector17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) -1, (float) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = array2DRowRealMatrix7.getColumnVector((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        double double30 = arrayRealVector2.getMaxValue();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor31 = null;
        try {
            double double32 = arrayRealVector2.walkInDefaultOrder(realVectorPreservingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 10, 52, 0, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-788545902) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray6, intArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) intArray8);
        java.lang.Throwable[] throwableArray11 = mathIllegalStateException10.getSuppressed();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        try {
            double double13 = arrayRealVector2.getEntry((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2, (int) (byte) 0, 0, (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, arrayRealVector7);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        double[] doubleArray15 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray15);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = arrayRealVector11.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector21.copy();
        try {
            array2DRowRealMatrix0.setColumnVector(10, (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 10, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.power((-788545902));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: p must be >= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector21);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray29 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray29);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = arrayRealVector25.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector21.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        arrayRealVector25.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector14.append(arrayRealVector25);
        try {
            org.apache.commons.math3.linear.RealVector realVector39 = array2DRowRealMatrix7.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(arrayRealVector38);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[] doubleArray16 = new double[] { 4.9E-324d };
        double[] doubleArray18 = new double[] { 4.9E-324d };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        try {
            array2DRowRealMatrix7.copySubMatrix((int) (byte) 10, (int) '#', (int) (short) 0, 1, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double3 = arrayRealVector2.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector2.mapDivide((double) (-1.0f));
        try {
            array2DRowRealMatrix0.setColumnVector((int) (byte) 10, (org.apache.commons.math3.linear.RealVector) arrayRealVector2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double[] doubleArray0 = null;
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        double[] doubleArray7 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 1847674149, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0000005f + "'", float1 == 6.0000005f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        java.lang.String str9 = realMatrixFormat0.format(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{{100,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,10,0},{0,0,0,0,1.5430806348}}" + "'", str9.equals("{{100,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,10,0},{0,0,0,0,1.5430806348}}"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, number1, (java.lang.Number) 0.0d, false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(1.0d, 2.2250738585072014E-308d, (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double[] doubleArray16 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, doubleArray16);
        java.lang.Double[] doubleArray19 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = arrayRealVector12.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray29 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray29);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = arrayRealVector25.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, arrayRealVector42);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        double[] doubleArray50 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector46, doubleArray50);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = arrayRealVector46.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        arrayRealVector46.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship60 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str61 = relationship60.toString();
        java.lang.Double[] doubleArray63 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        double[] doubleArray68 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector64, doubleArray68);
        java.lang.Double[] doubleArray71 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray71);
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = arrayRealVector64.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint75 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector46, 1.0d, relationship60, (org.apache.commons.math3.linear.RealVector) arrayRealVector72, (double) (-1));
        try {
            double double76 = arrayRealVector36.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertTrue("'" + relationship60 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship60.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "<=" + "'", str61.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor2, 6, 1, (-127), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 6, (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math3.util.FastMath.log(20.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9957322735539913d + "'", double1 == 2.9957322735539913d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        try {
            double double5 = array2DRowRealMatrix0.getEntry((int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray16 = new double[] { 1.4210854715202004E-14d, 20.0d, 0.9738729699514619d, 10, (byte) 100, (short) 1 };
        try {
            blockRealMatrix8.setRow(1847674149, doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,847,674,149)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(2.2250738585072014E-308d, 1.3010299956639813d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.225073858507202E-308d + "'", double2 == 2.225073858507202E-308d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = blockRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor9, 0, (int) ' ', (int) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int1 = arrayRealVector0.getMinIndex();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor2 = null;
        try {
            double double5 = arrayRealVector0.walkInOptimizedOrder(realVectorChangingVisitor2, (-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction20 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector19.map(univariateFunction20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 100.0d);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        try {
            int int7 = matrixDimensionMismatchException4.getWrongDimension(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        try {
            int int7 = matrixDimensionMismatchException4.getWrongDimension((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.7182818284590453d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) '4');
        boolean boolean3 = arrayRealVector2.isNaN();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor30 = null;
        try {
            double double31 = arrayRealVector5.walkInOptimizedOrder(realVectorChangingVisitor30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException noFeasibleSolutionException0 = new org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException();
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        double[] doubleArray9 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray9);
        double double11 = arrayRealVector5.getLInfNorm();
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5, arrayRealVector14);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        java.lang.Object[] objArray25 = new java.lang.Object[] { (short) 10, arrayRealVector14, (short) 10, "", arrayRealVector24 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray25);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException27 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray25);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext28 = mathArithmeticException27.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext29 = mathArithmeticException27.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext30 = mathArithmeticException27.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = mathArithmeticException27.getContext();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(exceptionContext28);
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertNotNull(exceptionContext30);
        org.junit.Assert.assertNotNull(exceptionContext31);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector2.mapToSelf(univariateFunction17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix9.getRowVector(1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = array2DRowRealMatrix9.walkInRowOrder(realMatrixChangingVisitor12, (int) (byte) 1, (-1), 0, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, arrayRealVector13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        double[] doubleArray21 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray21);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector13.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        arrayRealVector17.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector6.append(arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector17.mapMultiply((-1.0d));
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix0, realVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector15);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, arrayRealVector24);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        double[] doubleArray32 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, doubleArray32);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector28.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector24.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector12.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double double40 = arrayRealVector12.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector12.mapAdd((double) (-788545902));
        try {
            org.apache.commons.math3.linear.RealVector realVector43 = array2DRowRealMatrix9.operateTranspose(realVector42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.NEGATIVE_INFINITY + "'", double40 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (int) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) (byte) 1, (int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 32, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 0, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 1847674149);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.03034064887984d + "'", double1 == 22.03034064887984d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 'a', 20.000000000000004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.437943429267561E39d + "'", double2 == 5.437943429267561E39d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = new double[] { 4.9E-324d };
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[][] doubleArray14 = new double[][] { doubleArray9, doubleArray11, doubleArray13 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray18 = new double[] { 4.9E-324d };
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[][] doubleArray23 = new double[][] { doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix16.add(blockRealMatrix25);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix7.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, arrayRealVector25);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, arrayRealVector32);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        double[] doubleArray40 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, doubleArray40);
        java.lang.Double[] doubleArray43 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = arrayRealVector36.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector32.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        arrayRealVector36.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector25.append(arrayRealVector36);
        java.lang.Double[] doubleArray51 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector52, arrayRealVector55);
        java.lang.Double[] doubleArray58 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58);
        java.lang.Double[] doubleArray61 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector59, arrayRealVector62);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65);
        double[] doubleArray70 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector66, doubleArray70);
        java.lang.Double[] doubleArray73 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = arrayRealVector66.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector62.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        arrayRealVector66.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector55.append(arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector36.append((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector36.append((double) (-1.0f));
        try {
            blockRealMatrix8.setColumnVector((-788545902), realVector82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-788,545,902)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(arrayRealVector79);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector82);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        double[] doubleArray26 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray26);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = arrayRealVector22.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector22);
        double double33 = arrayRealVector9.getL1Norm();
        try {
            arrayRealVector9.setEntry((int) (byte) 100, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int2 = org.apache.commons.math3.util.FastMath.max(52, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[] doubleArray7 = new double[] { 4.9E-324d };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(1, 10, doubleArray8, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "<=", "<=", "<=", "hi!", "hi!");
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        java.lang.String str8 = realMatrixFormat6.getColumnSeparator();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = realMatrixFormat6.parse("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"Array2DRowRealMatrix{{0.0},{0.0},{0.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double[] doubleArray32 = new double[] { 4.9E-324d };
        double[] doubleArray34 = new double[] { 4.9E-324d };
        double[] doubleArray36 = new double[] { 4.9E-324d };
        double[][] doubleArray37 = new double[][] { doubleArray32, doubleArray34, doubleArray36 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        double[] doubleArray40 = array2DRowRealMatrix38.getColumn(0);
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[] doubleArray46 = new double[] { 4.9E-324d };
        double[][] doubleArray47 = new double[][] { doubleArray42, doubleArray44, doubleArray46 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray47);
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[] doubleArray55 = new double[] { 4.9E-324d };
        double[][] doubleArray56 = new double[][] { doubleArray51, doubleArray53, doubleArray55 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix49.add(blockRealMatrix58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = array2DRowRealMatrix38.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix58);
        try {
            blockRealMatrix27.setRowMatrix((int) (byte) 10, blockRealMatrix58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertNotNull(realMatrix60);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        double[] doubleArray28 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, doubleArray28);
        double double30 = arrayRealVector24.getLInfNorm();
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24, arrayRealVector33);
        arrayRealVector19.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, true);
        java.lang.Double[] doubleArray44 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, arrayRealVector48);
        java.lang.Double[] doubleArray51 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        double[] doubleArray56 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector52, doubleArray56);
        java.lang.Double[] doubleArray59 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = arrayRealVector52.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector48.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        double[] doubleArray69 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector65, doubleArray69);
        java.lang.Double[] doubleArray72 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray72);
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = arrayRealVector65.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector52, arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, arrayRealVector75);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector19.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix74);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        double[] doubleArray8 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        java.lang.String str11 = realMatrixFormat0.format(realMatrix10);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{{1.5430806348},{100},{1.5430806348}}" + "'", str11.equals("{{1.5430806348},{100},{1.5430806348}}"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[] doubleArray7 = new double[] { 4.9E-324d };
        double[] doubleArray9 = new double[] { 4.9E-324d };
        double[][] doubleArray10 = new double[][] { doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn(0);
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[] doubleArray17 = new double[] { 4.9E-324d };
        double[] doubleArray19 = new double[] { 4.9E-324d };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[] doubleArray26 = new double[] { 4.9E-324d };
        double[] doubleArray28 = new double[] { 4.9E-324d };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix22.add(blockRealMatrix31);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix0.multiply(realMatrix33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        double[] doubleArray2 = new double[] { 4.9E-324d };
        double[] doubleArray4 = new double[] { 4.9E-324d };
        double[] doubleArray6 = new double[] { 4.9E-324d };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray7);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix9.add(blockRealMatrix18);
        java.lang.StringBuffer stringBuffer20 = null;
        java.text.FieldPosition fieldPosition21 = null;
        try {
            java.lang.StringBuffer stringBuffer22 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix19, stringBuffer20, fieldPosition21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        try {
            blockRealMatrix27.multiplyEntry((int) (short) 0, 1, 22026.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 52, 22026.465794806754d, (double) 6.0000005f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(0L, (long) (-52));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        java.lang.String str1 = mathIllegalStateException0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math3.exception.MathIllegalStateException: illegal state" + "'", str1.equals("org.apache.commons.math3.exception.MathIllegalStateException: illegal state"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 10.0f, 2.2250738585072014E-308d, 22026.465794806754d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) 1847674149);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        java.lang.Double[] doubleArray40 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        try {
            org.apache.commons.math3.linear.RealVector realVector42 = blockRealMatrix38.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>> arrayRealVectorPair2 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>>(arrayRealVector0, (java.lang.Comparable<java.lang.String>) "");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVectorPair2.getKey();
        org.junit.Assert.assertNull(arrayRealVector3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(22026.465794806754d, 0.0d, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray21 = new double[] { 4.9E-324d };
        double[] doubleArray23 = new double[] { 4.9E-324d };
        double[] doubleArray25 = new double[] { 4.9E-324d };
        double[][] doubleArray26 = new double[][] { doubleArray21, doubleArray23, doubleArray25 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray26);
        double[] doubleArray30 = new double[] { 4.9E-324d };
        double[] doubleArray32 = new double[] { 4.9E-324d };
        double[] doubleArray34 = new double[] { 4.9E-324d };
        double[][] doubleArray35 = new double[][] { doubleArray30, doubleArray32, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix28.add(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix37.subtract(blockRealMatrix57);
        try {
            blockRealMatrix18.setRowMatrix((int) (byte) -1, blockRealMatrix58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[] doubleArray35 = new double[] { 4.9E-324d };
        double[][] doubleArray36 = new double[][] { doubleArray31, doubleArray33, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix38.add(blockRealMatrix47);
        double[] doubleArray50 = new double[] { 4.9E-324d };
        double[] doubleArray52 = new double[] { 4.9E-324d };
        double[] doubleArray54 = new double[] { 4.9E-324d };
        double[][] doubleArray55 = new double[][] { doubleArray50, doubleArray52, doubleArray54 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray55);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix57.add(blockRealMatrix66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix47.subtract(blockRealMatrix67);
        double[][] doubleArray69 = blockRealMatrix68.getData();
        try {
            array2DRowRealMatrix7.setSubMatrix(doubleArray69, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int31 = arrayRealVector30.getMinIndex();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction32 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector30.mapToSelf(univariateFunction32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector30.mapDivide(0.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector16.subtract(realVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(realVector35);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix38.getColumnMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix17.add(realMatrix19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        double[] doubleArray10 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray10);
        double double12 = arrayRealVector6.getLInfNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector11.mapSubtract(0.0d);
        java.io.ObjectOutputStream objectOutputStream19 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector11, objectOutputStream19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (-127), 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-126.99999f) + "'", float2 == (-126.99999f));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector9.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship23 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str24 = relationship23.toString();
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        double[] doubleArray31 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = arrayRealVector27.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint38 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector9, 1.0d, relationship23, (org.apache.commons.math3.linear.RealVector) arrayRealVector35, (double) (-1));
        org.apache.commons.math3.optimization.linear.Relationship relationship39 = linearConstraint38.getRelationship();
        org.apache.commons.math3.linear.RealVector realVector40 = linearConstraint38.getCoefficients();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + relationship23 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship23.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "<=" + "'", str24.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + relationship39 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship39.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        try {
            org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector5.getSubVector((int) (short) -1, (-788545902));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of elements should be positive (-788,545,902)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) '#', (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.util.MathUtils.checkFinite(1.4210854715202004E-14d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat11 = new org.apache.commons.math3.linear.RealMatrixFormat();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = realMatrixFormat11.parse("{{1.5430806348},{100},{1.5430806348}}");
        try {
            array2DRowRealMatrix7.setRowMatrix((int) '#', realMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0023450509582335632d + "'", double0 == 0.0023450509582335632d);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(1.7182818284590453d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (-1.0f), true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapAdd((double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix(52, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -52 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        float float1 = org.apache.commons.math3.util.FastMath.signum(6.0000005f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        double[] doubleArray36 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray36);
        try {
            double[] doubleArray40 = blockRealMatrix27.operate(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        double[] doubleArray14 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair19 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair21 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, 1.5430806348152437d);
        try {
            double[] doubleArray22 = array2DRowRealMatrix7.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix7.getSubMatrix(0, (int) (short) -1, 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor1, (int) (short) 100, (int) 'a', (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("{", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        java.lang.Double[] doubleArray40 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        double[] doubleArray45 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, doubleArray45);
        java.lang.Double[] doubleArray48 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = arrayRealVector41.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix37.add(realMatrix50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix50);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int2 = org.apache.commons.math3.util.FastMath.min((-788545902), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-788545902) + "'", int2 == (-788545902));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix18.power((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (3x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9738729699514619d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55.798810960089604d + "'", double1 == 55.798810960089604d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(4.9E-324d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        double[] doubleArray10 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray10);
        double double12 = arrayRealVector6.getLInfNorm();
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector15.mapSubtract(0.0d);
        try {
            array2DRowRealMatrix0.setRowVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray43 = new double[] { 10.0f, 1L, 0.0f, 1.1102230246251565E-16d };
        double[][] doubleArray44 = new double[][] { doubleArray43 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 1x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 1.5430806348152437d);
        double[] doubleArray13 = pointValuePair12.getKey();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.5707963267948966d, 22026.0d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor39 = null;
        try {
            double double40 = blockRealMatrix37.walkInRowOrder(realMatrixChangingVisitor39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, true);
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector9);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        double[] doubleArray17 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = arrayRealVector13.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector9.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        double[] doubleArray30 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray30);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = arrayRealVector26.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector13, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector36);
        java.lang.String str38 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = realVectorFormat0.parse("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"Array2DRowRealMatrix{{0.0},{0.0},{0.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{100; 100}" + "'", str38.equals("{100; 100}"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray4 = new double[] { 10.0f, 1L, 0.0f, 1.1102230246251565E-16d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[] doubleArray12 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair19 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, 1.5430806348152437d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (short) 100, false);
        try {
            double[] doubleArray23 = array2DRowRealMatrix6.operate(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        double[] doubleArray28 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, doubleArray28);
        double double30 = arrayRealVector24.getLInfNorm();
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24, arrayRealVector33);
        arrayRealVector19.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor40 = null;
        try {
            double double41 = arrayRealVector24.walkInDefaultOrder(realVectorPreservingVisitor40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double41 = array2DRowRealMatrix40.getNorm();
        try {
            blockRealMatrix37.setRowMatrix((int) '#', (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor30 = null;
        try {
            double double31 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        int[] intArray41 = new int[] { (byte) 100, (-1) };
        int[] intArray44 = new int[] { 1847674149, 1 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix45 = blockRealMatrix37.getSubMatrix(intArray41, intArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix8.getRowMatrix((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix9.walkInColumnOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        try {
            double[] doubleArray4 = array2DRowRealMatrix0.getColumn((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix(obj0, "{100}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector11);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        double[] doubleArray30 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray30);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = arrayRealVector26.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector22.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector36.copy();
        double double38 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        boolean boolean39 = arrayRealVector2.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 9900.0d + "'", double38 == 9900.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(Double.NEGATIVE_INFINITY, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        try {
            double[] doubleArray80 = blockRealMatrix76.getColumn((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        try {
            double double11 = array2DRowRealMatrix7.getEntry((int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double[] doubleArray16 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, doubleArray16);
        java.lang.Double[] doubleArray19 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = arrayRealVector12.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray29 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray29);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = arrayRealVector25.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector35);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor37 = null;
        try {
            double double38 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>> arrayRealVectorPair2 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>>(arrayRealVector0, (java.lang.Comparable<java.lang.String>) "");
        java.lang.Comparable<java.lang.String> strComparable3 = arrayRealVectorPair2.getSecond();
        org.junit.Assert.assertTrue("'" + strComparable3 + "' != '" + "" + "'", strComparable3.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 100L, (float) (-127), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 100.0d, false);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray20);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector28);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        double[] doubleArray36 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray36);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = arrayRealVector32.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector28.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        arrayRealVector32.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship46 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str47 = relationship46.toString();
        java.lang.Double[] doubleArray49 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        double[] doubleArray54 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, doubleArray54);
        java.lang.Double[] doubleArray57 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray57);
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = arrayRealVector50.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint61 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector32, 1.0d, relationship46, (org.apache.commons.math3.linear.RealVector) arrayRealVector58, (double) (-1));
        org.apache.commons.math3.optimization.linear.Relationship relationship62 = linearConstraint61.getRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint64 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray20, relationship62, 0.0d);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint66 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, relationship62, (double) 1.1920929E-7f);
        java.io.ObjectInputStream objectInputStream68 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) linearConstraint66, "", objectInputStream68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + relationship46 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship46.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "<=" + "'", str47.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertTrue("'" + relationship62 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship62.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        try {
            double[] doubleArray21 = blockRealMatrix18.getRow((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (short) 10, (long) (-127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat3 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        boolean boolean30 = array2DRowRealMatrix7.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) (-1), false);
        double[] doubleArray21 = pointValuePair20.getFirst();
        double[] doubleArray22 = pointValuePair20.getKey();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray22);
        try {
            blockRealMatrix8.setRowMatrix(100, realMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(1.5430806348152437d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException5 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (short) 0, (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor30 = null;
        try {
            double double33 = arrayRealVector29.walkInOptimizedOrder(realVectorPreservingVisitor30, (int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("{100; 100}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int1 = arrayRealVector0.getMinIndex();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector0.mapToSelf(univariateFunction2);
        boolean boolean4 = arrayRealVector0.isInfinite();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor5 = null;
        try {
            double double8 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor5, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1.0f), 1.5430806348152437d, (double) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7224284372420832d + "'", double1 == 0.7224284372420832d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix76, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int21 = arrayRealVector20.getMinIndex();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector20.mapAddToSelf((double) ' ');
        org.apache.commons.math3.linear.RealVector realVector25 = realVector23.mapSubtract(20.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector5.ebeMultiply(realVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor39 = null;
        try {
            double double40 = blockRealMatrix38.walkInOptimizedOrder(realMatrixPreservingVisitor39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(10);
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[] doubleArray7 = new double[] { 4.9E-324d };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[] doubleArray16 = new double[] { 4.9E-324d };
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray14, doubleArray16 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix10.add(blockRealMatrix19);
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[] doubleArray26 = new double[] { 4.9E-324d };
        double[][] doubleArray27 = new double[][] { doubleArray22, doubleArray24, doubleArray26 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray27);
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[] doubleArray35 = new double[] { 4.9E-324d };
        double[][] doubleArray36 = new double[][] { doubleArray31, doubleArray33, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix29.add(blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix19.subtract(blockRealMatrix39);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix1, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x10 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double12 = array2DRowRealMatrix11.getNorm();
        double double13 = array2DRowRealMatrix11.getNorm();
        double double14 = array2DRowRealMatrix11.getNorm();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = array2DRowRealMatrix10.multiply(array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 22026.465794806754d, (java.lang.Number) 0.0023450509582335632d, (java.lang.Number) 1.5430806348152437d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        double[] doubleArray27 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray27);
        double double29 = arrayRealVector23.getLInfNorm();
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector32.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor40 = null;
        try {
            double double43 = arrayRealVector39.walkInDefaultOrder(realVectorPreservingVisitor40, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector39);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 52, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "<=", "<=", "<=", "hi!", "hi!");
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        java.lang.String str8 = realMatrixFormat6.getColumnSeparator();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = realMatrixFormat6.parse("{");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"{\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix9.getRowVector(1);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.preMultiply(realMatrix12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double[] doubleArray11 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix0.subtract(realMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double31 = array2DRowRealMatrix30.getNorm();
        double double32 = array2DRowRealMatrix30.getNorm();
        int int33 = array2DRowRealMatrix30.getRowDimension();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = array2DRowRealMatrix7.subtract(array2DRowRealMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix7.getSubMatrix((int) '4', 0, 100, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 52, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        try {
            org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix17.getColumnVector(1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.setRowMatrix((int) (short) 1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0d, 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector5.mapDivideToSelf(0.0023450509582335632d);
        double double22 = realVector21.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 42642.9965834628d + "'", double22 == 42642.9965834628d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix7.walkInRowOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210804127942926d + "'", double1 == 1.4210804127942926d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double double30 = blockRealMatrix27.getNorm();
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[] doubleArray35 = new double[] { 4.9E-324d };
        double[] doubleArray37 = new double[] { 4.9E-324d };
        double[][] doubleArray38 = new double[][] { doubleArray33, doubleArray35, doubleArray37 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray38);
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[] doubleArray46 = new double[] { 4.9E-324d };
        double[][] doubleArray47 = new double[][] { doubleArray42, doubleArray44, doubleArray46 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix40.add(blockRealMatrix49);
        double double51 = blockRealMatrix50.getFrobeniusNorm();
        try {
            blockRealMatrix27.setRowMatrix((int) '#', (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.5E-323d + "'", double30 == 1.5E-323d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        int int21 = arrayRealVector20.getMaxIndex();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int24 = arrayRealVector23.getMinIndex();
        double double25 = arrayRealVector23.getL1Norm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20, arrayRealVector23);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix18.getColumnMatrix((-788545902));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-788,545,902)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 6.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (-1), (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double[] doubleArray16 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, doubleArray16);
        java.lang.Double[] doubleArray19 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = arrayRealVector12.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray29 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray29);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = arrayRealVector25.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector2.mapSubtractToSelf(22.03034064887984d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 6, (-52));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3322676295501878E-15d + "'", double2 == 1.3322676295501878E-15d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix9.walkInColumnOrder(realMatrixChangingVisitor10, 1847674149, (-52), 1847674149, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,847,674,149)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[] doubleArray7 = new double[] { 4.9E-324d };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[] doubleArray16 = new double[] { 4.9E-324d };
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray14, doubleArray16 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix10.add(blockRealMatrix19);
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[] doubleArray26 = new double[] { 4.9E-324d };
        double[][] doubleArray27 = new double[][] { doubleArray22, doubleArray24, doubleArray26 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray27);
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[] doubleArray35 = new double[] { 4.9E-324d };
        double[][] doubleArray36 = new double[][] { doubleArray31, doubleArray33, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix29.add(blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix19.subtract(blockRealMatrix39);
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[] doubleArray46 = new double[] { 4.9E-324d };
        double[][] doubleArray47 = new double[][] { doubleArray42, doubleArray44, doubleArray46 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray47);
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[] doubleArray55 = new double[] { 4.9E-324d };
        double[][] doubleArray56 = new double[][] { doubleArray51, doubleArray53, doubleArray55 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix49.add(blockRealMatrix58);
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[] doubleArray65 = new double[] { 4.9E-324d };
        double[][] doubleArray66 = new double[][] { doubleArray61, doubleArray63, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray66);
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[] doubleArray74 = new double[] { 4.9E-324d };
        double[][] doubleArray75 = new double[][] { doubleArray70, doubleArray72, doubleArray74 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix68.add(blockRealMatrix77);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix79 = blockRealMatrix58.subtract(blockRealMatrix78);
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = blockRealMatrix19.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix78);
        java.lang.StringBuffer stringBuffer81 = null;
        java.text.FieldPosition fieldPosition82 = null;
        try {
            java.lang.StringBuffer stringBuffer83 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix78, stringBuffer81, fieldPosition82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(blockRealMatrix79);
        org.junit.Assert.assertNotNull(realMatrix80);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1847674149);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1847674112 + "'", int1 == 1847674112);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math3.util.FastMath.sin(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.225073858507202E-308d + "'", double1 == 2.225073858507202E-308d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        java.lang.String str30 = arrayRealVector5.toString();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor31 = null;
        try {
            double double32 = arrayRealVector5.walkInDefaultOrder(realVectorPreservingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{100}" + "'", str30.equals("{100}"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = blockRealMatrix8.walkInRowOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) '4');
        try {
            blockRealMatrix76.setColumnVector((int) (byte) 100, (org.apache.commons.math3.linear.RealVector) arrayRealVector82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round(0.0f, (-127), (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -127, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) (short) 1, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, intArray1, intArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int1 = arrayRealVector0.getMinIndex();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector0.mapAddToSelf((double) ' ');
        double double4 = arrayRealVector0.getMaxValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 6.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7781512503836436d + "'", double1 == 0.7781512503836436d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 35.0f, (double) 10, 55.798810960089604d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-127), (float) (short) 100, (-788545902));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double2 = org.apache.commons.math3.util.Precision.round(2.9957322735539913d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9957322735539913d + "'", double2 == 2.9957322735539913d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector9.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship23 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str24 = relationship23.toString();
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        double[] doubleArray31 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = arrayRealVector27.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint38 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector9, 1.0d, relationship23, (org.apache.commons.math3.linear.RealVector) arrayRealVector35, (double) (-1));
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector9.mapSubtract((double) 6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + relationship23 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship23.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "<=" + "'", str24.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        double double3 = array2DRowRealMatrix0.getNorm();
        int[] intArray10 = new int[] { '#', 6, ' ', 10, (-127), (byte) -1 };
        int[] intArray17 = new int[] { (-127), 6, 10, (byte) -1, (-52), (byte) 10 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix0.getSubMatrix(intArray10, intArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 0L, 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math3.util.FastMath.rint(5.437943429267561E39d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.437943429267561E39d + "'", double1 == 5.437943429267561E39d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(6.283185307179586d, (double) (-1.0f), 1847674112);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        int int6 = matrixDimensionMismatchException4.getExpectedDimension(0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(6.0000005f, (float) (short) 0, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix38.getColumnMatrix((-788545902));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-788,545,902)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        double[] doubleArray7 = new double[] { (-127), 1.7182818284590453d, 1L, (short) -1 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector2.mapDivide(0.9738729699514619d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0f, (float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix9.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.createMatrix((-1), 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double[] doubleArray4 = new double[] { 10.0f, 1L, 0.0f, 1.1102230246251565E-16d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector26.copy();
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        double[] doubleArray34 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, doubleArray34);
        double double36 = arrayRealVector30.getLInfNorm();
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        boolean boolean46 = array2DRowRealMatrix6.equals((java.lang.Object) arrayRealVector39);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        double double3 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.createMatrix((int) (short) 1, (int) (byte) 1);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, arrayRealVector13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        double[] doubleArray21 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray21);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector13.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        arrayRealVector17.set((double) 1847674149);
        try {
            array2DRowRealMatrix0.setRowVector(32, (org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix7.walkInRowOrder(realMatrixPreservingVisitor8, 6, (int) (short) 1, (int) (byte) 1, 1847674112);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double double30 = blockRealMatrix27.getNorm();
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        double[] doubleArray37 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        java.lang.Double[] doubleArray44 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, arrayRealVector45);
        java.lang.Double[] doubleArray48 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48);
        double[] doubleArray53 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray53);
        java.lang.Double[] doubleArray56 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = arrayRealVector49.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        arrayRealVector49.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship63 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str64 = relationship63.toString();
        java.lang.Double[] doubleArray66 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66);
        double[] doubleArray71 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector67, doubleArray71);
        java.lang.Double[] doubleArray74 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray74);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = arrayRealVector67.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint78 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector49, 1.0d, relationship63, (org.apache.commons.math3.linear.RealVector) arrayRealVector75, (double) (-1));
        org.apache.commons.math3.optimization.linear.Relationship relationship79 = linearConstraint78.getRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint81 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray37, relationship79, 0.0d);
        try {
            double[] doubleArray82 = blockRealMatrix27.operate(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.5E-323d + "'", double30 == 1.5E-323d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertTrue("'" + relationship63 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship63.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "<=" + "'", str64.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertTrue("'" + relationship79 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship79.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor79 = null;
        try {
            double double84 = blockRealMatrix76.walkInRowOrder(realMatrixPreservingVisitor79, (int) (short) 100, 0, 10, 1847674112);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = array2DRowRealMatrix7.getRowVector(1847674149);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,847,674,149)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = blockRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) 'a', (-788545902));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -788,545,902 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.util.MathUtils.checkFinite(0.7224284372420832d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "<=", "<=", "<=", "hi!", "hi!");
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = realMatrixFormat6.parse("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"Array2DRowRealMatrix{{0.0},{0.0},{0.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.power(1847674149);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray14 = new double[] { 10.0f, 1L, 0.0f, 1.1102230246251565E-16d };
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = array2DRowRealMatrix7.add(array2DRowRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 1x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 10, 52, 0, 0 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { (-788545902) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray5, intArray7);
        java.lang.Integer[] intArray9 = multiDimensionMismatchException8.getWrongDimensions();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor79 = null;
        try {
            double double80 = blockRealMatrix17.walkInRowOrder(realMatrixPreservingVisitor79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean1 = arrayRealVector0.isNaN();
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, arrayRealVector7);
        try {
            double double9 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, arrayRealVector36);
        try {
            arrayRealVector2.setSubVector((-788545902), (org.apache.commons.math3.linear.RealVector) arrayRealVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-788,545,902)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 52, 0, 0 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-788545902) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray7, intArray9);
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { (-52), 1, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray9, intArray14);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray9);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(3.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0948906034924214E-108d + "'", double1 == 3.0948906034924214E-108d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 9900.0d, number2, true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (short) 100, 1.4210804127942926d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double double30 = blockRealMatrix27.getNorm();
        double double31 = blockRealMatrix27.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double37 = blockRealMatrix27.walkInColumnOrder(realMatrixPreservingVisitor32, (int) (short) 1, (int) '4', 1847674149, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.5E-323d + "'", double30 == 1.5E-323d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.5E-323d + "'", double31 == 1.5E-323d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        java.io.ObjectOutputStream objectOutputStream30 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, objectOutputStream30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray10 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, 1.5430806348152437d);
        try {
            double[] doubleArray18 = array2DRowRealMatrix0.preMultiply(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.0023450509582335632d, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4013321812311688d + "'", double2 == 2.4013321812311688d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 1.5430806348152437d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (short) 100, false);
        java.lang.Double double16 = pointValuePair15.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16.equals(100.0d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        try {
            blockRealMatrix17.multiplyEntry(1847674112, (-52), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,847,674,112)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "<=", "<=", "<=", "hi!", "hi!");
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        java.lang.String str8 = realMatrixFormat6.getColumnSeparator();
        java.lang.String str9 = realMatrixFormat6.getSuffix();
        java.lang.String str10 = realMatrixFormat6.getRowPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = realMatrixFormat6.parse("{");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"{\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<=" + "'", str9.equals("<="));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "<=" + "'", str10.equals("<="));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.text.NumberFormat numberFormat3 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat(",", "", "", numberFormat3);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double16 = array2DRowRealMatrix10.walkInColumnOrder(realMatrixPreservingVisitor11, 0, (int) (short) 10, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        double[] doubleArray9 = new double[] { (-127), 1.7182818284590453d, 1L, (short) -1 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, doubleArray9);
        try {
            double[] doubleArray11 = array2DRowRealMatrix0.preMultiply(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        double double3 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor4, (int) ' ', (-1), (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        long long1 = org.apache.commons.math3.util.FastMath.round(4.9E-324d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        double double21 = arrayRealVector19.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int23 = arrayRealVector22.getMinIndex();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector22.mapToSelf(univariateFunction24);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector19.add((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10000.0d + "'", double21 == 10000.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector25);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Class<?> wildcardClass7 = arrayRealVector6.getClass();
        java.lang.Class<?> wildcardClass8 = arrayRealVector6.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.732511156817248d + "'", double1 == 3.732511156817248d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double2 = org.apache.commons.math3.util.FastMath.min(1.7182818284590453d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(6.0000005f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0000005f + "'", float2 == 6.0000005f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) -1, (int) (short) -1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 1847674149);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1847674149L + "'", long1 == 1847674149L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix7.getSubMatrix((-127), 1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[][] doubleArray39 = blockRealMatrix38.getData();
        double[][] doubleArray40 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) ' ', (int) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str3 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        double[] doubleArray9 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray9);
        double double11 = arrayRealVector5.getLInfNorm();
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5, arrayRealVector14);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector14.mapSubtract(0.0d);
        try {
            double double22 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector15);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        double[] doubleArray23 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray23);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = arrayRealVector19.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        double[] doubleArray36 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray36);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = arrayRealVector32.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, arrayRealVector32);
        java.lang.String str43 = arrayRealVector19.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector9.append(arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector44.copy();
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, arrayRealVector51);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        double[] doubleArray59 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray59);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = arrayRealVector55.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector51.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector55.append((double) (-1));
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = arrayRealVector45.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix69, 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{100}" + "'", str43.equals("{100}"));
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(realMatrix69);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int40 = arrayRealVector39.getMinIndex();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction41 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector39.mapToSelf(univariateFunction41);
        boolean boolean43 = arrayRealVector39.isInfinite();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = realMatrixFormat0.parse("{{1.5430806348},{100},{1.5430806348}}");
        java.lang.String str3 = realMatrixFormat0.getPrefix();
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 10, 52, 0, 0 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { (-788545902) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable6, intArray11, intArray13);
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { (-52), 1, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException19 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable5, intArray13, intArray18);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) str3, localizable4, (java.lang.Object[]) intArray13);
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{" + "'", str3.equals("{"));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray4 = new double[] { 10.0f, 1L, 0.0f, 1.1102230246251565E-16d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[] doubleArray8 = new double[] { 4.9E-324d };
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[][] doubleArray13 = new double[][] { doubleArray8, doubleArray10, doubleArray12 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray13);
        double[] doubleArray17 = new double[] { 4.9E-324d };
        double[] doubleArray19 = new double[] { 4.9E-324d };
        double[] doubleArray21 = new double[] { 4.9E-324d };
        double[][] doubleArray22 = new double[][] { doubleArray17, doubleArray19, doubleArray21 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix15.add(blockRealMatrix24);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        double[] doubleArray32 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, doubleArray32);
        double[] doubleArray34 = blockRealMatrix25.preMultiply(doubleArray32);
        double[] doubleArray36 = new double[] { 4.9E-324d };
        double[] doubleArray38 = new double[] { 4.9E-324d };
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[][] doubleArray41 = new double[][] { doubleArray36, doubleArray38, doubleArray40 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        double[] doubleArray44 = array2DRowRealMatrix42.getColumn(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, doubleArray44);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray32);
        try {
            double[] doubleArray47 = array2DRowRealMatrix6.preMultiply(doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int1 = arrayRealVector0.getMinIndex();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector0.mapToSelf(univariateFunction2);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double7 = arrayRealVector0.walkInDefaultOrder(realVectorPreservingVisitor4, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealVector realVector6 = array2DRowRealMatrix0.getRowVector(1847674112);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,847,674,112)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        double double3 = array2DRowRealMatrix0.getNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.power((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str8 = array2DRowRealMatrix7.toString();
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[] doubleArray18 = array2DRowRealMatrix16.getColumn(0);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix16.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        java.lang.String str39 = array2DRowRealMatrix16.toString();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = array2DRowRealMatrix7.multiply(array2DRowRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str39.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = blockRealMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor19, (int) (short) 0, (int) (byte) 10, 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        java.lang.String str30 = arrayRealVector5.toString();
        org.apache.commons.math3.linear.RealVector realVector31 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector5.ebeDivide(realVector31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{100}" + "'", str30.equals("{100}"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0f));
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        double double15 = arrayRealVector9.getLInfNorm();
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector18);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, arrayRealVector18, (short) 10, "", arrayRealVector28 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable5, objArray29);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException31 = new org.apache.commons.math3.exception.MathArithmeticException(localizable4, objArray29);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), localizable3, objArray29);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[][] doubleArray39 = blockRealMatrix38.getData();
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[] doubleArray46 = new double[] { 4.9E-324d };
        double[][] doubleArray47 = new double[][] { doubleArray42, doubleArray44, doubleArray46 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray47);
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[] doubleArray55 = new double[] { 4.9E-324d };
        double[][] doubleArray56 = new double[][] { doubleArray51, doubleArray53, doubleArray55 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix49.add(blockRealMatrix58);
        double double60 = blockRealMatrix59.getFrobeniusNorm();
        try {
            blockRealMatrix38.setRowMatrix((-52), blockRealMatrix59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 1.4E-45f, (java.lang.Number) 20.000000000000004d, (java.lang.Number) (byte) 100);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int2 = arrayRealVector1.getMinIndex();
        double double3 = arrayRealVector1.getL1Norm();
        double double4 = arrayRealVector1.getLInfNorm();
        java.lang.String str5 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) (-52), false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooLargeException3.getContext();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-52) + "'", number5.equals((-52)));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor4, 10, 0, 6, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor20 = null;
        try {
            double double25 = blockRealMatrix18.walkInRowOrder(realMatrixPreservingVisitor20, (int) (byte) 100, (int) (short) 0, (int) (short) -1, 1847674112);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math3.optimization.linear.Relationship relationship79 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str80 = relationship79.toString();
        java.lang.String str81 = relationship79.toString();
        boolean boolean82 = blockRealMatrix17.equals((java.lang.Object) relationship79);
        org.apache.commons.math3.linear.RealMatrix realMatrix83 = blockRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealVector realVector84 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17, realVector84);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertTrue("'" + relationship79 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship79.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "<=" + "'", str80.equals("<="));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "<=" + "'", str81.equals("<="));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(realMatrix83);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixPreservingVisitor10, (int) (short) -1, 0, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        double[] doubleArray14 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray14);
        double[] doubleArray18 = array2DRowRealMatrix7.preMultiply(doubleArray14);
        try {
            array2DRowRealMatrix7.addToEntry((-1), 52, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = new double[] { 4.9E-324d };
        double[] doubleArray23 = new double[] { 4.9E-324d };
        double[] doubleArray25 = new double[] { 4.9E-324d };
        double[][] doubleArray26 = new double[][] { doubleArray21, doubleArray23, doubleArray25 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray29 = array2DRowRealMatrix27.getColumn(0);
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[] doubleArray35 = new double[] { 4.9E-324d };
        double[][] doubleArray36 = new double[][] { doubleArray31, doubleArray33, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix38.add(blockRealMatrix47);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
        double double50 = blockRealMatrix47.getNorm();
        double double51 = blockRealMatrix47.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix18.multiply(blockRealMatrix47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.5E-323d + "'", double50 == 1.5E-323d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.5E-323d + "'", double51 == 1.5E-323d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        double[] doubleArray9 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray9);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 0, 1, 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) (-10L), 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        double[] doubleArray25 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray25);
        double[] doubleArray27 = blockRealMatrix18.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int30 = arrayRealVector29.getMinIndex();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector29.mapMultiplyToSelf((-1.0d));
        try {
            blockRealMatrix18.setColumnVector(1847674112, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,847,674,112)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, arrayRealVector35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        double[] doubleArray43 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, doubleArray43);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = arrayRealVector39.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector35.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        arrayRealVector39.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship53 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str54 = relationship53.toString();
        java.lang.Double[] doubleArray56 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        double[] doubleArray61 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, doubleArray61);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = arrayRealVector57.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint68 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector39, 1.0d, relationship53, (org.apache.commons.math3.linear.RealVector) arrayRealVector65, (double) (-1));
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector5.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertTrue("'" + relationship53 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship53.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "<=" + "'", str54.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertNotNull(realVector69);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector5.mapDivideToSelf(0.0023450509582335632d);
        java.lang.Class<?> wildcardClass22 = realVector21.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, arrayRealVector17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, arrayRealVector24);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        double[] doubleArray32 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, doubleArray32);
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector28.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector24.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        java.lang.Double[] doubleArray40 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        double[] doubleArray45 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, doubleArray45);
        java.lang.Double[] doubleArray48 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = arrayRealVector41.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28, arrayRealVector41);
        java.lang.String str52 = arrayRealVector28.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector18.append(arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector53.copy();
        java.lang.Double[] doubleArray56 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        java.lang.Double[] doubleArray59 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, arrayRealVector60);
        java.lang.Double[] doubleArray63 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        double[] doubleArray68 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector64, doubleArray68);
        java.lang.Double[] doubleArray71 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray71);
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = arrayRealVector64.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector60.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector64.append((double) (-1));
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = arrayRealVector54.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = arrayRealVector11.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) realMatrix78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 1x3");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{100}" + "'", str52.equals("{100}"));
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realMatrix73);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 'a', (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.443584143042217E69d + "'", double2 == 3.443584143042217E69d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double double20 = arrayRealVector5.getLInfNorm();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>> arrayRealVectorPair22 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>>(arrayRealVector5, (java.lang.Comparable<java.lang.String>) "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}");
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>> arrayRealVectorPair23 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.ArrayRealVector, java.lang.Comparable<java.lang.String>>(arrayRealVectorPair22);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix6, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int1 = arrayRealVector0.getMinIndex();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector0.mapToSelf(univariateFunction2);
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector9);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        double[] doubleArray17 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = arrayRealVector13.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector9.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        arrayRealVector13.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship27 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str28 = relationship27.toString();
        java.lang.Double[] doubleArray30 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        double[] doubleArray35 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = arrayRealVector31.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint42 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector13, 1.0d, relationship27, (org.apache.commons.math3.linear.RealVector) arrayRealVector39, (double) (-1));
        java.lang.String str43 = relationship27.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint45 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector3, relationship27, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + relationship27 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship27.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "<=" + "'", str28.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "<=" + "'", str43.equals("<="));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math3.util.FastMath.floor(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1), false);
        double[] doubleArray19 = pointValuePair18.getFirst();
        try {
            double[] doubleArray20 = array2DRowRealMatrix7.preMultiply(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int10 = arrayRealVector9.getMinIndex();
        double double11 = arrayRealVector9.getL1Norm();
        double double12 = arrayRealVector9.getLInfNorm();
        try {
            double double13 = arrayRealVector2.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        int int1 = org.apache.commons.math3.util.FastMath.abs((-52));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 100, 10, (-788545902), 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double double2 = array2DRowRealMatrix0.getNorm();
        double double3 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.createMatrix((int) (short) 1, (int) (byte) 1);
        double double7 = array2DRowRealMatrix0.getTrace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 100.0d, false);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        boolean boolean26 = pointValuePair13.equals((java.lang.Object) arrayRealVector16);
        java.lang.Double double27 = pointValuePair13.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27.equals(100.0d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(2.4013321812311688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9837179422651126d + "'", double1 == 0.9837179422651126d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        double[] doubleArray25 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray25);
        double[] doubleArray27 = blockRealMatrix18.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double29 = blockRealMatrix18.walkInOptimizedOrder(realMatrixPreservingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) ' ', 51.99999999999999d, (double) (-52));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor12 = null;
        try {
            double double13 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        double[] doubleArray25 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray25);
        double[] doubleArray27 = blockRealMatrix18.preMultiply(doubleArray25);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        double[] doubleArray34 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, doubleArray34);
        double double36 = arrayRealVector30.getLInfNorm();
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector39);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        java.lang.Double[] doubleArray49 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector47, arrayRealVector50);
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        java.lang.Double[] doubleArray56 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector54, arrayRealVector57);
        java.lang.Double[] doubleArray60 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray60);
        double[] doubleArray65 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector61, doubleArray65);
        java.lang.Double[] doubleArray68 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray68);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = arrayRealVector61.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector57.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        arrayRealVector61.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector50.append(arrayRealVector61);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector61.mapMultiply((-1.0d));
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = arrayRealVector39.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix18.preMultiply(realMatrix77);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(realMatrix77);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double[] doubleArray16 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, doubleArray16);
        java.lang.Double[] doubleArray19 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = arrayRealVector12.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray29 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray29);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = arrayRealVector25.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, arrayRealVector42);
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, arrayRealVector51);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        double[] doubleArray59 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray59);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = arrayRealVector55.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector51.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector39.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        double double67 = arrayRealVector39.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector39.mapAdd((double) (-788545902));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector39);
        double[] doubleArray71 = arrayRealVector39.toArray();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(arrayRealVector66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.NEGATIVE_INFINITY + "'", double67 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray21 = new double[] { 4.9E-324d };
        double[] doubleArray23 = new double[] { 4.9E-324d };
        double[] doubleArray25 = new double[] { 4.9E-324d };
        double[][] doubleArray26 = new double[][] { doubleArray21, doubleArray23, doubleArray25 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray29 = array2DRowRealMatrix27.getColumn(0);
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[] doubleArray35 = new double[] { 4.9E-324d };
        double[][] doubleArray36 = new double[][] { doubleArray31, doubleArray33, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix38.add(blockRealMatrix47);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
        double double50 = blockRealMatrix47.getNorm();
        try {
            blockRealMatrix18.setColumnMatrix(3, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.5E-323d + "'", double50 == 1.5E-323d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}", "<=", "{100}", "{100; 100}", "{", "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{}", "{100; 100}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector6.unitVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector6.mapSubtractToSelf(1.4210854715202004E-14d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) '#', (-52));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector15);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        double[] doubleArray23 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray23);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = arrayRealVector19.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        double[] doubleArray36 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray36);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = arrayRealVector32.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, arrayRealVector32);
        java.lang.String str43 = arrayRealVector19.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector9.append(arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector44.copy();
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, arrayRealVector51);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        double[] doubleArray59 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray59);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = arrayRealVector55.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector51.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector55.append((double) (-1));
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = arrayRealVector45.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        double[] doubleArray70 = arrayRealVector2.toArray();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{100}" + "'", str43.equals("{100}"));
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.0d, 6.283185307179586d, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6991118430775174d + "'", double3 == 2.6991118430775174d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector15);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        double[] doubleArray23 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray23);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = arrayRealVector19.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        double[] doubleArray36 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray36);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = arrayRealVector32.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, arrayRealVector32);
        java.lang.String str43 = arrayRealVector19.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector9.append(arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector44.copy();
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, arrayRealVector51);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        double[] doubleArray59 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray59);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = arrayRealVector55.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector51.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector55.append((double) (-1));
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = arrayRealVector45.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        int int70 = arrayRealVector45.getDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{100}" + "'", str43.equals("{100}"));
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 3 + "'", int70 == 3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector16.set((double) 1847674149);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector5.append(arrayRealVector16);
        double[] doubleArray30 = arrayRealVector16.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("{{100,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,10,0},{0,0,0,0,1.5430806348}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"{{100,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,10,0},{0,0,0,0,1.5430806348}}\" unparseable (from position 1) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector12);
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        double[] doubleArray20 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray20);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = arrayRealVector16.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        double[] doubleArray33 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray33);
        java.lang.Double[] doubleArray36 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = arrayRealVector29.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector29);
        java.lang.String str40 = arrayRealVector16.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector6.append(arrayRealVector16);
        boolean boolean42 = arrayRealVector41.isNaN();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{100}" + "'", str40.equals("{100}"));
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        org.apache.commons.math3.linear.RealVector realVector20 = null;
        try {
            blockRealMatrix17.setRowVector((-1), realVector20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector2.append(arrayRealVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor8, 1847674149, (int) (byte) 10, 3, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,847,674,149)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray7 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray7);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, 1.5430806348152437d);
        try {
            double[] doubleArray15 = array2DRowRealMatrix0.preMultiply(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector11.mapSubtractToSelf(100.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector8);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector15);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        double[] doubleArray23 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray23);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = arrayRealVector19.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        double[] doubleArray36 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray36);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = arrayRealVector32.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, arrayRealVector32);
        java.lang.String str43 = arrayRealVector19.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector9.append(arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector44.copy();
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, arrayRealVector51);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        double[] doubleArray59 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray59);
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = arrayRealVector55.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector51.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector55.append((double) (-1));
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = arrayRealVector45.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        double[] doubleArray75 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray75);
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray75);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray75);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix69, (org.apache.commons.math3.linear.AnyMatrix) realMatrix78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{100}" + "'", str43.equals("{100}"));
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat2.parse("{100}");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat2.parse("{100}");
        java.lang.String str7 = realVectorFormat2.getPrefix();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{" + "'", str7.equals("{"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        int int1 = arrayRealVector0.getMinIndex();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector0.mapToSelf(univariateFunction2);
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector9);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        double[] doubleArray17 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = arrayRealVector13.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector9.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        double[] doubleArray24 = arrayRealVector23.getDataRef();
        try {
            double double25 = arrayRealVector3.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        boolean boolean19 = blockRealMatrix17.isTransposable();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix17.createMatrix((int) (byte) -1, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix9.transpose();
        java.lang.String str11 = array2DRowRealMatrix9.toString();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0}}" + "'", str11.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[] doubleArray35 = new double[] { 4.9E-324d };
        double[][] doubleArray36 = new double[][] { doubleArray31, doubleArray33, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix38.add(blockRealMatrix47);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        double[] doubleArray55 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, doubleArray55);
        double[] doubleArray57 = blockRealMatrix48.preMultiply(doubleArray55);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        double[] doubleArray67 = array2DRowRealMatrix65.getColumn(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, doubleArray67);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray55);
        try {
            double[] doubleArray70 = blockRealMatrix27.operate(doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn(0);
        double[] doubleArray11 = new double[] { 4.9E-324d };
        double[] doubleArray13 = new double[] { 4.9E-324d };
        double[] doubleArray15 = new double[] { 4.9E-324d };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix18.add(blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double double30 = blockRealMatrix27.getNorm();
        double double31 = blockRealMatrix27.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = blockRealMatrix27.walkInOptimizedOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.5E-323d + "'", double30 == 1.5E-323d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.5E-323d + "'", double31 == 1.5E-323d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10000.0d, number1, (java.lang.Number) 1.3322676295501878E-15d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 1, (long) (-127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 97.0d);
        arrayRealVector2.set(1.5707963267948966d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat2.parse("{100}");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat2.parse("{100}");
        java.text.NumberFormat numberFormat7 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = realVectorFormat9.parse("{100}");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = realVectorFormat9.parse("{100}");
        java.lang.StringBuffer stringBuffer14 = null;
        java.text.FieldPosition fieldPosition15 = null;
        try {
            java.lang.StringBuffer stringBuffer16 = realVectorFormat2.format((org.apache.commons.math3.linear.RealVector) arrayRealVector13, stringBuffer14, fieldPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(arrayRealVector13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        arrayRealVector19.setEntry(0, 0.0d);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector29);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        double[] doubleArray37 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, doubleArray37);
        java.lang.Double[] doubleArray40 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = arrayRealVector33.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        arrayRealVector33.set((double) 1847674149);
        org.apache.commons.math3.optimization.linear.Relationship relationship47 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        java.lang.String str48 = relationship47.toString();
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        double[] doubleArray55 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, doubleArray55);
        java.lang.Double[] doubleArray58 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = arrayRealVector51.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint62 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector33, 1.0d, relationship47, (org.apache.commons.math3.linear.RealVector) arrayRealVector59, (double) (-1));
        org.apache.commons.math3.optimization.linear.Relationship relationship63 = linearConstraint62.getRelationship();
        org.apache.commons.math3.optimization.linear.Relationship relationship64 = linearConstraint62.getRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint66 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector19, relationship64, 0.9837179422651126d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertTrue("'" + relationship47 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship47.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "<=" + "'", str48.equals("<="));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertTrue("'" + relationship63 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship63.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship64 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship64.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(1.4210804127942926d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        double[] doubleArray25 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray25);
        double[] doubleArray27 = blockRealMatrix18.preMultiply(doubleArray25);
        try {
            blockRealMatrix18.multiplyEntry((int) '4', (int) (byte) 100, (double) (-126.99999f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        int int2 = org.apache.commons.math3.util.FastMath.max(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray13 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray13);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = arrayRealVector9.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector19.copy();
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        double[] doubleArray27 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray27);
        double double29 = arrayRealVector23.getLInfNorm();
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector19.map(univariateFunction39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector5);
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double[] doubleArray22 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector18.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector2.combineToSelf(Double.NEGATIVE_INFINITY, (double) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, arrayRealVector35);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        double[] doubleArray43 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, doubleArray43);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = arrayRealVector39.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector35.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector49.copy();
        java.lang.Double[] doubleArray53 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        double[] doubleArray58 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector54, doubleArray58);
        double double60 = arrayRealVector54.getLInfNorm();
        java.lang.Double[] doubleArray62 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector63, arrayRealVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector54, arrayRealVector63);
        arrayRealVector49.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector54.mapDivideToSelf((double) 'a');
        double double72 = arrayRealVector29.getL1Distance(realVector71);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.0d + "'", double60 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + Double.POSITIVE_INFINITY + "'", double72 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) "{100; 100}");
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        boolean boolean19 = blockRealMatrix17.isTransposable();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix17.getSubMatrix((-52), (int) (short) 100, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.4E-45f, (float) 1L, (float) 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            array2DRowRealMatrix7.setEntry((int) (byte) 0, 1847674112, 3.443584143042217E69d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,847,674,112)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 10, 52, 0, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-788545902) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray6, intArray8);
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { (-52), 1, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray8, intArray13);
        java.lang.Integer[] intArray15 = multiDimensionMismatchException14.getWrongDimensions();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = multiDimensionMismatchException14.getContext();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(exceptionContext16);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[][] doubleArray39 = blockRealMatrix38.getData();
        double[] doubleArray41 = new double[] { 4.9E-324d };
        double[] doubleArray43 = new double[] { 4.9E-324d };
        double[] doubleArray45 = new double[] { 4.9E-324d };
        double[][] doubleArray46 = new double[][] { doubleArray41, doubleArray43, doubleArray45 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        double[] doubleArray50 = new double[] { 4.9E-324d };
        double[] doubleArray52 = new double[] { 4.9E-324d };
        double[] doubleArray54 = new double[] { 4.9E-324d };
        double[][] doubleArray55 = new double[][] { doubleArray50, doubleArray52, doubleArray54 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix48.add(blockRealMatrix57);
        double[] doubleArray60 = new double[] { 4.9E-324d };
        double[] doubleArray62 = new double[] { 4.9E-324d };
        double[] doubleArray64 = new double[] { 4.9E-324d };
        double[][] doubleArray65 = new double[][] { doubleArray60, doubleArray62, doubleArray64 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[] doubleArray69 = new double[] { 4.9E-324d };
        double[] doubleArray71 = new double[] { 4.9E-324d };
        double[] doubleArray73 = new double[] { 4.9E-324d };
        double[][] doubleArray74 = new double[][] { doubleArray69, doubleArray71, doubleArray73 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray74);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix67.add(blockRealMatrix76);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix57.subtract(blockRealMatrix77);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix79 = blockRealMatrix38.subtract(blockRealMatrix78);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double81 = array2DRowRealMatrix80.getNorm();
        double double82 = array2DRowRealMatrix80.getNorm();
        double double83 = array2DRowRealMatrix80.getNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix86 = array2DRowRealMatrix80.createMatrix((int) (short) 1, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix87 = blockRealMatrix38.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(blockRealMatrix79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix86);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(3.732511156817248d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.732511156817248d + "'", double2 == 3.732511156817248d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double[] doubleArray5 = new double[] { (byte) 100, 0.0d, 2.2250738585072014E-308d, (short) 10, 1.5430806348152437d };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), false);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 1.5430806348152437d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (short) 100, false);
        double[] doubleArray16 = pointValuePair15.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{", "{100}", "");
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double[] doubleArray6 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray6);
        double double8 = arrayRealVector2.getLInfNorm();
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector11);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector22);
        java.lang.Double[] doubleArray25 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        double[] doubleArray30 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray30);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = arrayRealVector26.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector22.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        java.lang.Double[] doubleArray38 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        double[] doubleArray43 = new double[] { 1.5430806348152437d, (byte) 100, 1.5430806348152437d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, doubleArray43);
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = arrayRealVector39.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector26, arrayRealVector39);
        java.lang.String str50 = arrayRealVector39.toString();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector16.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{100}" + "'", str50.equals("{100}"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            array2DRowRealMatrix7.addToEntry((int) (short) 10, (-1), 10.000000000000002d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        double[] doubleArray20 = new double[] { 4.9E-324d };
        double[] doubleArray22 = new double[] { 4.9E-324d };
        double[] doubleArray24 = new double[] { 4.9E-324d };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { 4.9E-324d };
        double[] doubleArray31 = new double[] { 4.9E-324d };
        double[] doubleArray33 = new double[] { 4.9E-324d };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix27.add(blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix17.subtract(blockRealMatrix37);
        double[] doubleArray40 = new double[] { 4.9E-324d };
        double[] doubleArray42 = new double[] { 4.9E-324d };
        double[] doubleArray44 = new double[] { 4.9E-324d };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { 4.9E-324d };
        double[] doubleArray51 = new double[] { 4.9E-324d };
        double[] doubleArray53 = new double[] { 4.9E-324d };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix47.add(blockRealMatrix56);
        double[] doubleArray59 = new double[] { 4.9E-324d };
        double[] doubleArray61 = new double[] { 4.9E-324d };
        double[] doubleArray63 = new double[] { 4.9E-324d };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray61, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        double[] doubleArray68 = new double[] { 4.9E-324d };
        double[] doubleArray70 = new double[] { 4.9E-324d };
        double[] doubleArray72 = new double[] { 4.9E-324d };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray70, doubleArray72 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix66.add(blockRealMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix56.subtract(blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor79 = null;
        try {
            double double80 = blockRealMatrix76.walkInRowOrder(realMatrixChangingVisitor79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) (-52));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException6 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(6, 0, (int) ' ', (int) (byte) 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = matrixDimensionMismatchException6.getContext();
        java.lang.Integer[] intArray8 = matrixDimensionMismatchException6.getWrongDimensions();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, (java.lang.Object[]) intArray8);
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Integer[] intArray17 = new java.lang.Integer[] { 10, 52, 0, 0 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { (-788545902) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable12, intArray17, intArray19);
        java.lang.Integer[] intArray24 = new java.lang.Integer[] { (-52), 1, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException25 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable11, intArray19, intArray24);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math3.exception.MathArithmeticException(localizable10, (java.lang.Object[]) intArray19);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException27 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray8, intArray19);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { 4.9E-324d };
        double[] doubleArray12 = new double[] { 4.9E-324d };
        double[] doubleArray14 = new double[] { 4.9E-324d };
        double[][] doubleArray15 = new double[][] { doubleArray10, doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix8.add(blockRealMatrix17);
        boolean boolean19 = blockRealMatrix17.isTransposable();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix17.getSubMatrix((int) (byte) 0, 0, (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double[] doubleArray1 = new double[] { 4.9E-324d };
        double[] doubleArray3 = new double[] { 4.9E-324d };
        double[] doubleArray5 = new double[] { 4.9E-324d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray10 = array2DRowRealMatrix9.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }
}

