import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.9296597126314966d, (java.lang.Number) 69.80051674581603d, false);
        java.lang.Number number11 = numberIsTooLargeException10.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.3796077390275217d + "'", number5.equals(0.3796077390275217d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 69.80051674581603d + "'", number11.equals(69.80051674581603d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double2 = org.apache.commons.math.util.FastMath.max(50.27389940120996d, 0.6321205588285577d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.27389940120996d + "'", double2 == 50.27389940120996d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.21240085597318314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21565366040153144d + "'", double1 == 0.21565366040153144d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray6);
        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl11.reseedRandomGenerator(100L);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizable2, randomDataImpl10, 100L, maxIterationsExceededException18, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("2b49661ba9868e83586147f5e1dba71bb98d78e1d26f5185989c", objArray22);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.floor(40.77752427469333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.0d + "'", double1 == 40.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray13);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09585493054941834d + "'", double4 == 0.09585493054941834d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 81.77993441889764d + "'", double6 == 81.77993441889764d);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        int int10 = randomDataImpl1.nextInt((int) (byte) 0, (int) ' ');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl1.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.17694479879185d + "'", double4 == 97.17694479879185d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.FastMath.pow(22.474698501009087d, 0.8894305254963171d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.930807614851348d + "'", double2 == 15.930807614851348d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.561581040188955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1167940956877751d) + "'", double1 == (-0.1167940956877751d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.log(0.4118179342542967d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8871739344521156d) + "'", double1 == (-0.8871739344521156d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl8, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", objArray10);
        java.lang.Object[] objArray13 = maxIterationsExceededException12.getArguments();
        int int14 = maxIterationsExceededException12.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (short) 1, (java.lang.Number) 0.47295125419950956d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number9 = numberIsTooLargeException8.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number19 = numberIsTooLargeException18.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooLargeException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray25 = numberIsTooLargeException24.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray31 = numberIsTooLargeException30.getArguments();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, "org.apache.commons.math.MathException: hi!", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable20, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray40);
        org.apache.commons.math.random.RandomGenerator randomGenerator43 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl44 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator43);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl45 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl45.reseedRandomGenerator(100L);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray51);
        java.lang.Object[] objArray53 = maxIterationsExceededException52.getArguments();
        java.lang.Object[] objArray56 = new java.lang.Object[] { localizable36, randomDataImpl44, 100L, maxIterationsExceededException52, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable34, objArray56);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable20, objArray56);
        org.apache.commons.math.random.RandomGenerator randomGenerator67 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl68 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator67);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl68, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", objArray70);
        java.lang.Object[] objArray73 = maxIterationsExceededException72.getArguments();
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable20, objArray73);
        java.lang.Object[] objArray75 = outOfRangeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0f + "'", number9.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10.0f + "'", number19.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray75);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        int int10 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) ' ');
//        double double12 = randomDataImpl1.nextExponential(84.91825837008986d);
//        java.lang.String str14 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 84.2372416368047d + "'", double4 == 84.2372416368047d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9271415995328226d + "'", double7 == 0.9271415995328226d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 18.669915761060814d + "'", double12 == 18.669915761060814d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9e63cfee8d" + "'", str14.equals("9e63cfee8d"));
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 35L, 50.27389940120996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        try {
//            int[] intArray12 = randomDataImpl1.nextPermutation(15, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (15): permutation size (100) exceeds permuation domain (15)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 85.91420436585473d + "'", double4 == 85.91420436585473d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0911841276836731d), (java.lang.Number) 20, false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.8373392452626645d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.279806985800641d + "'", double1 == 5.279806985800641d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.atanh(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9999999958776927d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        int int12 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) ' ');
//        long long15 = randomDataImpl1.nextLong(0L, 96L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 85.26921828818796d + "'", double4 == 85.26921828818796d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 70L + "'", long15 == 70L);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double11 = randomDataImpl1.nextT((double) (byte) 1);
//        try {
//            int int14 = randomDataImpl1.nextPascal(0, 71.6783941778998d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 71.678 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 85.4465901971538d + "'", double4 == 85.4465901971538d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8840239792717893d + "'", double11 == 0.8840239792717893d);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        double double13 = randomDataImpl1.nextCauchy(0.1999608207388626d, 2.2495859853146735E-7d);
//        try {
//            long long15 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 73.16767703072111d + "'", double4 == 73.16767703072111d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 159.04616641484625d + "'", double10 == 159.04616641484625d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.1999607192475929d + "'", double13 == 0.1999607192475929d);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.5650814614239032E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0824991745207994E17d + "'", double1 == 4.0824991745207994E17d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double4 = normalDistributionImpl0.density((double) 10.0f);
        try {
            double double7 = normalDistributionImpl0.cumulativeProbability(0.39104575784009526d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.69459862670642E-23d + "'", double4 == 7.69459862670642E-23d);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        java.lang.String str14 = randomDataImpl1.nextSecureHexString(1);
//        try {
//            double double17 = randomDataImpl1.nextGaussian(0.19348666174586046d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 73.04674297934892d + "'", double4 == 73.04674297934892d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "b" + "'", str14.equals("b"));
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        randomDataImpl1.reSeed((long) 100);
//        randomDataImpl1.reSeed(35L);
//        long long11 = randomDataImpl1.nextLong((long) (byte) 10, (long) 60);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 74.77207852428512d + "'", double4 == 74.77207852428512d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 47L + "'", long11 == 47L);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        double double12 = randomDataImpl1.nextT(7.0d);
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric(1, 16, 24);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 16 is larger than the maximum (1): number of successes (16) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 74.6833925698022d + "'", double4 == 74.6833925698022d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9205512134987367d + "'", double7 == 0.9205512134987367d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6629637731727527d + "'", double10 == 0.6629637731727527d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.5600659200636632d) + "'", double12 == (-0.5600659200636632d));
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.05154365172832798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 377.9291246171548d + "'", double1 == 377.9291246171548d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.07446344319909004d, (java.lang.Number) 0, true);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) '4');
//        long long9 = randomDataImpl1.nextSecureLong((long) (short) -1, 15L);
//        try {
//            double double12 = randomDataImpl1.nextGamma(0.0d, (double) 19L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 783.6451834415203d + "'", double4 == 783.6451834415203d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "8bb524b5bd46b670e40b57a847b1e82e901e5887282d721834a0" + "'", str6.equals("8bb524b5bd46b670e40b57a847b1e82e901e5887282d721834a0"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        double double11 = randomDataImpl1.nextExponential(0.44783479200344534d);
//        int int14 = randomDataImpl1.nextInt(15, 35);
//        try {
//            randomDataImpl1.setSecureAlgorithm("c09eadfb366a3e0310c38ce09425a26bdd0b4690a909d076daed", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.11747349931751082d + "'", double4 == 0.11747349931751082d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.54554206489941d + "'", double6 == 100.54554206489941d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5306829291490487d + "'", double9 == 0.5306829291490487d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6021051805284977d + "'", double11 == 0.6021051805284977d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 27 + "'", int14 == 27);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.22646519138187088d, (java.lang.Number) 0.06893822784761361d, (java.lang.Number) 84.2372416368047d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double7 = normalDistributionImpl0.cumulativeProbability(46.62166798277185d, 107.52383629114054d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray13 = numberIsTooLargeException12.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(16, localizable6, objArray13);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.948148009134034E13d, 0.47944615950454317d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3301707.610914742d + "'", double2 == 3301707.610914742d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.0d, 31.270368997361853d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999991522d + "'", double2 == 0.9999999999991522d);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        double double13 = randomDataImpl1.nextGamma(2.7015257296375244d, 29.608888043985793d);
//        int int16 = randomDataImpl1.nextBinomial(0, 0.1999606625952326d);
//        try {
//            int int20 = randomDataImpl1.nextHypergeometric(13, (int) (short) 0, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (13): sample size (52) must be less than or equal to population size (13)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 13.594872915261588d + "'", double4 == 13.594872915261588d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9215266161387015d + "'", double7 == 0.9215266161387015d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 17.975995451542627d + "'", double13 == 17.975995451542627d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        int int12 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) ' ');
//        java.lang.String str14 = randomDataImpl1.nextHexString(18);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 96.17753704540709d + "'", double4 == 96.17753704540709d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "52fa7d3a789695f2ba" + "'", str14.equals("52fa7d3a789695f2ba"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (short) 100);
//        try {
//            long long12 = randomDataImpl1.nextSecureLong(100L, (long) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.33463717866535964d + "'", double4 == 0.33463717866535964d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 106.7168891413591d + "'", double6 == 106.7168891413591d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 89 + "'", int9 == 89);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("6ecc0f9cf0ae273", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3364564251863103d + "'", double4 == 0.3364564251863103d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl20, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray29);
        java.lang.Object[] objArray31 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException24, localizable25, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable7, objArray31);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, number35, (java.lang.Number) 0.970974762107423d, false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long1 = org.apache.commons.math.util.FastMath.abs(98L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 98L + "'", long1 == 98L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 10);
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, number8, (java.lang.Number) 44.69348890483312d, false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.03305848241929154d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0005464813963338d + "'", double1 == 1.0005464813963338d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(69.80051674581603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.354670355305231d + "'", double1 == 8.354670355305231d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.9296597126314966d, (java.lang.Number) 69.80051674581603d, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.3796077390275217d + "'", number5.equals(0.3796077390275217d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.6952694875949689d), (double) (byte) 1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double8 = randomDataImpl1.nextChiSquare((double) (short) 100);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3589743433595854d + "'", double4 == 0.3589743433595854d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.98656294279971d + "'", double6 == 97.98656294279971d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.31649680863161d + "'", double8 == 103.31649680863161d);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0621717148059133d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.ceil(40.77752427469333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.0d + "'", double1 == 41.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(63.35840289195546d, 0.43571855503071766d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.3912338279262167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0775131383407768d + "'", double1 == 1.0775131383407768d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3301707.610914742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8917391129163685E8d + "'", double1 == 1.8917391129163685E8d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(41.0d, (-0.4121576859496273d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.412 is smaller than, or equal to, the minimum (0): standard deviation (-0.412)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.0911841276836731d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3358186060702022d + "'", double1 == 0.3358186060702022d);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        double double7 = randomDataImpl1.nextF(0.3770174256150502d, 2.718281828459045d);
//        try {
//            double double10 = randomDataImpl1.nextF(87.29286113456672d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.154379070405042E-4d + "'", double4 == 3.154379070405042E-4d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.369125348485406d + "'", double7 == 1.369125348485406d);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator15 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl16, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray25);
        java.lang.Object[] objArray27 = maxIterationsExceededException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException20, localizable21, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray27);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable5, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray37);
        java.lang.Object[] objArray40 = mathIllegalArgumentException39.getArguments();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number47 = numberIsTooLargeException46.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooLargeException46.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator64 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator64);
        java.lang.Object[] objArray67 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl65, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray74);
        java.lang.Object[] objArray76 = maxIterationsExceededException75.getArguments();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException69, localizable70, objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray76);
        java.lang.Object[] objArray79 = maxIterationsExceededException78.getArguments();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable54, objArray79);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable82, objArray86);
        java.lang.Object[] objArray89 = mathIllegalArgumentException88.getArguments();
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable48, objArray89);
        org.apache.commons.math.exception.util.Localizable localizable93 = mathIllegalArgumentException92.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 10.0f + "'", number47.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 10.0f + "'", number53.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertTrue("'" + localizable93 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable93.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.0911841276836731d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (short) 100);
//        try {
//            double double11 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3946652238869766d + "'", double4 == 0.3946652238869766d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 91.36959756679754d + "'", double6 == 91.36959756679754d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68 + "'", int9 == 68);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        try {
//            int int12 = randomDataImpl1.nextInt((int) (byte) 100, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 99.19316688789058d + "'", double4 == 99.19316688789058d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(25.937539580623483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.80138855624356d + "'", double1 == 57.80138855624356d);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl1.getClass();
//        try {
//            long long11 = randomDataImpl1.nextLong(29L, (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 29 is larger than, or equal to, the maximum (-1): lower bound (29) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 68.06422760808499d + "'", double4 == 68.06422760808499d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9363583440423722d + "'", double7 == 0.9363583440423722d);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray16);
        java.lang.Object[] objArray19 = mathIllegalArgumentException18.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator28 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl29 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator28);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl29, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable22, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException18, "hi!", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1.749721612987703d, (java.lang.Number) 14.903216738460985d, false);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray31);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        java.lang.String str14 = randomDataImpl1.nextSecureHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double16 = normalDistributionImpl15.getMean();
//        double double17 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 69.90243752710397d + "'", double4 == 69.90243752710397d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9" + "'", str14.equals("9"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.6501341356232105d) + "'", double17 == (-0.6501341356232105d));
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl2.reseedRandomGenerator(1L);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.24387979418110328d, 0.3796077390275217d);
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "7565fa671c");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 7565fa671c");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05154365172832798d + "'", double7 == 0.05154365172832798d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.23717220460257984d + "'", double8 == 0.23717220460257984d);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.825691794909465d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 0.5d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number9 = numberIsTooLargeException8.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) (byte) 10, (java.lang.Number) 10, false);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        java.lang.Object[] objArray18 = numberIsTooSmallException16.getArguments();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0f + "'", number9.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        java.lang.Object[] objArray9 = maxIterationsExceededException8.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException8.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable10);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        int[] intArray13 = randomDataImpl1.nextPermutation(35, 22);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 64.24268798128398d + "'", double4 == 64.24268798128398d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-211.71866452858228d) + "'", double10 == (-211.71866452858228d));
//        org.junit.Assert.assertNotNull(intArray13);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 87L, (java.lang.Number) 189826.95528170085d, true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.8597042078028618d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7759409198006028d) + "'", double1 == (-0.7759409198006028d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(29);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5042820159726888d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.504282015972689d + "'", double1 == 0.504282015972689d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 88L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 88L + "'", long1 == 88L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "2", objArray2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.special.Erf.erf(7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.682424789537251E-23d + "'", double1 == 8.682424789537251E-23d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.1752011936438014d, 1.8436525386819747d, 2213888.2435685736d);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 65.45203654163308d + "'", double4 == 65.45203654163308d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.930216564902329d + "'", double7 == 0.930216564902329d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.559130815791023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 95.50043627406082d + "'", double1 == 95.50043627406082d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 0.5d, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        int int10 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) ' ');
//        double double12 = randomDataImpl1.nextExponential(84.91825837008986d);
//        try {
//            int int15 = randomDataImpl1.nextPascal((int) (byte) 10, (double) 60);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 60 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 64.60549281760962d + "'", double4 == 64.60549281760962d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9157365754028041d + "'", double7 == 0.9157365754028041d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 62.885698096673735d + "'", double12 == 62.885698096673735d);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.sin((-18.86062227865251d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.011066131242928426d) + "'", double1 == (-0.011066131242928426d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double2 = org.apache.commons.math.util.FastMath.min(94.57352269777122d, 1.241728039225479E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.241728039225479E-18d + "'", double2 == 1.241728039225479E-18d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.special.Erf.erf(4.046520636303111d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999895121342d + "'", double1 == 0.9999999895121342d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.749721612987703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.25166374701818d + "'", double1 == 100.25166374701818d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9999999999991522d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284567407d + "'", double1 == 1.7182818284567407d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        double double11 = randomDataImpl8.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl12.reseedRandomGenerator(1L);
//        double double15 = normalDistributionImpl12.getStandardDeviation();
//        double double17 = normalDistributionImpl12.inverseCumulativeProbability((double) 0L);
//        double double18 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double19 = normalDistributionImpl12.sample();
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution21 = null;
//        try {
//            int int22 = randomDataImpl1.nextInversionDeviate(integerDistribution21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.23812649192466262d + "'", double4 == 0.23812649192466262d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 30.368246421086752d + "'", double11 == 30.368246421086752d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.3882967820863044d) + "'", double18 == (-0.3882967820863044d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.561581040188955d + "'", double19 == 1.561581040188955d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.4445048014865005d) + "'", double20 == (-1.4445048014865005d));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 20, (long) 60);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60L + "'", long2 == 60L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double2 = org.apache.commons.math.util.FastMath.min((-61.54191176200181d), 114.3891226019389d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-61.54191176200181d) + "'", double2 == (-61.54191176200181d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.3912338279262167d, (java.lang.Number) 84.2372416368047d, false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int2 = org.apache.commons.math.util.FastMath.min(13, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        double double12 = randomDataImpl1.nextCauchy(0.010836558541039962d, 57.29577951308234d);
//        double double15 = randomDataImpl1.nextUniform(98.0d, 1.3273072331627778E19d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.22431739599318054d + "'", double4 == 0.22431739599318054d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 80.58176774999986d + "'", double6 == 80.58176774999986d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.5617698111746443d + "'", double9 == 3.5617698111746443d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 49.699729400657816d + "'", double12 == 49.699729400657816d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 7.807691393469611E18d + "'", double15 == 7.807691393469611E18d);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double6 = normalDistributionImpl0.density((double) 1);
        double double7 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.24197072451914337d + "'", double6 == 0.24197072451914337d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException6);
        java.lang.String str8 = convergenceException7.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getMean();
        double[] doubleArray7 = normalDistributionImpl0.sample(1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        long long9 = randomDataImpl1.nextPoisson(44.725416200613196d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 60.1309060947479d + "'", double4 == 60.1309060947479d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 47L + "'", long9 == 47L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray10);
        java.lang.Object[] objArray13 = mathIllegalArgumentException12.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        java.lang.Object[] objArray24 = mathIllegalArgumentException23.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator33 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator33);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl34, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException23, "hi!", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray47);
        java.lang.Object[] objArray50 = mathIllegalArgumentException49.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator59 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl60 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl60, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException49, "hi!", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("hi!", objArray62);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(35, localizable15, objArray62);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(35, localizable3, objArray62);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(10, "6ecc0f9cf0ae273", objArray62);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray62);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        try {
//            int int13 = randomDataImpl1.nextZipf((int) (byte) -1, (double) 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 41.571765184433d + "'", double4 == 41.571765184433d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9165901279355472d + "'", double7 == 0.9165901279355472d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.17453292519943295d, (java.lang.Number) 24, (java.lang.Number) 0.5493061443340549d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 24 + "'", number4.equals(24));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 24 + "'", number5.equals(24));
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 41.313771021587186d + "'", double4 == 41.313771021587186d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8503021457402034d + "'", double7 == 0.8503021457402034d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(15.930807614851348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.516204478473435d + "'", double1 == 2.516204478473435d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.45792971447185016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9829111076778834d, 3.5617698111746443d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9726069316900855d + "'", double2 == 0.9726069316900855d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.0911841276836731d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.floor(99.62046925909928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5d, 7.69459862670642E-23d, 0.3949416458995614d);
        double double5 = normalDistributionImpl3.cumulativeProbability(0.5876673996180602d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.8840239792717893d, (java.lang.Number) 3.5617698111746443d, false);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        randomDataImpl1.reSeed((long) 100);
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) (short) 10);
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        double double13 = randomDataImpl10.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl14.reseedRandomGenerator(1L);
//        double double17 = normalDistributionImpl14.getStandardDeviation();
//        double double19 = normalDistributionImpl14.inverseCumulativeProbability((double) 0L);
//        double double20 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double22 = normalDistributionImpl14.cumulativeProbability((-1.0621717148059133d));
//        double double23 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            int[] intArray26 = randomDataImpl1.nextPermutation(10, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (10): permutation size (52) exceeds permuation domain (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 37.766350276628884d + "'", double4 == 37.766350276628884d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "561f553834" + "'", str8.equals("561f553834"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0036733498956390024d + "'", double13 == 0.0036733498956390024d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4155528728696323d + "'", double20 == 1.4155528728696323d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.14407886904420542d + "'", double22 == 0.14407886904420542d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-0.8597042078028618d) + "'", double23 == (-0.8597042078028618d));
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1, 1.0878825598789765d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2422079676186446d + "'", double1 == 1.2422079676186446d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl10, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray19);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException14, localizable15, objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray21);
        java.lang.Throwable[] throwableArray24 = maxIterationsExceededException23.getSuppressed();
        java.lang.Throwable[] throwableArray25 = maxIterationsExceededException23.getSuppressed();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable7, objArray8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (byte) 10, (java.lang.Number) 10, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator29 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator29);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl30, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray39);
        java.lang.Object[] objArray41 = maxIterationsExceededException40.getArguments();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException34, localizable35, objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray41);
        java.lang.Object[] objArray44 = maxIterationsExceededException43.getArguments();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable19, objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(97, localizable7, objArray44);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 10.0f + "'", number18.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.1999608207388626d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 1.8436525386819747d, (java.lang.Number) 9.999999999999998d, true);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((double) (short) 0);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 10, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double13 = normalDistributionImpl5.cumulativeProbability((-1.0621717148059133d));
//        double double15 = normalDistributionImpl5.cumulativeProbability(0.841344746068543d);
//        normalDistributionImpl5.reseedRandomGenerator((long) 88);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.8547234951324916E-4d + "'", double4 == 4.8547234951324916E-4d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.109574019484469d + "'", double11 == 1.109574019484469d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.14407886904420542d + "'", double13 == 0.14407886904420542d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7999225850214973d + "'", double15 == 0.7999225850214973d);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.8823728225158143d, 0.0d, 0.4959198326004437d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        randomDataImpl1.reSeed();
//        int int14 = randomDataImpl1.nextZipf(1, 25.222985934502482d);
//        try {
//            double double17 = randomDataImpl1.nextGamma((double) 32.0f, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 33.098266925804424d + "'", double4 == 33.098266925804424d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-22.206170072700104d) + "'", double10 == (-22.206170072700104d));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(15.930807614851348d, 0.26040534270272864d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.930807614851346d + "'", double2 == 15.930807614851346d);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        double double11 = randomDataImpl1.nextExponential(0.44783479200344534d);
//        int int14 = randomDataImpl1.nextSecureInt(0, 15);
//        try {
//            int int17 = randomDataImpl1.nextPascal(12, 91.6219872962048d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 91.622 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.17904375315485302d + "'", double4 == 0.17904375315485302d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.1078486963633d + "'", double6 == 89.1078486963633d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5851206443792273d + "'", double9 == 0.5851206443792273d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.036408295976281764d + "'", double11 == 0.036408295976281764d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, 16L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5674744539063689d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5674744539063689d + "'", double2 == 0.5674744539063689d);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray6);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray6);
//        java.lang.Object[] objArray9 = mathIllegalArgumentException8.getArguments();
//        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable11, objArray12);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (-75.8908547263655d));
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 0.9283751625724556d, (java.lang.Number) 74.99200917961215d, true);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        java.lang.Object[] objArray24 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray24);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray24);
//        java.lang.Object[] objArray27 = mathIllegalArgumentException26.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator36 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl37 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator36);
//        java.lang.Object[] objArray39 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl37, 10L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray39);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray39);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException26, "hi!", objArray39);
//        java.lang.Throwable throwable44 = null;
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        java.lang.Object[] objArray51 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray51);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, objArray51);
//        org.apache.commons.math.random.RandomGenerator randomGenerator54 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl55 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator54);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl56 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl56.reseedRandomGenerator(100L);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray62);
//        java.lang.Object[] objArray64 = maxIterationsExceededException63.getArguments();
//        java.lang.Object[] objArray67 = new java.lang.Object[] { localizable47, randomDataImpl55, 100L, maxIterationsExceededException63, 0.45792971447185016d, '4' };
//        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("hi!", objArray67);
//        java.lang.String str69 = mathException68.getPattern();
//        org.apache.commons.math.exception.util.Localizable localizable71 = null;
//        org.apache.commons.math.exception.util.Localizable localizable72 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator78 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl79 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator78);
//        java.lang.Object[] objArray81 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl79, 10L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray81);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable71, localizable72, objArray81);
//        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException68, "", objArray81);
//        org.apache.commons.math.random.RandomGenerator randomGenerator85 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl86 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator85);
//        double double89 = randomDataImpl86.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { mathException68, randomDataImpl86, 100, 1.5707963267948966d };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(throwable44, "", objArray92);
//        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException26, "", objArray92);
//        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException(localizable11, objArray92);
//        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray92);
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray24);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray39);
//        org.junit.Assert.assertNotNull(objArray51);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(objArray67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
//        org.junit.Assert.assertNotNull(objArray81);
//        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.6473520704442785E-4d + "'", double89 == 1.6473520704442785E-4d);
//        org.junit.Assert.assertNotNull(objArray92);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5905040535376296d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0461827947652167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8467636702875607d + "'", double1 == 1.8467636702875607d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable2, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4);
        java.lang.String str7 = convergenceException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable1);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.ConvergenceException: " + "'", str7.equals("org.apache.commons.math.ConvergenceException: "));
        org.junit.Assert.assertNull(localizable8);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        int int9 = randomDataImpl1.nextZipf(100, (double) 97);
//        double double12 = randomDataImpl1.nextCauchy(1.0878811995641964d, 3.109369441615935E-6d);
//        int int15 = randomDataImpl1.nextBinomial(19, 0.21358358613110687d);
//        double double17 = randomDataImpl1.nextExponential(0.07137002627171281d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.22006350669064934d + "'", double4 == 0.22006350669064934d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0878815832463686d + "'", double12 == 1.0878815832463686d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.009499327644436933d + "'", double17 == 0.009499327644436933d);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        java.lang.Object[] objArray7 = outOfRangeException4.getArguments();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 96.0f + "'", number5.equals(96.0f));
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextCauchy(3.5936275273962304d, 55.32768878020956d);
//        try {
//            long long15 = randomDataImpl1.nextSecureLong((long) 11, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 11 is larger than, or equal to, the maximum (0): lower bound (11) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 56.196814236077834d + "'", double4 == 56.196814236077834d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.50463112678813d + "'", double12 == 52.50463112678813d);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (short) 1, (java.lang.Number) 0.47295125419950956d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 1 + "'", number4.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 1 + "'", number6.equals((short) 1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9248506659826856d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        double double11 = randomDataImpl1.nextExponential(0.44783479200344534d);
//        randomDataImpl1.reSeed((long) ' ');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.21968702211013827d + "'", double4 == 0.21968702211013827d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 104.89043249909021d + "'", double6 == 104.89043249909021d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.4847903667852275d) + "'", double9 == (-0.4847903667852275d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3363298962376296d + "'", double11 == 0.3363298962376296d);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        long long1 = org.apache.commons.math.util.FastMath.abs(87L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 87L + "'", long1 == 87L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0617970746878473d, 0.4140890227940399d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.689556501423696d + "'", double2 == 0.689556501423696d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.010836558541039962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9651086185299615d) + "'", double1 == (-1.9651086185299615d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray19);
        java.lang.Object[] objArray22 = mathIllegalArgumentException21.getArguments();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "convergence failed", objArray22);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, number11, (java.lang.Number) (-1), (java.lang.Number) 0.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.9128412277134819d, (java.lang.Number) 4.9E-324d, false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability(3.5617698111746443d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        int int12 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) ' ');
//        double double15 = randomDataImpl1.nextF(0.14614958006663759d, 3.141592653589793d);
//        try {
//            int int18 = randomDataImpl1.nextZipf(0, 50.83472904837748d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 49.537337476868395d + "'", double4 == 49.537337476868395d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 18 + "'", int12 == 18);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.15394245342731447d + "'", double15 == 0.15394245342731447d);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.9751160743707064d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4324513382309914d + "'", double1 == 1.4324513382309914d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(2.2495859853146735E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.97603578203211E13d + "'", double1 == 1.97603578203211E13d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        org.apache.commons.math.random.RandomGenerator randomGenerator8 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator8);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl10.reseedRandomGenerator(100L);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizable1, randomDataImpl9, 100L, maxIterationsExceededException17, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22);
        java.lang.Throwable[] throwableArray24 = mathException23.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException23.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(localizable25);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 98L, (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        org.apache.commons.math.random.RandomGenerator randomGenerator8 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator8);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl10.reseedRandomGenerator(100L);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizable1, randomDataImpl9, 100L, maxIterationsExceededException17, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        java.lang.String str23 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator32 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl33 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator32);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl33, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, "", objArray35);
        java.lang.Object[] objArray39 = mathException38.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.30462561220860923d, 85.26921828818796d, 4.641588833612779d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 85.269 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 68.67216816885978d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray36);
        org.apache.commons.math.random.RandomGenerator randomGenerator39 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl40 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator39);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl41.reseedRandomGenerator(100L);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray47);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizable32, randomDataImpl40, 100L, maxIterationsExceededException48, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable30, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable16, objArray52);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) 0.6321205588285577d, (java.lang.Number) 4.8547234951324916E-4d, false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray6);
        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl11.reseedRandomGenerator(100L);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizable2, randomDataImpl10, 100L, maxIterationsExceededException18, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        java.lang.Throwable[] throwableArray25 = mathException23.getSuppressed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("org.apache.commons.math.ConvergenceException: 2", (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray6 = numberIsTooLargeException5.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray12 = numberIsTooLargeException11.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "org.apache.commons.math.MathException: hi!", objArray12);
        java.lang.Throwable[] throwableArray14 = mathException13.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "bd8b1fdee502fb90bfe07e0e4b3a6a2cb76", (java.lang.Object[]) throwableArray14);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.3949416458995614d, 0.3607581050654419d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8306016381792103d + "'", double2 == 0.8306016381792103d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable5, objArray6);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str8.equals("{0} is larger than, or equal to, the maximum ({1})"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.512991811647731d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 24);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 24.0f + "'", float1 == 24.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number38 = numberIsTooLargeException37.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooLargeException37.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable39, objArray40);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number48 = numberIsTooLargeException47.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooLargeException47.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray54 = numberIsTooLargeException53.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray60 = numberIsTooLargeException59.getArguments();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException53, "org.apache.commons.math.MathException: hi!", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable49, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.ConvergenceException: ", objArray60);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException29, "f2725e945838d89f4f507fcc1b4daabf", objArray60);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 10.0f + "'", number38.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 10.0f + "'", number48.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator18 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl19, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray28);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException23, localizable24, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray30);
        java.lang.Class<?> wildcardClass33 = objArray30.getClass();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(throwable0, localizable6, objArray30);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 14.903216738460985d, (java.lang.Number) (-2.0579895193368998d), false);
        java.lang.Number number39 = numberIsTooLargeException38.getMax();
        boolean boolean40 = numberIsTooLargeException38.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-2.0579895193368998d) + "'", number39.equals((-2.0579895193368998d)));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double2 = org.apache.commons.math.util.FastMath.max(9.999999999999998d, 81.77993441889764d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 81.77993441889764d + "'", double2 == 81.77993441889764d);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double14 = randomDataImpl1.nextF(0.39104575784009526d, (double) 1.0f);
//        int int17 = randomDataImpl1.nextSecureInt(29, 52);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 353.4361705112366d + "'", double4 == 353.4361705112366d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.46711039697594725d) + "'", double11 == (-0.46711039697594725d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.600007030726339d + "'", double14 == 9.600007030726339d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 45 + "'", int17 == 45);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl2.reseedRandomGenerator(1L);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.24387979418110328d, 0.3796077390275217d);
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        long long10 = randomDataImpl1.nextPoisson(47.7278454342259d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05154365172832798d + "'", double7 == 0.05154365172832798d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5087063569531193d + "'", double8 == 0.5087063569531193d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 42L + "'", long10 == 42L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14550003380861354d) + "'", double1 == (-0.14550003380861354d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.20757123791676968d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20757123791676965d + "'", double2 == 0.20757123791676965d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.3989422804014327d, (java.lang.Number) 377.9291246171548d, false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability(6.55500334591278d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 6.555 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (short) 100);
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(97);
//        double double14 = randomDataImpl1.nextUniform((double) 1, 1.053091277489779d);
//        try {
//            double double17 = randomDataImpl1.nextWeibull(0.825691794909465d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2535107920707649d + "'", double4 == 0.2535107920707649d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 80.4430978289224d + "'", double6 == 80.4430978289224d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1aa7a2e98fa3e54b9c02ea415108d501137c2a9f9cd58a542e84eecb2ad5e7fac8cff02437b332fe337da09dc6d7d46ac" + "'", str11.equals("1aa7a2e98fa3e54b9c02ea415108d501137c2a9f9cd58a542e84eecb2ad5e7fac8cff02437b332fe337da09dc6d7d46ac"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0156427251091016d + "'", double14 == 1.0156427251091016d);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        int int9 = randomDataImpl1.nextZipf(100, (double) 97);
//        double double12 = randomDataImpl1.nextCauchy(1.0878811995641964d, 3.109369441615935E-6d);
//        int int15 = randomDataImpl1.nextBinomial(19, 0.21358358613110687d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution16 = null;
//        try {
//            double double17 = randomDataImpl1.nextInversionDeviate(continuousDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25299226556095084d + "'", double4 == 0.25299226556095084d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3L + "'", long6 == 3L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0878822452191954d + "'", double12 == 1.0878822452191954d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.7182818284567407d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(22);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        try {
//            double double7 = randomDataImpl1.nextWeibull(114.3891226019389d, (-5.791122528842996E8d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -579,112,252.884 is smaller than, or equal to, the minimum (0): scale (-579,112,252.884)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25278560144160467d + "'", double4 == 0.25278560144160467d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getGeneralPattern();
        int int6 = maxIterationsExceededException4.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.8204498504250056E66d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(1);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.atan(17.89400457879299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.514969755888731d + "'", double1 == 1.514969755888731d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.log1p(51.84386644926108d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9673416497489122d + "'", double1 == 3.9673416497489122d);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        int int10 = randomDataImpl1.nextInt((int) (byte) 0, (int) ' ');
//        try {
//            java.lang.String str12 = randomDataImpl1.nextSecureHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 66.47627163462708d + "'", double4 == 66.47627163462708d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.17453292519943295d, number1, false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 6.875685348521053d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable7, objArray8);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException9.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 41.0d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double8 = randomDataImpl1.nextChiSquare((double) (short) 100);
//        try {
//            double double11 = randomDataImpl1.nextWeibull((-0.3291799577374817d), 0.05154365172832798d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.329 is smaller than, or equal to, the minimum (0): shape (-0.329)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.23761070801284778d + "'", double4 == 0.23761070801284778d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.97217695248874d + "'", double6 == 89.97217695248874d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.2418503168602d + "'", double8 == 103.2418503168602d);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.sin(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6569865987187891d + "'", double1 == 0.6569865987187891d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 87L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.038015112528436E37d + "'", double1 == 3.038015112528436E37d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.24531723299342215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2503597609480183d + "'", double1 == 0.2503597609480183d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.8722276181537971d, 0.7573317415648186d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.872227618153797d + "'", double2 == 0.872227618153797d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double2 = org.apache.commons.math.util.FastMath.min(81.77993441889764d, (-0.011032137432646735d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.011032137432646735d) + "'", double2 == (-0.011032137432646735d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("339b6d406dcc43cb61348cdcf306ae2d262853f11f0904a8b5a6bef0d0c64010bf3e1d51abd3aa540012a87da80d288b2", objArray4);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable9, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (byte) 10, (java.lang.Number) 10, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number21 = numberIsTooLargeException20.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException20.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable22, objArray23);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number31 = numberIsTooLargeException30.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooLargeException30.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray37 = numberIsTooLargeException36.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray43 = numberIsTooLargeException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException36, "org.apache.commons.math.MathException: hi!", objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable32, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable9, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1, "6ecc0f9cf0ae273", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException1.getSpecificPattern();
        boolean boolean49 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0f + "'", number8.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 10.0f + "'", number31.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNull(localizable48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double7 = normalDistributionImpl0.cumulativeProbability(0.05154365172832798d, (double) 100.0f);
        double double8 = normalDistributionImpl0.sample();
        normalDistributionImpl0.reseedRandomGenerator(98L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.47944615950454317d + "'", double7 == 0.47944615950454317d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6246292191371761d + "'", double8 == 0.6246292191371761d);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (short) 100);
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(97);
//        randomDataImpl1.reSeedSecure((long) 11);
//        double double15 = randomDataImpl1.nextChiSquare(1.4324513382309914d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24140550132047225d + "'", double4 == 0.24140550132047225d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 94.68430446283918d + "'", double6 == 94.68430446283918d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 55 + "'", int9 == 55);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "96ecfd6636f5598a79f3ef90aea4e697ad2877d4976f8686b7771b5f65be0e972c44bbb5f408b560c7560c176c8fd5aac" + "'", str11.equals("96ecfd6636f5598a79f3ef90aea4e697ad2877d4976f8686b7771b5f65be0e972c44bbb5f408b560c7560c176c8fd5aac"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.9329567789091042d + "'", double15 == 1.9329567789091042d);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(44.725416200613196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.022610468981839035d + "'", double1 == 0.022610468981839035d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable1, objArray2);
        try {
            java.lang.String str4 = maxIterationsExceededException3.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.5936275273962304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.593627527396231d + "'", double1 == 3.593627527396231d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable5, objArray6);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7);
        java.lang.Class<?> wildcardClass10 = convergenceException9.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str8.equals("{0} is larger than, or equal to, the maximum ({1})"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.36665524127069987d, (java.lang.Number) 0.995387367940485d, true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable9, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl22, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray31);
        java.lang.Object[] objArray33 = maxIterationsExceededException32.getArguments();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException26, localizable27, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray33);
        java.lang.Class<?> wildcardClass36 = objArray33.getClass();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable3, localizable9, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator46 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator46);
        java.lang.Object[] objArray49 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl47, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray49);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NumberIsTooSmallException: 0.412 is smaller than the minimum (8.314)", objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException(11, localizable9, objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(19, "org.apache.commons.math.MathException: hi!", objArray49);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0f + "'", number8.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(objArray49);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) '4');
//        long long9 = randomDataImpl1.nextSecureLong((long) (short) -1, 15L);
//        double double12 = randomDataImpl1.nextCauchy(0.0d, 0.23417655849041552d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 15.271264348179162d + "'", double4 == 15.271264348179162d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "b8d8400b50249a78df2a4592503fd3d0fff51343128ccde3986a" + "'", str6.equals("b8d8400b50249a78df2a4592503fd3d0fff51343128ccde3986a"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 15L + "'", long9 == 15L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-3.557981549420964d) + "'", double12 == (-3.557981549420964d));
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1, localizable3, objArray4);
        java.lang.Object[] objArray6 = convergenceException1.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("9", objArray6);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int[] intArray4 = randomDataImpl1.nextPermutation((int) (byte) 1, 1);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.1999606625952326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22135471229049417d + "'", double1 == 0.22135471229049417d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.825691794909465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7350170286937323d + "'", double1 == 0.7350170286937323d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.6546144663255556E19d, number1, (java.lang.Number) 10);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.log(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6931471805599453d) + "'", double1 == (-0.6931471805599453d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-3.557981549420964d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable10, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) (-75.8908547263655d));
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        org.apache.commons.math.random.RandomGenerator randomGenerator24 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator24);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl26 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl26.reseedRandomGenerator(100L);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray32);
        java.lang.Object[] objArray34 = maxIterationsExceededException33.getArguments();
        java.lang.Object[] objArray37 = new java.lang.Object[] { localizable17, randomDataImpl25, 100L, maxIterationsExceededException33, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: hi!", objArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable10, objArray37);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray37);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long6 = randomDataImpl1.nextPoisson(46.282086480509435d);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 93.87203509990088d + "'", double4 == 93.87203509990088d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 41L + "'", long6 == 41L);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl10, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray19);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException14, localizable15, objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray21);
        int int24 = maxIterationsExceededException23.getMaxIterations();
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.random.RandomGenerator randomGenerator37 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator37);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl38, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("{0} is larger than, or equal to, the maximum ({1})", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException23, localizable30, objArray40);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        java.lang.Object[] objArray7 = mathException6.getArguments();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 96.0f + "'", number5.equals(96.0f));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl20, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray29);
        java.lang.Object[] objArray31 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException24, localizable25, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray31);
        java.lang.Class<?> wildcardClass34 = objArray31.getClass();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(throwable1, localizable7, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator44 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator44);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl45, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray47);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NumberIsTooSmallException: 0.412 is smaller than the minimum (8.314)", objArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(11, localizable7, objArray47);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, objArray57);
        java.lang.Object[] objArray60 = mathIllegalArgumentException59.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator69 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator69);
        java.lang.Object[] objArray72 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl70, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray72);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException59, "hi!", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException51, "convergence failed", objArray72);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.8840239792717893d, 7.0d);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray12);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number20 = numberIsTooLargeException19.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator31 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl32 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl32, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray41);
        java.lang.Object[] objArray43 = maxIterationsExceededException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException36, localizable37, objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray43);
        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable21, objArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray46);
        java.lang.Number number49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number49);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-0.3656749468758122d), (java.lang.Number) 0.04537540194980249d, false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10.0f + "'", number20.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray46);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        double double15 = randomDataImpl1.nextGaussian((double) 98L, Double.POSITIVE_INFINITY);
//        try {
//            int int19 = randomDataImpl1.nextHypergeometric((int) ' ', 11, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (32): sample size (100) must be less than or equal to population size (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 81.46412418149305d + "'", double4 == 81.46412418149305d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.4711276743037347d, (java.lang.Number) (byte) -1, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.4711276743037347d + "'", number5.equals(1.4711276743037347d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.14614958006663759d, (java.lang.Number) 0.5042820159726888d, false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.010836982743604793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.734723475976807E-18d + "'", double1 == 1.734723475976807E-18d);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        double double11 = randomDataImpl8.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl12.reseedRandomGenerator(1L);
//        double double15 = normalDistributionImpl12.getStandardDeviation();
//        double double17 = normalDistributionImpl12.inverseCumulativeProbability((double) 0L);
//        double double18 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double19 = normalDistributionImpl12.sample();
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double23 = randomDataImpl1.nextBeta(34.213115462145595d, 0.17791211831147322d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.23696077929129156d + "'", double4 == 0.23696077929129156d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 24.3571572976292d + "'", double11 == 24.3571572976292d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.4394007238905039d) + "'", double18 == (-0.4394007238905039d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.561581040188955d + "'", double19 == 1.561581040188955d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.025790943372216903d + "'", double20 == 0.025790943372216903d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.9994772930920011d + "'", double23 == 0.9994772930920011d);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.util.FastMath.max(24.627015616044797d, 103.0939387038896d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 103.0939387038896d + "'", double2 == 103.0939387038896d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.special.Erf.erf(0.1828028409624149d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20399612595907754d + "'", double1 == 0.20399612595907754d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double[] doubleArray5 = normalDistributionImpl0.sample((int) 'a');
        java.lang.Class<?> wildcardClass6 = normalDistributionImpl0.getClass();
        double double7 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (byte) 10, (java.lang.Number) 10, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.01083698274360479d, (java.lang.Number) 0.3818838848431867d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 10.0d, (java.lang.Number) (-0.35057032410162714d), (java.lang.Number) 84.91825837008986d);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        randomDataImpl1.reSeed((long) 100);
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) (short) 10);
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        double double13 = randomDataImpl10.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl14.reseedRandomGenerator(1L);
//        double double17 = normalDistributionImpl14.getStandardDeviation();
//        double double19 = normalDistributionImpl14.inverseCumulativeProbability((double) 0L);
//        double double20 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double22 = normalDistributionImpl14.cumulativeProbability((-1.0621717148059133d));
//        double double23 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        randomDataImpl1.reSeedSecure(4L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 66.9361455860433d + "'", double4 == 66.9361455860433d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "561f553834" + "'", str8.equals("561f553834"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 39.00560798982979d + "'", double13 == 39.00560798982979d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.4176709941163949d) + "'", double20 == (-0.4176709941163949d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.14407886904420542d + "'", double22 == 0.14407886904420542d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-0.8597042078028618d) + "'", double23 == (-0.8597042078028618d));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray7);
        org.apache.commons.math.random.RandomGenerator randomGenerator10 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl12.reseedRandomGenerator(100L);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizable3, randomDataImpl11, 100L, maxIterationsExceededException19, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable1, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("8", objArray23);
        java.lang.Object[] objArray27 = convergenceException26.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number34 = numberIsTooLargeException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooLargeException33.getGeneralPattern();
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable35, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number44 = numberIsTooLargeException43.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooLargeException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray50 = numberIsTooLargeException49.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray56 = numberIsTooLargeException55.getArguments();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException49, "org.apache.commons.math.MathException: hi!", objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable45, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, "f56995746292f178b6b5b4f5069e061fc1705df8638a85ead5bd", objArray56);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 10.0f + "'", number34.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10.0f + "'", number44.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray56);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        int int13 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) 'a');
//        int int17 = randomDataImpl1.nextHypergeometric(16, 0, (int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 62.01813043187147d + "'", double4 == 62.01813043187147d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8909671320829397d + "'", double7 == 0.8909671320829397d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.8847925332709026E-7d + "'", double10 == 1.8847925332709026E-7d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 68.67216816885978d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass3 = notStrictlyPositiveException1.getClass();
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean5 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.atan(93.87203509990088d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5601439299002324d + "'", double1 == 1.5601439299002324d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.15785840382471578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl10, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray19);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException14, localizable15, objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray21);
        java.lang.Object[] objArray24 = maxIterationsExceededException23.getArguments();
        int int25 = maxIterationsExceededException23.getMaxIterations();
        java.lang.Object[] objArray26 = maxIterationsExceededException23.getArguments();
        int int27 = maxIterationsExceededException23.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.2215487265496865d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double2 = org.apache.commons.math.util.FastMath.min(3.5617698111746443d, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) '4');
//        long long9 = randomDataImpl1.nextSecureLong((long) (short) -1, 15L);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double13 = randomDataImpl1.nextF(0.24954006386441938d, (-24.39534554885089d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -24.395 is smaller than, or equal to, the minimum (0): degrees of freedom (-24.395)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.904988220155929d + "'", double4 == 10.904988220155929d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a6d7dce1c68d87089098ad83cf1c1aa337f63055506eefa9a52c" + "'", str6.equals("a6d7dce1c68d87089098ad83cf1c1aa337f63055506eefa9a52c"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray8);
        java.lang.Object[] objArray11 = mathIllegalArgumentException10.getArguments();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray19);
        java.lang.Object[] objArray22 = mathIllegalArgumentException21.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator31 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl32 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl32, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException21, "hi!", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray45);
        java.lang.Object[] objArray48 = mathIllegalArgumentException47.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator57 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator57);
        java.lang.Object[] objArray60 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl58, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray60);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException47, "hi!", objArray60);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("hi!", objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(35, localizable13, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(35, localizable1, objArray60);
        java.lang.Object[] objArray67 = maxIterationsExceededException66.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray67);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double7 = randomDataImpl1.nextCauchy(3.58351893845611d, 0.47295125419950956d);
//        try {
//            double double10 = randomDataImpl1.nextGamma((double) (byte) 0, (-4.440892098500626E-16d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.22775016265850195d + "'", double4 == 0.22775016265850195d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.531271025354686d + "'", double7 == 3.531271025354686d);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.38581129531356667d), (double) 97, 101.99969623205054d, 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(81.77993441889764d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4273291176747995d + "'", double1 == 1.4273291176747995d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        double double13 = randomDataImpl1.nextGamma(2.7015257296375244d, 29.608888043985793d);
//        int int16 = randomDataImpl1.nextBinomial(0, 0.1999606625952326d);
//        try {
//            double double19 = randomDataImpl1.nextF(1.0d, (-0.5498142964673939d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.55 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.55)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 59.986425225994246d + "'", double4 == 59.986425225994246d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9630465481241449d + "'", double7 == 0.9630465481241449d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 79.50846225537005d + "'", double13 == 79.50846225537005d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.3656749468758122d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3575796970385528d) + "'", double1 == (-0.3575796970385528d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5E-323d + "'", double1 == 1.5E-323d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        long long1 = org.apache.commons.math.util.FastMath.abs(60L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 60L + "'", long1 == 60L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 1, 1.109574019484469d, 8.682424789537251E-23d, 11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (11) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 100, (java.lang.Number) 0.07149157667917685d, (java.lang.Number) 40.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(60);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) '4');
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) (short) 10);
//        try {
//            double double11 = randomDataImpl1.nextF((-0.3575796970385528d), 63.24585066008639d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.358 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.358)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5624727430824017d + "'", double4 == 0.5624727430824017d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "d15a7cd314db4634396ed3ce6fda33fbc5bf62e0bb9ea33d6c2b" + "'", str6.equals("d15a7cd314db4634396ed3ce6fda33fbc5bf62e0bb9ea33d6c2b"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2abaad0baf" + "'", str8.equals("2abaad0baf"));
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str12 = randomDataImpl1.nextSecureHexString((int) '#');
//        int int15 = randomDataImpl1.nextInt(20, (int) '#');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.92383317407145d + "'", double4 == 52.92383317407145d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "71259655239256e4bda9767f74e8b8f19bd" + "'", str12.equals("71259655239256e4bda9767f74e8b8f19bd"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.special.Erf.erf(1.6456677510321152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9800520605495211d + "'", double1 == 0.9800520605495211d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator16 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl17, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6, "hi!", objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6);
        java.lang.String str24 = mathException23.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.MathException: " + "'", str24.equals("org.apache.commons.math.MathException: "));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        double double15 = randomDataImpl1.nextGamma((double) 20, 0.8427007929497151d);
//        double double17 = randomDataImpl1.nextT(353.4361705112366d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 54.65723241961061d + "'", double4 == 54.65723241961061d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 14.264796017710157d + "'", double15 == 14.264796017710157d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.5653150604217223d) + "'", double17 == (-1.5653150604217223d));
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.20757123791676965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20906501510996636d + "'", double1 == 0.20906501510996636d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0024347940274441885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13950342175621194d + "'", double1 == 0.13950342175621194d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.06893822784761361d, 40.77752427469333d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 2.2495859853146735E-7d, (java.lang.Number) (-0.6501341356232105d), false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.4417345421414022E-36d, (java.lang.Number) 0.15918960379189448d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double14 = randomDataImpl1.nextF(0.39104575784009526d, (double) 1.0f);
//        double double17 = randomDataImpl1.nextGaussian(7.625239999300341E-54d, 0.18958236085559627d);
//        try {
//            int[] intArray20 = randomDataImpl1.nextPermutation(0, 12);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 12 is larger than the maximum (0): permutation size (12) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7396650660464691d + "'", double4 == 0.7396650660464691d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0266450269494372d) + "'", double11 == (-1.0266450269494372d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.1236140302171193d + "'", double14 == 0.1236140302171193d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.3473974372425997d) + "'", double17 == (-0.3473974372425997d));
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(12.716079753244326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2219374596403016d + "'", double1 == 0.2219374596403016d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.9800520605495211d, (java.lang.Number) (-0.4824747298270493d), false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException6.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable8, objArray9);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number17 = numberIsTooLargeException16.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray23 = numberIsTooLargeException22.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray29 = numberIsTooLargeException28.getArguments();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, "org.apache.commons.math.MathException: hi!", objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable18, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.ConvergenceException: ", objArray29);
        int int33 = maxIterationsExceededException32.getMaxIterations();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 10.0f + "'", number17.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.21427612190975057d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        randomDataImpl1.reSeed();
//        double double14 = randomDataImpl1.nextCauchy(1.7267809410285682E-9d, 0.8840239792717893d);
//        randomDataImpl1.reSeedSecure(10L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 54.85879006596729d + "'", double4 == 54.85879006596729d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-23.07440638093661d) + "'", double10 == (-23.07440638093661d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.050181104585619515d + "'", double14 == 0.050181104585619515d);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.22135471229049417d, 51.1359249009074d, 96.48583285410783d, (int) 'a');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.9141461864902605E-25d + "'", double4 == 6.9141461864902605E-25d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.4121576859496273d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9800520605495211d, 0.689556501423696d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4920902048753111d + "'", double2 == 0.4920902048753111d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.5905040535376296d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double2 = org.apache.commons.math.util.FastMath.min(0.23417655849041552d, 44.725416200613196d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.23417655849041552d + "'", double2 == 0.23417655849041552d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getMean();
        double double8 = normalDistributionImpl0.cumulativeProbability(0.1672534957718592d, 8.314372756818326d);
        double double9 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.43358529681611513d + "'", double8 == 0.43358529681611513d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable10, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) (-75.8908547263655d));
        boolean boolean15 = notStrictlyPositiveException14.getBoundIsAllowed();
        java.lang.Number number16 = notStrictlyPositiveException14.getMin();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0 + "'", number16.equals(0));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextBinomial((int) (byte) 0, 0.8894305254963171d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2742934329779327d + "'", double4 == 0.2742934329779327d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 103.93064631980363d + "'", double6 == 103.93064631980363d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int2 = org.apache.commons.math.util.FastMath.min(88, 55);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55 + "'", int2 == 55);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double12 = normalDistributionImpl5.sample();
//        double[] doubleArray14 = normalDistributionImpl5.sample(18);
//        double double15 = normalDistributionImpl5.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 48814.13744071683d + "'", double4 == 48814.13744071683d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.10756518963203031d + "'", double11 == 0.10756518963203031d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.561581040188955d + "'", double12 == 1.561581040188955d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int13 = randomDataImpl1.nextPascal(15, 18.338086592654733d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 18.338 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 81.61762981307275d + "'", double4 == 81.61762981307275d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.0000000000000004d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9999999999991522d, (-24.39534554885089d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.715441767946841d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGaussian(0.19754158626110724d, 1.4273291176747995d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 83.57677512456844d + "'", double4 == 83.57677512456844d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.223898927704819d + "'", double8 == 2.223898927704819d);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 15.930807614851348d);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9431910296713536d) + "'", double1 == (-0.9431910296713536d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray12);
        org.apache.commons.math.random.RandomGenerator randomGenerator15 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator15);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl17.reseedRandomGenerator(100L);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray23);
        java.lang.Object[] objArray25 = maxIterationsExceededException24.getArguments();
        java.lang.Object[] objArray28 = new java.lang.Object[] { localizable8, randomDataImpl16, 100L, maxIterationsExceededException24, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) mathException29);
        java.lang.Object[] objArray31 = mathIllegalArgumentException6.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 6.875685348521053d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 6.875685348521053d + "'", number2.equals(6.875685348521053d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray6);
        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl11.reseedRandomGenerator(100L);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizable2, randomDataImpl10, 100L, maxIterationsExceededException18, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        java.lang.String str24 = mathException23.getPattern();
        java.lang.String str25 = mathException23.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator34 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator34);
        java.lang.Object[] objArray37 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl35, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray44);
        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException39, localizable40, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException23, "org.apache.commons.math.MathException: hi!", objArray46);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("4d3a4d9cb6c13c2b775f652975fba222982ec2b6191c9c99a206f4fddd235e44b5685729b3c87bec96c5df6c3ec9b8681", objArray46);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str25.equals("org.apache.commons.math.MathException: hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray46);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        double double7 = randomDataImpl1.nextF(0.3770174256150502d, 2.718281828459045d);
//        randomDataImpl1.reSeed(19L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7589.312174783662d + "'", double4 == 7589.312174783662d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.01236585548461512d + "'", double7 == 0.01236585548461512d);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 54.65077540676269d, (java.lang.Number) 36.365754719395014d, true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5498142964673939d), (java.lang.Number) 2979.3805346802806d, false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable2, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (-0.6321205588285577d));
        org.junit.Assert.assertNull(localizable1);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-0.6746441423588928d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.20906501510996636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21061874854647292d + "'", double1 == 0.21061874854647292d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.special.Erf.erf(0.20757123791676965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.230898258360528d + "'", double1 == 0.230898258360528d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double[] doubleArray5 = normalDistributionImpl0.sample((int) 'a');
        java.lang.Class<?> wildcardClass6 = normalDistributionImpl0.getClass();
        double double8 = normalDistributionImpl0.cumulativeProbability(91.6219872962048d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        long long2 = org.apache.commons.math.util.FastMath.max(96L, 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 35L, (java.lang.Number) 0.20757123791676968d, true);
        java.lang.Class<?> wildcardClass5 = numberIsTooSmallException4.getClass();
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.21427612190975057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21764898160946616d + "'", double1 == 0.21764898160946616d);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        randomDataImpl1.reSeed();
//        int int14 = randomDataImpl1.nextZipf(1, 25.222985934502482d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 79.57786358880159d + "'", double4 == 79.57786358880159d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 291.78263082750624d + "'", double10 == 291.78263082750624d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int1 = org.apache.commons.math.util.FastMath.abs(60);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 60 + "'", int1 == 60);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double13 = normalDistributionImpl5.density(0.1999608207388626d);
//        double double14 = normalDistributionImpl5.getMean();
//        double double16 = normalDistributionImpl5.density(0.0d);
//        double double17 = normalDistributionImpl5.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10250.36060389756d + "'", double4 == 10250.36060389756d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.8327604948639298d + "'", double11 == 1.8327604948639298d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.39104575784009526d + "'", double13 == 0.39104575784009526d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.3989422804014327d + "'", double16 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.561581040188955d + "'", double17 == 1.561581040188955d);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 59, (-75.8908547263655d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.06001130231617E-135d + "'", double2 == 4.06001130231617E-135d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.asin(100.25166374701818d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        double double11 = randomDataImpl1.nextExponential(0.44783479200344534d);
//        int int14 = randomDataImpl1.nextInt(15, 35);
//        double double17 = randomDataImpl1.nextGaussian(26.74676383308201d, 0.872227618153797d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2713906292223511d + "'", double4 == 0.2713906292223511d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 86.76622401712028d + "'", double6 == 86.76622401712028d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.690432717057863d) + "'", double9 == (-0.690432717057863d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.31539032012106166d + "'", double11 == 0.31539032012106166d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.305821771862508d + "'", double17 == 27.305821771862508d);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(71.6783941778998d, 2.7015257296375244d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.901419408985361E-74d + "'", double2 == 3.901419408985361E-74d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.log1p(103.0939387038896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.645293748218629d + "'", double1 == 4.645293748218629d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.cosh(31.270368997361853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9033502214555805E13d + "'", double1 == 1.9033502214555805E13d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable7, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 10L);
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, number12, (java.lang.Number) (-1), (java.lang.Number) 0.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number21 = numberIsTooLargeException20.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException20.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable22, objArray23);
        java.lang.Throwable[] throwableArray25 = maxIterationsExceededException24.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(52, localizable7, (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double14 = randomDataImpl1.nextF(0.39104575784009526d, (double) 1.0f);
//        try {
//            double double16 = randomDataImpl1.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 567.8526187763408d + "'", double4 == 567.8526187763408d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5731363269511681d + "'", double11 == 0.5731363269511681d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 86.59593607288483d + "'", double14 == 86.59593607288483d);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray36);
        org.apache.commons.math.random.RandomGenerator randomGenerator39 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl40 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator39);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl41.reseedRandomGenerator(100L);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray47);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizable32, randomDataImpl40, 100L, maxIterationsExceededException48, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable30, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable16, objArray52);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 26.481350254060672d, (java.lang.Number) 0.09479238471064773d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9126732399377375d, (java.lang.Number) 100.0f, false);
        numberIsTooSmallException59.addSuppressed((java.lang.Throwable) numberIsTooLargeException63);
        boolean boolean65 = numberIsTooLargeException63.getBoundIsAllowed();
        boolean boolean66 = numberIsTooLargeException63.getBoundIsAllowed();
        java.lang.Number number67 = numberIsTooLargeException63.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 100.0f + "'", number67.equals(100.0f));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.690432717057863d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        int int9 = randomDataImpl1.nextZipf(100, (double) 97);
//        double double12 = randomDataImpl1.nextCauchy(1.0878811995641964d, 3.109369441615935E-6d);
//        double double14 = randomDataImpl1.nextChiSquare(353.4361705112366d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2440340300203556d + "'", double4 == 0.2440340300203556d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0878901035331996d + "'", double12 == 1.0878901035331996d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 327.69667971213823d + "'", double14 == 327.69667971213823d);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl20, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray29);
        java.lang.Object[] objArray31 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException24, localizable25, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable7, objArray31);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number39 = numberIsTooLargeException38.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number46 = numberIsTooLargeException45.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooLargeException45.getGeneralPattern();
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable47, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) 10L);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable47, objArray52);
        java.lang.Object[] objArray54 = null;
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException34, localizable40, objArray54);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 10.0f + "'", number39.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 10.0f + "'", number46.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        randomDataImpl1.reSeed((long) 100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 72.35402434690985d + "'", double4 == 72.35402434690985d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.942140614568423d + "'", double7 == 0.942140614568423d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9830471198238661d + "'", double10 == 0.9830471198238661d);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, 100L);
//        java.lang.String str9 = randomDataImpl1.nextSecureHexString((int) '4');
//        double double12 = randomDataImpl1.nextWeibull(25.937539580623483d, 0.21565366040153144d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 72.25727737403298d + "'", double4 == 72.25727737403298d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 95L + "'", long7 == 95L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a9a5b3b73ba8816e1f4a37151df1f4ab6743ef837dfbc0a7278d" + "'", str9.equals("a9a5b3b73ba8816e1f4a37151df1f4ab6743ef837dfbc0a7278d"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.21778373542280843d + "'", double12 == 0.21778373542280843d);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double2 = org.apache.commons.math.util.FastMath.pow(44.69348890483312d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.69348890483312d + "'", double2 == 44.69348890483312d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.random.RandomGenerator randomGenerator6 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator6);
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl7, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("{0} is larger than, or equal to, the maximum ({1})", objArray9);
        java.lang.Class<?> wildcardClass12 = convergenceException11.getClass();
        java.lang.String str13 = convergenceException11.getPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str13.equals("{0} is larger than, or equal to, the maximum ({1})"));
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl1.reseedRandomGenerator(100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        double double6 = randomDataImpl0.nextChiSquare(7589.312174783662d);
//        long long8 = randomDataImpl0.nextPoisson(0.09479238471064773d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.315055057192924d + "'", double4 == 2.315055057192924d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7378.780169315607d + "'", double6 == 7378.780169315607d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        int int9 = randomDataImpl1.nextZipf(100, (double) 97);
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.36884906555988933d + "'", double4 == 0.36884906555988933d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6d4ef2528644d6bd2293246a108c122d212e77213db971b809780bb7fcade32b810763a5b954b12be3e463c2be4561c78c1e" + "'", str11.equals("6d4ef2528644d6bd2293246a108c122d212e77213db971b809780bb7fcade32b810763a5b954b12be3e463c2be4561c78c1e"));
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.signum(46.52363512324914d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.109369441615935E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01459567245484775d + "'", double1 == 0.01459567245484775d);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        randomDataImpl1.reSeedSecure((long) 59);
//        int int15 = randomDataImpl1.nextSecureInt(0, 16);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 98.13732395912119d + "'", double4 == 98.13732395912119d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-446.2662505832234d) + "'", double10 == (-446.2662505832234d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(436.9450405164186d, (-0.3291799577374817d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.329 is smaller than, or equal to, the minimum (0): standard deviation (-0.329)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, 7.131852712598321E-7d, 1.0878811995641964d);
        double double5 = normalDistributionImpl3.cumulativeProbability((-0.09733935539955661d));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.21240085597318314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21240085597318314d + "'", double1 == 0.21240085597318314d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        org.apache.commons.math.random.RandomGenerator randomGenerator8 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator8);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl10.reseedRandomGenerator(100L);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizable1, randomDataImpl9, 100L, maxIterationsExceededException17, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, "24c387abab911f544388d27fd09911a0db830f9ff7cbc751aaeb", objArray24);
        java.lang.String str26 = mathException25.getPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "24c387abab911f544388d27fd09911a0db830f9ff7cbc751aaeb" + "'", str26.equals("24c387abab911f544388d27fd09911a0db830f9ff7cbc751aaeb"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double3 = normalDistributionImpl0.getMean();
        double double5 = normalDistributionImpl0.density((double) 5L);
        try {
            double double8 = normalDistributionImpl0.cumulativeProbability(1.6473520704442785E-4d, (-0.6746441423588928d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4867195147342979E-6d + "'", double5 == 1.4867195147342979E-6d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8427007929497151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9445489455354418d + "'", double1 == 0.9445489455354418d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable6, objArray7);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 1.9751160743707064d, (java.lang.Number) 0.9830471198238661d, (java.lang.Number) 101.99969623205054d);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.3796077390275217d + "'", number5.equals(0.3796077390275217d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.log(99.10829572357183d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.596213148463804d + "'", double1 == 4.596213148463804d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.signum(85.57471435858936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray36);
        org.apache.commons.math.random.RandomGenerator randomGenerator39 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl40 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator39);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl41.reseedRandomGenerator(100L);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray47);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizable32, randomDataImpl40, 100L, maxIterationsExceededException48, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable30, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable16, objArray52);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 26.481350254060672d, (java.lang.Number) 0.09479238471064773d, false);
        boolean boolean60 = numberIsTooSmallException59.getBoundIsAllowed();
        boolean boolean61 = numberIsTooSmallException59.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double3 = normalDistributionImpl0.getMean();
        double double6 = normalDistributionImpl0.cumulativeProbability(55.32768878020956d, 3170.0430573193257d);
        double double8 = normalDistributionImpl0.cumulativeProbability(0.3622068133401169d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6414012557756436d + "'", double8 == 0.6414012557756436d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 60);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1420073898156842E26d + "'", double1 == 1.1420073898156842E26d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double[] doubleArray6 = normalDistributionImpl0.sample((int) (byte) 100);
        double[] doubleArray8 = normalDistributionImpl0.sample(15);
        try {
            double double10 = normalDistributionImpl0.inverseCumulativeProbability(86.42824201378897d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 86.428 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double7 = normalDistributionImpl0.cumulativeProbability(0.05154365172832798d, (double) 100.0f);
        double double8 = normalDistributionImpl0.sample();
        double double9 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.47944615950454317d + "'", double7 == 0.47944615950454317d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6246292191371761d + "'", double8 == 0.6246292191371761d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        randomDataImpl1.reSeed((long) 100);
//        randomDataImpl1.reSeed(35L);
//        long long10 = randomDataImpl1.nextPoisson(3.901419408985361E-74d);
//        double double13 = randomDataImpl1.nextBeta(3.9297333015862225E-4d, 15.930807614851346d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 94.1626008429542d + "'", double4 == 94.1626008429542d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(18.338086592654733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.282299218020003d + "'", double1 == 4.282299218020003d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number10 = numberIsTooLargeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl22, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable11, objArray24);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable4, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator37 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator37);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl38, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable31, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray40);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathIllegalArgumentException44.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0f + "'", number10.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNull(localizable45);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(12);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number8 = outOfRangeException7.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator18 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl19, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "e29c90bbb50243fa52407941c71cb5123bdb29abc15fe804c319f7081cae208160bf6a8bbcec65dd7fc6aa476c3a2e84c", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "org.apache.commons.math.MathException: ", objArray21);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.3796077390275217d + "'", number8.equals(0.3796077390275217d));
        org.junit.Assert.assertNotNull(objArray21);
    }
}

