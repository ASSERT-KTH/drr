import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4711276743037347d + "'", double2 == 1.4711276743037347d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextInt((int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0): lower bound (52) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int[] intArray4 = randomDataImpl1.nextPermutation(1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextBeta(0.0d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.104");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 10, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45792971447185016d + "'", double2 == 0.45792971447185016d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test014");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        try {
//            int[] intArray10 = randomDataImpl1.nextPermutation((-1), (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (-1): permutation size (1) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 91.63231523481909d + "'", double4 == 91.63231523481909d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.45792971447185016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3770174256150502d + "'", double1 == 0.3770174256150502d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 100, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (short) 0, 1.4711276743037347d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        try {
//            double double7 = randomDataImpl1.nextGamma(0.0d, 96.48583285410783d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.1691823719510778d + "'", double4 == 0.1691823719510778d);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.600161852571429d + "'", double1 == 4.600161852571429d);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        try {
//            int int8 = randomDataImpl1.nextHypergeometric((int) (byte) 1, (int) (short) 100, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (1): number of successes (100) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.449543572620365E-5d + "'", double4 == 5.449543572620365E-5d);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        long long1 = org.apache.commons.math.util.FastMath.round(95.95371980941931d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 96L + "'", long1 == 96L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            java.lang.String str3 = randomDataImpl1.nextSecureHexString((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) 96L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.0f + "'", float2 == 96.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 0, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.special.Erf.erf(0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4086262911371656d + "'", double1 == 0.4086262911371656d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.4086262911371656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38730565711751785d + "'", double1 == 0.38730565711751785d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException6.getSuppressed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        try {
//            int int10 = randomDataImpl1.nextInt(100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 57.262324870996196d + "'", double4 == 57.262324870996196d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 0, 1.5707963267948966d, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.3770174256150502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.083791446880058d + "'", double1 == 8.083791446880058d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        try {
//            double double9 = randomDataImpl1.nextChiSquare((-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.5 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 57.57675420922663d + "'", double4 == 57.57675420922663d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) ' ', (double) ' ', Double.POSITIVE_INFINITY, 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9296597126314966d + "'", double4 == 0.9296597126314966d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 0, 95.95371980941931d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        try {
//            int int10 = randomDataImpl1.nextSecureInt((int) '4', (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (1): lower bound (52) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 48.75657717437384d + "'", double4 == 48.75657717437384d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8533565165065399d + "'", double7 == 0.8533565165065399d);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        try {
//            double double9 = randomDataImpl1.nextWeibull(0.0d, (double) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2068972322468499d + "'", double4 == 0.2068972322468499d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 92.6930413781624d + "'", double6 == 92.6930413781624d);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8427007929497151d + "'", double1 == 0.8427007929497151d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.47295125419950956d + "'", double0 == 0.47295125419950956d);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long2 = org.apache.commons.math.util.FastMath.max(3L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double3 = normalDistributionImpl0.getMean();
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        long long13 = randomDataImpl1.nextLong(96L, (long) (short) 100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 29.608888043985797d + "'", double4 == 29.608888043985797d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.247597350032484d + "'", double10 == 6.247597350032484d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 98L + "'", long13 == 98L);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        try {
//            int int12 = randomDataImpl1.nextPascal(10, (-0.6321205588285577d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.632 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.17278223496572043d + "'", double4 == 0.17278223496572043d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 92.09547201252718d + "'", double6 == 92.09547201252718d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5700495145307305d + "'", double9 == 0.5700495145307305d);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        try {
//            long long10 = randomDataImpl1.nextLong(96L, 1L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 96 is larger than, or equal to, the maximum (1): lower bound (96) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 31.688966065749185d + "'", double4 == 31.688966065749185d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9153488854330085d + "'", double7 == 0.9153488854330085d);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        try {
//            double double7 = randomDataImpl1.nextWeibull(0.5d, (-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 31.535782576383188d + "'", double4 == 31.535782576383188d);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1662.8064859732033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.77752427469333d + "'", double1 == 40.77752427469333d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.signum(94.43132302115413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 96L, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9126732399377374d, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9126732399377375d + "'", double2 == 0.9126732399377375d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(29.608888043985797d, 0.20757123791676968d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.608888043985793d + "'", double2 == 29.608888043985793d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.tan(56.19809744051465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3656749468758122d) + "'", double1 == (-0.3656749468758122d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable2, objArray3);
        try {
            java.lang.String str5 = convergenceException4.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(localizable1);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9496044232827009d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9829111076778834d + "'", double1 == 0.9829111076778834d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.6321205588285577d), 1662.8064859732033d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        int int13 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) 'a');
//        try {
//            double double16 = randomDataImpl1.nextUniform((double) (byte) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 21.998058228377584d + "'", double4 == 21.998058228377584d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9006171335976427d + "'", double7 == 0.9006171335976427d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9823515243247982d + "'", double10 == 0.9823515243247982d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 81 + "'", int13 == 81);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5063656411097588d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.979815974417952E-5d, (double) (short) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.4711276743037347d, (java.lang.Number) (byte) -1, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) -1 + "'", number6.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) -1 + "'", number7.equals((byte) -1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.38730565711751785d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int4 = randomDataImpl0.nextHypergeometric((int) (short) 10, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (10): number of successes (35) must be less than or equal to population size (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(Double.POSITIVE_INFINITY, (-0.5498142964673939d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5498142964673939d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4229430380526849d) + "'", double1 == (-0.4229430380526849d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 0, (double) ' ');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6321205588285577d + "'", double1 == 0.6321205588285577d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.3770174256150502d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        try {
            double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 35 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.247597350032484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl1.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14491836621348747d + "'", double4 == 0.14491836621348747d);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 10, 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 15, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15L + "'", long2 == 15L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.3770174256150502d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0L, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.expm1(56.19809744051465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.549902718048101E24d + "'", double1 == 2.549902718048101E24d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        int int10 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) ' ');
//        try {
//            int int13 = randomDataImpl1.nextSecureInt((int) (short) 1, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (1): lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 43.14552392775825d + "'", double4 == 43.14552392775825d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9207098327944758d + "'", double7 == 0.9207098327944758d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.461729143006029E41d + "'", double1 == 2.461729143006029E41d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextSecureInt(97, 15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (15): lower bound (97) must be strictly less than upper bound (15)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0d, (-0.3656749468758122d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06893822784761361d + "'", double1 == 0.06893822784761361d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.exp(44.725416200613196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6546144663255556E19d + "'", double1 == 2.6546144663255556E19d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, 100L);
//        try {
//            long long10 = randomDataImpl1.nextLong(58L, (long) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 58 is larger than, or equal to, the maximum (10): lower bound (58) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 38.75155945877649d + "'", double4 == 38.75155945877649d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(95.95371980941931d, 0.3912338279262167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.247597350032484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 258.38582512321625d + "'", double1 == 258.38582512321625d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.549902718048101E24d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, 100L);
//        try {
//            double double10 = randomDataImpl1.nextCauchy(0.20757123791676968d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 40.94451051351815d + "'", double4 == 40.94451051351815d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 96L + "'", long7 == 96L);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextGaussian(25.937539580623483d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(Double.NEGATIVE_INFINITY, 0.05154365172832798d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        int int13 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) 'a');
//        try {
//            int int16 = randomDataImpl1.nextBinomial((int) (byte) 100, 1.0000000000000002d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 33.769045428617076d + "'", double4 == 33.769045428617076d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9350214645764764d + "'", double7 == 0.9350214645764764d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.07629880930458603d + "'", double10 == 0.07629880930458603d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 50 + "'", int13 == 50);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.573155003527255d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable16, (java.lang.Number) 0.0f, (java.lang.Number) 46.52363512324914d, (java.lang.Number) 15L);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.3912338279262167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3818838848431867d + "'", double1 == 0.3818838848431867d);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        try {
//            int int7 = randomDataImpl1.nextBinomial((int) (byte) -1, 0.17453292519943295d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.88411706405023d + "'", double4 == 9.88411706405023d);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double2 = org.apache.commons.math.util.FastMath.min(7.69459862670642E-23d, 25.937539580623483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.69459862670642E-23d + "'", double2 == 7.69459862670642E-23d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.3796077390275217d, (java.lang.Number) 2.2495859853146735E-7d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.3796077390275217d + "'", number4.equals(0.3796077390275217d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(21.772312162421045d, 2.979815974417952E-5d, 0.9496044232827009d, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.tanh(44.725416200613196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray12);
        java.lang.Object[] objArray16 = mathIllegalArgumentException15.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("hi!", "org.apache.commons.math.MathException: hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MathException: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.21860419601686604d + "'", double4 == 0.21860419601686604d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 141.04812489687959d + "'", double6 == 141.04812489687959d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 15.37351817462658d + "'", double9 == 15.37351817462658d);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable2, objArray3);
        java.lang.String str5 = convergenceException0.getPattern();
        org.junit.Assert.assertNull(localizable1);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "convergence failed" + "'", str5.equals("convergence failed"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9296597126314966d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        try {
//            int int8 = randomDataImpl1.nextHypergeometric((int) (byte) 10, 0, (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 50.433860704533075d + "'", double4 == 50.433860704533075d);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        int int13 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) 'a');
//        try {
//            int int16 = randomDataImpl1.nextSecureInt(15, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 15 is larger than, or equal to, the maximum (-1): lower bound (15) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.35269287743202d + "'", double4 == 52.35269287743202d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.856136624345236d + "'", double7 == 0.856136624345236d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.8341973322588593d + "'", double10 == 0.8341973322588593d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 83 + "'", int13 == 83);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        try {
//            long long7 = randomDataImpl1.nextSecureLong(0L, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.48303404261504523d + "'", double4 == 0.48303404261504523d);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric((int) (byte) 0, (int) (byte) -1, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.05438691709397d + "'", double4 == 52.05438691709397d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4023066454805946d + "'", double1 == 3.4023066454805946d);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl1.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 51.925390506223316d + "'", double4 == 51.925390506223316d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9996949470902442d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6456677510321152d + "'", double1 == 1.6456677510321152d);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl1.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 53.312109634433746d + "'", double4 == 53.312109634433746d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 188.1581343864706d + "'", double10 == 188.1581343864706d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.010837194861078087d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01083698274360479d + "'", double1 == 0.01083698274360479d);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        try {
//            int[] intArray13 = randomDataImpl1.nextPermutation(0, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (0): permutation size (1) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.83643176512985d + "'", double4 == 52.83643176512985d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.201558232998046d) + "'", double10 == (-2.201558232998046d));
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 98L);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        try {
//            long long13 = randomDataImpl1.nextLong(96L, (long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 96 is larger than, or equal to, the maximum (10): lower bound (96) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.61874939977628d + "'", double4 == 52.61874939977628d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 277.63758736175606d + "'", double10 == 277.63758736175606d);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5493061443340549d + "'", double1 == 0.5493061443340549d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        java.lang.String str14 = randomDataImpl1.nextSecureHexString(1);
//        try {
//            int int17 = randomDataImpl1.nextInt((int) (byte) 0, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 78.86966452179307d + "'", double4 == 78.86966452179307d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9" + "'", str14.equals("9"));
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(55.32768878020956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3170.0430573193257d + "'", double1 == 3170.0430573193257d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray10 = numberIsTooLargeException9.getArguments();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "org.apache.commons.math.MathException: hi!", objArray10);
        boolean boolean12 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double2 = org.apache.commons.math.util.FastMath.max(258.38582512321625d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 258.38582512321625d + "'", double2 == 258.38582512321625d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0E-9d, (double) 97, (double) (byte) 0, 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.625239999300341E-54d + "'", double4 == 7.625239999300341E-54d);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, 100L);
//        double double10 = randomDataImpl1.nextGamma(0.9126732399377374d, 1.0000000000000002d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 54.65077540676269d + "'", double4 == 54.65077540676269d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.44783479200344534d + "'", double10 == 0.44783479200344534d);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (byte) 10, (java.lang.Number) 10, false);
        boolean boolean13 = numberIsTooSmallException12.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        int int10 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) ' ');
//        try {
//            int int13 = randomDataImpl1.nextSecureInt((int) '#', (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (10): lower bound (35) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 50.42611914614383d + "'", double4 == 50.42611914614383d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8831920564979873d + "'", double7 == 0.8831920564979873d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 29 + "'", int10 == 29);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.06893822784761361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0012031990564309012d + "'", double1 == 0.0012031990564309012d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.559130815791023d + "'", double1 == 4.559130815791023d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1L), (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.625239999300341E-54d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.4711276743037347d, (java.lang.Number) (byte) -1, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double12 = normalDistributionImpl5.sample();
//        normalDistributionImpl5.reseedRandomGenerator((long) (short) 10);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.049291688196848496d + "'", double4 == 0.049291688196848496d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.9718229830168652d + "'", double11 == 1.9718229830168652d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.561581040188955d + "'", double12 == 1.561581040188955d);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8427007929497151d + "'", double1 == 0.8427007929497151d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        org.apache.commons.math.random.RandomGenerator randomGenerator8 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator8);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl10.reseedRandomGenerator(100L);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizable1, randomDataImpl9, 100L, maxIterationsExceededException17, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        java.lang.String str23 = mathException22.getPattern();
        java.lang.String str24 = mathException22.toString();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator33 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator33);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl34, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray43);
        java.lang.Object[] objArray45 = maxIterationsExceededException44.getArguments();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException38, localizable39, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22, "org.apache.commons.math.MathException: hi!", objArray45);
        java.lang.String str48 = convergenceException47.getPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str24.equals("org.apache.commons.math.MathException: hi!"));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str48.equals("org.apache.commons.math.MathException: hi!"));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray7);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray7);
//        org.apache.commons.math.random.RandomGenerator randomGenerator10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl12.reseedRandomGenerator(100L);
//        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray18);
//        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
//        java.lang.Object[] objArray23 = new java.lang.Object[] { localizable3, randomDataImpl11, 100L, maxIterationsExceededException19, 0.45792971447185016d, '4' };
//        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
//        java.lang.String str25 = mathException24.getPattern();
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator34 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator34);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl35, 10L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray37);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray37);
//        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException24, "", objArray37);
//        org.apache.commons.math.random.RandomGenerator randomGenerator41 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl42 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator41);
//        double double45 = randomDataImpl42.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { mathException24, randomDataImpl42, 100, 1.5707963267948966d };
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable0, "", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(objArray18);
//        org.junit.Assert.assertNotNull(objArray20);
//        org.junit.Assert.assertNotNull(objArray23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 107.52383629114054d + "'", double45 == 107.52383629114054d);
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(localizable50);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8871739344521155d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4118179342542967d + "'", double1 == 0.4118179342542967d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.log10(94.43132302115413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9751160743707064d + "'", double1 == 1.9751160743707064d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int2 = org.apache.commons.math.util.FastMath.max(15, 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
//        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
//        java.lang.Throwable throwable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray16);
//        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl21 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl21.reseedRandomGenerator(100L);
//        java.lang.Object[] objArray27 = new java.lang.Object[] { 100L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray27);
//        java.lang.Object[] objArray29 = maxIterationsExceededException28.getArguments();
//        java.lang.Object[] objArray32 = new java.lang.Object[] { localizable12, randomDataImpl20, 100L, maxIterationsExceededException28, 0.45792971447185016d, '4' };
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
//        java.lang.String str34 = mathException33.getPattern();
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator43 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl44 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator43);
//        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl44, 10L };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray46);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
//        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException33, "", objArray46);
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        double double54 = randomDataImpl51.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { mathException33, randomDataImpl51, 100, 1.5707963267948966d };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable9, "", objArray57);
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable6, objArray57);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.7015257296375244d + "'", double54 == 2.7015257296375244d);
//        org.junit.Assert.assertNotNull(objArray57);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        double double3 = normalDistributionImpl0.getMean();
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability(5.298342365610589d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 5.298 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (short) 100);
//        try {
//            double double12 = randomDataImpl1.nextF(0.0d, 0.891552824853609d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.28917448786362865d + "'", double4 == 0.28917448786362865d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 87.44790466706006d + "'", double6 == 87.44790466706006d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 79 + "'", int9 == 79);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        java.lang.String str9 = maxIterationsExceededException8.getPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str9.equals("{0} is larger than, or equal to, the maximum ({1})"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator8 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator8);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl9, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException13, localizable14, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable0, objArray20);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 15L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator17 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl18 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl18, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException7, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("2", objArray20);
        java.lang.String str25 = convergenceException24.toString();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.ConvergenceException: 2" + "'", str25.equals("org.apache.commons.math.ConvergenceException: 2"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.01083698274360479d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010836558541039962d + "'", double1 == 0.010836558541039962d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator15 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl16, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray25);
        java.lang.Object[] objArray27 = maxIterationsExceededException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException20, localizable21, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray27);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable5, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray37);
        java.lang.Object[] objArray40 = mathIllegalArgumentException39.getArguments();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray40);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
        java.lang.Object[] objArray53 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl51, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray53);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray60);
        java.lang.Object[] objArray62 = maxIterationsExceededException61.getArguments();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException55, localizable56, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(localizable5, objArray62);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0012031990564309012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.722078073620237d + "'", double1 == 6.722078073620237d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.7015257296375244d, number1, false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 96.0f + "'", number5.equals(96.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.45792971447185016d + "'", number6.equals(0.45792971447185016d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9154272268957971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.970974762107423d + "'", double1 == 0.970974762107423d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.ceil(42.00873660289519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.0d + "'", double1 == 43.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        double double3 = normalDistributionImpl0.getMean();
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability((-0.03871157267119d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.039 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.6321205588285577d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.2077648676480475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20485050837138863d + "'", double1 == 0.20485050837138863d);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        int int10 = randomDataImpl1.nextInt((int) (byte) 0, (int) ' ');
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 14.903216738460985d + "'", double4 == 14.903216738460985d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.log10(56.19809744051465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.749721612987703d + "'", double1 == 1.749721612987703d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.special.Gamma.digamma(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.503599627370497E15d) + "'", double1 == (-4.503599627370497E15d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.3656749468758122d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.35057032410162714d) + "'", double1 == (-0.35057032410162714d));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        try {
//            long long13 = randomDataImpl1.nextLong((long) 100, (long) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 92.17281278121975d + "'", double4 == 92.17281278121975d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8931965986544553d + "'", double7 == 0.8931965986544553d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.floor((-4.503599627370497E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.503599627370497E15d) + "'", double1 == (-4.503599627370497E15d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.01083698274360479d, 0.010837194861078087d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.010836982743604793d + "'", double2 == 0.010836982743604793d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        try {
//            int int12 = randomDataImpl1.nextInt((int) '4', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0): lower bound (52) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.1429527768199002d + "'", double4 == 0.1429527768199002d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.25001396942518d + "'", double6 == 97.25001396942518d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.3995564188094476d) + "'", double9 == (-2.3995564188094476d));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.asin(258.38582512321625d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl1.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 19.03950784570614d + "'", double4 == 19.03950784570614d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8871896929860024d + "'", double7 == 0.8871896929860024d);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9126732399377374d, 27.391749910748793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 27.391749910748793d + "'", double2 == 27.391749910748793d);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        double double13 = randomDataImpl1.nextGamma(2.7015257296375244d, 29.608888043985793d);
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric((int) (byte) 0, 0, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 18.846011217743403d + "'", double4 == 18.846011217743403d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8937513859327715d + "'", double7 == 0.8937513859327715d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 71.78668744747227d + "'", double13 == 71.78668744747227d);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 98L, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(115.28511402798057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 115.28511402798058d + "'", double1 == 115.28511402798058d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.049291688196848496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator16 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl17, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6, "hi!", objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        java.lang.Object[] objArray6 = maxIterationsExceededException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        java.lang.Object[] objArray8 = mathException7.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.4959198326004437d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.15448707202449546d, 3.4023066454805946d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04537540194980249d + "'", double2 == 0.04537540194980249d);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl2.reseedRandomGenerator(1L);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.24387979418110328d, 0.3796077390275217d);
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric(24, 97, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (24): number of successes (97) must be less than or equal to population size (24)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05154365172832798d + "'", double7 == 0.05154365172832798d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9512713994952529d + "'", double8 == 1.9512713994952529d);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.4118179342542967d, (java.lang.Number) 8.314372756818326d, true);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.412 is smaller than the minimum (8.314)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.412 is smaller than the minimum (8.314)"));
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl1.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.38346200428620353d + "'", double4 == 0.38346200428620353d);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.ulp(6.247597350032484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 1, (-0.5498142964673939d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0734969518535578d + "'", double2 == 2.0734969518535578d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.561581040188955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 122.33019410182337d, (java.lang.Number) 8.535380095788955d, (java.lang.Number) 2.549902718048101E24d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.15785840382471578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15918960379189448d + "'", double1 == 0.15918960379189448d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1458772928133102E-108d + "'", double1 == 2.1458772928133102E-108d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 88, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double2 = org.apache.commons.math.util.FastMath.min(1.6456677510321152d, 94.43132302115413d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6456677510321152d + "'", double2 == 1.6456677510321152d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double5 = normalDistributionImpl0.cumulativeProbability(0.24387979418110328d, 0.3796077390275217d);
        double double7 = normalDistributionImpl0.density(46.282086480509435d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05154365172832798d + "'", double5 == 0.05154365172832798d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4505495340698077d) + "'", double1 == (-0.4505495340698077d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, 0.3523890909055015d);
        double[] doubleArray4 = normalDistributionImpl2.sample((int) '4');
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.01083698274360479d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.exp(74.99200917961215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.703529203440295E32d + "'", double1 == 3.703529203440295E32d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 10, (float) 88);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 88.0f + "'", float2 == 88.0f);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        double double7 = randomDataImpl1.nextF(0.3770174256150502d, 2.718281828459045d);
//        try {
//            double double10 = randomDataImpl1.nextUniform((double) 96.0f, (double) 15);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 96 is larger than, or equal to, the maximum (15): lower bound (96) must be strictly less than upper bound (15)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1085834933776349E-5d + "'", double4 == 1.1085834933776349E-5d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04400679235880075d + "'", double7 == 0.04400679235880075d);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5493061443340549d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8189765857918984d + "'", double1 == 0.8189765857918984d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9126732399377375d, (java.lang.Number) 100.0f, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 68.67216816885978d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray7 = numberIsTooLargeException6.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1, "2", objArray7);
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        int int12 = randomDataImpl1.nextZipf(35, 0.9248506659826856d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 19.700939443479026d + "'", double4 == 19.700939443479026d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        int int10 = randomDataImpl1.nextInt((int) (byte) 0, (int) ' ');
//        try {
//            double double13 = randomDataImpl1.nextBeta((double) (byte) -1, 0.6321205588285577d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.78");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 19.42682056163632d + "'", double4 == 19.42682056163632d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        double double7 = randomDataImpl1.nextF(0.3770174256150502d, 2.718281828459045d);
//        try {
//            int int11 = randomDataImpl1.nextHypergeometric((int) (short) 10, (int) '4', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (10): number of successes (52) must be less than or equal to population size (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.8363612270769587E-8d + "'", double4 == 1.8363612270769587E-8d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 37.715563257449745d + "'", double7 == 37.715563257449745d);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (short) 1, (java.lang.Number) 0.47295125419950956d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.47295125419950956d + "'", number4.equals(0.47295125419950956d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.15785840382471578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3973139864448718d + "'", double1 == 0.3973139864448718d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) ' ', 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4417345421414022E-36d + "'", double2 == 1.4417345421414022E-36d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("2", objArray13);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.559130815791023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.715441767946841d + "'", double1 == 1.715441767946841d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308234d + "'", double1 == 57.29577951308234d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.3291799577374817d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-18.86062227865251d) + "'", double1 == (-18.86062227865251d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        org.apache.commons.math.random.RandomGenerator randomGenerator8 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator8);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl10.reseedRandomGenerator(100L);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizable1, randomDataImpl9, 100L, maxIterationsExceededException17, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator31 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl32 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl32, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray34);
        mathException22.addSuppressed((java.lang.Throwable) mathIllegalArgumentException37);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.20757123791676968d, (java.lang.Number) 0.9126732399377375d, false);
        org.apache.commons.math.random.RandomGenerator randomGenerator10 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl11, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, "", objArray13);
        java.lang.String str16 = mathException15.getPattern();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 15L, (java.lang.Number) 1.6659493224147073d, true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        float float2 = org.apache.commons.math.util.FastMath.min(88.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 96.0f, (java.lang.Number) 51.84386644926108d, false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0L, (java.lang.Number) 115.28511402798057d, (java.lang.Number) (-1.0d));
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double12 = normalDistributionImpl5.sample();
//        double double13 = normalDistributionImpl5.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09824496469161757d + "'", double4 == 0.09824496469161757d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0024347940274441885d + "'", double11 == 0.0024347940274441885d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.561581040188955d + "'", double12 == 1.561581040188955d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.cos((-75.8908547263655d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8810915704862087d + "'", double1 == 0.8810915704862087d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.log1p(56.19809744051465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.046520636303111d + "'", double1 == 4.046520636303111d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.atan(26.74676383308201d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5334260322082676d + "'", double1 == 1.5334260322082676d);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        double double11 = randomDataImpl1.nextChiSquare(0.17453292519943295d);
//        try {
//            int int14 = randomDataImpl1.nextInt((int) (short) 0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19708602117993546d + "'", double4 == 0.19708602117993546d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.04703264196944d + "'", double6 == 89.04703264196944d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.3212595283329981d) + "'", double9 == (-0.3212595283329981d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.007828660069930238d + "'", double11 == 0.007828660069930238d);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.47944615950454317d, 0.05154365172832798d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.96281792207218d + "'", double2 == 0.96281792207218d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException11.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable13, objArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 10L);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.891552824853609d, (java.lang.Number) 25.222985934502482d, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator33 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator33);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl34, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray43);
        java.lang.Object[] objArray45 = maxIterationsExceededException44.getArguments();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException38, localizable39, objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray45);
        java.lang.Object[] objArray48 = maxIterationsExceededException47.getArguments();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable6, objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray48);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10.0f + "'", number12.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.cosh(44.725416200613196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3273072331627778E19d + "'", double1 == 1.3273072331627778E19d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.14407886904420542d, 0.09824496469161757d, (-1.573155003527255d), 15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (15) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        randomDataImpl1.reSeed();
//        double double14 = randomDataImpl1.nextCauchy(1.7267809410285682E-9d, 0.8840239792717893d);
//        try {
//            int int17 = randomDataImpl1.nextInt(1, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (1): lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 31.754107885059685d + "'", double4 == 31.754107885059685d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-82.46680416120165d) + "'", double10 == (-82.46680416120165d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.9339278190516217d) + "'", double14 == (-0.9339278190516217d));
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.549902718048101E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.cosh(63.96243422880708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0026329009050364E27d + "'", double1 == 3.0026329009050364E27d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.7267809410285682E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.791122528842996E8d) + "'", double1 == (-5.791122528842996E8d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.asin(29.608888043985793d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        int int9 = randomDataImpl1.nextZipf(100, (double) 97);
//        try {
//            int[] intArray12 = randomDataImpl1.nextPermutation((int) '#', (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (35): permutation size (52) exceeds permuation domain (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.17940708060159408d + "'", double4 == 0.17940708060159408d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: hi!", objArray1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.log(36.365754719395014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5936275273962304d + "'", double1 == 3.5936275273962304d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8871739344521155d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0911841276836731d) + "'", double1 == (-1.0911841276836731d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.04537540194980249d, (java.lang.Number) 8.881784197001252E-16d, false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.549902718048101E24d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.89400457879299d + "'", double1 == 17.89400457879299d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable9, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException17.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray24 = numberIsTooLargeException23.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray30 = numberIsTooLargeException29.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, "org.apache.commons.math.MathException: hi!", objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable19, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray39);
        org.apache.commons.math.random.RandomGenerator randomGenerator42 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator42);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl44 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl44.reseedRandomGenerator(100L);
        java.lang.Object[] objArray50 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray50);
        java.lang.Object[] objArray52 = maxIterationsExceededException51.getArguments();
        java.lang.Object[] objArray55 = new java.lang.Object[] { localizable35, randomDataImpl43, 100L, maxIterationsExceededException51, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable33, objArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable19, objArray55);
        convergenceException2.addSuppressed((java.lang.Throwable) mathException58);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0f + "'", number8.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 10.0f + "'", number18.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray55);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        double double12 = randomDataImpl1.nextT(7.0d);
//        try {
//            long long15 = randomDataImpl1.nextLong(88L, (long) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 88 is larger than, or equal to, the maximum (1): lower bound (88) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 62.72954153328557d + "'", double4 == 62.72954153328557d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8679722141060819d + "'", double7 == 0.8679722141060819d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.041741009652280066d + "'", double10 == 0.041741009652280066d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0978019263674634d) + "'", double12 == (-1.0978019263674634d));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double2 = org.apache.commons.math.util.FastMath.pow(63.96243422880708d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.26040534270272864d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.cosh(86.20476831353835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3715927999310066E37d + "'", double1 == 1.3715927999310066E37d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double1 = org.apache.commons.math.util.FastMath.ulp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.sinh(46.52363512324914d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.015451976515918E19d + "'", double1 == 8.015451976515918E19d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double2 = org.apache.commons.math.util.FastMath.min(0.1999608207388626d, (double) 96.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1999608207388626d + "'", double2 == 0.1999608207388626d);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "4d3a4d9cb6c13c2b775f652975fba222982ec2b6191c9c99a206f4fddd235e44b5685729b3c87bec96c5df6c3ec9b8681");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 4d3a4d9cb6c13c2b775f652975fba222982ec2b6191c9c99a206f4fddd235e44b5685729b3c87bec96c5df6c3ec9b8681");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 59.448177310671525d + "'", double4 == 59.448177310671525d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.4417345421414022E-36d, (java.lang.Number) 0.15918960379189448d, true);
        java.lang.Class<?> wildcardClass4 = numberIsTooSmallException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8189765857918984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.049291688196848496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36665524127069987d + "'", double1 == 0.36665524127069987d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0878811995641964d, 0.1999608207388626d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8494202381273023d + "'", double2 == 0.8494202381273023d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.3267565761419914d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        try {
            double double6 = normalDistributionImpl0.inverseCumulativeProbability((-0.8871739344521155d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.887 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl1.reseedRandomGenerator(100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.13542756489354157d) + "'", double4 == (-0.13542756489354157d));
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.641588833612779d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        try {
//            double double15 = randomDataImpl1.nextUniform(71.6783941778998d, 1.5430806348152437d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 71.678 is larger than, or equal to, the maximum (1.543): lower bound (71.678) must be strictly less than upper bound (1.543)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 50.03138701403813d + "'", double4 == 50.03138701403813d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 0.5d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        java.lang.String str14 = randomDataImpl1.nextSecureHexString(1);
//        try {
//            double double17 = randomDataImpl1.nextGamma(0.9829111076778834d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 51.61966378860524d + "'", double4 == 51.61966378860524d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "7" + "'", str14.equals("7"));
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.5936275273962304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 11, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int2 = org.apache.commons.math.util.FastMath.min(13, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double13 = normalDistributionImpl5.cumulativeProbability(1.0d);
//        double double15 = normalDistributionImpl5.cumulativeProbability(0.2215487265496865d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.198786870989907E-4d + "'", double4 == 9.198786870989907E-4d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5674744539063689d + "'", double11 == 0.5674744539063689d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.841344746068543d + "'", double13 == 0.841344746068543d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5876673996180602d + "'", double15 == 0.5876673996180602d);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07601103664133135d + "'", double1 == 0.07601103664133135d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        long long12 = randomDataImpl1.nextPoisson(14.903216738460985d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 36.5353837288671d + "'", double4 == 36.5353837288671d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-61.54191176200181d) + "'", double10 == (-61.54191176200181d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 16L + "'", long12 == 16L);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.0024347940274441885d, (java.lang.Number) 0.8494202381273023d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, localizable4, objArray5);
        java.lang.Object[] objArray7 = convergenceException2.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.ConvergenceException: 2", objArray7);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double3 = normalDistributionImpl0.getMean();
        double double5 = normalDistributionImpl0.density(0.19754158626110724d);
        double double7 = normalDistributionImpl0.cumulativeProbability(7.69459862670642E-23d);
        double double8 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.3912338279262167d + "'", double5 == 0.3912338279262167d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10, 0.8840239792717893d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.4417345421414022E-36d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4417345421414022E-36d + "'", double1 == 1.4417345421414022E-36d);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl2.reseedRandomGenerator(1L);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.24387979418110328d, 0.3796077390275217d);
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric(13, 15, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 15 is larger than the maximum (13): number of successes (15) must be less than or equal to population size (13)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05154365172832798d + "'", double7 == 0.05154365172832798d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.5025289953244693d) + "'", double8 == (-0.5025289953244693d));
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (short) 100);
//        try {
//            int int12 = randomDataImpl1.nextPascal(100, Double.POSITIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: ∞ out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.17545690124982838d + "'", double4 == 0.17545690124982838d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.60113176889713d + "'", double6 == 100.60113176889713d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable7, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number16 = numberIsTooLargeException15.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray22 = numberIsTooLargeException21.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray28 = numberIsTooLargeException27.getArguments();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException21, "org.apache.commons.math.MathException: hi!", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable17, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray37);
        org.apache.commons.math.random.RandomGenerator randomGenerator40 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator40);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl42 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl42.reseedRandomGenerator(100L);
        java.lang.Object[] objArray48 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray48);
        java.lang.Object[] objArray50 = maxIterationsExceededException49.getArguments();
        java.lang.Object[] objArray53 = new java.lang.Object[] { localizable33, randomDataImpl41, 100L, maxIterationsExceededException49, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("hi!", objArray53);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable31, objArray53);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable17, objArray53);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 26.481350254060672d, (java.lang.Number) 0.09479238471064773d, false);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator68 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl69 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator68);
        java.lang.Object[] objArray71 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl69, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray71);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable61, localizable62, objArray71);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray78);
        java.lang.Object[] objArray80 = maxIterationsExceededException79.getArguments();
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException73, localizable74, objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable17, objArray80);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10.0f + "'", number16.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray80);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator10 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl11, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray20);
        java.lang.Object[] objArray22 = maxIterationsExceededException21.getArguments();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException15, localizable16, objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray22);
        java.lang.Object[] objArray25 = maxIterationsExceededException24.getArguments();
        int int26 = maxIterationsExceededException24.getMaxIterations();
        java.lang.Object[] objArray27 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("c09eadfb366a3e0310c38ce09425a26bdd0b4690a909d076daed", objArray27);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertNotNull(objArray27);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int13 = randomDataImpl1.nextPascal((int) (short) 100, (-0.4229430380526849d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.423 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.15852932064568973d + "'", double4 == 0.15852932064568973d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 81.94124607411261d + "'", double6 == 81.94124607411261d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.06255339624980413d) + "'", double9 == (-0.06255339624980413d));
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) '4');
//        double double8 = randomDataImpl1.nextExponential(0.36665524127069987d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.109369441615935E-6d + "'", double4 == 3.109369441615935E-6d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24c387abab911f544388d27fd09911a0db830f9ff7cbc751aaeb" + "'", str6.equals("24c387abab911f544388d27fd09911a0db830f9ff7cbc751aaeb"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.512991811647731d + "'", double8 == 0.512991811647731d);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999779095030014d + "'", double1 == 0.9999779095030014d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.03871157267119d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.33828307655636747d) + "'", double1 == (-0.33828307655636747d));
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextBeta(0.3523890909055015d, 0.3796077390275217d);
//        try {
//            int int14 = randomDataImpl1.nextHypergeometric((-1), 35, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 24.514464725280238d + "'", double4 == 24.514464725280238d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8986216814490117d + "'", double7 == 0.8986216814490117d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.720214016522141d + "'", double10 == 0.720214016522141d);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getMean();
        double double4 = normalDistributionImpl0.cumulativeProbability(1.053091277489779d, (double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14614958006663759d + "'", double4 == 0.14614958006663759d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.06893822784761361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07137002627171281d + "'", double1 == 0.07137002627171281d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.atan(51.1359249009074d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5512430957593546d + "'", double1 == 1.5512430957593546d);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.3818838848431867d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("convergence failed", "org.apache.commons.math.ConvergenceException: ");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.ConvergenceException: ");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.47627224076526E-4d + "'", double2 == 1.47627224076526E-4d);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8402864822065015d + "'", double1 == 1.8402864822065015d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int13 = randomDataImpl1.nextPascal(24, 6.722078073620237d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 6.722 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 25.594815533654177d + "'", double4 == 25.594815533654177d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        normalDistributionImpl0.reseedRandomGenerator(0L);
        try {
            double[] doubleArray6 = normalDistributionImpl0.sample((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray17);
        org.apache.commons.math.random.RandomGenerator randomGenerator20 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator20);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl22 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl22.reseedRandomGenerator(100L);
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray28);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        java.lang.Object[] objArray33 = new java.lang.Object[] { localizable13, randomDataImpl21, 100L, maxIterationsExceededException29, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("hi!", objArray33);
        mathIllegalArgumentException11.addSuppressed((java.lang.Throwable) mathException34);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException11);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray44);
        org.apache.commons.math.random.RandomGenerator randomGenerator47 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator47);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl49 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl49.reseedRandomGenerator(100L);
        java.lang.Object[] objArray55 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray55);
        java.lang.Object[] objArray57 = maxIterationsExceededException56.getArguments();
        java.lang.Object[] objArray60 = new java.lang.Object[] { localizable40, randomDataImpl48, 100L, maxIterationsExceededException56, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("hi!", objArray60);
        java.lang.String str62 = mathException61.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator71 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl72 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator71);
        java.lang.Object[] objArray74 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl72, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, localizable65, objArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException61, "", objArray74);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("org.apache.commons.math.ConvergenceException: 2", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "9ab62956c15644153f1e1deb60c13346eb3e3e340f7f38678c37", objArray74);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double2 = org.apache.commons.math.util.FastMath.max(46.52363512324914d, 36.5353837288671d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 46.52363512324914d + "'", double2 == 46.52363512324914d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3949416458995614d, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8823728225158143d + "'", double2 == 0.8823728225158143d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.549902718048101E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.19809744051465d + "'", double1 == 56.19809744051465d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 19L + "'", long1 == 19L);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl1.reseedRandomGenerator(100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        try {
//            double double7 = normalDistributionImpl1.cumulativeProbability(1.653274893429081d, 0.8494202381273023d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.11663229463717519d) + "'", double4 == (-0.11663229463717519d));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.07137002627171281d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07149157667917685d + "'", double1 == 0.07149157667917685d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.07601103664133135d, (double) 16L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.241728039225479E-18d + "'", double2 == 1.241728039225479E-18d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 19.700939443479026d, (java.lang.Number) 96L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("f2725e945838d89f4f507fcc1b4daabf", objArray1);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl1.reseedRandomGenerator(100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        double double5 = normalDistributionImpl1.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.3330495577833787d) + "'", double4 == (-0.3330495577833787d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray36);
        org.apache.commons.math.random.RandomGenerator randomGenerator39 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl40 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator39);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl41.reseedRandomGenerator(100L);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray47);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizable32, randomDataImpl40, 100L, maxIterationsExceededException48, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable30, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable16, objArray52);
        java.lang.Class<?> wildcardClass56 = localizable16.getClass();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl8, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException12, localizable13, objArray19);
        java.lang.Throwable[] throwableArray21 = mathException20.getSuppressed();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        java.lang.String str7 = mathException6.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 96.0f + "'", number5.equals(96.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MathException: 0.38 out of [96, 0.458] range" + "'", str7.equals("org.apache.commons.math.MathException: 0.38 out of [96, 0.458] range"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.512991811647731d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4140890227940399d + "'", double1 == 0.4140890227940399d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 0.5d, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        double double10 = randomDataImpl1.nextCauchy(0.3796077390275217d, 100.0d);
//        randomDataImpl1.reSeed();
//        try {
//            int[] intArray14 = randomDataImpl1.nextPermutation((int) (short) 0, 15);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 15 is larger than the maximum (0): permutation size (15) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 71.32429464439555d + "'", double4 == 71.32429464439555d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.7170468425494687d) + "'", double10 == (-2.7170468425494687d));
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.8746654245922568d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5060511752502133d + "'", double1 == 0.5060511752502133d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        long long1 = org.apache.commons.math.util.FastMath.abs(96L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 96L + "'", long1 == 96L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5000000000000003d + "'", double2 == 0.5000000000000003d);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 15.852323628373629d + "'", double4 == 15.852323628373629d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.9739232942419126d) + "'", double11 == (-0.9739232942419126d));
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator17 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl18 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl18, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException7, "hi!", objArray20);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("4d3a4d9cb6c13c2b775f652975fba222982ec2b6191c9c99a206f4fddd235e44b5685729b3c87bec96c5df6c3ec9b8681", objArray20);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 88L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.exp((-75.8908547263655d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0990578825753928E-33d + "'", double1 == 1.0990578825753928E-33d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.3656749468758122d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number11 = numberIsTooLargeException10.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable12, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 10L);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.891552824853609d, (java.lang.Number) 25.222985934502482d, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator32 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl33 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator32);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl33, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray35);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray42);
        java.lang.Object[] objArray44 = maxIterationsExceededException43.getArguments();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException37, localizable38, objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray44);
        java.lang.Object[] objArray47 = maxIterationsExceededException46.getArguments();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable5, objArray47);
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable5, objArray49);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10.0f + "'", number11.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray47);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) '4');
//        double double9 = randomDataImpl1.nextGaussian(0.0d, 2.7015257296375244d);
//        randomDataImpl1.reSeedSecure((long) '4');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 47.7278454342259d + "'", double4 == 47.7278454342259d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "d25fca2b18dc668f9e46290718bf7d5ca63f690171fbc3b6e390" + "'", str6.equals("d25fca2b18dc668f9e46290718bf7d5ca63f690171fbc3b6e390"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.873124263338708d + "'", double9 == 2.873124263338708d);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, (long) (byte) 1);
//        randomDataImpl1.reSeed((long) 10);
//        double double12 = randomDataImpl1.nextGamma((double) (short) 100, (double) 58L);
//        java.lang.String str14 = randomDataImpl1.nextSecureHexString(1);
//        double double16 = randomDataImpl1.nextChiSquare(2.718281828459045d);
//        try {
//            double double18 = randomDataImpl1.nextExponential((-0.6321205588285577d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.632 is smaller than, or equal to, the minimum (0): mean (-0.632)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 67.13995152237342d + "'", double4 == 67.13995152237342d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6143.498337667273d + "'", double12 == 6143.498337667273d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "7" + "'", str14.equals("7"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.053091277489779d + "'", double16 == 1.053091277489779d);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.3796077390275217d + "'", number5.equals(0.3796077390275217d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.45792971447185016d + "'", number6.equals(0.45792971447185016d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.6321205588285577d), 57.29577951308234d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.011032137432646735d) + "'", double2 == (-0.011032137432646735d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8746654245922568d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray36);
        org.apache.commons.math.random.RandomGenerator randomGenerator39 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl40 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator39);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl41.reseedRandomGenerator(100L);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray47);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizable32, randomDataImpl40, 100L, maxIterationsExceededException48, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable30, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable16, objArray52);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 25.937539580623483d, (java.lang.Number) 0.0024347940274441885d, false);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException59);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double14 = randomDataImpl1.nextF(0.39104575784009526d, (double) 1.0f);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl1.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.7083587067328447d + "'", double4 == 2.7083587067328447d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.494915591952201d) + "'", double11 == (-1.494915591952201d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 368.18286187426577d + "'", double14 == 368.18286187426577d);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.39104575784009526d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0774376865407744d + "'", double1 == 1.0774376865407744d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.7257332292642875d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6952694875949689d) + "'", double1 == (-0.6952694875949689d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.979815974417952E-5d, (-0.8871739344521155d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable2, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray12);
        java.lang.Object[] objArray14 = maxIterationsExceededException13.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable7, objArray14);
        org.junit.Assert.assertNull(localizable1);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double13 = normalDistributionImpl5.density(0.1999608207388626d);
//        double double14 = normalDistributionImpl5.sample();
//        try {
//            double double16 = normalDistributionImpl5.inverseCumulativeProbability(44.725416200613196d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 44.725 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 198259.68612242446d + "'", double4 == 198259.68612242446d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-2.1256318630582984d) + "'", double11 == (-2.1256318630582984d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.39104575784009526d + "'", double13 == 0.39104575784009526d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.561581040188955d + "'", double14 == 1.561581040188955d);
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 0.9296597126314966d);
//        double double11 = randomDataImpl1.nextExponential(0.44783479200344534d);
//        int int14 = randomDataImpl1.nextInt(15, 35);
//        try {
//            int int17 = randomDataImpl1.nextBinomial(13, 115.28511402798058d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 115.285 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.28864703789386237d + "'", double4 == 0.28864703789386237d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 105.21698545280516d + "'", double6 == 105.21698545280516d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.7428072356538279d) + "'", double9 == (-0.7428072356538279d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.060671392554064084d + "'", double11 == 0.060671392554064084d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 17 + "'", int14 == 17);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray21 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, "org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable16, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (-0.6952694875949689d), (java.lang.Number) 6.247597350032484d, false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.signum(63.96243422880708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        float float1 = org.apache.commons.math.util.FastMath.abs(88.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 88.0f + "'", float1 == 88.0f);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(1L);
//        double double8 = normalDistributionImpl5.getStandardDeviation();
//        double double10 = normalDistributionImpl5.inverseCumulativeProbability((double) 0L);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double13 = normalDistributionImpl5.cumulativeProbability(1.0d);
//        try {
//            double double16 = normalDistributionImpl5.cumulativeProbability((double) 0.0f, (-0.5063656411097588d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3792181.3058831724d + "'", double4 == 3792181.3058831724d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.4176683945021233d) + "'", double11 == (-1.4176683945021233d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.841344746068543d + "'", double13 == 0.841344746068543d);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.3656749468758122d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9338826266002687d + "'", double1 == 0.9338826266002687d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.33828307655636747d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        randomDataImpl1.reSeedSecure();
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.ConvergenceException: 2", "e29c90bbb50243fa52407941c71cb5123bdb29abc15fe804c319f7081cae208160bf6a8bbcec65dd7fc6aa476c3a2e84c");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: e29c90bbb50243fa52407941c71cb5123bdb29abc15fe804c319f7081cae208160bf6a8bbcec65dd7fc6aa476c3a2e84c");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.22171856775590332d + "'", double4 == 0.22171856775590332d);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 60);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator16 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl17, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6, "hi!", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException6.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable23);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 18, (-1.0621717148059133d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.141592653589793d, (java.lang.Number) Double.POSITIVE_INFINITY, false);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        long long6 = randomDataImpl1.nextPoisson(3.58351893845611d);
//        int int9 = randomDataImpl1.nextZipf(100, (double) 97);
//        double double12 = randomDataImpl1.nextGaussian(0.0d, 2.1458772928133102E-108d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.21240085597318314d + "'", double4 == 0.21240085597318314d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3L + "'", long6 == 3L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-2.4089157047048594E-108d) + "'", double12 == (-2.4089157047048594E-108d));
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(1L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double5 = normalDistributionImpl0.inverseCumulativeProbability((double) 0L);
        double double6 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.3796077390275217d + "'", number5.equals(0.3796077390275217d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 96.0f + "'", number6.equals(96.0f));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.010837194861078087d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl2.reseedRandomGenerator(1L);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.24387979418110328d, 0.3796077390275217d);
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05154365172832798d + "'", double7 == 0.05154365172832798d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.03305848241929154d) + "'", double8 == (-0.03305848241929154d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.19348666174586046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5590821766949694d + "'", double1 == 1.5590821766949694d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.floor(32.705460941458455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3796077390275217d, (java.lang.Number) 96.0f, (java.lang.Number) 0.45792971447185016d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Throwable[] throwableArray7 = outOfRangeException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 96.0f + "'", number5.equals(96.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 96.0f + "'", number6.equals(96.0f));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 97, (java.lang.Number) 68.67216816885978d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.1646872979319529d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1662008839688603d + "'", double1 == 0.1662008839688603d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.special.Erf.erf(44.68574868754839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.special.Gamma.digamma(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.423484575406847d + "'", double1 == 1.423484575406847d);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl1.getClass();
//        java.lang.String str10 = randomDataImpl1.nextHexString(15);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 46.62166798277185d + "'", double4 == 46.62166798277185d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8675341090279372d + "'", double7 == 0.8675341090279372d);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6ecc0f9cf0ae273" + "'", str10.equals("6ecc0f9cf0ae273"));
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.0d), 0.004951540000537842d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.565844827260634d) + "'", double2 == (-1.565844827260634d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl8, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException12, localizable13, objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException12);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.1458772928133102E-108d, 2.0734969518535578d);
        double[] doubleArray4 = normalDistributionImpl2.sample(10);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.749721612987703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = maxIterationsExceededException8.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double6 = randomDataImpl1.nextChiSquare((double) 100);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (short) 100);
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(97);
//        double double14 = randomDataImpl1.nextWeibull(0.010837194861078087d, 1.3273072331627778E19d);
//        randomDataImpl1.reSeedSecure(2L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2088802113716516d + "'", double4 == 0.2088802113716516d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 73.34117173209074d + "'", double6 == 73.34117173209074d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "339b6d406dcc43cb61348cdcf306ae2d262853f11f0904a8b5a6bef0d0c64010bf3e1d51abd3aa540012a87da80d288b2" + "'", str11.equals("339b6d406dcc43cb61348cdcf306ae2d262853f11f0904a8b5a6bef0d0c64010bf3e1d51abd3aa540012a87da80d288b2"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.8204498504250056E66d + "'", double14 == 1.8204498504250056E66d);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        java.lang.Object[] objArray7 = maxIterationsExceededException6.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        java.lang.Object[] objArray10 = new java.lang.Object[] { mathException8, 4.600161852571429d };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("4d3a4d9cb6c13c2b775f652975fba222982ec2b6191c9c99a206f4fddd235e44b5685729b3c87bec96c5df6c3ec9b8681", objArray10);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        randomDataImpl1.reSeed((long) 100);
//        randomDataImpl1.reSeed(35L);
//        try {
//            java.lang.String str10 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 75.82339058796633d + "'", double4 == 75.82339058796633d);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.19305963494217543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 10L);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, number11, (java.lang.Number) (-1), (java.lang.Number) 0.0f);
        java.lang.Number number15 = outOfRangeException14.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1) + "'", number15.equals((-1)));
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        long long7 = randomDataImpl1.nextLong(0L, 100L);
//        try {
//            int int10 = randomDataImpl1.nextInt((int) 'a', 18);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (18): lower bound (97) must be strictly less than upper bound (18)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 72.17922152902666d + "'", double4 == 72.17922152902666d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 64L + "'", long7 == 64L);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 96.0f, (java.lang.Number) 0.1999606625952326d, (java.lang.Number) 10.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-2.0579895193368998d), 0.05154365172832798d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5457559279979505d) + "'", double2 == (-1.5457559279979505d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        org.apache.commons.math.random.RandomGenerator randomGenerator8 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator8);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl10.reseedRandomGenerator(100L);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizable1, randomDataImpl9, 100L, maxIterationsExceededException17, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        java.lang.String str23 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator32 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl33 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator32);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl33, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, "", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException38.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNull(localizable39);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.979815974417952E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.031002483236449226d + "'", double1 == 0.031002483236449226d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.0d + "'", double1 == 98.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03490658503988659d + "'", double1 == 0.03490658503988659d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 68.67216816885978d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number10 = numberIsTooLargeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (byte) 10, (java.lang.Number) 10, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number23 = numberIsTooLargeException22.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException22.getGeneralPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable24, objArray25);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number33 = numberIsTooLargeException32.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooLargeException32.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray39 = numberIsTooLargeException38.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray45 = numberIsTooLargeException44.getArguments();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException38, "org.apache.commons.math.MathException: hi!", objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable34, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable11, objArray45);
        java.lang.Object[] objArray49 = convergenceException48.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("4d3a4d9cb6c13c2b775f652975fba222982ec2b6191c9c99a206f4fddd235e44b5685729b3c87bec96c5df6c3ec9b8681", objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1, "org.apache.commons.math.MathException: 0.38 out of [96, 0.458] range", objArray49);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0f + "'", number10.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 10.0f + "'", number23.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 10.0f + "'", number33.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.0024347940274441885d, (java.lang.Number) 12.302734745810286d, number2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta((double) (byte) 10, (double) '#');
//        double double7 = randomDataImpl1.nextUniform((-0.9339944966542343d), 114.3891226019389d);
//        try {
//            double double9 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.21465471161161928d + "'", double4 == 0.21465471161161928d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 108.29508619286067d + "'", double7 == 108.29508619286067d);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.floor(6.987032264460418E-52d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.010837194861078087d, (double) 3L, (double) 52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 3 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl2.reseedRandomGenerator(1L);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.24387979418110328d, 0.3796077390275217d);
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        int int11 = randomDataImpl1.nextSecureInt(11, (int) '#');
//        try {
//            double double14 = randomDataImpl1.nextBeta((-0.9339944966542343d), 3.703529203440295E32d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.217");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05154365172832798d + "'", double7 == 0.05154365172832798d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.1949294677508187d) + "'", double8 == (-0.1949294677508187d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.8494202381273023d, (java.lang.Number) 3.1336067460396586E-6d, false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.8894305254963171d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07446344319909004d + "'", double1 == 0.07446344319909004d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int1 = org.apache.commons.math.util.FastMath.abs(18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6493238552479715d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        double double10 = randomDataImpl1.nextWeibull(2.549902718048101E24d, 3.9212131939158583d);
//        double double13 = randomDataImpl1.nextGamma(2.7015257296375244d, 29.608888043985793d);
//        int int16 = randomDataImpl1.nextBinomial(0, 0.1999606625952326d);
//        double double19 = randomDataImpl1.nextF(0.9999999958776927d, 0.47295125419950956d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 49.17389103832435d + "'", double4 == 49.17389103832435d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9077246345754663d + "'", double7 == 0.9077246345754663d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.9212131939158583d + "'", double10 == 3.9212131939158583d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 124.92791910043711d + "'", double13 == 124.92791910043711d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.8373392452626645d + "'", double19 == 1.8373392452626645d);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray3);
        java.lang.Object[] objArray5 = maxIterationsExceededException4.getArguments();
        int int6 = maxIterationsExceededException4.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray6 = numberIsTooLargeException5.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray12 = numberIsTooLargeException11.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "org.apache.commons.math.MathException: hi!", objArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = maxIterationsExceededException14.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform((double) 10L, (double) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) 'a', 10.0d);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl1.getClass();
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        double double13 = randomDataImpl10.nextF(0.17453292519943295d, 0.17453292519943295d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl14.reseedRandomGenerator(1L);
//        double double17 = normalDistributionImpl14.getStandardDeviation();
//        double double19 = normalDistributionImpl14.inverseCumulativeProbability((double) 0L);
//        double double20 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double22 = normalDistributionImpl14.density(0.1999608207388626d);
//        double double23 = normalDistributionImpl14.sample();
//        double[] doubleArray25 = normalDistributionImpl14.sample((int) (short) 100);
//        double double26 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 50.83472904837748d + "'", double4 == 50.83472904837748d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9128412277134819d + "'", double7 == 0.9128412277134819d);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.30462561220860923d + "'", double13 == 0.30462561220860923d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.685290584610967d) + "'", double20 == (-1.685290584610967d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.39104575784009526d + "'", double22 == 0.39104575784009526d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.561581040188955d + "'", double23 == 1.561581040188955d);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.4824747298270493d) + "'", double26 == (-0.4824747298270493d));
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(100L);
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double[] doubleArray6 = normalDistributionImpl0.sample(11);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (short) 1, (java.lang.Number) 0.47295125419950956d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number9 = numberIsTooLargeException8.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number19 = numberIsTooLargeException18.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooLargeException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray25 = numberIsTooLargeException24.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray31 = numberIsTooLargeException30.getArguments();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, "org.apache.commons.math.MathException: hi!", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable20, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray40);
        org.apache.commons.math.random.RandomGenerator randomGenerator43 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl44 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator43);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl45 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl45.reseedRandomGenerator(100L);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray51);
        java.lang.Object[] objArray53 = maxIterationsExceededException52.getArguments();
        java.lang.Object[] objArray56 = new java.lang.Object[] { localizable36, randomDataImpl44, 100L, maxIterationsExceededException52, 0.45792971447185016d, '4' };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable34, objArray56);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable20, objArray56);
        org.apache.commons.math.random.RandomGenerator randomGenerator67 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl68 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator67);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl68, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", objArray70);
        java.lang.Object[] objArray73 = maxIterationsExceededException72.getArguments();
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable20, objArray73);
        java.lang.Number number75 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 68.67216816885978d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException77);
        java.lang.Number number79 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0f + "'", number9.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10.0f + "'", number19.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNull(number75);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0.47295125419950956d + "'", number79.equals(0.47295125419950956d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number11 = numberIsTooLargeException10.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable12, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 10L);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray24);
        java.lang.Object[] objArray27 = mathIllegalArgumentException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray35);
        java.lang.Object[] objArray38 = mathIllegalArgumentException37.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator47 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator47);
        java.lang.Object[] objArray50 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl48, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException37, "hi!", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator63 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl64 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator63);
        java.lang.Object[] objArray66 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl64, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray73);
        java.lang.Object[] objArray75 = maxIterationsExceededException74.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException68, localizable69, objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable29, objArray75);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10.0f + "'", number11.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.049291688196848496d, 6.987032264460418E-52d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9248506659826856d, 0.0d, 6.987032264460418E-52d, 15);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator15 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl16, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray25);
        java.lang.Object[] objArray27 = maxIterationsExceededException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException20, localizable21, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray27);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable5, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray37);
        java.lang.Object[] objArray40 = mathIllegalArgumentException39.getArguments();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number47 = numberIsTooLargeException46.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooLargeException46.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator64 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator64);
        java.lang.Object[] objArray67 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl65, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray74);
        java.lang.Object[] objArray76 = maxIterationsExceededException75.getArguments();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException69, localizable70, objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray76);
        java.lang.Object[] objArray79 = maxIterationsExceededException78.getArguments();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable54, objArray79);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable82, objArray86);
        java.lang.Object[] objArray89 = mathIllegalArgumentException88.getArguments();
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable48, objArray89);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException96 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 7.69459862670642E-23d, (java.lang.Number) 258.38582512321625d, (java.lang.Number) (byte) 1);
        java.lang.Object[] objArray97 = outOfRangeException96.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 10.0f + "'", number47.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 10.0f + "'", number53.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(objArray97);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (byte) 10, (java.lang.Number) 10, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException17.getGeneralPattern();
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable19, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 1L, false);
        java.lang.Number number28 = numberIsTooLargeException27.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray34 = numberIsTooLargeException33.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 9.999999999999998d, false);
        java.lang.Object[] objArray40 = numberIsTooLargeException39.getArguments();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException33, "org.apache.commons.math.MathException: hi!", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable6, objArray40);
        java.lang.Object[] objArray44 = convergenceException43.getArguments();
        java.lang.String str45 = convergenceException43.getPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 10.0f + "'", number18.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str45.equals("{0} is larger than, or equal to, the maximum ({1})"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.7755575615628914E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7320508075688772d + "'", double1 == 1.7320508075688772d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double1 = org.apache.commons.math.util.FastMath.abs(47.7278454342259d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 47.7278454342259d + "'", double1 == 47.7278454342259d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.random.RandomGenerator randomGenerator16 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.0d, 100, 1.4711276743037347d, randomDataImpl17, 10L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6, "hi!", objArray19);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException6, "", objArray24);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.7257332292642875d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2751075772809723d + "'", double1 == 1.2751075772809723d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.tan(3170.0430573193257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17791211831147322d + "'", double1 == 0.17791211831147322d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 26);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4537856055185257d + "'", double1 == 0.4537856055185257d);
    }
}

