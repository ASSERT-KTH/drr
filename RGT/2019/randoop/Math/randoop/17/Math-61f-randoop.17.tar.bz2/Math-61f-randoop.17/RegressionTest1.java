import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
//        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 100.0f, (byte) 100 };
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray5);
//        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
//        convergenceException6.addSuppressed((java.lang.Throwable) convergenceException7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl9.sample();
//        normalDistributionImpl9.setMean(Double.NaN);
//        double[] doubleArray14 = normalDistributionImpl9.sample((int) (byte) 100);
//        java.lang.Object[] objArray17 = new java.lang.Object[] {};
//        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
//        java.lang.IllegalArgumentException illegalArgumentException19 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray17);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray14, "permutation size ({0}", objArray17);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
//        java.lang.Throwable throwable23 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { localizedFormats26, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(throwable23, 0.0d, "", objArray30);
//        java.lang.UnsupportedOperationException unsupportedOperationException32 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException20, "permutation size ({0}", objArray30);
//        java.lang.IllegalStateException illegalStateException34 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray30);
//        java.lang.Object[] objArray35 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray30);
//        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
//        org.junit.Assert.assertNotNull(objArray5);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4736780504930178d + "'", double10 == 1.4736780504930178d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray18);
//        org.junit.Assert.assertNotNull(illegalArgumentException19);
//        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
//        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(unsupportedOperationException32);
//        org.junit.Assert.assertNotNull(illegalStateException34);
//        org.junit.Assert.assertNotNull(objArray35);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.Object[] objArray5 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray4);
        java.lang.IllegalArgumentException illegalArgumentException6 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray4);
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray4);
        java.lang.NullPointerException nullPointerException8 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray4);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable0, objArray4);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(illegalArgumentException6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(nullPointerException8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(1.2381110433655316d, (int) (short) 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0d, (java.lang.Number) 0.8217051001031704d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8217051001031704d + "'", number5.equals(0.8217051001031704d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.8217051001031704d + "'", number6.equals(0.8217051001031704d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8217051001031704d + "'", number7.equals(0.8217051001031704d));
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        double double7 = randomDataImpl0.nextGaussian((double) ' ', 1.0d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0614272708860666d) + "'", double2 == (-2.0614272708860666d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.3013051763084796d) + "'", double3 == (-0.3013051763084796d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4817165822970768d + "'", double4 == 1.4817165822970768d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 31.021873586122286d + "'", double7 == 31.021873586122286d);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextF((-0.9283373747298397d), (-0.9393272378248494d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(10);
//        double double19 = randomDataImpl0.nextGaussian(0.0d, 1.4344528869931015d);
//        int int22 = randomDataImpl0.nextSecureInt(17, 35);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.29948507116579187d) + "'", double2 == (-0.29948507116579187d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.4498406271839833d) + "'", double3 == (-0.4498406271839833d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.65588185240282d + "'", double4 == 1.65588185240282d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 28 + "'", int14 == 28);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "375d261aa6" + "'", str16.equals("375d261aa6"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.096373434754801d) + "'", double19 == (-1.096373434754801d));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 100.0f, (java.lang.Number) 0.0f, false);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.ArithmeticException arithmeticException11 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray10);
        java.util.NoSuchElementException noSuchElementException12 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("72ce9adfc8", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException13 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        java.lang.IllegalArgumentException illegalArgumentException14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("72ce9adfc8", objArray10);
        java.lang.IllegalStateException illegalStateException15 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(arithmeticException11);
        org.junit.Assert.assertNotNull(noSuchElementException12);
        org.junit.Assert.assertNotNull(illegalArgumentException13);
        org.junit.Assert.assertNotNull(illegalArgumentException14);
        org.junit.Assert.assertNotNull(illegalStateException15);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (short) -1, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.14659224297650125d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9892745845971714d + "'", double1 == 0.9892745845971714d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
        int int3 = poissonDistributionImpl1.inverseCumulativeProbability(1.0d);
        double double5 = poissonDistributionImpl1.cumulativeProbability((double) 10);
        double double7 = poissonDistributionImpl1.probability(10);
        double double10 = poissonDistributionImpl1.cumulativeProbability(0, 33);
        int[] intArray12 = poissonDistributionImpl1.sample(100);
        double double13 = poissonDistributionImpl1.getMean();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.611924821055805E-6d + "'", double5 == 5.611924821055805E-6d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.929283182309498E-6d + "'", double7 == 3.929283182309498E-6d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6150373563537195d + "'", double10 == 0.6150373563537195d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 32.0d + "'", double13 == 32.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.Object[] objArray5 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray4);
        java.text.ParseException parseException6 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray5);
        java.lang.UnsupportedOperationException unsupportedOperationException7 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray5);
        java.lang.RuntimeException runtimeException8 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) unsupportedOperationException7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        java.lang.IllegalArgumentException illegalArgumentException14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) unsupportedOperationException7, 0.9386867598047597d, localizable10, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(parseException6);
        org.junit.Assert.assertNotNull(unsupportedOperationException7);
        org.junit.Assert.assertNotNull(runtimeException8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(illegalArgumentException14);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        try {
//            double double17 = poissonDistributionImpl9.cumulativeProbability(25.706840281719657d, (-0.9283373747298397d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6152253509084552d + "'", double2 == 0.6152253509084552d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.2952768677153494d) + "'", double3 == (-0.2952768677153494d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2885937287614115d + "'", double4 == 1.2885937287614115d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39 + "'", int14 == 39);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        int int10 = randomDataImpl0.nextSecureInt((-1), (int) (short) 10);
//        double double13 = randomDataImpl0.nextF(0.9387377460784728d, 0.6294201067597038d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.22315708634168197d + "'", double2 == 0.22315708634168197d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.15626807954603555d + "'", double3 == 0.15626807954603555d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2932433042407405d + "'", double4 == 1.2932433042407405d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 21.232579304463336d + "'", double13 == 21.232579304463336d);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1544279.422581926d), 1.0E-9d, (double) 3);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        long long10 = randomDataImpl0.nextLong(0L, (long) ' ');
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl13.sample();
//        double double15 = normalDistributionImpl13.sample();
//        double double17 = normalDistributionImpl13.density((java.lang.Double) (-0.23962444073877046d));
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double21 = randomDataImpl0.nextUniform((-0.05658256644109446d), 0.11471080296496314d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8099566379482491d + "'", double2 == 0.8099566379482491d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.25065977109094406d) + "'", double3 == (-0.25065977109094406d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2528510560184738d + "'", double4 == 1.2528510560184738d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 12L + "'", long10 == 12L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "842d0a59451fbebe31fc679345aff0f6ea3" + "'", str12.equals("842d0a59451fbebe31fc679345aff0f6ea3"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.07898425346779353d + "'", double14 == 0.07898425346779353d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.5837619738002672d) + "'", double15 == (-0.5837619738002672d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.3876515268837937d + "'", double17 == 0.3876515268837937d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.2924550741160828d) + "'", double18 == (-0.2924550741160828d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.029602638569864566d) + "'", double21 == (-0.029602638569864566d));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats9, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable6, 0.0d, "", objArray13);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        java.lang.Object[] objArray19 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException14, "hi!", objArray19);
        double[] doubleArray22 = functionEvaluationException14.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray31 = new java.lang.Object[] { localizedFormats27, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(throwable24, 0.0d, "", objArray31);
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        java.lang.Object[] objArray37 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray37);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException32, "hi!", objArray37);
        double[] doubleArray40 = functionEvaluationException32.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        java.lang.Object[] objArray45 = new java.lang.Object[] { localizedFormats42, 100.0f, (byte) 100 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException();
        convergenceException46.addSuppressed((java.lang.Throwable) convergenceException47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        java.lang.Object[] objArray50 = new java.lang.Object[] { functionEvaluationException32, convergenceException46, localizedFormats49 };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, localizable5, objArray50);
        java.lang.Object[] objArray53 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((double) 100L, "23af2699eb", objArray50);
        java.lang.String str56 = functionEvaluationException55.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: 23af2699eb" + "'", str56.equals("org.apache.commons.math.FunctionEvaluationException: 23af2699eb"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.6047768935282067d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.Object[] objArray5 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray4);
        java.text.ParseException parseException6 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray5);
        java.lang.Object[] objArray7 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray5);
        java.io.EOFException eOFException8 = org.apache.commons.math.MathRuntimeException.createEOFException("72ce9adfc8", objArray7);
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("de8ea16184", objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(parseException6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(eOFException8);
        org.junit.Assert.assertNotNull(eOFException9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        java.lang.Object[] objArray3 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray2);
        java.lang.IllegalArgumentException illegalArgumentException4 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray2);
        java.lang.ArithmeticException arithmeticException5 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray2);
        org.apache.commons.math.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) arithmeticException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray9);
        java.lang.Object[] objArray13 = mathRuntimeException12.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(illegalArgumentException4);
        org.junit.Assert.assertNotNull(arithmeticException5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(illegalArgumentException11);
        org.junit.Assert.assertNotNull(objArray13);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
//        java.lang.Throwable throwable3 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats6, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(throwable3, 0.0d, "", objArray10);
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray15);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray16);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException11, "hi!", objArray16);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double21 = normalDistributionImpl20.sample();
//        normalDistributionImpl20.setMean(Double.NaN);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
//        java.lang.Object[] objArray27 = new java.lang.Object[] { functionEvaluationException11, (-0.5440211108893698d), Double.NaN, localizedFormats24, localizedFormats25, localizedFormats26 };
//        java.lang.IllegalArgumentException illegalArgumentException28 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray27);
//        java.io.EOFException eOFException29 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray27);
//        java.lang.UnsupportedOperationException unsupportedOperationException30 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray27);
//        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
//        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.8293024663496347d) + "'", double21 == (-0.8293024663496347d));
//        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
//        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
//        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(illegalArgumentException28);
//        org.junit.Assert.assertNotNull(eOFException29);
//        org.junit.Assert.assertNotNull(unsupportedOperationException30);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.24675658370542725d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats4, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable1, 0.0d, "", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        java.lang.String str11 = convergenceException10.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.ConvergenceException: row index LCM_OVERFLOW_64_BITS out of allowed range [�, 0]" + "'", str11.equals("org.apache.commons.math.ConvergenceException: row index LCM_OVERFLOW_64_BITS out of allowed range [�, 0]"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795E-5d + "'", double1 == 3.1622776601683795E-5d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
        int int3 = poissonDistributionImpl1.inverseCumulativeProbability(1.0d);
        double double5 = poissonDistributionImpl1.cumulativeProbability((double) 10);
        int int7 = poissonDistributionImpl1.inverseCumulativeProbability(0.0d);
        try {
            double double10 = poissonDistributionImpl1.cumulativeProbability(0.9769983725873234d, (double) (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.611924821055805E-6d + "'", double5 == 5.611924821055805E-6d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(10);
//        double double19 = randomDataImpl0.nextCauchy((-0.29043950585920736d), (double) 10000000);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 100.0f, 3.2710663101885897d, 0.0d);
//        double double25 = normalDistributionImpl23.cumulativeProbability(0.3998270466032986d);
//        normalDistributionImpl23.reseedRandomGenerator((long) 100);
//        double double28 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double29 = normalDistributionImpl23.getMean();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.46415849017032945d + "'", double2 == 0.46415849017032945d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.014603345147451836d) + "'", double3 == (-0.014603345147451836d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.9338281275833487d + "'", double4 == 1.9338281275833487d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 28 + "'", int14 == 28);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "e252d5e469" + "'", str16.equals("e252d5e469"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-6111790.352661006d) + "'", double19 == (-6111790.352661006d));
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 99.85884978371188d + "'", double28 == 99.85884978371188d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.Object[] objArray5 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray4);
        java.text.ParseException parseException6 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray5);
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats10, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(throwable7, 0.0d, "", objArray14);
        java.lang.ArithmeticException arithmeticException16 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray14);
        java.lang.Throwable throwable17 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats20, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable17, 0.0d, "", objArray24);
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        java.lang.Object[] objArray30 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException25, "hi!", objArray30);
        arithmeticException16.addSuppressed((java.lang.Throwable) functionEvaluationException25);
        double[] doubleArray34 = functionEvaluationException25.getArgument();
        java.lang.Throwable throwable37 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray44 = new java.lang.Object[] { localizedFormats40, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(throwable37, 0.0d, "", objArray44);
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        java.lang.Object[] objArray50 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray50);
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException45, "hi!", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable53 = mathRuntimeException52.getLocalizablePattern();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException52);
        java.lang.Throwable[] throwableArray55 = mathRuntimeException52.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable56 = mathRuntimeException52.getLocalizablePattern();
        java.lang.Object[] objArray57 = mathRuntimeException52.getArguments();
        org.apache.commons.math.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.MathRuntimeException("{0}", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(doubleArray34, "", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(6, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(parseException6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(arithmeticException16);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(objArray57);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeed();
//        long long20 = randomDataImpl0.nextLong((long) 1, 35L);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3703744621028722d) + "'", double2 == (-1.3703744621028722d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8413627617745303d + "'", double3 == 0.8413627617745303d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6810811328669316d) + "'", double4 == (-0.6810811328669316d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 38 + "'", int14 == 38);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "b772ed37ba" + "'", str16.equals("b772ed37ba"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9L + "'", long20 == 9L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.32332713662799617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3350860139020129d + "'", double1 == 0.3350860139020129d);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double2 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.setStandardDeviation(0.8597834122413388d);
//        double double5 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.107116275184987d) + "'", double1 == (-1.107116275184987d));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7836530827367035d + "'", double2 == 0.7836530827367035d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.8099566379482491d, (-0.9735970398683839d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2277822506437102d + "'", double2 == 1.2277822506437102d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.Object[] objArray5 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray4);
        java.util.NoSuchElementException noSuchElementException8 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("c61e5cb99dd05e1975f1d2349b00a524e1a", objArray4);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException(localizable0, objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(noSuchElementException8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl(1.0d, (double) '4', (int) (byte) 1);
        double double4 = poissonDistributionImpl3.getMean();
        double double6 = poissonDistributionImpl3.probability(0.0d);
        try {
            int int8 = poissonDistributionImpl3.inverseCumulativeProbability((-0.7851094381140283d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.36787944117144233d + "'", double6 == 0.36787944117144233d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        java.lang.Object[] objArray3 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException4, "hi!", objArray7);
        double[] doubleArray11 = functionEvaluationException4.getArgument();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 30);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 30.0f + "'", float1 == 30.0f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9892745845971714d, 0.3980712937478205d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9892745845971713d + "'", double2 == 0.9892745845971713d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        java.lang.Object[] objArray4 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray3);
        java.text.ParseException parseException5 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray4);
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats9, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable6, 0.0d, "", objArray13);
        java.lang.ArithmeticException arithmeticException15 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray13);
        java.util.NoSuchElementException noSuchElementException16 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("6a7be64c1361cfad88c6d461b361d24357e", objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(parseException5);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(arithmeticException15);
        org.junit.Assert.assertNotNull(noSuchElementException16);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 100.0f, 3.2710663101885897d, 0.0d);
        double double5 = normalDistributionImpl3.cumulativeProbability(0.3998270466032986d);
        normalDistributionImpl3.reseedRandomGenerator((long) 100);
        double double8 = normalDistributionImpl3.sample();
        normalDistributionImpl3.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 102.04320359507902d + "'", double8 == 102.04320359507902d);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl(1.0d, (double) '4', (int) (byte) 1);
//        double double4 = poissonDistributionImpl3.getMean();
//        int int5 = poissonDistributionImpl3.sample();
//        double double7 = poissonDistributionImpl3.cumulativeProbability(2.0817965069284585d);
//        int int8 = poissonDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9386867598047597d + "'", double7 == 0.9386867598047597d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats4, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable1, 0.0d, "", objArray8);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException9, "hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException16.getLocalizablePattern();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException16);
        java.lang.Throwable[] throwableArray19 = mathRuntimeException16.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = mathRuntimeException16.getLocalizablePattern();
        java.lang.Object[] objArray21 = mathRuntimeException16.getArguments();
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException("{0}", objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathRuntimeException22, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathRuntimeException22.getLocalizablePattern();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable31);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(0.8405943243359154d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7997123802960269d + "'", double2 == 0.7997123802960269d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(10);
//        double double19 = randomDataImpl0.nextGaussian(0.0d, 1.4344528869931015d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double21 = normalDistributionImpl20.sample();
//        double double22 = normalDistributionImpl20.sample();
//        double double24 = normalDistributionImpl20.density((java.lang.Double) (-0.23962444073877046d));
//        double double25 = normalDistributionImpl20.getMean();
//        double[] doubleArray27 = normalDistributionImpl20.sample(100);
//        double double28 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        double double31 = randomDataImpl0.nextGamma((double) 41, 1.1468143446960186d);
//        double double34 = randomDataImpl0.nextGaussian((double) 30, 0.176341268285607d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8139601754663673d) + "'", double2 == (-0.8139601754663673d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.7325575018566216d) + "'", double3 == (-0.7325575018566216d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.756686221569819d) + "'", double4 == (-0.756686221569819d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 26 + "'", int14 == 26);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "79a8d6cd59" + "'", str16.equals("79a8d6cd59"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.8174338594468906d + "'", double19 == 1.8174338594468906d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.13402134276065894d) + "'", double21 == (-0.13402134276065894d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.626366151137202d + "'", double22 == 0.626366151137202d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.3876515268837937d + "'", double24 == 0.3876515268837937d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.7455146510963526d) + "'", double28 == (-1.7455146510963526d));
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 34.78333923812842d + "'", double31 == 34.78333923812842d);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 29.937158471462745d + "'", double34 == 29.937158471462745d);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
        int int3 = poissonDistributionImpl1.inverseCumulativeProbability(1.0d);
        double double5 = poissonDistributionImpl1.normalApproximateProbability((int) (byte) 100);
        try {
            double double8 = poissonDistributionImpl1.cumulativeProbability(100, (int) (short) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.setMean(Double.NaN);
//        double[] doubleArray5 = normalDistributionImpl0.sample((int) (byte) 100);
//        normalDistributionImpl0.setStandardDeviation((double) 100.0f);
//        double double9 = normalDistributionImpl0.density((java.lang.Double) (-0.692015672561419d));
//        normalDistributionImpl0.setMean(1.3120853965583525d);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.379306881059641d) + "'", double1 == (-1.379306881059641d));
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 1);
        try {
            long long5 = randomDataImpl0.nextSecureLong((long) 10000000, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10,000,000 is larger than, or equal to, the maximum (10): lower bound (10,000,000) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 1);
        randomDataImpl0.reSeedSecure(17L);
        try {
            long long7 = randomDataImpl0.nextLong((long) ' ', 21L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (21): lower bound (32) must be strictly less than upper bound (21)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        int[] intArray16 = poissonDistributionImpl9.sample(1);
//        double double18 = poissonDistributionImpl9.cumulativeProbability(0.3998270466032986d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0098735082038788d) + "'", double2 == (-1.0098735082038788d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.766741616048144d) + "'", double3 == (-0.766741616048144d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.7262400444468414d) + "'", double4 == (-0.7262400444468414d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 30 + "'", int14 == 30);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.2664165549094158E-14d + "'", double18 == 1.2664165549094158E-14d);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(10);
//        double double19 = randomDataImpl0.nextGaussian(0.0d, 1.4344528869931015d);
//        try {
//            int int22 = randomDataImpl0.nextSecureInt(29, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 29 is larger than, or equal to, the maximum (0): lower bound (29) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5190152928028293d) + "'", double2 == (-1.5190152928028293d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.30242600951403625d + "'", double3 == 0.30242600951403625d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.7362146687215627d) + "'", double4 == (-0.7362146687215627d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 36 + "'", int14 == 36);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "e6348bb07d" + "'", str16.equals("e6348bb07d"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.14262878718073263d + "'", double19 == 0.14262878718073263d);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.24675658370542725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21866914095171036d) + "'", double1 == (-0.21866914095171036d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.929283182309498E-6d, (-0.26344291965454564d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415777384681904d + "'", double2 == 3.1415777384681904d);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        double double7 = randomDataImpl0.nextGaussian((double) ' ', 1.0d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7141386262610847d) + "'", double2 == (-0.7141386262610847d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7247820014882618d + "'", double3 == 0.7247820014882618d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.7432998351323601d) + "'", double4 == (-0.7432998351323601d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 34.2203769991517d + "'", double7 == 34.2203769991517d);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        int[] intArray16 = poissonDistributionImpl9.sample(1);
//        poissonDistributionImpl9.reseedRandomGenerator((long) (byte) 10);
//        int int19 = poissonDistributionImpl9.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.031185400745452d) + "'", double2 == (-1.031185400745452d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3947791632185997d + "'", double3 == 0.3947791632185997d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0125344199596886d) + "'", double4 == (-1.0125344199596886d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 28 + "'", int14 == 28);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 34 + "'", int19 == 34);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6470434810831891d + "'", double1 == 0.6470434810831891d);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        long long10 = randomDataImpl0.nextLong(0L, (long) ' ');
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) '#');
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.3337225836586013d) + "'", double2 == (-0.3337225836586013d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.3138517579356358d) + "'", double3 == (-0.3138517579356358d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0166670854331852d) + "'", double4 == (-1.0166670854331852d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 17L + "'", long10 == 17L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "303f3ea9f10fe71b5e1ce2e60e7662e3b4b" + "'", str12.equals("303f3ea9f10fe71b5e1ce2e60e7662e3b4b"));
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl4 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double6 = poissonDistributionImpl4.probability(1);
//        int[] intArray8 = poissonDistributionImpl4.sample((int) (short) 1);
//        java.lang.Throwable throwable9 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray16 = new java.lang.Object[] { localizedFormats12, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(throwable9, 0.0d, "", objArray16);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl21 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double22 = normalDistributionImpl21.sample();
//        double double23 = normalDistributionImpl21.sample();
//        double double24 = randomDataImpl20.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl21);
//        int int27 = randomDataImpl20.nextPascal((int) (short) 10, 0.0d);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { localizedFormats2, poissonDistributionImpl4, throwable9, localizedFormats18, localizedFormats19, 0.0d };
//        java.util.NoSuchElementException noSuchElementException29 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("de8ea16184", objArray28);
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray28);
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.052532975710136E-13d + "'", double6 == 4.052532975710136E-13d);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
//        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-0.5466130024639548d) + "'", double22 == (-0.5466130024639548d));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-0.4188488365864071d) + "'", double23 == (-0.4188488365864071d));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0476505438399277d) + "'", double24 == (-1.0476505438399277d));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertNotNull(noSuchElementException29);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        double double10 = randomDataImpl0.nextBeta(0.32332713662799617d, 0.3876515268837937d);
//        int int13 = randomDataImpl0.nextZipf((int) '4', (double) 100.0f);
//        double double15 = randomDataImpl0.nextT(0.31854342972879973d);
//        try {
//            double double18 = randomDataImpl0.nextF(0.3864846693457329d, (-0.2924550741160828d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1065192969749589d) + "'", double2 == (-1.1065192969749589d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.47166833033688005d) + "'", double3 == (-0.47166833033688005d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9184136030803312d) + "'", double4 == (-0.9184136030803312d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.06816818120984984d + "'", double10 == 0.06816818120984984d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-37.47379250731071d) + "'", double15 == (-37.47379250731071d));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        long long10 = randomDataImpl0.nextLong(0L, (long) ' ');
//        double double13 = randomDataImpl0.nextBeta((double) 1, 0.1652214443996481d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3047606294537886d) + "'", double2 == (-1.3047606294537886d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.13288705699425268d) + "'", double3 == (-0.13288705699425268d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.93080867070948d) + "'", double4 == (-0.93080867070948d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 26L + "'", long10 == 26L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9954809826573912d + "'", double13 == 0.9954809826573912d);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        long long10 = randomDataImpl0.nextLong(0L, (long) ' ');
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) '#');
//        randomDataImpl0.reSeed((long) 28);
//        long long16 = randomDataImpl0.nextPoisson(2.0390581558066536d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1308893481606248d + "'", double2 == 1.1308893481606248d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5016791985459319d + "'", double3 == 0.5016791985459319d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9259714768788061d) + "'", double4 == (-0.9259714768788061d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 26L + "'", long10 == 26L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4f07c06e7d59176ac68049904daeba2075a" + "'", str12.equals("4f07c06e7d59176ac68049904daeba2075a"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3L + "'", long16 == 3L);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(10);
//        double double19 = randomDataImpl0.nextGaussian(0.0d, 1.4344528869931015d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double21 = normalDistributionImpl20.sample();
//        double double22 = normalDistributionImpl20.sample();
//        double double24 = normalDistributionImpl20.density((java.lang.Double) (-0.23962444073877046d));
//        double double25 = normalDistributionImpl20.getMean();
//        double[] doubleArray27 = normalDistributionImpl20.sample(100);
//        double double28 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        int int31 = randomDataImpl0.nextZipf(31, 1.5397929895435218d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3070478399400656d) + "'", double2 == (-1.3070478399400656d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07573925115404333d + "'", double3 == 0.07573925115404333d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9342772269987112d) + "'", double4 == (-0.9342772269987112d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "7823c7eda0" + "'", str16.equals("7823c7eda0"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.36575754478453965d) + "'", double19 == (-0.36575754478453965d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.501126244432834d) + "'", double21 == (-0.501126244432834d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-0.4663867359200142d) + "'", double22 == (-0.4663867359200142d));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.3876515268837937d + "'", double24 == 0.3876515268837937d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0216372810007393d) + "'", double28 == (-1.0216372810007393d));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19 + "'", int31 == 19);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        int int10 = randomDataImpl0.nextSecureInt((-1), (int) (short) 10);
//        double double12 = randomDataImpl0.nextT(1.3387174608617622d);
//        try {
//            double double15 = randomDataImpl0.nextWeibull((-0.93080867070948d), (-0.766741616048144d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.26423289255647686d) + "'", double2 == (-0.26423289255647686d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.31178013867691545d + "'", double3 == 0.31178013867691545d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8860288473540919d) + "'", double4 == (-0.8860288473540919d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.049695769675654186d + "'", double12 == 0.049695769675654186d);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.13288705699425268d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.613867517685105d) + "'", double1 == (-7.613867517685105d));
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        double[] doubleArray6 = normalDistributionImpl1.sample(35);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(0.8597834122413388d);
//        org.apache.commons.math.exception.util.Localizable localizable9 = functionEvaluationException8.getLocalizablePattern();
//        java.lang.Throwable throwable11 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats14, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable11, 0.0d, "", objArray18);
//        java.lang.Object[] objArray23 = new java.lang.Object[] {};
//        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray23);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray24);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException19, "hi!", objArray24);
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("permutation size ({0}", objArray24);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable9, objArray24);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
//        java.lang.Object[] objArray33 = new java.lang.Object[] {};
//        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray33);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray34);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
//        java.lang.Object[] objArray38 = new java.lang.Object[] {};
//        java.lang.Object[] objArray39 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray38);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray38);
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException35, "hi!", objArray38);
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray38);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, (org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray38);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8827041815703541d) + "'", double2 == (-0.8827041815703541d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.367677891901072d + "'", double3 == 1.367677891901072d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8903594914654169d) + "'", double4 == (-0.8903594914654169d));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
//        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray18);
//        org.junit.Assert.assertNotNull(objArray23);
//        org.junit.Assert.assertNotNull(objArray24);
//        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
//        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
//        org.junit.Assert.assertNotNull(objArray33);
//        org.junit.Assert.assertNotNull(objArray34);
//        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertNotNull(objArray39);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
//        java.lang.Throwable throwable1 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats4, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable1, 0.0d, "", objArray8);
//        java.lang.UnsupportedOperationException unsupportedOperationException10 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
//        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) unsupportedOperationException10);
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Throwable throwable15 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray22 = new java.lang.Object[] { localizedFormats18, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(throwable15, 0.0d, "", objArray22);
//        java.lang.Object[] objArray27 = new java.lang.Object[] {};
//        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray28);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException23, "hi!", objArray28);
//        double[] doubleArray31 = functionEvaluationException23.getArgument();
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
//        java.lang.Throwable throwable33 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray40 = new java.lang.Object[] { localizedFormats36, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(throwable33, 0.0d, "", objArray40);
//        java.lang.Object[] objArray45 = new java.lang.Object[] {};
//        java.lang.Object[] objArray46 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray45);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray46);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException41, "hi!", objArray46);
//        double[] doubleArray49 = functionEvaluationException41.getArgument();
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
//        java.lang.Object[] objArray54 = new java.lang.Object[] { localizedFormats51, 100.0f, (byte) 100 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException();
//        convergenceException55.addSuppressed((java.lang.Throwable) convergenceException56);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
//        java.lang.Object[] objArray59 = new java.lang.Object[] { functionEvaluationException41, convergenceException55, localizedFormats58 };
//        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException23, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray59);
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, localizable14, objArray59);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl62 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl63 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double64 = normalDistributionImpl63.sample();
//        double double65 = normalDistributionImpl63.sample();
//        double double66 = randomDataImpl62.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl63);
//        double[] doubleArray68 = normalDistributionImpl63.sample((int) (short) 0);
//        java.lang.Object[] objArray73 = new java.lang.Object[] {};
//        java.lang.Object[] objArray74 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray73);
//        java.lang.IllegalArgumentException illegalArgumentException75 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray73);
//        java.lang.ArithmeticException arithmeticException76 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray73);
//        java.lang.NullPointerException nullPointerException77 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray73);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException61, doubleArray68, "de8ea16184", objArray73);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException79 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) unsupportedOperationException10, "Cardan angles singularity", objArray73);
//        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
//        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(unsupportedOperationException10);
//        org.junit.Assert.assertNotNull(illegalArgumentException11);
//        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray22);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
//        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertNotNull(objArray45);
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertNotNull(doubleArray49);
//        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
//        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
//        org.junit.Assert.assertNotNull(objArray59);
//        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.4986252173800579d + "'", double64 == 0.4986252173800579d);
//        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-1.5461653795667911d) + "'", double65 == (-1.5461653795667911d));
//        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 2.044096213907991d + "'", double66 == 2.044096213907991d);
//        org.junit.Assert.assertNotNull(doubleArray68);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertNotNull(illegalArgumentException75);
//        org.junit.Assert.assertNotNull(arithmeticException76);
//        org.junit.Assert.assertNotNull(nullPointerException77);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        double[] doubleArray6 = normalDistributionImpl1.sample(35);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
//        java.lang.Object[] objArray13 = new java.lang.Object[] {};
//        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
//        java.lang.IllegalArgumentException illegalArgumentException15 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray13);
//        java.lang.ArithmeticException arithmeticException16 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray13);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) arithmeticException16);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
//        java.lang.Throwable throwable19 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats22, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(throwable19, 0.0d, "", objArray26);
//        java.lang.Object[] objArray31 = new java.lang.Object[] {};
//        java.lang.Object[] objArray32 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray31);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray32);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException27, "hi!", objArray32);
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray32);
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray32);
//        java.lang.Object[] objArray37 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray32);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "21f5f825e1", objArray37);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, objArray37);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6967365678769653d) + "'", double2 == (-0.6967365678769653d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4657278443339988d + "'", double3 == 0.4657278443339988d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0310641394563367d) + "'", double4 == (-1.0310641394563367d));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(illegalArgumentException15);
//        org.junit.Assert.assertNotNull(arithmeticException16);
//        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
//        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(objArray37);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        long long10 = randomDataImpl0.nextLong(0L, (long) ' ');
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) '#');
//        randomDataImpl0.reSeed();
//        java.lang.String str15 = randomDataImpl0.nextHexString(29);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3259126468153781d + "'", double2 == 1.3259126468153781d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.30833503419599695d) + "'", double3 == (-0.30833503419599695d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.1520526506198354d) + "'", double4 == (-1.1520526506198354d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 26L + "'", long10 == 26L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "27e1223d77074d136c3d7cec99f4f57043d" + "'", str12.equals("27e1223d77074d136c3d7cec99f4f57043d"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "c049749f5a7e6a04f91d2b3f4fcdd" + "'", str15.equals("c049749f5a7e6a04f91d2b3f4fcdd"));
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        long long10 = randomDataImpl0.nextLong(0L, (long) ' ');
//        long long12 = randomDataImpl0.nextPoisson(0.42717373202362807d);
//        int int15 = randomDataImpl0.nextBinomial((int) '#', 0.8122830498810298d);
//        int int19 = randomDataImpl0.nextHypergeometric(41, 0, 33);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7086538361711653d) + "'", double2 == (-0.7086538361711653d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.444066046954408d + "'", double3 == 1.444066046954408d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.1494404231567397d) + "'", double4 == (-1.1494404231567397d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 12L + "'", long10 == 12L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 29 + "'", int15 == 29);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
//        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 100.0f, (byte) 100 };
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray5);
//        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
//        convergenceException6.addSuppressed((java.lang.Throwable) convergenceException7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl9.sample();
//        normalDistributionImpl9.setMean(Double.NaN);
//        double[] doubleArray14 = normalDistributionImpl9.sample((int) (byte) 100);
//        java.lang.Object[] objArray17 = new java.lang.Object[] {};
//        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
//        java.lang.IllegalArgumentException illegalArgumentException19 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray17);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray14, "permutation size ({0}", objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable21 = functionEvaluationException20.getLocalizablePattern();
//        java.lang.Throwable throwable25 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray32 = new java.lang.Object[] { localizedFormats28, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(throwable25, 0.0d, "", objArray32);
//        java.lang.Object[] objArray37 = new java.lang.Object[] {};
//        java.lang.Object[] objArray38 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray37);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray38);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException33, "hi!", objArray38);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, (java.lang.Number) (byte) -1, (java.lang.Number) (-1.0f), true);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
//        java.lang.Throwable throwable48 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
//        java.lang.Object[] objArray55 = new java.lang.Object[] { localizedFormats51, Double.NaN, 0, (short) -1 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(throwable48, 0.0d, "", objArray55);
//        java.lang.UnsupportedOperationException unsupportedOperationException57 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, objArray55);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray55);
//        java.lang.Object[] objArray60 = new java.lang.Object[] {};
//        java.lang.Object[] objArray61 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray60);
//        java.lang.IllegalArgumentException illegalArgumentException62 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray60);
//        java.lang.Object[] objArray65 = new java.lang.Object[] { "hi!", 1.0f, objArray55, objArray60, (-0.08078026086362443d), (-1) };
//        java.lang.IllegalArgumentException illegalArgumentException66 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray60);
//        java.lang.NullPointerException nullPointerException67 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException20, "hi!", objArray60);
//        java.lang.ArithmeticException arithmeticException69 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray60);
//        java.lang.IllegalArgumentException illegalArgumentException70 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) arithmeticException69);
//        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
//        org.junit.Assert.assertNotNull(objArray5);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.9761086050191148d) + "'", double10 == (-0.9761086050191148d));
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray18);
//        org.junit.Assert.assertNotNull(illegalArgumentException19);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
//        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
//        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
//        org.junit.Assert.assertNotNull(objArray55);
//        org.junit.Assert.assertNotNull(unsupportedOperationException57);
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray61);
//        org.junit.Assert.assertNotNull(illegalArgumentException62);
//        org.junit.Assert.assertNotNull(objArray65);
//        org.junit.Assert.assertNotNull(illegalArgumentException66);
//        org.junit.Assert.assertNotNull(nullPointerException67);
//        org.junit.Assert.assertNotNull(arithmeticException69);
//        org.junit.Assert.assertNotNull(illegalArgumentException70);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalArgumentException illegalArgumentException2 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray1);
        org.junit.Assert.assertNotNull(illegalArgumentException2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.7068815253719314d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7850796542880554d) + "'", double1 == (-0.7850796542880554d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats4, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable1, 0.0d, "", objArray8);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException9, "hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException16.getLocalizablePattern();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException16);
        java.lang.Throwable[] throwableArray19 = mathRuntimeException16.getSuppressed();
        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("dcc3af48386047f4a927b5c8e7f1ea4761b", (java.lang.Object[]) throwableArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(noSuchElementException20);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats1, 100.0f, (byte) 100 };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getLocalizablePattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.sample();
//        double double3 = normalDistributionImpl1.sample();
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        int int7 = randomDataImpl0.nextPascal((int) (short) 10, 0.0d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl9 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double11 = poissonDistributionImpl9.cumulativeProbability((double) (byte) 10);
//        poissonDistributionImpl9.reseedRandomGenerator(0L);
//        int int14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl9);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(10);
//        double double19 = randomDataImpl0.nextGaussian(0.0d, 1.4344528869931015d);
//        long long22 = randomDataImpl0.nextLong(0L, 25L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0107668153726515d) + "'", double2 == (-2.0107668153726515d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.49224143833287226d + "'", double3 == 0.49224143833287226d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.4298758396323692d) + "'", double4 == (-0.4298758396323692d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.611924821055805E-6d + "'", double11 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 29 + "'", int14 == 29);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "b668ac333a" + "'", str16.equals("b668ac333a"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.2294146895720375d) + "'", double19 == (-3.2294146895720375d));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 17L + "'", long22 == 17L);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.24431868917291955d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.783237985019075d + "'", double1 == 0.783237985019075d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.3124534472317495d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
//        double double3 = poissonDistributionImpl1.cumulativeProbability((double) (byte) 10);
//        int int4 = poissonDistributionImpl1.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.611924821055805E-6d + "'", double3 == 5.611924821055805E-6d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Object[] objArray1 = null;
        java.util.ConcurrentModificationException concurrentModificationException2 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("de8ea16184", objArray1);
        org.junit.Assert.assertNotNull(concurrentModificationException2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) ' ');
        int int3 = poissonDistributionImpl1.inverseCumulativeProbability(1.0d);
        double double5 = poissonDistributionImpl1.cumulativeProbability((double) 10);
        double double7 = poissonDistributionImpl1.probability(10);
        double double10 = poissonDistributionImpl1.cumulativeProbability(0, 33);
        int int12 = poissonDistributionImpl1.inverseCumulativeProbability((double) 0L);
        double double14 = poissonDistributionImpl1.probability(19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.611924821055805E-6d + "'", double5 == 5.611924821055805E-6d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.929283182309498E-6d + "'", double7 == 3.929283182309498E-6d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6150373563537195d + "'", double10 == 0.6150373563537195d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.00412412239728124d + "'", double14 == 0.00412412239728124d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (byte) -1, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizedFormats18, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(throwable15, 0.0d, "", objArray22);
        java.lang.UnsupportedOperationException unsupportedOperationException24 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException12, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray22);
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("21f5f825e1", objArray22);
        java.lang.ArithmeticException arithmeticException27 = org.apache.commons.math.MathRuntimeException.createArithmeticException("72ce9adfc8", objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(unsupportedOperationException24);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertNotNull(arithmeticException27);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.8961388862077218d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.254990989630845d) + "'", double1 == (-3.254990989630845d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats4, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable1, 0.0d, "", objArray8);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException9, "hi!", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException("72ce9adfc8", objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2L);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats8, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(throwable5, 0.0d, "", objArray12);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException13, "hi!", objArray18);
        double[] doubleArray21 = functionEvaluationException13.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Object[] objArray30 = new java.lang.Object[] { localizedFormats26, Double.NaN, 0, (short) -1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(throwable23, 0.0d, "", objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        java.lang.Object[] objArray36 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "", objArray36);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException31, "hi!", objArray36);
        double[] doubleArray39 = functionEvaluationException31.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        java.lang.Object[] objArray44 = new java.lang.Object[] { localizedFormats41, 100.0f, (byte) 100 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException();
        convergenceException45.addSuppressed((java.lang.Throwable) convergenceException46);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        java.lang.Object[] objArray49 = new java.lang.Object[] { functionEvaluationException31, convergenceException45, localizedFormats48 };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException13, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray49);
        java.text.ParseException parseException51 = org.apache.commons.math.MathRuntimeException.createParseException(0, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray49);
        java.lang.IllegalStateException illegalStateException52 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(parseException51);
        org.junit.Assert.assertNotNull(illegalStateException52);
    }
}

