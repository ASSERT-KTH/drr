import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.add(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.newInstance(dfp21);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp21.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp30);
        java.lang.Class<?> wildcardClass32 = dfp30.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5514266812416906d, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06881948313032381d + "'", double2 == 0.06881948313032381d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.659409443987937d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 143.48781534365938d + "'", double1 == 143.48781534365938d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-65521551));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.add(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.add(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp23.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.multiply(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp7.remainder(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField1.newDfp(dfp40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.signum(5.420079367456773E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 89);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1843470716281956036L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8434707162819561E18d) + "'", double1 == (-1.8434707162819561E18d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        float float2 = org.apache.commons.math.util.FastMath.max(32760.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32760.0f + "'", float2 == 32760.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(28.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags(16);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags(16);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2621221781635855E15d + "'", double1 == 2.2621221781635855E15d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.cos((-2.4871469606651075d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7933854675284423d) + "'", double1 == (-0.7933854675284423d));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        java.lang.Class<?> wildcardClass1 = mersenneTwister0.getClass();
//        int int3 = mersenneTwister0.nextInt(100);
//        long long4 = mersenneTwister0.nextLong();
//        int int5 = mersenneTwister0.nextInt();
//        float float6 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 56 + "'", int3 == 56);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3185796982366791922L + "'", long4 == 3185796982366791922L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-919007745) + "'", int5 == (-919007745));
//        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.09111369f + "'", float6 == 0.09111369f);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.multiply(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        java.lang.String str43 = dfp41.toString();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.power10((int) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(0);
        int int48 = dfpField47.getRadixDigits();
        int int49 = dfpField47.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = dfpField47.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.getSqr3();
        int int52 = dfp51.log10();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.add(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.sqrt();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp31.multiply(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.ceil();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Infinity" + "'", str43.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        java.lang.Object obj11 = null;
        boolean boolean12 = dfp10.equals(obj11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.multiply((-65521551));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.08314684972886147d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.746501045726147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.585942543509105d + "'", double1 == 57.585942543509105d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-0.7059602000407633d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.025676021633806948d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025676021633806945d + "'", double2 == 0.025676021633806945d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("Infinity");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.divide((int) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.add(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.add(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.sqrt();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp5.nextAfter(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp35 = dfp5.divide(dfp34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        int int29 = dfpField28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp37.add(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.add(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.newInstance(dfp48);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp48.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp48.ceil();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp48.newInstance("Infinity");
        org.apache.commons.math.dfp.Dfp dfp61 = dfp15.dotrap(92, "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (null)", dfp32, dfp48);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 78);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4469.070802020421d + "'", double1 == 4469.070802020421d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        int int9 = dfpField8.getRadixDigits();
        int int10 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getE();
        dfpField15.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        int int23 = dfpField22.getRadixDigits();
        int int24 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = dfpField22.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getOne();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField15.newDfp(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp13.add(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        int int31 = dfpField30.getRadixDigits();
        int int32 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = dfpField30.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.ceil();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.getZero();
        boolean boolean37 = dfp28.greaterThan(dfp34);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        int[] intArray9 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
        mersenneTwister3.setSeed(intArray9);
        mersenneTwister1.setSeed(intArray9);
        mersenneTwister1.setSeed((long) 0);
        long long14 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed(2);
        byte[] byteArray23 = new byte[] { (byte) -1, (byte) 0, (byte) 0, (byte) 2, (byte) -1, (byte) 1 };
        mersenneTwister1.nextBytes(byteArray23);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2780242596957121269L + "'", long14 == 2780242596957121269L);
        org.junit.Assert.assertNotNull(byteArray23);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.add(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.add(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp14.newInstance(dfp20);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.floor();
        boolean boolean30 = dfp14.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp4.newInstance(dfp14);
        int int32 = dfp4.intValue();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.add(dfp40);
        java.lang.String str42 = dfp40.toString();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp30.subtract(dfp40);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp30.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 0.589 is smaller than the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp46 = dfp26.add(dfp30);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Infinity" + "'", str42.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1843470716281956036L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8434707162819561E18d + "'", double1 == 1.8434707162819561E18d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        int[] intArray7 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
        mersenneTwister1.setSeed(intArray7);
        float float9 = mersenneTwister1.nextFloat();
        int int11 = mersenneTwister1.nextInt(8);
        float float12 = mersenneTwister1.nextFloat();
        double double13 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5894222f + "'", float9 == 0.5894222f);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.090170264f + "'", float12 == 0.090170264f);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.7758870849245094d + "'", double13 == 0.7758870849245094d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits(73);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590464d + "'", double1 == 1.7182818284590464d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.add(dfp13);
        java.lang.String str15 = dfp13.toString();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.subtract(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.add(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp26.newInstance(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp44.add(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp39.add(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp13.multiply(dfp39);
        java.lang.String str53 = dfp13.toString();
        int int54 = dfp13.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Infinity" + "'", str15.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Infinity" + "'", str53.equals("Infinity"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int[] intArray3 = new int[] { 32760, (byte) 0, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        mersenneTwister4.setSeed(32);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-958060055) + "'", int5 == (-958060055));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1251249291323246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.atan((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.9E-324d) + "'", double1 == (-4.9E-324d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getZero();
        int int24 = dfp23.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        int[] intArray9 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
        mersenneTwister3.setSeed(intArray9);
        mersenneTwister1.setSeed(intArray9);
        float float12 = mersenneTwister1.nextFloat();
        int int14 = mersenneTwister1.nextInt(8);
        java.lang.Class<?> wildcardClass15 = mersenneTwister1.getClass();
        int int17 = mersenneTwister1.nextInt((int) (byte) 2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5894222f + "'", float12 == 0.5894222f);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.add(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.newInstance(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.add(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp44.add(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp38.newInstance(dfp44);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.Dfp.copysign(dfp21, dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField1.newDfp(dfp21);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField1.newDfp((byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.multiply(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp47.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp57 = new org.apache.commons.math.dfp.Dfp(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField59.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp57.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp31.add(dfp57);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp64.multiply((int) '#');
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp9.floor();
        int int24 = dfp9.classify();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp9.newInstance("Infinity");
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp47.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp41.floor();
        boolean boolean57 = dfp41.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp31.newInstance(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField65.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp63.add(dfp68);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField71.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField76.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp74.add(dfp79);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp68.newInstance(dfp74);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp68.floor();
        boolean boolean83 = dfp58.greaterThan(dfp68);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp26.nextAfter(dfp68);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        int[] intArray9 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
        mersenneTwister3.setSeed(intArray9);
        mersenneTwister1.setSeed(intArray9);
        mersenneTwister1.setSeed((long) 0);
        long long14 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed(2);
        float float17 = mersenneTwister1.nextFloat();
        long long18 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2780242596957121269L + "'", long14 == 2780242596957121269L);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.43599486f + "'", float17 == 0.43599486f);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3414161789664041453L + "'", long18 == 3414161789664041453L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.8064934420314375E86d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.0f);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549038d + "'", double1 == 1.5574077246549038d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.ceil();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        int int10 = dfpField9.getRadixDigits();
        int int11 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.newInstance(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        int int21 = dfpField20.getRadixDigits();
        int int22 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField20.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getOne();
        boolean boolean25 = dfp7.lessThan(dfp24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-919007745));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 919007745L + "'", long1 == 919007745L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) 2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4613583527127430549L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean6 = numberIsTooSmallException5.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean12 = numberIsTooSmallException11.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable13, objArray21);
        java.lang.Number number24 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(number24, number25, false);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 2.0f, (java.lang.Number) 50, true);
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable7, localizable28, objArray33);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        float float2 = org.apache.commons.math.util.FastMath.max(2.0f, (float) (-32767));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int1 = org.apache.commons.math.util.FastMath.abs((-65521551));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 65521551 + "'", int1 == 65521551);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) 2504369237645498586L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.multiply(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        java.lang.String str43 = dfp41.toString();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.power10((int) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(0);
        int int48 = dfpField47.getRadixDigits();
        int int49 = dfpField47.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = dfpField47.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.getSqr3();
        int int52 = dfp51.log10();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.add(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.sqrt();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp31.multiply(dfp54);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp54.newInstance((byte) 0, (byte) 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Infinity" + "'", str43.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.693790523369731d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9346282997376141d + "'", double1 == 0.9346282997376141d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp8.multiply(dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getE();
        dfpField6.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        int int14 = dfpField13.getRadixDigits();
        int int15 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField13.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField6.newDfp(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getE();
        dfpField20.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        int int28 = dfpField27.getRadixDigits();
        int int29 = dfpField27.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getOne();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField20.newDfp(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp18.add(dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp18.multiply((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.getOne();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.getTwo();
        boolean boolean48 = dfp41.greaterThan(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp41.newInstance();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp41.multiply(4);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp4.multiply(dfp41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.add(dfp13);
        java.lang.String str15 = dfp13.toString();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.subtract(dfp13);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance((-0.16299078079570548d));
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.add(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.add(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp28.newInstance(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp46.add(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp57.add(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp51.newInstance(dfp57);
        org.apache.commons.math.dfp.Dfp dfp65 = org.apache.commons.math.dfp.Dfp.copysign(dfp34, dfp64);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(0);
        int int68 = dfpField67.getRadixDigits();
        int int69 = dfpField67.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode70 = dfpField67.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp65.nextAfter(dfp72);
        int int74 = dfp73.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp18.multiply(dfp73);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Infinity" + "'", str15.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode70 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode70.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 4 + "'", int74 == 4);
        org.junit.Assert.assertNotNull(dfp75);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int2 = org.apache.commons.math.util.FastMath.max(46, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.multiply(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp47.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp57 = new org.apache.commons.math.dfp.Dfp(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField59.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp57.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp31.add(dfp57);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp31.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp31.floor();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.add(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp38.add(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp32.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.Dfp.copysign(dfp15, dfp45);
        int int47 = dfp46.log10K();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.ceil();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10((int) '#');
        boolean boolean15 = dfp5.greaterThan(dfp12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5488135008937807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1544162506663938d + "'", double1 == 1.1544162506663938d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.add(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.newInstance(dfp22);
        boolean boolean30 = dfp6.unequal(dfp22);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp22.newInstance((long) 73);
        boolean boolean33 = dfp32.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.add(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.add(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.sqrt();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField1.newDfp(dfp32);
        dfpField1.setIEEEFlags(1);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.1490826104066896d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        java.lang.String str11 = dfp9.toString();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.add(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.add(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp21.newInstance(dfp27);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.floor();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp9.nextAfter(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.add(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp53.add(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp47.newInstance(dfp53);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp47.floor();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp61.newInstance((int) (byte) 100);
        java.lang.String str64 = dfp61.toString();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.getOne();
        boolean boolean66 = dfp37.lessThan(dfp65);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Infinity" + "'", str11.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Infinity" + "'", str64.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1071487177940904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7453357150526566d + "'", double1 == 0.7453357150526566d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        int[] intArray7 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
        mersenneTwister1.setSeed(intArray7);
        float float9 = mersenneTwister1.nextFloat();
        boolean boolean10 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5894222f + "'", float9 == 0.5894222f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        int int8 = dfpField7.getRadixDigits();
        int int9 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp5.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        int int17 = dfpField16.getRadixDigits();
        int int18 = dfpField16.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.add(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp30.newInstance(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.add(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.add(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp53.newInstance(dfp59);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.Dfp.copysign(dfp36, dfp66);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField16.newDfp(dfp36);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField16.getOne();
        boolean boolean70 = dfp14.greaterThan(dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp14.newInstance(35.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(0);
        int int3 = dfpField2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.getSqr2Reciprocal();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("Infinity");
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
//        int[] intArray11 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
//        mersenneTwister5.setSeed(intArray11);
//        mersenneTwister3.setSeed(intArray11);
//        mersenneTwister3.setSeed((long) 0);
//        long long16 = mersenneTwister3.nextLong();
//        mersenneTwister3.setSeed(2);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister();
//        java.lang.Class<?> wildcardClass20 = mersenneTwister19.getClass();
//        int int22 = mersenneTwister19.nextInt(100);
//        long long23 = mersenneTwister19.nextLong();
//        int[] intArray27 = new int[] { 32760, (byte) 0, (-1) };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray27);
//        mersenneTwister19.setSeed(intArray27);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math.random.MersenneTwister(intArray27);
//        mersenneTwister3.setSeed(intArray27);
//        mersenneTwister1.setSeed(intArray27);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister33 = new org.apache.commons.math.random.MersenneTwister(intArray27);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2780242596957121269L + "'", long16 == 2780242596957121269L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 46 + "'", int22 == 46);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 7226266727096310025L + "'", long23 == 7226266727096310025L);
//        org.junit.Assert.assertNotNull(intArray27);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        int int8 = dfpField7.getRadixDigits();
        int int9 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp5.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        int int17 = dfpField16.getRadixDigits();
        int int18 = dfpField16.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.add(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp30.newInstance(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.add(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.add(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp53.newInstance(dfp59);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.Dfp.copysign(dfp36, dfp66);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField16.newDfp(dfp36);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField16.getOne();
        boolean boolean70 = dfp14.greaterThan(dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp69.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dfp71);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        dfpField1.setIEEEFlagsBits((-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        int[] intArray7 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
        mersenneTwister1.setSeed(intArray7);
        float float9 = mersenneTwister1.nextFloat();
        int int11 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed(1L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister((long) (short) 0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        int[] intArray23 = new int[] { (-1), 32760, 32760, (byte) 100, (short) 10 };
        mersenneTwister17.setSeed(intArray23);
        int int26 = mersenneTwister17.nextInt(100);
        byte[] byteArray28 = new byte[] { (byte) -1 };
        mersenneTwister17.nextBytes(byteArray28);
        mersenneTwister15.nextBytes(byteArray28);
        mersenneTwister1.nextBytes(byteArray28);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5894222f + "'", float9 == 0.5894222f);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 50 + "'", int26 == 50);
        org.junit.Assert.assertNotNull(byteArray28);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.add(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.add(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp14.newInstance(dfp20);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.floor();
        boolean boolean30 = dfp14.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp4.newInstance(dfp14);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getE();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp43.add(dfp48);
        java.lang.String str50 = dfp48.toString();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp48.power10((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp38.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp31.newInstance(dfp53);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Infinity" + "'", str50.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((double) 0L);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-4), (float) 78L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 78.0f + "'", float2 == 78.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getE();
        dfpField6.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        int int14 = dfpField13.getRadixDigits();
        int int15 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField13.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField6.newDfp(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getE();
        dfpField20.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        int int28 = dfpField27.getRadixDigits();
        int int29 = dfpField27.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getOne();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField20.newDfp(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp18.add(dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp18.multiply((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 2 is smaller than the minimum (50): 2 is smaller than, or equal to, the minimum (50)");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp15.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.add(dfp14);
        java.lang.String str16 = dfp14.toString();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp4.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        int int22 = dfpField21.getRadixDigits();
        int int23 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = dfpField21.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.ceil();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.ceil();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp14.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Infinity" + "'", str16.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.add(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.add(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp23.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.multiply(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp44.add(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp55.add(dfp60);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp49.newInstance(dfp55);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp55.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp65 = new org.apache.commons.math.dfp.Dfp(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray68 = dfpField67.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp65.multiply(dfp70);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp39.add(dfp65);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField1.newDfp(dfp72);
        double double74 = dfp72.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfpArray68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.POSITIVE_INFINITY + "'", double74 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.add(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.newDfp(dfp15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 74);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.00000000000001d + "'", double1 == 74.00000000000001d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        int int9 = dfpField8.getRadixDigits();
        int int10 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 2147483647);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        java.lang.String str11 = dfp9.toString();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.add(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.add(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp21.newInstance(dfp27);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.floor();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp9.nextAfter(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp9.power10(89);
        org.apache.commons.math.dfp.Dfp dfp39 = new org.apache.commons.math.dfp.Dfp(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField41.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.add(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.add(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp53.newInstance(dfp59);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp59.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp69 = new org.apache.commons.math.dfp.Dfp(dfp59);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField41.newDfp(dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField41.getTwo();
        boolean boolean72 = dfp38.greaterThan(dfp71);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Infinity" + "'", str11.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013292325585375278d) + "'", double1 == (-0.013292325585375278d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp15.ceil();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp15.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        int int7 = dfp5.log10();
        int int8 = dfp5.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2147483647L + "'", long1 == 2147483647L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 2504369237645498586L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.multiply((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.add(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.add(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp34.newInstance(dfp40);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.getZero();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: -222,762,514,793,705,909 is smaller than, or equal to, the minimum (0): -222,762,514,793,705,909 is smaller than the minimum (0)");
        boolean boolean51 = dfp15.unequal(dfp50);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.add(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.newInstance(dfp22);
        boolean boolean30 = dfp6.unequal(dfp22);
        double double31 = dfp6.toDouble();
        boolean boolean32 = dfp6.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double2 = org.apache.commons.math.util.FastMath.max((-3.0d), (-0.013292325585375278d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.013292325585375278d) + "'", double2 == (-0.013292325585375278d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.6937905233697308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.746501045726147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2614713015373162d + "'", double1 == 2.2614713015373162d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 10, (byte) 0);
        int int8 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1846239932, 1.0176064912058516d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963262437188d + "'", double2 == 1.5707963262437188d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 0, 10, 0L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException15, localizable16, localizable17, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable5, localizable6, objArray21);
        java.lang.Number number24 = numberIsTooSmallException3.getArgument();
        java.lang.Number number25 = numberIsTooSmallException3.getMin();
        java.lang.Number number26 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.5894222f + "'", number4.equals(0.5894222f));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.5894222f + "'", number24.equals(0.5894222f));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0d + "'", number25.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.5894222f + "'", number26.equals(0.5894222f));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 0, 10, 0L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException15, localizable16, localizable17, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable5, localizable6, objArray21);
        java.lang.Number number24 = numberIsTooSmallException3.getArgument();
        java.lang.Number number25 = numberIsTooSmallException3.getArgument();
        java.lang.Number number26 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.5894222f + "'", number4.equals(0.5894222f));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.5894222f + "'", number24.equals(0.5894222f));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.5894222f + "'", number25.equals(0.5894222f));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.multiply(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getTwo();
        boolean boolean37 = dfp3.greaterThan(dfp35);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.newInstance((byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.8414709848078965d, (java.lang.Number) 49.40723197656493d, false);
        boolean boolean11 = numberIsTooSmallException10.getBoundIsAllowed();
        boolean boolean12 = numberIsTooSmallException10.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean17 = numberIsTooSmallException16.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean23 = numberIsTooSmallException22.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable24, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 0.5894222f);
        java.lang.Number number37 = null;
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(number37, number38, false);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException40.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) 2.0f, (java.lang.Number) 50, true);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(0);
        int int48 = dfpField47.getRadixDigits();
        int int49 = dfpField47.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = dfpField47.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField47.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10, localizable18, localizable41, (java.lang.Object[]) dfpArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) 0.8414709848078965d, (java.lang.Number) 49.40723197656493d, false);
        java.lang.Number number59 = numberIsTooSmallException58.getMin();
        mathIllegalArgumentException53.addSuppressed((java.lang.Throwable) numberIsTooSmallException58);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 49.40723197656493d + "'", number59.equals(49.40723197656493d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10((-32767));
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getE();
        dfpField26.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        int int34 = dfpField33.getRadixDigits();
        int int35 = dfpField33.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField33.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getOne();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField26.newDfp(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp43.add(dfp48);
        java.lang.String str50 = dfp48.toString();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp55.add(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField68.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp66.add(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp60.newInstance(dfp66);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp60.floor();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp48.nextAfter(dfp74);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField77.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField82.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp80.add(dfp85);
        java.lang.String str87 = dfp85.toString();
        boolean boolean88 = dfp75.greaterThan(dfp85);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp38.nextAfter(dfp85);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp22.remainder(dfp89);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Infinity" + "'", str50.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "Infinity" + "'", str87.equals("Infinity"));
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.floor();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        int int12 = dfpField11.getRadixDigits();
        int int13 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField11.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((byte) 10);
        int int19 = dfp18.intValue();
        double[] doubleArray20 = dfp18.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp9.newInstance(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.add(dfp35);
        java.lang.String str37 = dfp35.toString();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp25.subtract(dfp35);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance((-0.16299078079570548d));
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Infinity" + "'", str37.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int2 = org.apache.commons.math.util.FastMath.max(78, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78 + "'", int2 == 78);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.add(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.newInstance(dfp22);
        boolean boolean30 = dfp6.unequal(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.add(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp51.add(dfp56);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp45.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp45.floor();
        boolean boolean61 = dfp45.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp35.newInstance(dfp45);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp62.newInstance((byte) 0);
        boolean boolean65 = dfp22.lessThan(dfp62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits(1846239932);
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField12.setRoundingMode(roundingMode16);
        dfpField7.setRoundingMode(roundingMode16);
        dfpField1.setRoundingMode(roundingMode16);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-7983612661375368595L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.8414709848078965d, (java.lang.Number) 49.40723197656493d, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean11 = numberIsTooSmallException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean17 = numberIsTooSmallException16.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable18, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 0.5894222f);
        java.lang.Number number31 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(number31, number32, false);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException34.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 2.0f, (java.lang.Number) 50, true);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        int int42 = dfpField41.getRadixDigits();
        int int43 = dfpField41.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode44 = dfpField41.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField41.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable12, localizable35, (java.lang.Object[]) dfpArray45);
        java.lang.Class<?> wildcardClass47 = mathRuntimeException46.getClass();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode44 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode44.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("1.609437912434");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        java.lang.Object[] objArray4 = mathIllegalArgumentException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.5704911417096115d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.051850805477743E-4d + "'", double1 == 3.051850805477743E-4d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32768.00000000001d + "'", double1 == 32768.00000000001d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(3.831008000716577E22d);
        int int5 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.add(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp38.add(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp32.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.Dfp.copysign(dfp15, dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(0);
        int int49 = dfpField48.getRadixDigits();
        int int50 = dfpField48.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode51 = dfpField48.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField48.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp46.nextAfter(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.rint();
        org.apache.commons.math.dfp.Dfp dfp56 = new org.apache.commons.math.dfp.Dfp(dfp54);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode51 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode51.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        java.lang.String str11 = dfp9.toString();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.power10((int) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        int int16 = dfpField15.getRadixDigits();
        int int17 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getSqr3();
        int int20 = dfp19.log10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp13.add(dfp19);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance((byte) -1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Infinity" + "'", str11.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 522926805, 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.22926816E8f + "'", float2 == 5.22926816E8f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7453357150526566d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9229218033403526d + "'", double1 == 0.9229218033403526d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.5894222f + "'", number4.equals(0.5894222f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.5894222f + "'", number5.equals(0.5894222f));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField6.setRoundingMode(roundingMode10);
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp(3.831008000716577E22d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.remainder(dfp9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        dfpField1.setIEEEFlagsBits((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.8064934420314375E86d, (java.lang.Number) (short) 1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.8064934420314375E86d + "'", number4.equals(1.8064934420314375E86d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.7182818284590464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3100528160534926d + "'", double1 == 1.3100528160534926d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.multiply(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp3.remainder(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp45.add(dfp50);
        java.lang.String str52 = dfp50.toString();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp40.subtract(dfp50);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp40.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 0.589 is smaller than the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp56 = dfp36.divide(dfp55);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Infinity" + "'", str52.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.add(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.newInstance(dfp22);
        boolean boolean30 = dfp6.unequal(dfp22);
        double double31 = dfp6.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp47.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp6.subtract(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp62.add(dfp67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField75.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp73.add(dfp78);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp67.newInstance(dfp73);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp73.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp83 = new org.apache.commons.math.dfp.Dfp(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField85 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField85.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField85.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp83.multiply(dfp88);
        int int90 = dfp89.log10();
        boolean boolean91 = dfp6.lessThan(dfp89);
        int int92 = dfp6.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfpArray86);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-4) + "'", int90 == (-4));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 4 + "'", int92 == 4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.add(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.add(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.sqrt();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField1.newDfp(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        int int36 = dfpField35.getRadixDigits();
        int int37 = dfpField35.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode38 = dfpField35.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp("Infinity");
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.divide((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10(32);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.getZero();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp57.add(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField65.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp68.add(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp62.newInstance(dfp68);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp62.floor();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp76.newInstance((int) (byte) 100);
        java.lang.String str79 = dfp76.toString();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp76.getOne();
        org.apache.commons.math.dfp.Dfp dfp81 = org.apache.commons.math.dfp.DfpField.computeLn(dfp41, dfp52, dfp80);
        boolean boolean82 = dfp32.unequal(dfp52);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode38 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode38.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "Infinity" + "'", str79.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        dfpField1.setIEEEFlags(79);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.exp((-7.5738226689354281E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int[] intArray3 = new int[] { 32760, (byte) 0, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int6 = mersenneTwister5.nextInt();
        float float7 = mersenneTwister5.nextFloat();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-958060055) + "'", int6 == (-958060055));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.9861045f + "'", float7 == 0.9861045f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.multiply(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.add(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp47.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp57 = new org.apache.commons.math.dfp.Dfp(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField59.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp57.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp31.add(dfp57);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp31.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp66.power10(1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.multiply(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getTwo();
        boolean boolean37 = dfp3.greaterThan(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp3.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        int int9 = dfpField8.getRadixDigits();
        int int10 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.add(dfp23);
        java.lang.String str25 = dfp23.toString();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.add(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp41.add(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp35.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp35.floor();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp23.nextAfter(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp55.add(dfp60);
        java.lang.String str62 = dfp60.toString();
        boolean boolean63 = dfp50.greaterThan(dfp60);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp13.nextAfter(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField65 = dfp64.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Infinity" + "'", str25.equals("Infinity"));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Infinity" + "'", str62.equals("Infinity"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfpField65);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        int int7 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlagsBits(40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits(73);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        boolean boolean5 = dfp4.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2780242596957121269L);
        mersenneTwister1.setSeed(1846239932);
        double double4 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.31853846933642704d + "'", double4 == 0.31853846933642704d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean10 = numberIsTooSmallException9.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, objArray19);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean26 = numberIsTooSmallException25.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5894222f, (java.lang.Number) 0.0d, true);
        boolean boolean32 = numberIsTooSmallException31.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable33, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1.0d), 0.0d, false, 1.0f, 1.0d, ' ' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable27, objArray51);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-0.9171038490640099d), (java.lang.Number) (-3.0d), false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.06881948313032381d, (java.lang.Number) 0, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField1.newDfp(dfp29);
        int int31 = dfp29.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        long long1 = org.apache.commons.math.util.FastMath.abs(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(40);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        int int11 = dfpField10.getRadixDigits();
        int int12 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getE();
        dfpField15.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        int int23 = dfpField22.getRadixDigits();
        int int24 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = dfpField22.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getOne();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField15.newDfp(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getE();
        dfpField29.setIEEEFlagsBits(1846239932);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(0);
        int int37 = dfpField36.getRadixDigits();
        int int38 = dfpField36.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = dfpField36.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getOne();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField29.newDfp(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp27.add(dfp40);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp27.multiply((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeExp(dfp13, dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp8.remainder(dfp13);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1071487177940904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0257189050036284d + "'", double1 == 3.0257189050036284d);
    }
}

