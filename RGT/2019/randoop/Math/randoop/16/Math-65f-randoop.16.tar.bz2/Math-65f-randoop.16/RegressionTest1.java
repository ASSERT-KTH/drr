import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix3.scalarAdd((double) (short) -1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix10.transpose();
        org.apache.commons.math.linear.RealVector realVector13 = blockRealMatrix11.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.scalarAdd((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix11.getRowVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix20.transpose();
        org.apache.commons.math.linear.RealVector realVector23 = blockRealMatrix21.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.scalarAdd((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector27 = blockRealMatrix25.getColumnVector((int) (byte) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix11.add(blockRealMatrix25);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix29 = blockRealMatrix7.preMultiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix25);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[][] doubleArray2 = array2DRowRealMatrix1.getData();
        org.apache.commons.math.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.MathRuntimeException(localizable0, (java.lang.Object[]) doubleArray2);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(0, (int) (byte) -1);
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix3 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException8 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException8);
        java.lang.String str10 = convergenceException9.toString();
        java.lang.Object[] objArray11 = new java.lang.Object[] { "", 0L, str10 };
        java.util.ConcurrentModificationException concurrentModificationException12 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray11);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException13 = new org.apache.commons.math.linear.InvalidMatrixException(localizable2, objArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(throwable0, localizable1, objArray11);
        java.lang.Throwable[] throwableArray15 = mathException14.getSuppressed();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str10.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(concurrentModificationException12);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, 35, (int) (byte) 0, 36, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException5 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException5);
        java.lang.String str7 = convergenceException6.toString();
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", 0L, str7 };
        java.util.ConcurrentModificationException concurrentModificationException9 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) concurrentModificationException9, localizable10, objArray13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.transpose();
        org.apache.commons.math.linear.RealVector realVector21 = blockRealMatrix19.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix19.scalarAdd((double) 2);
        double[] doubleArray25 = blockRealMatrix23.getColumn(1);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException15, doubleArray25);
        double[] doubleArray27 = functionEvaluationException26.getArgument();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str7.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(concurrentModificationException9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 2);
        double[] doubleArray9 = blockRealMatrix7.getColumn(1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = blockRealMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        double[] doubleArray7 = blockRealMatrix4.getColumn((int) (short) 10);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray10 = new double[] { (byte) 10 };
        double[] doubleArray16 = new double[] { (byte) 1, (byte) -1, ' ', 0.0d, (short) 0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix17 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray16);
        org.apache.commons.math.linear.RealVector realVector20 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray10);
        org.apache.commons.math.linear.BigMatrix bigMatrix21 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray10);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = convergenceException22.getArguments();
        org.apache.commons.math.exception.Localizable localizable24 = convergenceException22.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException33 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException33);
        java.lang.String str35 = convergenceException34.toString();
        java.lang.Object[] objArray36 = new java.lang.Object[] { "", 0L, str35 };
        java.util.ConcurrentModificationException concurrentModificationException37 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26, localizable27, objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable25, objArray36);
        java.lang.Throwable[] throwableArray40 = mathException39.getSuppressed();
        java.lang.Throwable[] throwableArray41 = mathException39.getSuppressed();
        java.lang.ArithmeticException arithmeticException42 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable24, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.exception.Localizable localizable44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException52 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException52);
        java.lang.String str54 = convergenceException53.toString();
        java.lang.Object[] objArray55 = new java.lang.Object[] { "", 0L, str54 };
        java.util.ConcurrentModificationException concurrentModificationException56 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException45, localizable46, objArray55);
        java.lang.Throwable throwable59 = null;
        org.apache.commons.math.exception.Localizable localizable60 = null;
        org.apache.commons.math.exception.Localizable localizable61 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException67 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException67);
        java.lang.String str69 = convergenceException68.toString();
        java.lang.Object[] objArray70 = new java.lang.Object[] { "", 0L, str69 };
        java.util.ConcurrentModificationException concurrentModificationException71 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray70);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException72 = new org.apache.commons.math.linear.InvalidMatrixException(localizable61, objArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable59, localizable60, objArray70);
        org.apache.commons.math.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException57, "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix", objArray70);
        java.lang.Object[] objArray75 = mathException57.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 10, localizable44, objArray75);
        java.lang.Object[] objArray77 = functionEvaluationException76.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable24, objArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, objArray77);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(bigMatrix17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(bigMatrix21);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable24.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str35.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(concurrentModificationException37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(arithmeticException42);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str54.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(concurrentModificationException56);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str69.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(concurrentModificationException71);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(objArray77);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        int int6 = blockRealMatrix3.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.transpose();
        double double13 = blockRealMatrix10.getEntry(2, (int) '4');
        double double14 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix17.transpose();
        org.apache.commons.math.linear.RealVector realVector20 = blockRealMatrix18.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix18.scalarAdd((double) 10.0f);
        double double25 = blockRealMatrix18.getEntry(0, 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix18.getColumnMatrix((int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix29 = blockRealMatrix18.scalarAdd((double) (byte) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix18.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix10.add(blockRealMatrix18);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix3.add(blockRealMatrix10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor33 = null;
        try {
            double double34 = blockRealMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray4 = convergenceException3.getArguments();
        org.apache.commons.math.exception.Localizable localizable5 = convergenceException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException14 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException14);
        java.lang.String str16 = convergenceException15.toString();
        java.lang.Object[] objArray17 = new java.lang.Object[] { "", 0L, str16 };
        java.util.ConcurrentModificationException concurrentModificationException18 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable8, objArray17);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable6, objArray17);
        java.lang.Throwable[] throwableArray21 = mathException20.getSuppressed();
        java.lang.Throwable[] throwableArray22 = mathException20.getSuppressed();
        java.lang.ArithmeticException arithmeticException23 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable5, (java.lang.Object[]) throwableArray22);
        double[] doubleArray26 = new double[] { (-1L), 0.0f };
        double[] doubleArray29 = new double[] { (-1L), 0.0f };
        double[] doubleArray32 = new double[] { (-1L), 0.0f };
        double[][] doubleArray33 = new double[][] { doubleArray26, doubleArray29, doubleArray32 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33, false);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException36 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable5, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException39 = new org.apache.commons.math.MaxEvaluationsExceededException((-1), "BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", (java.lang.Object[]) doubleArray33);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable5.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str16.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(arithmeticException23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException36);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException(100, 0);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray5 = convergenceException4.getArguments();
        org.apache.commons.math.exception.Localizable localizable6 = convergenceException4.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException15 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException15);
        java.lang.String str17 = convergenceException16.toString();
        java.lang.Object[] objArray18 = new java.lang.Object[] { "", 0L, str17 };
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray18);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray18);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable7, objArray18);
        java.lang.Throwable[] throwableArray22 = mathException21.getSuppressed();
        java.lang.Throwable[] throwableArray23 = mathException21.getSuppressed();
        java.lang.ArithmeticException arithmeticException24 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable6, (java.lang.Object[]) throwableArray23);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nonSquareMatrixException2, (double) 100L, localizable6, objArray25);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable29 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException35 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException35);
        java.lang.String str37 = convergenceException36.toString();
        java.lang.Object[] objArray38 = new java.lang.Object[] { "", 0L, str37 };
        java.util.ConcurrentModificationException concurrentModificationException39 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException28, localizable29, objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable27, objArray38);
        java.lang.Throwable[] throwableArray42 = mathException41.getSuppressed();
        java.lang.Throwable[] throwableArray43 = mathException41.getSuppressed();
        java.io.EOFException eOFException44 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable6, (java.lang.Object[]) throwableArray43);
        java.io.IOException iOException45 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException44);
        org.apache.commons.math.optimization.OptimizationException optimizationException46 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) eOFException44);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) eOFException44);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str17.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(arithmeticException24);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str37.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(concurrentModificationException39);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(eOFException44);
        org.junit.Assert.assertNotNull(iOException45);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        blockRealMatrix2.addToEntry((int) (byte) 10, 1, (double) '#');
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a');
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 2);
        double[] doubleArray9 = blockRealMatrix7.getColumn(1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix12.transpose();
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.scalarAdd((double) 10.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix7.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix21.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix22.scalarAdd((double) (short) -1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix24.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix7.add(blockRealMatrix24);
        double[] doubleArray34 = new double[] { (byte) 1, (byte) -1, ' ', 0.0d, (short) 0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix35 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray34);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray34);
        try {
            blockRealMatrix24.setColumn((int) (short) -1, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 99]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(bigMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 1);
        double[] doubleArray8 = new double[] { (byte) 1, (byte) -1, ' ', 0.0d, (short) 0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray8);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray13 = convergenceException12.getArguments();
        org.apache.commons.math.exception.Localizable localizable14 = convergenceException12.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable18 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException24 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException24);
        java.lang.String str26 = convergenceException25.toString();
        java.lang.Object[] objArray27 = new java.lang.Object[] { "", 0L, str26 };
        java.util.ConcurrentModificationException concurrentModificationException28 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray27);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable16, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("hi!", objArray27);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException32 = new org.apache.commons.math.linear.MatrixIndexException(localizable14, objArray27);
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable35 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException41 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException41);
        java.lang.String str43 = convergenceException42.toString();
        java.lang.Object[] objArray44 = new java.lang.Object[] { "", 0L, str43 };
        java.util.ConcurrentModificationException concurrentModificationException45 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray44);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException46 = new org.apache.commons.math.linear.InvalidMatrixException(localizable35, objArray44);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(throwable33, localizable34, objArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray8, localizable14, objArray44);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("evaluation failed for argument = {0}", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(bigMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str26.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(concurrentModificationException28);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str43.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(concurrentModificationException45);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(100.0d);
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) 35);
        int int7 = levenbergMarquardtOptimizer0.getIterations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 1000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix3.scalarAdd((double) (short) -1);
        double double6 = blockRealMatrix3.getFrobeniusNorm();
        double double7 = blockRealMatrix3.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.createMatrix(52, 1);
        boolean boolean5 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.getColumnMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 2);
        double[] doubleArray9 = blockRealMatrix7.getColumn(1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix12.transpose();
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.scalarAdd((double) 10.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix7.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix21.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix22.scalarAdd((double) (short) -1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix24.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix7.add(blockRealMatrix24);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix27.getColumnMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 99]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (-1));
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) '#');
        int int6 = levenbergMarquardtOptimizer0.getIterations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (short) 0);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double double6 = blockRealMatrix3.getEntry(2, (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix3.scalarAdd((double) (short) 100);
        double[] doubleArray11 = new double[] { (byte) 10 };
        double[] doubleArray17 = new double[] { (byte) 1, (byte) -1, ' ', 0.0d, (short) 0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray17);
        org.apache.commons.math.linear.RealVector realVector21 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray11);
        try {
            blockRealMatrix3.setRow((int) (byte) 1, doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x1 but expected 1x100");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(bigMatrix18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        double[] doubleArray1 = new double[] { 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray1);
        double double3 = array2DRowRealMatrix2.getNorm();
        int int4 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.scalarMultiply(0.0d);
        boolean boolean7 = array2DRowRealMatrix2.isSquare();
        java.lang.String str8 = array2DRowRealMatrix2.toString();
        double double9 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{1.0}}" + "'", str8.equals("Array2DRowRealMatrix{{1.0}}"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException9 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException9);
        java.lang.String str11 = convergenceException10.toString();
        java.lang.Object[] objArray12 = new java.lang.Object[] { "", 0L, str11 };
        java.util.ConcurrentModificationException concurrentModificationException13 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray19 = convergenceException18.getArguments();
        org.apache.commons.math.exception.Localizable localizable20 = convergenceException18.getLocalizablePattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException22 = new org.apache.commons.math.MaxEvaluationsExceededException(2, localizable20, objArray21);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException25 = new org.apache.commons.math.linear.NonSquareMatrixException(100, 0);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray28 = convergenceException27.getArguments();
        org.apache.commons.math.exception.Localizable localizable29 = convergenceException27.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable30 = null;
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException38 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException38);
        java.lang.String str40 = convergenceException39.toString();
        java.lang.Object[] objArray41 = new java.lang.Object[] { "", 0L, str40 };
        java.util.ConcurrentModificationException concurrentModificationException42 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable32, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable30, objArray41);
        java.lang.Throwable[] throwableArray45 = mathException44.getSuppressed();
        java.lang.Throwable[] throwableArray46 = mathException44.getSuppressed();
        java.lang.ArithmeticException arithmeticException47 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable29, (java.lang.Object[]) throwableArray46);
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nonSquareMatrixException25, (double) 100L, localizable29, objArray48);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix52.transpose();
        org.apache.commons.math.linear.RealVector realVector55 = blockRealMatrix53.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix53.scalarAdd((double) 10.0f);
        double[][] doubleArray58 = blockRealMatrix53.getData();
        java.lang.UnsupportedOperationException unsupportedOperationException59 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable29, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException15, (double) 2147483647, localizable20, (java.lang.Object[]) doubleArray58);
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        java.lang.IllegalStateException illegalStateException63 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", (java.lang.Object[]) doubleArray58);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str11.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(concurrentModificationException13);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable20.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable29.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str40.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(concurrentModificationException42);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(arithmeticException47);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(unsupportedOperationException59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(illegalStateException63);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 2);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix3.copy();
        try {
            double double9 = blockRealMatrix3.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 10x100 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = blockRealMatrix4.scalarMultiply((double) 'a');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl10 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8, 0.0d);
        double double11 = lUDecompositionImpl10.getDeterminant();
        int[] intArray12 = lUDecompositionImpl10.getPivot();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl15 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13, 0.0d);
        int[] intArray16 = lUDecompositionImpl15.getPivot();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix4, intArray12, intArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: empty selected row index array");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 2);
        double[] doubleArray9 = blockRealMatrix3.getRow(0);
        try {
            double double10 = blockRealMatrix3.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 10x100 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        boolean boolean3 = blockRealMatrix2.isSquare();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 10.0f);
        double[][] doubleArray8 = blockRealMatrix3.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray12 = new double[] { 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double double14 = array2DRowRealMatrix13.getNorm();
        int int15 = array2DRowRealMatrix13.getRowDimension();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix13);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix2);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor4, 0, (int) '4', (int) ' ', 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException3 = new org.apache.commons.math.linear.NonSquareMatrixException(100, 0);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray6 = convergenceException5.getArguments();
        org.apache.commons.math.exception.Localizable localizable7 = convergenceException5.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException16 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException16);
        java.lang.String str18 = convergenceException17.toString();
        java.lang.Object[] objArray19 = new java.lang.Object[] { "", 0L, str18 };
        java.util.ConcurrentModificationException concurrentModificationException20 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable8, objArray19);
        java.lang.Throwable[] throwableArray23 = mathException22.getSuppressed();
        java.lang.Throwable[] throwableArray24 = mathException22.getSuppressed();
        java.lang.ArithmeticException arithmeticException25 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable7, (java.lang.Object[]) throwableArray24);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nonSquareMatrixException3, (double) 100L, localizable7, objArray26);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix30.transpose();
        org.apache.commons.math.linear.RealVector realVector33 = blockRealMatrix31.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.scalarAdd((double) 10.0f);
        double[][] doubleArray36 = blockRealMatrix31.getData();
        java.lang.UnsupportedOperationException unsupportedOperationException37 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable7, (java.lang.Object[]) doubleArray36);
        java.lang.Object[] objArray38 = null;
        java.io.EOFException eOFException39 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable7, objArray38);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray42 = convergenceException41.getArguments();
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException(localizable40, objArray42);
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException52 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException52);
        java.lang.String str54 = convergenceException53.toString();
        java.lang.Object[] objArray55 = new java.lang.Object[] { "", 0L, str54 };
        java.util.ConcurrentModificationException concurrentModificationException56 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray55);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException57 = new org.apache.commons.math.linear.InvalidMatrixException(localizable46, objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException43, (double) (short) -1, "hi!", objArray55);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException59 = new org.apache.commons.math.linear.MatrixIndexException(localizable7, objArray55);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException62 = new org.apache.commons.math.linear.NonSquareMatrixException(100, 0);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray65 = convergenceException64.getArguments();
        org.apache.commons.math.exception.Localizable localizable66 = convergenceException64.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable67 = null;
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable69 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException75 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException75);
        java.lang.String str77 = convergenceException76.toString();
        java.lang.Object[] objArray78 = new java.lang.Object[] { "", 0L, str77 };
        java.util.ConcurrentModificationException concurrentModificationException79 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException68, localizable69, objArray78);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException(localizable67, objArray78);
        java.lang.Throwable[] throwableArray82 = mathException81.getSuppressed();
        java.lang.Throwable[] throwableArray83 = mathException81.getSuppressed();
        java.lang.ArithmeticException arithmeticException84 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable66, (java.lang.Object[]) throwableArray83);
        java.lang.Object[] objArray85 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nonSquareMatrixException62, (double) 100L, localizable66, objArray85);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix89 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix90 = blockRealMatrix89.transpose();
        org.apache.commons.math.linear.RealVector realVector92 = blockRealMatrix90.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix94 = blockRealMatrix90.scalarAdd((double) 10.0f);
        double[][] doubleArray95 = blockRealMatrix90.getData();
        java.lang.UnsupportedOperationException unsupportedOperationException96 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable66, (java.lang.Object[]) doubleArray95);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix97 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray95);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException98 = new org.apache.commons.math.MaxEvaluationsExceededException((-1), localizable7, (java.lang.Object[]) doubleArray95);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable7.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str18.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(concurrentModificationException20);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(arithmeticException25);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(unsupportedOperationException37);
        org.junit.Assert.assertNotNull(eOFException39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str54.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(concurrentModificationException56);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable66.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str77.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(concurrentModificationException79);
        org.junit.Assert.assertNotNull(throwableArray82);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertNotNull(arithmeticException84);
        org.junit.Assert.assertNotNull(blockRealMatrix90);
        org.junit.Assert.assertNotNull(realVector92);
        org.junit.Assert.assertNotNull(blockRealMatrix94);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(unsupportedOperationException96);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix(35);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 2);
        double[] doubleArray9 = blockRealMatrix7.getColumn(1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix12.transpose();
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.scalarAdd((double) 10.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix7.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix7.scalarAdd((double) 2);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = blockRealMatrix20.scalarMultiply((double) 0);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 10.0f);
        double double10 = blockRealMatrix3.getEntry(0, 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix3.getColumnMatrix((int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix14 = blockRealMatrix3.scalarAdd((double) (byte) 0);
        try {
            blockRealMatrix3.multiplyEntry(100, 1, 316.22776601683796d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, 1) in a 10x100 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 1);
        double[] doubleArray7 = new double[] { (byte) 1, (byte) -1, ' ', 0.0d, (short) 0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray12 = convergenceException11.getArguments();
        org.apache.commons.math.exception.Localizable localizable13 = convergenceException11.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException23 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException23);
        java.lang.String str25 = convergenceException24.toString();
        java.lang.Object[] objArray26 = new java.lang.Object[] { "", 0L, str25 };
        java.util.ConcurrentModificationException concurrentModificationException27 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, localizable17, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable15, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException31 = new org.apache.commons.math.linear.MatrixIndexException(localizable13, objArray26);
        java.lang.Throwable throwable32 = null;
        org.apache.commons.math.exception.Localizable localizable33 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException40 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException40);
        java.lang.String str42 = convergenceException41.toString();
        java.lang.Object[] objArray43 = new java.lang.Object[] { "", 0L, str42 };
        java.util.ConcurrentModificationException concurrentModificationException44 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray43);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException45 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, objArray43);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(throwable32, localizable33, objArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, doubleArray7, localizable13, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray49 = convergenceException48.getArguments();
        org.apache.commons.math.exception.Localizable localizable50 = convergenceException48.getLocalizablePattern();
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException1, localizable50, objArray51);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException58 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException58);
        java.lang.String str60 = convergenceException59.toString();
        java.lang.Object[] objArray61 = new java.lang.Object[] { "", 0L, str60 };
        java.util.ConcurrentModificationException concurrentModificationException62 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray61);
        org.apache.commons.math.exception.Localizable localizable63 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) concurrentModificationException62, localizable63, objArray66);
        double[] doubleArray74 = new double[] { (byte) 1, (byte) -1, ' ', 0.0d, (short) 0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix75 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray74);
        org.apache.commons.math.linear.RealVector realVector76 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) concurrentModificationException62, doubleArray74);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException77);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException85 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException85);
        java.lang.String str87 = convergenceException86.toString();
        java.lang.Object[] objArray88 = new java.lang.Object[] { "", 0L, str87 };
        java.util.ConcurrentModificationException concurrentModificationException89 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray88);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException78, "evaluation failed for argument = {0}", objArray88);
        java.io.EOFException eOFException91 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable50, objArray88);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable13.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str25.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(concurrentModificationException27);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str42.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(concurrentModificationException44);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable50.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str60.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(concurrentModificationException62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(bigMatrix75);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str87.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(concurrentModificationException89);
        org.junit.Assert.assertNotNull(eOFException91);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.scalarAdd((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector9 = blockRealMatrix7.getColumnVector((int) (byte) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix12.transpose();
        org.apache.commons.math.linear.RealVector realVector15 = blockRealMatrix13.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.scalarAdd((double) 10.0f);
        int int18 = blockRealMatrix17.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix17.scalarAdd((double) (-1L));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix7.subtract(blockRealMatrix17);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl23 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) blockRealMatrix17, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 10x100 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix3.transpose();
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(52);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 10.0f);
        double[][] doubleArray9 = blockRealMatrix4.getData();
        java.io.EOFException eOFException10 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.MaxIterationsExceededException: hi!", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, true);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(eOFException10);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException1);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException5 = new org.apache.commons.math.linear.NonSquareMatrixException((int) ' ', (int) (short) 0);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 1);
        double[] doubleArray15 = new double[] { (byte) 1, (byte) -1, ' ', 0.0d, (short) 0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix16 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray15);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray20 = convergenceException19.getArguments();
        org.apache.commons.math.exception.Localizable localizable21 = convergenceException19.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException31 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException31);
        java.lang.String str33 = convergenceException32.toString();
        java.lang.Object[] objArray34 = new java.lang.Object[] { "", 0L, str33 };
        java.util.ConcurrentModificationException concurrentModificationException35 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException24, localizable25, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable23, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException39 = new org.apache.commons.math.linear.MatrixIndexException(localizable21, objArray34);
        java.lang.Throwable throwable40 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        org.apache.commons.math.exception.Localizable localizable42 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException48 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException48);
        java.lang.String str50 = convergenceException49.toString();
        java.lang.Object[] objArray51 = new java.lang.Object[] { "", 0L, str50 };
        java.util.ConcurrentModificationException concurrentModificationException52 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray51);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException53 = new org.apache.commons.math.linear.InvalidMatrixException(localizable42, objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(throwable40, localizable41, objArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray15, localizable21, objArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nonSquareMatrixException5, (double) (-1.0f), "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix", objArray51);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException57 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) functionEvaluationException56);
        org.apache.commons.math.optimization.OptimizationException optimizationException58 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) invalidMatrixException57);
        mathRuntimeException2.addSuppressed((java.lang.Throwable) invalidMatrixException57);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(bigMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str33.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(concurrentModificationException35);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str50.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(concurrentModificationException52);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector(52);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException(localizable6, (java.lang.Object[]) doubleArray8);
        boolean boolean10 = blockRealMatrix3.equals((java.lang.Object) doubleArray8);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = blockRealMatrix3.scalarMultiply((double) 10.0f);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 52);
        java.lang.String str2 = functionEvaluationException1.getPattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException13 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException13);
        java.lang.String str15 = convergenceException14.toString();
        java.lang.Object[] objArray16 = new java.lang.Object[] { "", 0L, str15 };
        java.util.ConcurrentModificationException concurrentModificationException17 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray16);
        java.lang.Throwable throwable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException28 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException28);
        java.lang.String str30 = convergenceException29.toString();
        java.lang.Object[] objArray31 = new java.lang.Object[] { "", 0L, str30 };
        java.util.ConcurrentModificationException concurrentModificationException32 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray31);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException33 = new org.apache.commons.math.linear.InvalidMatrixException(localizable22, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(throwable20, localizable21, objArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException18, "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix", objArray31);
        java.lang.Object[] objArray36 = mathException18.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 10, localizable5, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.exception.Localizable localizable39 = convergenceException38.getLocalizablePattern();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray41 = convergenceException40.getArguments();
        org.apache.commons.math.exception.Localizable localizable42 = convergenceException40.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException52 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException52);
        java.lang.String str54 = convergenceException53.toString();
        java.lang.Object[] objArray55 = new java.lang.Object[] { "", 0L, str54 };
        java.util.ConcurrentModificationException concurrentModificationException56 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException45, localizable46, objArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable44, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("hi!", objArray55);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException60 = new org.apache.commons.math.linear.MatrixIndexException(localizable42, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException1, localizable39, objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException61, (double) 100L);
        java.lang.String str64 = convergenceException61.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "evaluation failed for argument = {0}" + "'", str2.equals("evaluation failed for argument = {0}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str15.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(concurrentModificationException17);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str30.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(concurrentModificationException32);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable42.equals(org.apache.commons.math.exception.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str54.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(concurrentModificationException56);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException3 = new org.apache.commons.math.linear.NonSquareMatrixException(2, 52);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean9 = array2DRowRealMatrix8.isSquare();
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException17 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException17);
        java.lang.String str19 = convergenceException18.toString();
        java.lang.Object[] objArray20 = new java.lang.Object[] { "", 0L, str19 };
        java.util.ConcurrentModificationException concurrentModificationException21 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray20);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException31 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException31);
        java.lang.String str33 = convergenceException32.toString();
        java.lang.Object[] objArray34 = new java.lang.Object[] { "", 0L, str33 };
        java.util.ConcurrentModificationException concurrentModificationException35 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException24, localizable25, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable23, objArray34);
        java.lang.Object[] objArray38 = new java.lang.Object[] { array2DRowRealMatrix8, mathException22, localizable23 };
        java.util.NoSuchElementException noSuchElementException39 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray38);
        java.util.NoSuchElementException noSuchElementException40 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("evaluation failed for argument = {0}", objArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nonSquareMatrixException3, (double) ' ', "", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException49 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException49);
        java.lang.String str51 = convergenceException50.toString();
        java.lang.Object[] objArray52 = new java.lang.Object[] { "", 0L, str51 };
        java.util.ConcurrentModificationException concurrentModificationException53 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException42, localizable43, objArray52);
        org.apache.commons.math.exception.Localizable localizable55 = null;
        org.apache.commons.math.exception.Localizable localizable56 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException62 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException62);
        java.lang.String str64 = convergenceException63.toString();
        java.lang.Object[] objArray65 = new java.lang.Object[] { "", 0L, str64 };
        java.util.ConcurrentModificationException concurrentModificationException66 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray65);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException67 = new org.apache.commons.math.linear.InvalidMatrixException(localizable56, objArray65);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException42, localizable55, objArray65);
        org.apache.commons.math.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException42);
        org.apache.commons.math.exception.Localizable localizable70 = mathRuntimeException69.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable71 = null;
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray73 = convergenceException72.getArguments();
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException74 = new org.apache.commons.math.linear.InvalidMatrixException(localizable71, objArray73);
        org.apache.commons.math.exception.Localizable localizable77 = null;
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException83 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (int) '#');
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nonSquareMatrixException83);
        java.lang.String str85 = convergenceException84.toString();
        java.lang.Object[] objArray86 = new java.lang.Object[] { "", 0L, str85 };
        java.util.ConcurrentModificationException concurrentModificationException87 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray86);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException88 = new org.apache.commons.math.linear.InvalidMatrixException(localizable77, objArray86);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException89 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException74, (double) (short) -1, "hi!", objArray86);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException41, localizable70, objArray86);
        java.util.ConcurrentModificationException concurrentModificationException91 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("convergence failed", objArray86);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str19.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(concurrentModificationException21);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str33.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(concurrentModificationException35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(noSuchElementException39);
        org.junit.Assert.assertNotNull(noSuchElementException40);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str51.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(concurrentModificationException53);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str64.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(concurrentModificationException66);
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable70.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix" + "'", str85.equals("org.apache.commons.math.ConvergenceException: a -1x35 matrix was provided instead of a square matrix"));
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(concurrentModificationException87);
        org.junit.Assert.assertNotNull(concurrentModificationException91);
    }
}

