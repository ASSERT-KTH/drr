import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 2147483647);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("1.6094379124341003746007593332");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.floor();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.6151364425761702d), 22.140692632779267d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5711645232847797d + "'", double2 == 0.5711645232847797d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        java.lang.Class<?> wildcardClass5 = dfp4.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.negate();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        boolean boolean13 = dfp12.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp9.add(dfp12);
        int int20 = dfp12.log10K();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getOne();
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp27, dfp31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp27.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp37 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp36, dfp37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.48689816668287006d), (-0.2501659148054412d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        boolean boolean18 = dfp3.unequal(dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        java.lang.String str21 = dfp3.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1." + "'", str21.equals("1."));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.2593935199454313d), (java.lang.Number) 3.0148177024962357d, false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017451520651465824d) + "'", double1 == (-0.017451520651465824d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        dfpField1.clearIEEEFlags();
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp(10L);
        boolean boolean11 = dfp10.isInfinite();
        boolean boolean12 = dfp4.greaterThan(dfp10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 100, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.divide(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getOne();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.divide(dfp25);
        boolean boolean27 = dfp16.lessThan(dfp22);
        boolean boolean28 = dfp9.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6709027040035029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = null;
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-4.821637045374455E-17d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.821637045374455E-17d) + "'", double1 == (-4.821637045374455E-17d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 106110179);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn10();
        int int8 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((-0.9999999999999999d));
        boolean boolean12 = dfp4.equals((java.lang.Object) dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getOne();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField14.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance((long) (-799263198));
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp27);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0, (java.lang.Number) 0.36787944117144233d, true);
        java.lang.Number number37 = numberIsTooSmallException36.getMin();
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.36787944117144233d + "'", number37.equals(0.36787944117144233d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.9E-324d) + "'", double1 == (-4.9E-324d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp14.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField16.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5689240493544077d) + "'", double1 == (-0.5689240493544077d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.getOne();
        boolean boolean9 = dfp6.isNaN();
        int int10 = dfp6.classify();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable3, localizable4, (java.lang.Object[]) dfpArray10);
        java.lang.Number number12 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number14 = notStrictlyPositiveException1.getMin();
        java.lang.Throwable[] throwableArray15 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0 + "'", number14.equals(0));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, (java.lang.Object[]) dfpArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.newInstance((int) (byte) 3);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, number51, (java.lang.Number) 1L, false);
        java.lang.Number number55 = numberIsTooSmallException54.getArgument();
        java.lang.Object[] objArray56 = new java.lang.Object[] { dfp47, (-0.4868981666828701d), 1.2041199826559248d, numberIsTooSmallException54 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray56);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException38, localizable39, localizable40, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray56);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0.15846744467736573d, (java.lang.Number) (-39329272), false);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply((int) 'a');
        int int10 = dfp6.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField20.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getOne();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp23.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp23.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp33 = dfp18.nextAfter(dfp23);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp23.negate();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9893582466233818d + "'", double1 == 0.9893582466233818d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, (long) 802985441);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        float float3 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((long) 356636359);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.31474304f + "'", float3 == 0.31474304f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.2041199826559248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5169340570603862d + "'", double1 == 1.5169340570603862d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.util.FastMath.max(20.385374398935145d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.385374398935145d + "'", double2 == 20.385374398935145d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-3221212818044151005L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        java.lang.String str8 = dfp3.toString();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.newInstance(1.5607966601082315d);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp10.subtract(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1." + "'", str8.equals("1."));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.signum(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double2 = org.apache.commons.math.util.FastMath.min(1.3859061287789949d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(0.0d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.36787944117144233d, 21.544346900318835d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3678794411714424d + "'", double2 == 0.3678794411714424d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7805794640849414d + "'", double1 == 0.7805794640849414d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.5294104010474555d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 356636359);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 356636352 + "'", int1 == 356636352);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-446095539));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7155267455770541d + "'", double1 == 0.7155267455770541d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        dfpField1.setIEEEFlags(1510020208);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode5);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.033221664276955463d + "'", double1 == 0.033221664276955463d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 2, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(8L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int[] intArray3 = new int[] { (byte) 3, ' ', (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray10 = new int[] { (short) 100, 4, (-32767), (-39329272), 1 };
        mersenneTwister4.setSeed(intArray10);
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) -1, (byte) 10 };
        mersenneTwister4.nextBytes(byteArray15);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, number39, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException(throwable43);
        numberIsTooSmallException42.addSuppressed((java.lang.Throwable) mathRuntimeException44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, number47, (java.lang.Number) 1L, false);
        java.lang.Number number51 = numberIsTooSmallException50.getArgument();
        java.lang.Number number52 = numberIsTooSmallException50.getArgument();
        mathRuntimeException44.addSuppressed((java.lang.Throwable) numberIsTooSmallException50);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) mathRuntimeException44);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField57.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray61 = dfpField57.getESplit();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField57.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField57.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, (java.lang.Object[]) dfpArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable66, number67, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable71 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException72 = new org.apache.commons.math.exception.MathRuntimeException(throwable71);
        numberIsTooSmallException70.addSuppressed((java.lang.Throwable) mathRuntimeException72);
        java.lang.Throwable[] throwableArray74 = mathRuntimeException72.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable55, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getLn10();
        int int79 = dfpField77.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField77.getZero();
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField77.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp[] dfpArray83 = dfpField77.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, (java.lang.Object[]) dfpArray83);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfpArray61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(throwableArray74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 16 + "'", int79 == 16);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfpArray83);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.669334276846743d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (short) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.divide(dfp15);
        boolean boolean17 = dfp16.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.log(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        dfpField7.setIEEEFlags(2147483647);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField7.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        long long1 = org.apache.commons.math.util.FastMath.round(0.011451117496857233d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-356636359), (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.56636352E8f) + "'", float2 == (-3.56636352E8f));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0019203836877835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7623994889984469d + "'", double1 == 0.7623994889984469d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        int int6 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.subtract(dfp10);
        boolean boolean12 = dfp2.greaterThan(dfp7);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.ceil(100.69314718055995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.0d + "'", double1 == 101.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.033203346412116204d) + "'", double1 == (-0.033203346412116204d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.47370165884665155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4423884736580154d + "'", double1 == 0.4423884736580154d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.divide(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn10();
        int int16 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.getPi();
        int int19 = dfp18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfp8.subtract(dfp18);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp4.multiply(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getOne();
        boolean boolean30 = dfp4.equals((java.lang.Object) dfp29);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 1);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1791095845 + "'", int2 == 1791095845);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException(throwable5);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException4.getSuppressed();
        java.lang.Object[] objArray10 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance((byte) 0, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        float float2 = org.apache.commons.math.util.FastMath.min((-2.14748365E9f), (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.14748365E9f) + "'", float2 == (-2.14748365E9f));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException(throwable5);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 1L, false);
        java.lang.Number number13 = numberIsTooSmallException12.getArgument();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        mathRuntimeException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.String str16 = numberIsTooSmallException12.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Throwable[] throwableArray18 = numberIsTooSmallException12.getSuppressed();
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)"));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(4);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(356636352);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-7910618197763358337L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException(throwable5);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 1L, false);
        java.lang.Number number13 = numberIsTooSmallException12.getArgument();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        mathRuntimeException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.String str16 = numberIsTooSmallException12.toString();
        boolean boolean17 = numberIsTooSmallException12.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException12.getGeneralPattern();
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(9223372036854775807L);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        int int10 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.sqrt();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.rint();
        java.lang.Class<?> wildcardClass13 = dfp9.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.8414709848078965d), (-1.7128389196617961d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.6849512358645993d) + "'", double2 == (-2.6849512358645993d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        int int5 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        boolean boolean15 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.power10(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getZero();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.newDfp();
        boolean boolean25 = dfp24.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.newInstance(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp21.add(dfp24);
        boolean boolean33 = dfp31.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField39.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getOne();
        org.apache.commons.math.dfp.Dfp dfp47 = org.apache.commons.math.dfp.DfpField.computeExp(dfp42, dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp42.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp42.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp52 = dfp37.nextAfter(dfp42);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp42.negate();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp18.divide(dfp53);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0149280275816275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.527681069351482d + "'", double1 == 0.527681069351482d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-0.5063656411097588d));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 3);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.2041199826559248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 717354021);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) (short) -1);
        java.lang.String str10 = dfp7.toString();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1." + "'", str10.equals("-1."));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        int int6 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getOne();
        boolean boolean12 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.floor();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10((-356636359));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.7456241416655579d), 1.2041199826559248d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2041199826559248d + "'", double2 == 1.2041199826559248d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.cosh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103343d + "'", double1 == 11013.232920103343d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (-0.2501659148054412d), false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn10();
        int int8 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((-0.9999999999999999d));
        boolean boolean12 = dfp4.equals((java.lang.Object) dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10(802985441);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.power10K((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        int int13 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.power10(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp6.divide(15);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.rint();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.newInstance("1.");
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(0.0d);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.asinh(6.389056098930683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5538026562465186d + "'", double1 == 2.5538026562465186d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 52.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-8073609976639479944L), 1.02409088E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.07361E18f) + "'", float2 == (-8.07361E18f));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double2 = org.apache.commons.math.util.FastMath.min(1.2041199826559248d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-2147483648));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException1.getSuppressed();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 1510020208);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1510020208L + "'", long2 == 1510020208L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-39329272), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.5430806348152437d, (java.lang.Number) 4999.999950000004d, false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((int) ' ');
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        boolean boolean15 = dfp6.equals((java.lang.Object) dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        dfpField1.setIEEEFlags((int) (short) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((-0.7596879128588213d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(8L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.067661995777765d + "'", double1 == 10.067661995777765d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-3.56636352E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = null;
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((byte) 100, (byte) 100);
        int int14 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        java.lang.Class<?> wildcardClass8 = dfp6.getClass();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        int int12 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getOne();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.negate();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn10();
        int int20 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.sqrt();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp16.newInstance(dfp25);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 559955467);
        dfpField1.setIEEEFlagsBits((-749997054));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass19 = roundingMode18.getClass();
        dfpField16.setRoundingMode(roundingMode18);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(10);
        boolean boolean23 = dfp14.unequal(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        int int27 = dfpField25.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getOne();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getLn5();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.getTwo();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField25.newDfp((double) 559955467);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.ceil();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.divide(16);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp14.newInstance(dfp32);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        java.lang.Class<?> wildcardClass5 = dfp4.getClass();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.power10K((int) (short) 1);
        boolean boolean16 = dfp4.lessThan(dfp15);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 4.0389678347315804E-28d, false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = mathRuntimeException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathRuntimeException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 559955467, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.multiply(0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getLn10();
        int int24 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getLn5();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField22.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass34 = roundingMode33.getClass();
        dfpField31.setRoundingMode(roundingMode33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField31.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp29.newInstance(dfp37);
        boolean boolean39 = dfp20.equals((java.lang.Object) dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.newInstance((long) 32768);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed((long) 687529068);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.643274665532871E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6830689358770354E-18d + "'", double1 == 1.6830689358770354E-18d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.floor();
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-2147483648));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23781619457280337d + "'", double1 == 0.23781619457280337d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.11235923E17f + "'", float1 == 2.11235923E17f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp(100);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        dfpField1.setIEEEFlags(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.divide(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField14.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField14.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.divide(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp4.nextAfter(dfp20);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.multiply((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(dfp10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.log(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.7368005696771d) + "'", double1 == (-36.7368005696771d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getOne();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.newDfp();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.divide(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField21.newDfp(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField36.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode38 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass39 = roundingMode38.getClass();
        dfpField36.setRoundingMode(roundingMode38);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField36.newDfp(10);
        boolean boolean43 = dfp34.unequal(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp42);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + roundingMode38 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode38.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7623994889984469d, (java.lang.Number) 100.0f, false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.7805794640849414d), (java.lang.Number) 22.140692632779267d, true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (-446095539));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-3221212818044151005L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        mersenneTwister1.setSeed((long) 32760);
        int int5 = mersenneTwister1.nextInt();
        mersenneTwister1.setSeed(100L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-39329272) + "'", int5 == (-39329272));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply((int) 'a');
        int int10 = dfp9.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getOne();
        boolean boolean42 = dfp36.equals((java.lang.Object) dfpField38);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField38.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable33, (java.lang.Object[]) dfpArray45);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 2.3978952727983707d, (java.lang.Number) 35L, false);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray45);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(28.031624894526136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.037731777517483d + "'", double1 == 3.037731777517483d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getOne();
        boolean boolean21 = dfp15.equals((java.lang.Object) dfpField17);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.nextAfter(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn10();
        int int27 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.floor();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp12.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getOne();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.divide(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getOne();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.negate();
        boolean boolean43 = dfp31.lessThan(dfp42);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, number3, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException(throwable7);
        numberIsTooSmallException6.addSuppressed((java.lang.Throwable) mathRuntimeException8);
        boolean boolean10 = numberIsTooSmallException6.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException6.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathIllegalArgumentException12.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField26.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, (java.lang.Object[]) dfpArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        boolean boolean37 = notStrictlyPositiveException36.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField41.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField41.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField41.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField41.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException36, localizable38, localizable39, (java.lang.Object[]) dfpArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, (java.lang.Object[]) dfpArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray45);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 2);
        dfpField50.setIEEEFlagsBits(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField50.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray53);
        java.lang.Object[] objArray55 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray55);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfpArray53);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.033221664276955463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int[] intArray5 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        mersenneTwister6.setSeed(4);
        int int10 = mersenneTwister6.nextInt(1510020208);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 202860983 + "'", int10 == 202860983);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        int int5 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        dfpField1.setIEEEFlags(52);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
//        boolean boolean2 = mersenneTwister1.nextBoolean();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        double double4 = mersenneTwister3.nextDouble();
//        byte[] byteArray5 = new byte[] {};
//        mersenneTwister3.nextBytes(byteArray5);
//        byte[] byteArray11 = new byte[] { (byte) 0, (byte) 2, (byte) -1, (byte) 1 };
//        mersenneTwister3.nextBytes(byteArray11);
//        mersenneTwister1.nextBytes(byteArray11);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5250060340474856d + "'", double4 == 0.5250060340474856d);
//        org.junit.Assert.assertNotNull(byteArray5);
//        org.junit.Assert.assertNotNull(byteArray11);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, (java.lang.Object[]) dfpArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.newInstance((int) (byte) 3);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, number51, (java.lang.Number) 1L, false);
        java.lang.Number number55 = numberIsTooSmallException54.getArgument();
        java.lang.Object[] objArray56 = new java.lang.Object[] { dfp47, (-0.4868981666828701d), 1.2041199826559248d, numberIsTooSmallException54 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray56);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException38, localizable39, localizable40, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray56);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 0.033221664276955463d);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNotNull(objArray56);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextDouble();
//        byte[] byteArray2 = new byte[] {};
//        mersenneTwister0.nextBytes(byteArray2);
//        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 2, (byte) -1, (byte) 1 };
//        mersenneTwister0.nextBytes(byteArray8);
//        long long10 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9451092943777584d + "'", double1 == 0.9451092943777584d);
//        org.junit.Assert.assertNotNull(byteArray2);
//        org.junit.Assert.assertNotNull(byteArray8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7095041528706754475L) + "'", long10 == (-7095041528706754475L));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.521780840845984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.580374854996466d + "'", double1 == 4.580374854996466d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0.0d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.newInstance((byte) 100, (byte) -1);
        boolean boolean23 = dfp14.unequal(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getOne();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.newDfp();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp29.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.newInstance((long) 16);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode40 = dfpField37.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField37.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField37.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp35.remainder(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.newDfp();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.getZero();
        int int54 = dfp53.log10K();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.newDfp();
        boolean boolean58 = dfp57.isInfinite();
        int int59 = dfp57.log10K();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp47.dotrap((int) (byte) 100, "1.", dfp53, dfp57);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.getOne();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.newDfp();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp64.divide(dfp67);
        java.lang.String str69 = dfp64.toString();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp64.negate();
        boolean boolean71 = dfp60.greaterThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp14.dotrap((int) (byte) 100, "1.", dfp43, dfp60);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.newInstance(22026.465794806718d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + roundingMode40 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode40.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1." + "'", str69.equals("1."));
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.ceil();
        boolean boolean24 = dfp17.equals((java.lang.Object) dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.subtract(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField33.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField33.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField39 = dfp38.getField();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp31.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp38.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpField39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getOne();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField8.newDfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp5.divide(dfp19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getOne();
        boolean boolean42 = dfp36.equals((java.lang.Object) dfpField38);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField38.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable33, (java.lang.Object[]) dfpArray45);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray47);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray45);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn10();
        int int8 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.remainder(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.newInstance(717354021);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray6 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister0.setSeed(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        int int10 = mersenneTwister9.nextInt();
        mersenneTwister9.setSeed(32768);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-749997054) + "'", int10 == (-749997054));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 559955467);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getOne();
        org.apache.commons.math.dfp.Dfp dfp14 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.floor();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField17.clearIEEEFlags();
        dfpField17.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getSqr2();
        int int23 = dfp22.getRadixDigits();
        java.lang.Class<?> wildcardClass24 = dfp22.getClass();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn2Split();
        int int28 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getOne();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp22.subtract(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.negate();
        boolean boolean33 = dfp15.lessThan(dfp30);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField1.newDfp(dfp15);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        mersenneTwister1.setSeed((long) 32760);
        mersenneTwister1.setSeed((int) ' ');
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double2 = org.apache.commons.math.util.FastMath.pow(164.4302509609931d, 4.0389678347315804E-28d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5729.5779513082325d, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5729.5779513082325d + "'", number5.equals(5729.5779513082325d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5250060340474856d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1410104218116275d + "'", double1 == 1.1410104218116275d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.0389678347315804E-28d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0389678347315804E-28d + "'", double1 == 4.0389678347315804E-28d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getOne();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField27.clearIEEEFlags();
        dfpField27.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getSqr2();
        int int33 = dfp32.getRadixDigits();
        java.lang.Class<?> wildcardClass34 = dfp32.getClass();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField36.clearIEEEFlags();
        dfpField36.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getSqr2();
        int int42 = dfp41.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.getOne();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getOne();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp47.divide(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.newDfp();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp55.getZero();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp55.power10((int) '4');
        boolean boolean59 = dfp52.greaterThan(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp43.divide(dfp58);
        boolean boolean61 = dfp32.greaterThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp62 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp32);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp14.nextAfter(dfp23);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp9.newInstance(dfp14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 8 + "'", int33 == 8);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 8 + "'", int42 == 8);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException(throwable5);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 1L, false);
        java.lang.Number number13 = numberIsTooSmallException12.getArgument();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        mathRuntimeException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.String str16 = numberIsTooSmallException12.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Object[] objArray18 = numberIsTooSmallException12.getArguments();
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)"));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertNotNull(objArray18);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
//        long long2 = mersenneTwister1.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        int int4 = mersenneTwister3.nextInt();
//        mersenneTwister3.setSeed((long) (short) 1);
//        int[] intArray12 = new int[] { '4', 10000, 8, (byte) -1, 8 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray12);
//        mersenneTwister3.setSeed(intArray12);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray12);
//        mersenneTwister1.setSeed(intArray12);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray12);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 623946069 + "'", int4 == 623946069);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.setIEEEFlagsBits((int) (short) 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.log(22.180709777452588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0992229821970683d + "'", double1 == 3.0992229821970683d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        int int15 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        boolean boolean19 = dfp18.isNaN();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp20);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) 2);
//        java.lang.Class<?> wildcardClass5 = mersenneTwister4.getClass();
//        double double6 = mersenneTwister4.nextDouble();
//        mersenneTwister4.setSeed(4);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister((long) 2);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister();
//        int[] intArray17 = new int[] { '4', 10000, 8, (byte) -1, 8 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray17);
//        mersenneTwister11.setSeed(intArray17);
//        mersenneTwister10.setSeed(intArray17);
//        mersenneTwister4.setSeed(intArray17);
//        mersenneTwister0.setSeed(intArray17);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8499269374804789420L + "'", long1 == 8499269374804789420L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.011451117496857233d + "'", double6 == 0.011451117496857233d);
//        org.junit.Assert.assertNotNull(intArray17);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        int int15 = dfp13.log10();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.ceil();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        int int20 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField26.getESplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.newDfp((byte) 1);
        int int33 = dfp32.log10();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getOne();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.divide(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getOne();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.divide(dfp49);
        boolean boolean51 = dfp40.lessThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp22.dotrap((int) (byte) 0, "1.", dfp32, dfp40);
        boolean boolean53 = dfp13.unequal(dfp40);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int2 = org.apache.commons.math.util.FastMath.max(1791095845, (-280028003));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1791095845 + "'", int2 == 1791095845);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.negate();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.power10K(0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-4.821637045374455E-17d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.415344177791547E-19d) + "'", double1 == (-8.415344177791547E-19d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.Number number7 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((long) (short) 1);
//        double double4 = mersenneTwister0.nextGaussian();
//        int int6 = mersenneTwister0.nextInt((int) (short) 1);
//        int int8 = mersenneTwister0.nextInt((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1337503072) + "'", int1 == (-1337503072));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0019203836877835d + "'", double4 == 1.0019203836877835d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags(32768);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getTwo();
        dfpField7.setIEEEFlagsBits(623946069);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        java.lang.Object[] objArray22 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.newInstance();
        int int6 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.divide(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField16.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp14.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.multiply((-280028003));
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.newDfp(dfp23);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.getOne();
        boolean boolean9 = dfp6.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance((double) 100.0f);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.divide((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.divide(2);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K((-1));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.subtract(dfp26);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        java.lang.String str6 = dfp5.toString();
        int int7 = dfp5.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.6094379124341003746007593332" + "'", str6.equals("1.6094379124341003746007593332"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1791095845);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1214.431272605375d + "'", double1 == 1214.431272605375d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        java.lang.Class<?> wildcardClass8 = dfp6.getClass();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        int int12 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getOne();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((long) 10);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        boolean boolean12 = dfp11.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp11.getField();
        boolean boolean14 = dfp7.equals((java.lang.Object) dfpField13);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        float float3 = mersenneTwister1.nextFloat();
        int int4 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.31474304f + "'", float3 == 0.31474304f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1973070045) + "'", int4 == (-1973070045));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.rint(19.692227221179177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.0d + "'", double1 == 20.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) (byte) 3);
        mersenneTwister1.setSeed(0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        boolean boolean8 = dfp2.equals((java.lang.Object) dfpField4);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((double) 0.0f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.ceil();
        boolean boolean24 = dfp17.equals((java.lang.Object) dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.subtract(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1097519667));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int2 = org.apache.commons.math.util.FastMath.max(1510020208, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1510020208 + "'", int2 == 1510020208);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) (byte) 3);
        double[] doubleArray8 = dfp5.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 3, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getOne();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.divide(dfp15);
        boolean boolean17 = dfp6.lessThan(dfp12);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp6.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.divide(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn10();
        int int16 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.getPi();
        int int19 = dfp18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfp8.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn10();
        int int26 = dfpField24.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp8.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getOne();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField41 = dfp40.getField();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.newDfp();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField41.newDfp(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField41.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.multiply(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField52.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.getOne();
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeExp(dfp55, dfp59);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp55.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp55.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp65 = dfp64.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.newDfp();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp68.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp70.rint();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp71.getOne();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp71.newInstance(1.5607966601082315d);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp65.add(dfp71);
        org.apache.commons.math.dfp.Dfp dfp76 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp49, dfp71);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpField41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        java.lang.String str10 = dfp9.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.15846744467736573d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9874702878827102d + "'", double1 == 0.9874702878827102d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.54060876f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43217763941513754d + "'", double1 == 0.43217763941513754d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 356636352);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(0.0d);
        dfpField1.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) 106110179);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 10, (-0.879752082911247d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 8);
        int int3 = mersenneTwister1.nextInt((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39 + "'", int3 == 39);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.2879033166650653d), 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2879033166650653d) + "'", double2 == (-0.2879033166650653d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 1L, false);
        java.lang.Number number13 = numberIsTooSmallException12.getArgument();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        mathRuntimeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number16 = numberIsTooSmallException12.getMin();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1L + "'", number16.equals(1L));
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 0);
//        int[] intArray7 = new int[] { '4', 10000, 8, (byte) -1, 8 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
//        int int9 = mersenneTwister8.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister((long) 10);
//        long long12 = mersenneTwister11.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        int int14 = mersenneTwister13.nextInt();
//        mersenneTwister13.setSeed((long) (short) 1);
//        int[] intArray22 = new int[] { '4', 10000, 8, (byte) -1, 8 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister(intArray22);
//        mersenneTwister13.setSeed(intArray22);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister(intArray22);
//        mersenneTwister11.setSeed(intArray22);
//        mersenneTwister8.setSeed(intArray22);
//        mersenneTwister1.setSeed(intArray22);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-749997054) + "'", int9 == (-749997054));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-7910618197763358337L) + "'", long12 == (-7910618197763358337L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1783849474 + "'", int14 == 1783849474);
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits(32768);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        boolean boolean22 = dfp21.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.newInstance(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp18.add(dfp21);
        boolean boolean30 = dfp28.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.DfpField.computeExp(dfp28, dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField36.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getOne();
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.DfpField.computeExp(dfp39, dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp39.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp49 = dfp34.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp39.negate();
        boolean boolean51 = dfp12.unequal(dfp50);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0.31474304f, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.540285678611575E-6d + "'", double2 == 9.540285678611575E-6d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        int int5 = dfp2.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getOne();
        boolean boolean42 = dfp36.equals((java.lang.Object) dfpField38);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField38.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable33, (java.lang.Object[]) dfpArray45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField48.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray52 = dfpField48.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray52);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertNotNull(dfpArray52);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2041199826559248d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.6829325265604496E7d + "'", double2 == 6.6829325265604496E7d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable5, localizable6, (java.lang.Object[]) dfpArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException(throwable18);
        numberIsTooSmallException17.addSuppressed((java.lang.Throwable) mathRuntimeException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, number22, (java.lang.Number) 1L, false);
        java.lang.Number number26 = numberIsTooSmallException25.getArgument();
        java.lang.Number number27 = numberIsTooSmallException25.getArgument();
        mathRuntimeException19.addSuppressed((java.lang.Throwable) numberIsTooSmallException25);
        java.lang.String str29 = numberIsTooSmallException25.toString();
        java.lang.Throwable[] throwableArray30 = numberIsTooSmallException25.getSuppressed();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException25);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)" + "'", str29.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)"));
        org.junit.Assert.assertNotNull(throwableArray30);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(4);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("0.");
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(39);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.log1p(89.42706130231652d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.504543573290995d + "'", double1 == 4.504543573290995d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((double) (-4));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.log(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.772588722239781d + "'", double1 == 2.772588722239781d);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((long) (short) 1);
//        double double4 = mersenneTwister0.nextGaussian();
//        int int6 = mersenneTwister0.nextInt((int) (short) 1);
//        mersenneTwister0.setSeed(1L);
//        long long9 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-890934628) + "'", int1 == (-890934628));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0019203836877835d + "'", double4 == 1.0019203836877835d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2084377003539008444L + "'", long9 == 2084377003539008444L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.newInstance(1.5607966601082315d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.sqrt();
        boolean boolean10 = dfp9.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray4 = new int[] { (byte) 3, ' ', (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        int[] intArray11 = new int[] { (short) 100, 4, (-32767), (-39329272), 1 };
        mersenneTwister5.setSeed(intArray11);
        mersenneTwister0.setSeed(intArray11);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((long) (short) 1);
//        int int4 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1858166470) + "'", int1 == (-1858166470));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 485306839 + "'", int4 == 485306839);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int2 = org.apache.commons.math.util.FastMath.max((-4), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.1622776601683795d, 0.6709027040035029d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3617381198099623d + "'", double2 == 1.3617381198099623d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        boolean boolean20 = dfp18.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.floor();
        boolean boolean22 = dfp7.unequal(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp7.multiply(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField29.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp(10L);
        boolean boolean33 = dfp32.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.getTwo();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeExp(dfp27, dfp32);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        int int5 = dfp4.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn10();
        int int11 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getPi();
        int int14 = dfp13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp3.subtract(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getOne();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.divide(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField19.newDfp(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp34 = dfp17.newInstance(dfp30);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int[] intArray5 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        double double8 = mersenneTwister7.nextDouble();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.825377706120686d + "'", double8 == 0.825377706120686d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (short) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        long long2 = org.apache.commons.math.util.FastMath.max(8499269374804789420L, (-3221212818044151005L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8499269374804789420L + "'", long2 == 8499269374804789420L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 15);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int int2 = org.apache.commons.math.util.FastMath.min(559955467, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        boolean boolean15 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp13.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7250509789627886d, 20.385374398935145d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7250509789627887d + "'", double2 == 0.7250509789627887d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-799263198));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable3, localizable4, (java.lang.Object[]) dfpArray10);
        java.lang.Number number12 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn10();
        int int17 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField15.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField15.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField15.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, (java.lang.Object[]) dfpArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, number32, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException(throwable36);
        numberIsTooSmallException35.addSuppressed((java.lang.Throwable) mathRuntimeException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, number40, (java.lang.Number) 1L, false);
        java.lang.Number number44 = numberIsTooSmallException43.getArgument();
        java.lang.Number number45 = numberIsTooSmallException43.getArgument();
        mathRuntimeException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException43);
        numberIsTooSmallException30.addSuppressed((java.lang.Throwable) mathRuntimeException37);
        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooSmallException30.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField50.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField50.getESplit();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField50.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField50.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, (java.lang.Object[]) dfpArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField64.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField64.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.getOne();
        boolean boolean68 = dfp62.equals((java.lang.Object) dfpField64);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField64.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField64.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable59, (java.lang.Object[]) dfpArray71);
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable59, objArray73);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfpArray66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfpArray71);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((byte) 0);
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp(1L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField14.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp5.remainder(dfp12);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        int int6 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.divide((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.add(dfp9);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance("1.");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K(4);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.divide(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.divide(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1337503072), Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        boolean boolean8 = dfp2.equals((java.lang.Object) dfpField4);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField15.clearIEEEFlags();
        dfpField15.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField11.newDfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getOne();
        boolean boolean31 = dfp25.equals((java.lang.Object) dfpField27);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp22.nextAfter(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        boolean boolean35 = dfp9.greaterThan(dfp34);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("-1.");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        double double3 = mersenneTwister1.nextDouble();
        long long4 = mersenneTwister1.nextLong();
        int[] intArray10 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        mersenneTwister1.setSeed(intArray10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.011451117496857233d + "'", double3 == 0.011451117496857233d);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-5798740597388316909L) + "'", long4 == (-5798740597388316909L));
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField26.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, (java.lang.Object[]) dfpArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray30);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0.9115479736173471d, (java.lang.Number) 4999.999950000004d, true);
        java.lang.Number number37 = numberIsTooSmallException36.getArgument();
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.9115479736173471d + "'", number37.equals(0.9115479736173471d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        java.lang.String str13 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        int int17 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField23.getESplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp((byte) 1);
        int int30 = dfp29.log10();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField32.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.divide(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getOne();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.divide(dfp46);
        boolean boolean48 = dfp37.lessThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp19.dotrap((int) (byte) 0, "1.", dfp29, dfp37);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp5.divide(dfp37);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp5.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0." + "'", str13.equals("0."));
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        double double3 = mersenneTwister1.nextDouble();
        long long4 = mersenneTwister1.nextLong();
        int[] intArray10 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        mersenneTwister1.setSeed(intArray10);
        float float14 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.011451117496857233d + "'", double3 == 0.011451117496857233d);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-5798740597388316909L) + "'", long4 == (-5798740597388316909L));
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.8253777f + "'", float14 == 0.8253777f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlags(16);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.abs(32760.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.0d + "'", double1 == 32760.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        java.lang.Class<?> wildcardClass8 = dfp6.getClass();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        int int12 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getOne();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        boolean boolean22 = dfp21.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.newInstance(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp18.add(dfp21);
        int int29 = dfp21.log10K();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp21.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getLn10();
        int int34 = dfpField32.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp30, dfp37);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 16 + "'", int34 == 16);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 559955467);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.rint();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getOne();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.newInstance(1.5607966601082315d);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getOne();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.divide(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getOne();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.newDfp();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp37.divide(dfp40);
        boolean boolean42 = dfp31.lessThan(dfp37);
        boolean boolean43 = dfp14.lessThan(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getOne();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.newDfp();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp52.divide(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getLn10();
        int int60 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.getZero();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField58.getPi();
        int int63 = dfp62.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp66 = dfp52.subtract(dfp62);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp48.multiply(dfp52);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp14.divide(dfp67);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 16 + "'", int60 == 16);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 8 + "'", int63 == 8);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
    }
}

