import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7970546072131424d) + "'", double1 == (-0.7970546072131424d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.42706130231652d + "'", double1 == 89.42706130231652d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4868981666828701d) + "'", double1 == (-0.4868981666828701d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.cosh(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10000, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.4868981666828701d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.48689816668287006d) + "'", double1 == (-0.48689816668287006d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getIEEEFlags();
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        java.lang.Class<?> wildcardClass1 = roundingMode0.getClass();
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.0f, (-0.48689816668287006d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) -1, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.4868981666828701d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2041199826559248d + "'", double1 == 1.2041199826559248d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015050303523504572d + "'", double1 == 0.015050303523504572d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 2, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5607966601082315d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 85.79525523348502d + "'", double2 == 85.79525523348502d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100, (java.lang.Number) 1.0d, false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.8414709848078965d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100L, Double.NaN, (-1.0d) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable2, localizable3, objArray7);
        java.lang.Throwable[] throwableArray9 = mathRuntimeException8.getSuppressed();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.sin(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2879033166650653d) + "'", double1 == (-0.2879033166650653d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 8, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.signum(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.210340371976184d + "'", double1 == 9.210340371976184d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int1 = org.apache.commons.math.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.8524798042768637d + "'", double0 == 0.8524798042768637d);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        int int5 = dfp2.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getLn10();
        int int4 = dfpField2.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.getPi();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 32768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.0d + "'", double1 == 10000.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int1 = org.apache.commons.math.util.FastMath.round(100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        int int3 = dfp2.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8623188722876839d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8623188722876839d + "'", double2 == 0.8623188722876839d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.544346900318835d + "'", double1 == 21.544346900318835d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189894035458565E-12d + "'", double1 == 1.8189894035458565E-12d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.abs(85.79525523348502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 85.79525523348502d + "'", double1 == 85.79525523348502d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        long long2 = org.apache.commons.math.util.FastMath.min((-6933228541055223099L), (long) 32768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6933228541055223099L) + "'", long2 == (-6933228541055223099L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
        mersenneTwister1.setSeed((long) (short) 10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.821637045374455E-17d) + "'", double1 == (-4.821637045374455E-17d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        int int6 = dfp5.classify();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10000);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfp3.subtract(dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double2 = org.apache.commons.math.util.FastMath.max(5729.5779513082325d, 10000.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10000.0d + "'", double2 == 10000.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        boolean boolean8 = dfp2.equals((java.lang.Object) dfpField4);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp dfp11 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp12 = dfp10.remainder(dfp11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.1622776601683795d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getZero();
        int int10 = dfp9.log10K();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        boolean boolean14 = dfp13.isInfinite();
        int int15 = dfp13.log10K();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.dotrap((int) (byte) 100, "1.", dfp9, dfp13);
        org.apache.commons.math.dfp.Dfp dfp17 = null;
        try {
            boolean boolean18 = dfp9.greaterThan(dfp17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp9, dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp22 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp13, dfp18, dfp22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("1.");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 10, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        boolean boolean7 = dfp6.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.newInstance(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.ceil();
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp10, dfp16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        int int4 = dfp2.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = mathRuntimeException1.getSpecificPattern();
        java.lang.Object[] objArray3 = mathRuntimeException1.getArguments();
        java.lang.Throwable[] throwableArray4 = mathRuntimeException1.getSuppressed();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        int int7 = dfp6.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int2 = org.apache.commons.math.util.FastMath.min(2, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int1 = org.apache.commons.math.util.FastMath.abs((-356636359));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 356636359 + "'", int1 == 356636359);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2261911708835171d) + "'", double1 == (-1.2261911708835171d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.8189894035458565E-12d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(9.210340371976184d, 0.015050303523504572d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.210340371976182d + "'", double2 == 9.210340371976182d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.ceil();
        boolean boolean24 = dfp17.equals((java.lang.Object) dfp23);
        int int25 = dfp23.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-356636359));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.56636359E8d + "'", double1 == 3.56636359E8d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable3, localizable4, (java.lang.Object[]) dfpArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathRuntimeException11.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000101d + "'", double1 == 100.00000000000101d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.clearIEEEFlags();
        dfpField11.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        int int17 = dfp16.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp4.subtract(dfp16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField3.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray4);
        java.lang.Throwable[] throwableArray6 = mathIllegalArgumentException5.getSuppressed();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp4.multiply(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.asinh(85.79525523348502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.145144847066013d + "'", double1 == 5.145144847066013d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32768);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32768.0f + "'", float1 == 32768.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        int int8 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 32768, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.4868981666828701d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        java.lang.String str3 = dfp2.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0." + "'", str3.equals("0."));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1 == 3.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10.0f, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 356636359);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8524798042768637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3859061287789949d + "'", double1 == 1.3859061287789949d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        double double10 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.atanh(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        int int15 = dfp13.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int2 = org.apache.commons.math.util.FastMath.min(100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        double double4 = mersenneTwister1.nextDouble();
        int[] intArray10 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        mersenneTwister1.setSeed(intArray10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.54060876f + "'", float3 == 0.54060876f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.43899594558373667d + "'", double4 == 0.43899594558373667d);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.sinh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 52, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        int int10 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.sqrt();
        boolean boolean12 = dfp9.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-6933228541055223099L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.abs(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        try {
            int int3 = mersenneTwister1.nextInt((-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2,147,483,648 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException(throwable5);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        java.lang.Number number8 = numberIsTooSmallException4.getMin();
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean10 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean11 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getZero();
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        boolean boolean21 = dfp20.isInfinite();
        int int22 = dfp20.log10K();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp10.dotrap((int) (byte) 100, "1.", dfp16, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getOne();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.divide(dfp30);
        java.lang.String str32 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp35 = dfp6.divide(dfp34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1." + "'", str32.equals("1."));
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180709777452588d + "'", double1 == 22.180709777452588d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.15846744467736573d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15846744467736573d + "'", double2 == 0.15846744467736573d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.031624894526136d + "'", double1 == 28.031624894526136d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0000000000000002d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.210340371976184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4999.999950000004d + "'", double1 == 4999.999950000004d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int2 = org.apache.commons.math.util.FastMath.min((-2147483648), 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7456241416655579d) + "'", double1 == (-0.7456241416655579d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.2261911708835171d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7065920069739766d) + "'", double1 == (-0.7065920069739766d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.2041199826559248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getOne();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.divide(dfp15);
        boolean boolean17 = dfp6.lessThan(dfp12);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.divide(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, (float) (byte) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass8 = roundingMode7.getClass();
        dfpField5.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField5.setRoundingMode(roundingMode11);
        dfpField1.setRoundingMode(roundingMode11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.643274665532871E-17d + "'", double1 == 9.643274665532871E-17d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 7.105427357601002E-15d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.4868981666828701d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.9106181977633577E18d) + "'", double1 == (-7.9106181977633577E18d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField3.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathIllegalArgumentException5.getSpecificPattern();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        boolean boolean8 = dfp7.isNaN();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        boolean boolean8 = dfp7.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0019203836877835d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 9.210340371976182d, (java.lang.Number) (-1.5574077246549023d), true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(35L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.140692632779267d + "'", double1 == 22.140692632779267d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.43899594558373667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43899594558373667d + "'", double1 == 0.43899594558373667d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0149280275816275d + "'", double1 == 1.0149280275816275d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
        int int3 = mersenneTwister1.nextInt(1024090862);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 717354021 + "'", int3 == 717354021);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 356636359);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.385374398935145d + "'", double1 == 20.385374398935145d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.69314718055995d + "'", double1 == 100.69314718055995d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.newInstance((long) 16);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField11.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField11.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.remainder(dfp16);
        boolean boolean18 = dfp9.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32767) + "'", int2 == (-32767));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.util.FastMath.min(1.8189894035458565E-12d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getZero();
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        boolean boolean21 = dfp20.isInfinite();
        int int22 = dfp20.log10K();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp10.dotrap((int) (byte) 100, "1.", dfp16, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getOne();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.divide(dfp30);
        java.lang.String str32 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        try {
            boolean boolean35 = dfp33.lessThan(dfp34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1." + "'", str32.equals("1."));
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.newInstance(dfp15);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.011451117496857233d, (java.lang.Number) 5.145144847066013d, false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 8);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.0f + "'", float1 == 8.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        java.lang.Class<?> wildcardClass8 = dfp6.getClass();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.power10K(15);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6709027040035029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.670902704003503d + "'", double1 == 0.670902704003503d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0149280275816275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.198368146357792d + "'", double1 == 1.198368146357792d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.2879033166650653d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.0d), (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int2 = org.apache.commons.math.util.FastMath.min((-2147483648), (-799263198));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp12);
        boolean boolean14 = dfp3.unequal(dfp13);
        int int15 = dfp3.intValue();
        double[] doubleArray16 = dfp3.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2);
        int int3 = mersenneTwister1.nextInt((int) '#');
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.025926113f + "'", float4 == 0.025926113f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.015050303523504572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0149280275816275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0074363640357775d + "'", double1 == 1.0074363640357775d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.56636359E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.692227221179177d + "'", double1 == 19.692227221179177d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10, (java.lang.Number) 97.0d, false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        java.lang.String str13 = dfp5.toString();
        int int14 = dfp5.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0." + "'", str13.equals("0."));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, number5, (java.lang.Number) 1L, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField12.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException8, localizable9, localizable10, (java.lang.Object[]) dfpArray14);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(dfpArray14);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.log10(100.00000000000101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000044d + "'", double1 == 2.0000000000000044d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8524798042768637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7529147225190617d + "'", double1 == 0.7529147225190617d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-7.9106181977633577E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10L, (java.lang.Number) (-0.9999999999999999d), true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10L + "'", number4.equals(10L));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn10();
        int int8 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.remainder(dfp13);
        int int15 = dfp13.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.2879033166650653d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2501659148054412d) + "'", double1 == (-0.2501659148054412d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 717354021, (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7005486364553047d + "'", double2 == 0.7005486364553047d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 717354021);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.newInstance((long) 16);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField17.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp15.remainder(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (byte) -1, "", dfp5, dfp15);
        int int25 = dfp2.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.sin(21.544346900318835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4320833916800826d + "'", double1 == 0.4320833916800826d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException(throwable18);
        numberIsTooSmallException17.addSuppressed((java.lang.Throwable) mathRuntimeException19);
        java.lang.Throwable[] throwableArray21 = mathRuntimeException19.getSuppressed();
        java.lang.Class<?> wildcardClass22 = throwableArray21.getClass();
        boolean boolean23 = dfp12.equals((java.lang.Object) throwableArray21);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn10();
        int int8 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((-0.9999999999999999d));
        boolean boolean12 = dfp4.equals((java.lang.Object) dfp11);
        double[] doubleArray13 = dfp4.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertNotNull(dfpArray17);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((long) (short) 1);
//        int[] intArray9 = new int[] { '4', 10000, 8, (byte) -1, 8 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
//        mersenneTwister0.setSeed(intArray9);
//        long long12 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-446095539) + "'", int1 == (-446095539));
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3221212818044151005L) + "'", long12 == (-3221212818044151005L));
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.0000000000000044d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.389056098930683d + "'", double1 == 6.389056098930683d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long1 = org.apache.commons.math.util.FastMath.round((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        int int7 = dfp6.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7005486364553047d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.611094081876894d + "'", double1 == 0.611094081876894d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1622776601683795d, (java.lang.Number) 9.643274665532871E-17d, true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10(100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 10.0d, (java.lang.Number) (-0.9999999999999999d), false);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-356636359));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.879752082911247d) + "'", double1 == (-0.879752082911247d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int[] intArray5 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        mersenneTwister6.setSeed(4);
        float float9 = mersenneTwister6.nextFloat();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.9670298f + "'", float9 == 0.9670298f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-39329272));
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.49139542717454177d + "'", double2 == 0.49139542717454177d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        try {
            int int2 = mersenneTwister0.nextInt((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        java.lang.Class<?> wildcardClass15 = dfp14.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(0.0d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2593935199454313d) + "'", double1 == (-0.2593935199454313d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.divide((int) (short) 100);
        java.lang.Class<?> wildcardClass5 = dfp4.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        boolean boolean8 = dfp6.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.7970546072131424d), 1.0074363640357775d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.669334276846743d) + "'", double2 == (-0.669334276846743d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int2 = org.apache.commons.math.util.FastMath.max(2, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(22.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.705389742920268d + "'", double1 == 4.705389742920268d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField3.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((int) (byte) 3);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, number18, (java.lang.Number) 1L, false);
        java.lang.Number number22 = numberIsTooSmallException21.getArgument();
        java.lang.Object[] objArray23 = new java.lang.Object[] { dfp14, (-0.4868981666828701d), 1.2041199826559248d, numberIsTooSmallException21 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray23);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable6, localizable7, objArray23);
        java.lang.Object[] objArray26 = mathRuntimeException25.getArguments();
        java.lang.Throwable[] throwableArray27 = mathRuntimeException25.getSuppressed();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.00000000000101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418188477E43d + "'", double1 == 2.6881171418188477E43d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.signum(22.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.9670298f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int[] intArray5 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        double double8 = mersenneTwister7.nextGaussian();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.47370165884665155d + "'", double8 == 0.47370165884665155d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn10();
        int int8 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.remainder(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getZero();
        int int25 = dfp24.log10K();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        boolean boolean29 = dfp28.isInfinite();
        int int30 = dfp28.log10K();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp18.dotrap((int) (byte) 100, "1.", dfp24, dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getLn10();
        int int35 = dfpField33.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getPi();
        int int38 = dfp37.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp18.divide(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField43.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField43.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.getZero();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField49.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getOne();
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeExp(dfp52, dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp52.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp52.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp62 = dfp61.sqrt();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp18.dotrap((int) (short) 0, "", dfp47, dfp61);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp13.add(dfp61);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1024090862);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.02409088E9f + "'", float1 == 1.02409088E9f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.power10((int) 'a');
        double double14 = dfp13.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E97d + "'", double14 == 1.0E97d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 3.0f, 4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 164.4302509609931d + "'", double2 == 164.4302509609931d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.025926113f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.6525045892921635d) + "'", double1 == (-3.6525045892921635d));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.power10(10000);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.power10K((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfp3.divide(dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7596879128588213d) + "'", double1 == (-0.7596879128588213d));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8862269254527579d + "'", double1 == 0.8862269254527579d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.4868981666828701d), (java.lang.Number) 100L, false);
        java.lang.Throwable throwable5 = null;
        try {
            numberIsTooSmallException4.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 52);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray6 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister0.setSeed(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister9.setSeed(0);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getOne();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.power10((int) '4');
        boolean boolean24 = dfp17.greaterThan(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.divide(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp27 = dfp25.subtract(dfp26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        java.lang.Class<?> wildcardClass10 = dfp9.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        float float3 = mersenneTwister1.nextFloat();
        double double4 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.31474304f + "'", float3 == 0.31474304f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.7128389196617964d) + "'", double4 == (-1.7128389196617964d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 3.637978807091713E-12d, (java.lang.Number) 4, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Object[] objArray7 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0.31474304f, 100.69314718055995d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.803002651582414E-51d + "'", double2 == 2.803002651582414E-51d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(Double.NaN, 52.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double2 = org.apache.commons.math.util.FastMath.max(10000.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10000.0d + "'", double2 == 10000.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0.025926113f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5862625882558896d) + "'", double1 == (-1.5862625882558896d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed((long) 10000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getESplit();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp((byte) 1);
        int int16 = dfp15.log10();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getOne();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.divide(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getOne();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.newDfp();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp29.divide(dfp32);
        boolean boolean34 = dfp23.lessThan(dfp29);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp5.dotrap((int) (byte) 0, "1.", dfp15, dfp23);
        int int36 = dfp15.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 8 + "'", int36 == 8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.7065920069739766d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6151364425761702d) + "'", double1 == (-0.6151364425761702d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.multiply((int) '#');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) (byte) 3);
        try {
            int int6 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 100, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        boolean boolean20 = dfp7.lessThan(dfp18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        boolean boolean8 = dfp2.equals((java.lang.Object) dfpField4);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField4.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-749997054));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3182099524058375d) + "'", double1 == (-0.3182099524058375d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        mersenneTwister1.setSeed(4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        boolean boolean20 = dfp18.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.floor();
        boolean boolean22 = dfp7.unequal(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getOne();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.divide(dfp31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.power10K((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp37.newInstance((byte) 0);
        boolean boolean41 = dfp28.unequal(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getZero();
        int int52 = dfp51.log10K();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.newDfp();
        boolean boolean56 = dfp55.isInfinite();
        int int57 = dfp55.log10K();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp45.dotrap((int) (byte) 100, "1.", dfp51, dfp55);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.getLn10();
        int int62 = dfpField60.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.getZero();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField60.getPi();
        int int65 = dfp64.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp45.divide(dfp64);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField70.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray72 = dfpField70.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray73 = dfpField70.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField70.getZero();
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField76.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField76.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField81.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField81.getOne();
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp79, dfp83);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp79.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp88 = dfp79.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp89 = dfp88.sqrt();
        org.apache.commons.math.dfp.Dfp dfp90 = dfp45.dotrap((int) (short) 0, "", dfp74, dfp88);
        org.apache.commons.math.dfp.Dfp dfp91 = dfp90.getTwo();
        org.apache.commons.math.dfp.Dfp dfp92 = dfp18.dotrap(717354021, "0.", dfp28, dfp90);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 16 + "'", int62 == 16);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 8 + "'", int65 == 8);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfpArray72);
        org.junit.Assert.assertNotNull(dfpArray73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.negate();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.divide(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((int) ' ');
        boolean boolean14 = dfp3.unequal(dfp10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 100, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance("1.6094379124341003746007593332");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.divide(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getOne();
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.DfpField.computeExp(dfp21, dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp21.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp7.add(dfp28);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 1L, false);
        java.lang.Number number13 = numberIsTooSmallException12.getArgument();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        mathRuntimeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Throwable[] throwableArray16 = numberIsTooSmallException12.getSuppressed();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.4868981666828701d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5294104010474555d) + "'", double1 == (-0.5294104010474555d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.0d + "'", double1 == 32760.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.log(20.385374398935145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0148177024962357d + "'", double1 == 3.0148177024962357d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8L, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2147483647);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        long long3 = mersenneTwister1.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        java.lang.Class<?> wildcardClass6 = mersenneTwister5.getClass();
        double double7 = mersenneTwister5.nextDouble();
        mersenneTwister5.setSeed(4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray18 = new int[] { '4', 10000, 8, (byte) -1, 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister(intArray18);
        mersenneTwister12.setSeed(intArray18);
        mersenneTwister11.setSeed(intArray18);
        mersenneTwister5.setSeed(intArray18);
        mersenneTwister1.setSeed(intArray18);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 211235929750981552L + "'", long3 == 211235929750981552L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.011451117496857233d + "'", double7 == 0.011451117496857233d);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) 1L, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        mathRuntimeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance((int) (byte) 3);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, number43, (java.lang.Number) 1L, false);
        java.lang.Number number47 = numberIsTooSmallException46.getArgument();
        java.lang.Object[] objArray48 = new java.lang.Object[] { dfp39, (-0.4868981666828701d), 1.2041199826559248d, numberIsTooSmallException46 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray48);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable5, localizable6, (java.lang.Object[]) dfpArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11);
        java.lang.String str13 = mathRuntimeException12.toString();
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 717354021);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 100, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField7.clearIEEEFlags();
        dfpField7.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getSqr2();
        int int13 = dfp12.getRadixDigits();
        java.lang.Class<?> wildcardClass14 = dfp12.getClass();
        boolean boolean15 = dfp5.equals((java.lang.Object) wildcardClass14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        boolean boolean20 = dfp18.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.floor();
        boolean boolean22 = dfp7.unequal(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp7.multiply(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp7.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9226350743220142d + "'", double1 == 0.9226350743220142d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException(throwable5);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        java.lang.Number number8 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 8, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, number15, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable19 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException(throwable19);
        numberIsTooSmallException18.addSuppressed((java.lang.Throwable) mathRuntimeException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, number23, (java.lang.Number) 1L, false);
        java.lang.Number number27 = numberIsTooSmallException26.getArgument();
        java.lang.Number number28 = numberIsTooSmallException26.getArgument();
        mathRuntimeException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException26);
        numberIsTooSmallException13.addSuppressed((java.lang.Throwable) mathRuntimeException20);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField35.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField35.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, (java.lang.Object[]) dfpArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, (java.lang.Object[]) dfpArray39);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
        boolean boolean46 = notStrictlyPositiveException45.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField50.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray52 = dfpField50.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField50.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField50.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException45, localizable47, localizable48, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (byte) 2);
        dfpField59.setIEEEFlagsBits(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray62 = dfpField59.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, (java.lang.Object[]) dfpArray62);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray67 = dfpField66.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException68 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable31, localizable64, (java.lang.Object[]) dfpArray67);
        java.lang.Class<?> wildcardClass69 = mathRuntimeException68.getClass();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dfpArray52);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfpArray62);
        org.junit.Assert.assertNotNull(dfpArray67);
        org.junit.Assert.assertNotNull(wildcardClass69);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        int int20 = dfp19.log10K();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        boolean boolean24 = dfp23.isInfinite();
        int int25 = dfp23.log10K();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.dotrap((int) (byte) 100, "1.", dfp19, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.power10(52);
        org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp28);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10000L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.011451117496857233d, 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.49139542717454177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 3, (float) (-2147483648));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.14748365E9f) + "'", float2 == (-2.14748365E9f));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1.02409088E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10000, 10000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.7596879128588213d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7250509789627886d + "'", double1 == 0.7250509789627886d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getOne();
        boolean boolean21 = dfp15.equals((java.lang.Object) dfpField17);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.nextAfter(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getOne();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField31 = dfp30.getField();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.newDfp();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField31.newDfp(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp22.divide(dfp38);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpField31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '4', 0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getZero();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField17.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.newInstance(dfp23);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getOne();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.power10((int) '4');
        boolean boolean24 = dfp17.greaterThan(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.divide(dfp23);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.newInstance(52.0d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 100, (byte) 0);
        boolean boolean15 = dfp7.greaterThan(dfp10);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.145144847066013d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance("1.");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K(4);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.divide(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("1.");
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.newInstance(dfp18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10000L, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.divide(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.clearIEEEFlags();
        dfpField18.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getSqr2();
        int int24 = dfp23.getRadixDigits();
        java.lang.Class<?> wildcardClass25 = dfp23.getClass();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        int int29 = dfpField27.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getOne();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp23.subtract(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.negate();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.newInstance();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp15.subtract(dfp34);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        double double2 = mersenneTwister1.nextGaussian();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7805794640849414d) + "'", double2 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.6027633f + "'", float3 == 0.6027633f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '4', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 8, false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0149280275816275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        double double3 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((long) (-1));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.011451117496857233d + "'", double3 == 0.011451117496857233d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4999.999950000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.517393161420904d + "'", double1 == 8.517393161420904d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.49139542717454177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47350244750040127d + "'", double1 == 0.47350244750040127d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.multiply(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((int) '#');
        int int14 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.ceil(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(8.517393161420904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 488.01068060300724d + "'", double1 == 488.01068060300724d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass19 = roundingMode18.getClass();
        dfpField16.setRoundingMode(roundingMode18);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(10);
        boolean boolean23 = dfp14.unequal(dfp22);
        int int24 = dfp14.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 559955467);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getZero();
        int int19 = dfp18.log10K();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.newDfp();
        boolean boolean23 = dfp22.isInfinite();
        int int24 = dfp22.log10K();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp12.dotrap((int) (byte) 100, "1.", dfp18, dfp22);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getLn10();
        int int29 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getPi();
        int int32 = dfp31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp12.divide(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField37.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.getZero();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField43.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getOne();
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp46, dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp46.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp46.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp56 = dfp55.sqrt();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp12.dotrap((int) (short) 0, "", dfp41, dfp55);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp8.add(dfp12);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.6151364425761702d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6625590129114538d) + "'", double1 == (-0.6625590129114538d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        boolean boolean18 = dfp3.unequal(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp3.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        boolean boolean8 = dfp2.equals((java.lang.Object) dfpField4);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField4.getLn2Split();
        int int12 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField4.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp2.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((long) (short) 1);
//        double double4 = mersenneTwister0.nextGaussian();
//        int int6 = mersenneTwister0.nextInt((int) (short) 1);
//        mersenneTwister0.setSeed((long) '4');
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1510020208 + "'", int1 == 1510020208);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0019203836877835d + "'", double4 == 1.0019203836877835d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.5294104010474555d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5050245432207991d) + "'", double1 == (-0.5050245432207991d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.clearIEEEFlags();
        dfpField5.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp("0.");
        int int16 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 8.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.9579870417283d + "'", double1 == 2979.9579870417283d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.util.FastMath.atan(20.385374398935145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.521780840845984d + "'", double1 == 1.521780840845984d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.tanh(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) (byte) 3);
        int int6 = mersenneTwister1.nextInt(559955467);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 106110179 + "'", int6 == 106110179);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-39329272));
        mersenneTwister1.setSeed(100);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.7128389196617964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7128389196617961d) + "'", double1 == (-1.7128389196617961d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        dfpField1.setIEEEFlags(1024090862);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5729.5779513082325d, 1024.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5729.577951308232d + "'", double2 == 5729.577951308232d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.getRadixDigits();
        java.lang.Class<?> wildcardClass8 = dfp6.getClass();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.divide(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = null;
        org.apache.commons.math.dfp.Dfp dfp20 = dfp6.dotrap((-39329272), "1.", dfp17, dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp17.getZero();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5406088298409573d + "'", double3 == 0.5406088298409573d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2979.9579870417283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.9579870417288d + "'", double1 == 2979.9579870417288d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(Double.POSITIVE_INFINITY);
        java.lang.String str8 = dfp5.toString();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2.7182818284590452353602874714" + "'", str8.equals("2.7182818284590452353602874714"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int2 = org.apache.commons.math.util.FastMath.min(717354021, (int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.7128389196617961d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0389678347315804E-28d + "'", double1 == 4.0389678347315804E-28d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.7128389196617961d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.6625590129114538d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.788420672620102d + "'", double1 == 0.788420672620102d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-8073609976639479944L), 0.6027633f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.6027633f + "'", float2 == 0.6027633f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5729.5779513082325d, number1, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 2);
        dfpField1.setIEEEFlagsBits(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.add(dfp5);
        boolean boolean14 = dfp12.equals((java.lang.Object) 3.141592653589793d);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.newInstance(0.0d);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0.54060876f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.974600527495173d + "'", double1 == 30.974600527495173d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.divide(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField14.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField14.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.divide(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp4.nextAfter(dfp20);
        int int23 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode7);
        java.lang.Class<?> wildcardClass9 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        boolean boolean20 = dfp18.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.floor();
        boolean boolean22 = dfp7.unequal(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.DfpField.computeExp(dfp34, dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp34.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp34.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.getTwo();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp29.newInstance(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField47.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getOne();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField53 = dfp52.getField();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.newDfp();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp56.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp56.power10((int) '4');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField53.newDfp(dfp59);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp59.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp18.dotrap((int) (byte) 2, "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)", dfp29, dfp62);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpField53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        boolean boolean8 = dfp2.equals((java.lang.Object) dfpField4);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField4.getLn2Split();
        int int12 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField4.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField4.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1L, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException(throwable5);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 1L, false);
        java.lang.Number number13 = numberIsTooSmallException12.getArgument();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        mathRuntimeException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathRuntimeException6.getGeneralPattern();
        java.lang.String str17 = mathRuntimeException6.toString();
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str17.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.3182099524058375d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getOne();
        boolean boolean8 = dfp2.equals((java.lang.Object) dfpField4);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.newDfp(21.544346900318835d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }
}

